//! WinFsp adapter: presents one unlocked vault (through `gp_app::vfs::Vfs`) as a drive.
//! Every callback goes through the Vfs, which refuses everything once the folder is locked; nothing here keeps keys.
use crate::controller::Mounter;
use crate::map::*;
use gp_app::vfs::{OpenOpts, VResult, Vfs, VfsError};
use std::collections::HashMap;
use std::ffi::c_void;
use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use vault_core::storage::DiskStorage;
use vault_core::Entry;
use winfsp::filesystem::{DirBuffer, DirInfo, DirMarker, FileInfo, FileSecurity, FileSystemContext, OpenFileInfo, VolumeInfo, WideNameInfo};
use winfsp::host::{FileSystemHost, VolumeParams};
use winfsp::{FspError, FspInit, Result, U16CStr};
use winfsp_sys::{FILE_ACCESS_RIGHTS, FILE_FLAGS_AND_ATTRIBUTES};

type V = Vfs<DiskStorage>;

fn err(e: VfsError) -> FspError {
    FspError::NTSTATUS(status_of(&e))
}

fn vp(name: &U16CStr) -> String {
    to_vault_path(&name.to_string_lossy())
}

fn fill(info: &mut FileInfo, path: &str, e: &Entry) {
    info.file_attributes = if e.is_dir { FILE_ATTRIBUTE_DIRECTORY } else { FILE_ATTRIBUTE_ARCHIVE };
    info.reparse_tag = 0;
    info.file_size = if e.is_dir { 0 } else { e.size };
    info.allocation_size = if e.is_dir { 0 } else { allocation_size(e.size) };
    let t = unix_to_filetime(e.mtime);
    info.creation_time = t;
    info.last_access_time = t;
    info.last_write_time = t;
    info.change_time = t;
    info.index_number = index_number(path);
    info.hard_links = 0;
    info.ea_size = 0;
}

fn root_entry() -> Entry {
    Entry { name: String::new(), is_dir: true, size: 0, mtime: 0 }
}

pub struct Ctx {
    h: u64,
    path: String,
    is_dir: bool,
    write: bool,
    dir_buffer: DirBuffer,
    gone: AtomicBool,
}

pub struct GpFs {
    vfs: Arc<V>,
    label: String,
}

impl GpFs {
    fn entry(&self, path: &str) -> VResult<Entry> {
        if path.is_empty() {
            return Ok(root_entry());
        }
        self.vfs.stat(path)
    }

    fn info_of(&self, c: &Ctx, out: &mut FileInfo) -> Result<()> {
        let e = if c.is_dir { self.entry(&c.path) } else { self.vfs.stat_handle(c.h) }.map_err(err)?;
        fill(out, &c.path, &e);
        Ok(())
    }

    fn make(&self, path: &str, o: OpenOpts, dir: bool, write: bool, info: &mut FileInfo) -> Result<Ctx> {
        let h = if dir {
            self.vfs.mkdir(path).map_err(err)?;
            self.vfs.open(path, OpenOpts::default()).map_err(err)?
        } else {
            self.vfs.open(path, o).map_err(err)?
        };
        let c = Ctx { h, path: path.to_string(), is_dir: dir, write, dir_buffer: DirBuffer::new(), gone: AtomicBool::new(false) };
        if let Err(e) = self.info_of(&c, info) {
            let _ = self.vfs.close(h);
            return Err(e);
        }
        Ok(c)
    }
}

impl FileSystemContext for GpFs {
    type FileContext = Ctx;

    fn get_security_by_name(&self, name: &U16CStr, _sd: Option<&mut [c_void]>, _r: impl FnOnce(&U16CStr) -> Option<FileSecurity>) -> Result<FileSecurity> {
        let p = vp(name);
        let e = self.entry(&p).map_err(err)?;
        Ok(FileSecurity { reparse: false, sz_security_descriptor: 0, attributes: if e.is_dir { FILE_ATTRIBUTE_DIRECTORY } else { FILE_ATTRIBUTE_ARCHIVE } })
    }

    fn open(&self, name: &U16CStr, create_options: u32, granted_access: FILE_ACCESS_RIGHTS, info: &mut OpenFileInfo) -> Result<Ctx> {
        let p = vp(name);
        let e = self.entry(&p).map_err(err)?;
        if e.is_dir && create_options & FILE_NON_DIRECTORY_FILE != 0 {
            return Err(FspError::NTSTATUS(STATUS_FILE_IS_A_DIRECTORY));
        }
        if !e.is_dir && create_options & FILE_DIRECTORY_FILE != 0 {
            return Err(FspError::NTSTATUS(STATUS_NOT_A_DIRECTORY));
        }
        let write = wants_write(granted_access as u32);
        let o = OpenOpts { write, delete_on_close: create_options & FILE_DELETE_ON_CLOSE != 0, ..Default::default() };
        let h = if p.is_empty() { self.vfs.open("", OpenOpts::default()) } else { self.vfs.open(&p, o) }.map_err(err)?;
        let c = Ctx { h, path: p, is_dir: e.is_dir, write, dir_buffer: DirBuffer::new(), gone: AtomicBool::new(false) };
        if let Err(e) = self.info_of(&c, info.as_mut()) {
            let _ = self.vfs.close(h);
            return Err(e);
        }
        Ok(c)
    }

    fn close(&self, c: Ctx) {
        let _ = self.vfs.close(c.h);
    }

    fn create(&self, name: &U16CStr, create_options: u32, _granted: FILE_ACCESS_RIGHTS, _attrs: FILE_FLAGS_AND_ATTRIBUTES, _sd: Option<&[c_void]>, _alloc: u64, _extra: Option<&[u8]>, _reparse: bool, info: &mut OpenFileInfo) -> Result<Ctx> {
        let p = vp(name);
        if p.is_empty() || self.entry(&p).is_ok() {
            return Err(FspError::NTSTATUS(STATUS_OBJECT_NAME_COLLISION));
        }
        let dir = create_options & FILE_DIRECTORY_FILE != 0;
        let o = OpenOpts { create: true, create_new: true, write: true, delete_on_close: create_options & FILE_DELETE_ON_CLOSE != 0, ..Default::default() };
        self.make(&p, o, dir, true, info.as_mut())
    }

    fn cleanup(&self, c: &Ctx, _name: Option<&U16CStr>, flags: u32) {
        if flags & FSP_CLEANUP_DELETE != 0 && !c.gone.swap(true, Ordering::SeqCst) {
            if c.is_dir {
                let _ = self.vfs.rmdir(&c.path);
            } else {
                let _ = self.vfs.set_delete_on_close(c.h, true);
            }
        } else if c.write && !c.is_dir {
            // CloseHandle returned in the application: make what it wrote the committed version now rather than at the
            // later, asynchronous `close`.
            let _ = self.vfs.flush(c.h);
        }
    }

    fn flush(&self, c: Option<&Ctx>, info: &mut FileInfo) -> Result<()> {
        let Some(c) = c else { return Ok(()) };
        if !c.is_dir {
            self.vfs.flush(c.h).map_err(err)?;
        }
        self.info_of(c, info)
    }

    fn get_file_info(&self, c: &Ctx, info: &mut FileInfo) -> Result<()> {
        self.info_of(c, info)
    }

    fn get_security(&self, _c: &Ctx, _sd: Option<&mut [c_void]>) -> Result<u64> {
        Ok(0)
    }

    fn set_security(&self, _c: &Ctx, _info: u32, _d: winfsp::filesystem::ModificationDescriptor) -> Result<()> {
        Ok(())
    }

    fn overwrite(&self, c: &Ctx, _attrs: FILE_FLAGS_AND_ATTRIBUTES, _replace: bool, _alloc: u64, _extra: Option<&[u8]>, info: &mut FileInfo) -> Result<()> {
        self.vfs.set_len(c.h, 0).map_err(err)?;
        self.info_of(c, info)
    }

    fn read_directory(&self, c: &Ctx, _pattern: Option<&U16CStr>, marker: DirMarker, buffer: &mut [u8]) -> Result<u32> {
        if let Ok(lock) = c.dir_buffer.acquire(marker.is_none(), None) {
            let mut entries = self.vfs.list(&c.path).map_err(err)?;
            entries.sort_by(|a, b| a.name.cmp(&b.name));
            let mut di = DirInfo::<255>::new();
            if !c.path.is_empty() {
                for dots in [".", ".."] {
                    di.reset();
                    fill(di.file_info_mut(), &c.path, &root_entry());
                    di.set_name(dots)?;
                    lock.write(&mut di)?;
                }
            }
            for e in entries {
                di.reset();
                let full = if c.path.is_empty() { e.name.clone() } else { format!("{}/{}", c.path, e.name) };
                fill(di.file_info_mut(), &full, &e);
                if di.set_name(&e.name).is_err() {
                    continue; // name longer than 255 UTF-16 units cannot be listed on Windows
                }
                lock.write(&mut di)?;
            }
        }
        Ok(c.dir_buffer.read(marker, buffer))
    }

    fn rename(&self, _c: &Ctx, from: &U16CStr, to: &U16CStr, replace: bool) -> Result<()> {
        self.vfs.rename(&vp(from), &vp(to), replace).map_err(err)
    }

    fn set_basic_info(&self, c: &Ctx, _a: u32, _ct: u64, _la: u64, _lw: u64, _lc: u64, info: &mut FileInfo) -> Result<()> {
        // Times are the vault's own modification times; timestamp changes by applications are accepted and ignored.
        self.info_of(c, info)
    }

    fn set_delete(&self, c: &Ctx, _name: &U16CStr, delete: bool) -> Result<()> {
        if delete && c.is_dir && !self.vfs.list(&c.path).map_err(err)?.is_empty() {
            return Err(FspError::NTSTATUS(STATUS_DIRECTORY_NOT_EMPTY));
        }
        Ok(())
    }

    fn set_file_size(&self, c: &Ctx, new_size: u64, set_allocation: bool, info: &mut FileInfo) -> Result<()> {
        let cur = self.vfs.stat_handle(c.h).map_err(err)?.size;
        if !set_allocation || new_size < cur {
            self.vfs.set_len(c.h, new_size).map_err(err)?;
        }
        self.info_of(c, info)
    }

    fn read(&self, c: &Ctx, buf: &mut [u8], offset: u64) -> Result<u32> {
        let data = self.vfs.read(c.h, offset, buf.len()).map_err(err)?;
        if data.is_empty() && !buf.is_empty() {
            return Err(FspError::NTSTATUS(STATUS_END_OF_FILE));
        }
        buf[..data.len()].copy_from_slice(&data);
        Ok(data.len() as u32)
    }

    fn write(&self, c: &Ctx, buf: &[u8], offset: u64, to_eof: bool, constrained: bool, info: &mut FileInfo) -> Result<u32> {
        let size = self.vfs.stat_handle(c.h).map_err(err)?.size;
        let off = if to_eof { size } else { offset };
        let data = if constrained {
            if off >= size {
                self.info_of(c, info)?;
                return Ok(0);
            }
            &buf[..buf.len().min((size - off) as usize)]
        } else {
            buf
        };
        let n = self.vfs.write(c.h, off, data).map_err(err)?;
        self.info_of(c, info)?;
        Ok(n as u32)
    }

    fn get_volume_info(&self, out: &mut VolumeInfo) -> Result<()> {
        // The vault has no fixed capacity; report a large, constant volume so applications never refuse to save.
        out.total_size = 1 << 40;
        out.free_size = (1 << 40) - (1 << 30);
        out.set_volume_label(&self.label);
        Ok(())
    }
}

pub struct WinFspMounter {
    _init: FspInit,
    hosts: HashMap<String, FileSystemHost<GpFs>>,
}

impl WinFspMounter {
    pub fn new() -> std::result::Result<Self, String> {
        let init = winfsp::winfsp_init().map_err(|_| "WinFsp is not installed".to_string())?;
        Ok(WinFspMounter { _init: init, hosts: HashMap::new() })
    }

    fn free_letter() -> Option<String> {
        ('D'..='Z').rev().map(|l| format!("{l}:")).find(|m| !Path::new(&format!("{m}\\")).exists())
    }
}

impl Mounter for WinFspMounter {
    fn mount(&mut self, id: &str, label: &str, vfs: Arc<V>) -> std::result::Result<String, String> {
        let mp = Self::free_letter().ok_or("no free drive letter")?;
        let mut p = VolumeParams::new();
        p.sector_size(4096)
            .sectors_per_allocation_unit(1)
            .max_component_length(255)
            .filesystem_name("GiftKey")
            .case_sensitive_search(true)
            .case_preserved_names(true)
            .unicode_on_disk(true)
            .file_info_timeout(1000);
        let short: String = label.chars().take(32).collect();
        let mut host: FileSystemHost<GpFs> = FileSystemHost::new(p, GpFs { vfs, label: short }).map_err(|e| format!("{e:?}"))?;
        host.mount(mp.clone()).map_err(|e| format!("{e:?}"))?;
        FileSystemHost::<GpFs>::start(&mut host).map_err(|e| format!("{e:?}"))?;
        self.hosts.insert(id.to_string(), host);
        Ok(mp)
    }

    fn unmount(&mut self, id: &str) {
        if let Some(mut h) = self.hosts.remove(id) {
            h.stop();
            h.unmount();
        }
    }
}
