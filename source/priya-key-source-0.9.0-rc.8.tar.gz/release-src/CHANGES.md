# Priya Key {{VERSION}} — changes since rc.7

**Release candidate — physical-device acceptance pending.** A software update cannot stop a USB cable/port/power fault (Device Manager showed "Unknown USB Device (Device Descriptor Request Failed)"), but the app now recovers from it instead of failing.

- **Reconnect by USB id, for up to ~25 s:** when the key drops off USB during pairing, the app finds it again by its USB id (so a changed COM number is fine), reopens it, and resumes (previously 8 tries at the same COM name, ~4 s). Up to 8 drops per pairing are tolerated.
- **Mid-session link loss is no longer a dead end:** if the USB link fails while folders are unlocked (heartbeat or poll error such as Windows error 5), everything locks (as before), the dead COM handle is released, and the app reopens the key on its own; reconnection requires the PIN again. Previously the app stayed disconnected until you unplugged and replugged. Notice shown: "The USB link to the key was lost; reconnecting…".
- Tests: link drops at ten different pairing points; a live-session link failure locks, is reported once, and the controller reconnects without unplugging and demands a fresh PIN; retry limits and non-link failures.
- Still true: a key that keeps failing at the Windows level (failed device descriptor) needs a different cable/port/hub, see the install guide.

# Priya Key — changes since rc.6 (kept for history)

**Release candidate — physical-device acceptance pending.**

## Fixed: pairing failed with "Access is denied (os error 5)" when the BOOT button was pressed (third real-device report)
- **What it means:** Windows error 5 on the key's COM port during pairing means the USB serial link dropped at that moment (the key reset or re-enumerated, a cable/port glitch) or another program had the port. The app treated that as fatal.
- **Fix 1 (resilience):** if the link drops while pairing, the app now closes the old port handle (a COM port can only be opened once), reopens the port (up to 8 attempts), and resumes. If the key had already accepted the PIN but the host lost the session, the app waits out the key's 3-second session timeout and continues (a fresh BOOT press may be asked for). Four lost links in one pairing end it with a clear message. Tested at ten different drop points against the real device core in the simulator (including drops right after the PIN was accepted).
- **Fix 2 (cause reduction):** the port is no longer opened with DTR asserted and RTS is released at once; on boards with an auto-reset circuit those lines drive EN/GPIO0, so asserting them can reset the key or put it in its boot loader. Pending real-hardware verification.
- **Fix 3 (message):** error 5 now explains itself: key disconnected/reset, or another program (serial monitor, Arduino IDE, a second Priya Key window) using the port; unplug/replug and retry.
- **If it still happens:** note whether the key disappears from Device Manager ▸ Ports when you press BOOT (then it is a power/cable/port problem: try another cable, a rear USB port or a powered hub) and whether its LED/boot message resets.

# Priya Key — changes since rc.5 (kept for history)

**Release candidate — physical-device acceptance pending.**

## Fixed: "WebView2 cannot read or write its data directory" (second real-device report)
- **Cause:** WebView2 stores its profile in `<exe name>.WebView2` next to the program, i.e. under `C:\Program Files\PriyaKey`, which a normal (non-administrator) user cannot write.
- **Fix:** the window now uses an explicit data folder `%LOCALAPPDATA%\PriyaKey\WebView2` (fallbacks: `%APPDATA%`, then the temp folder; each is write-tested first). Settings and the pairing record stay in `%APPDATA%\PriyaKey` (also write-tested, falls back to `%LOCALAPPDATA%`). Nothing is written next to the program any more.
- **Other start-up failures of the same kind are now visible and actionable instead of silent:** a failed window/WebView2 creation, an unwritable profile folder, an unreadable settings folder and any unexpected panic show a message box that says what failed and what to do, and leave a one-line `startup-error.txt` in `%LOCALAPPDATA%\PriyaKey` (error text only, no keys/PINs/folder names). A leftover process holding the single-instance port no longer makes the app exit silently.
- Source-level regression tests guard these rules. **Pending real-PC verification.**

# Priya Key — changes since rc.4 (kept for history)

**Release candidate — physical-device acceptance pending.**

## Fixed: "winfsp-x64.dll was not found" at start-up (first real-device report)
- **Cause:** the Windows exe imported `winfsp-x64.dll` as a normal import. (The delay-load flag set by the WinFsp bindings does not reach our executable.) Windows therefore needed the DLL at launch, but WinFsp installs it under its own folder, which is not on PATH, and on a PC without WinFsp it is absent altogether.
- **Fix:** the DLL is now delay-loaded by the exe, and at start-up the app finds the installed copy itself (registry `InstallDir`, then the default WinFsp folders) and loads it by full path before WinFsp is initialised. Without WinFsp the app still starts and shows "WinFsp is not installed or cannot be loaded" with the places it looked in.
- **Guard:** `tools/build_windows.sh` now fails the build unless `winfsp-x64.dll` appears as a delay-load import (checked with llvm-readobj). Cannot be exercised on Windows from the build machine: **pending device verification.**

# Priya Key — changes since rc.3 (kept for history)

**Release candidate — physical-device acceptance pending.** Documentation/page-only update; app, firmware and installer logic are unchanged.

- First real-world report: Windows 11 **Smart App Control** blocked the unsigned download/installer. The setup page, ZIP README, install guide, limitations, test checklist and status now explain it: it has no "Run anyway", options are another PC / Windows 10 / switching it off knowingly (historically irreversible), and SmartScreen's "Run anyway" step is labelled as SmartScreen-only. Android is unaffected. Code signing (the real fix) is **not** done.

# Priya Key {{VERSION}} — changes since rc.2 (and the setup-page handoff update)

**Release candidate — physical-device acceptance pending.** No device was used; the board was not flashed or reconfigured.

## New
- **First-use setup page** (`setup-site/`): mobile-friendly, Windows and Android choices, concise steps, permission guidance, verification fingerprints (SHA-256 of both installers and the Android signing-certificate fingerprint), explicit statement that connecting the key cannot install the app. Relative links only; **not published** (no hosting destination was found).
- **Printable QR card kit** (`qr-card/`): template card (no QR; marked not for printing) and a tool that makes the real card only for a public https address and refuses localhost, IPs, private/placeholder/example names (writes nothing when refusing). **Final QR code: pending the publishing address.**
- **Discreet mode** (Settings, explicit, off by default). On key removal: lock all (as before), dismiss previews, close the dashboard, remove the Windows tray icon (or close the Android task, remove provider roots, stop the connection notification and foreground service). Minimal detection stays (Windows: 2 s polling process; Android: none; the app is designed to be started by Android's USB-attach prompt, which is **pending verification on a real phone**). Reconnection shows the PIN screen; a fresh PIN is always required. Manual launch always works. Not invisibility: app remains in installed-app lists, USB device stays visible, required notification/tray icon remain while connected. Android launcher entry is kept; launcher-specific hiding is documented as optional.
- Windows installer: *Desktop shortcut* is an optional component (off by default).

## Fixed
- Test helper pressed the simulated BOOT button after pairing finished, which could trip the privacy button and make controller tests flaky; presses now stop when pairing completes.
- Board-arrival retry back-off applied after successful opens (could delay a reconnection by 2 s); now only after failures.
- QR tool validated its URL after creating the output folder; it now validates first.

## Verification
See STATUS.md and `source/` logs. New tests: discreet persistence and API (gp-app), conceal/reveal/fresh-auth/manual-launch (Windows controller, against the real device-core simulator), setup-page builder and QR-card tool (Python, including a decode of the generated QR).

## Setup-page handoff (same rc.3 binaries)
- The Windows download is now a **complete ZIP** (`PriyaKey-Windows-Complete-…zip`: installer + `redist/` with WinFsp and the offline WebView2 installer + README that says to extract everything first). The page offers it first and the 2 MB installer-only download second, with accurate instructions.
- The unconditional “no internet needed after download” claim was removed from the page and the card. Now: the app itself never uses the internet; the complete package needs nothing else downloaded; installer-only may need WebView2 from Microsoft; the key's USB serial driver comes from Windows itself (not in the package).
- Android USB-attach relaunch is described everywhere as **pending verification on a real phone**, not guaranteed.
- The page links the GPL source archive and licences; the publish set is an allowlist (`tools/stage_publish.py`); `tools/verify_published.py` checks a live address; `tools/finish_publish.py` makes the final QR card only after that passes.
- Tests added: ZIP contents/reproducibility, page claims, allowlist refusals (keys, backups, host state, extra files, symlinks), verifier against a local server (corrupted download, wrong fingerprint, missing link, swapped inner installer, HTTPS-only), finish step (no card without verification).
