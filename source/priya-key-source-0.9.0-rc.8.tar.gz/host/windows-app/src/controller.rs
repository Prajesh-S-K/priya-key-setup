//! Application logic that is independent of Windows: owns the Service, keeps mounts in step with unlocked folders,
//! follows the board's arrival and removal. The platform supplies a `Mounter` (WinFsp on Windows).
use gp_app::service::Service;
use gp_app::vfs::Vfs;
use gp_app::api;
use vault_core::storage::DiskStorage;
use gpkey_host::{Link, NullLink};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::{Duration, Instant};

pub trait Mounter {
    /// Mount the unlocked folder and return where it appears (for example "Z:").
    fn mount(&mut self, id: &str, label: &str, vfs: Arc<Vfs<DiskStorage>>) -> Result<String, String>;
    /// Remove the mount. Must not fail; open handles in other programs start failing because the Vfs is locked.
    fn unmount(&mut self, id: &str);
    /// Why mounting cannot work at all (for example the file-system driver is missing), if known.
    fn problem(&self) -> Option<String> {
        None
    }
}

/// Requests from the controller to the window layer (discreet mode).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum UiEvent {
    /// The key was unplugged while discreet mode is on: close the dashboard and remove the tray icon.
    Conceal,
    /// The key came back after a Conceal: show the dashboard again (at the PIN screen; the session was already locked).
    Reveal,
}

pub type BoxLink = Box<dyn Link + Send>;

pub struct Controller<M: Mounter> {
    svc: Service<BoxLink>,
    mounter: M,
    mounts: HashMap<String, String>,
    port: Option<String>,
    last_try: Option<Instant>,
    notices: Vec<String>,
    ui: Vec<UiEvent>,
    concealed: bool,
    /// Finds and opens the key again (by USB id, so a changed COM number is fine).
    opener: Option<Arc<dyn Fn() -> Result<BoxLink, String> + Send + Sync>>,
}

impl<M: Mounter> Controller<M> {
    pub fn new(home: impl Into<PathBuf>, mounter: M) -> Result<Self, String> {
        let mut c = Self::with_link(home, mounter, Box::new(NullLink))?;
        c.set_opener(Arc::new(|| {
            let ports = crate::device::find_ports();
            let p = ports.first().ok_or_else(|| "the key is not visible to Windows yet".to_string())?;
            gpkey_host::SerialLink::open(p).map(|l| Box::new(l) as BoxLink).map_err(|e| e.to_string())
        }));
        Ok(c)
    }

    /// How to reopen the key's serial port if the link drops while pairing.
    pub fn set_opener(&mut self, f: Arc<dyn Fn() -> Result<BoxLink, String> + Send + Sync>) {
        self.opener = Some(f);
    }

    pub fn with_link(home: impl Into<PathBuf>, mounter: M, link: BoxLink) -> Result<Self, String> {
        Ok(Controller { svc: Service::new(home, link)?, mounter, mounts: HashMap::new(), port: None, last_try: None, notices: vec![], ui: vec![], concealed: false, opener: None })
    }

    pub fn service(&mut self) -> &mut Service<BoxLink> {
        &mut self.svc
    }

    pub fn mounts(&self) -> &HashMap<String, String> {
        &self.mounts
    }

    pub fn port(&self) -> Option<&str> {
        self.port.as_deref()
    }

    /// One dashboard request. The response is the API response, with the mount points added to `status`.
    pub fn handle(&mut self, req: &str) -> String {
        let is_status = serde_json::from_str::<Value>(req).ok().and_then(|v| v.get("cmd").and_then(|c| c.as_str().map(|s| s == "status"))).unwrap_or(false);
        let out = api::handle(&mut self.svc, req);
        self.reconcile();
        if !is_status {
            return out;
        }
        let Ok(mut v) = serde_json::from_str::<Value>(&out) else { return out };
        if let Some(d) = v.get_mut("data").and_then(|d| d.as_object_mut()) {
            d.insert("mounts".into(), json!(self.mounts));
            d.insert("board_connected".into(), json!(self.port.is_some()));
            d.insert("mount_problem".into(), json!(self.mounter.problem()));
            let (_, source, version) = self.svc.dashboard("");
            d.insert("app".into(), json!({"version": env!("CARGO_PKG_VERSION"), "platform": "Windows", "dashboard_source": source, "dashboard_version": version}));
            d.insert("notices".into(), json!(std::mem::take(&mut self.notices)));
        }
        v.to_string()
    }

    /// Mount what is unlocked, unmount what is not (locked, removed board, privacy press, heartbeat loss).
    pub fn reconcile(&mut self) {
        let want: Vec<(String, String)> = self
            .svc
            .cards(true)
            .into_iter()
            .filter(|c| c.state == "Unlocked" || c.state == "Saving")
            .map(|c| (c.id, c.name))
            .collect();
        let gone: Vec<String> = self
            .mounts
            .keys()
            .filter(|id| match self.svc.open_vault(id) {
                Some(ov) => ov.is_locked() || !want.iter().any(|(w, _)| w == *id),
                None => true,
            })
            .cloned()
            .collect();
        for id in gone {
            self.mounter.unmount(&id);
            self.mounts.remove(&id);
        }
        for (id, name) in want {
            if self.mounts.contains_key(&id) {
                continue;
            }
            let Some(ov) = self.svc.open_vault(&id) else { continue };
            match self.mounter.mount(&id, &name, ov.vfs.clone()) {
                Ok(mp) => {
                    self.mounts.insert(id, mp);
                }
                Err(e) => {
                    self.notices.push(format!("Could not open '{name}' as a drive: {e}. Is WinFsp installed?"));
                    self.svc.lock(&id);
                }
            }
        }
    }

    /// Call about every 500 ms. `ports` is the current list of board ports; `opener` opens one.
    pub fn tick_with(&mut self, ports: &[String], opener: &mut dyn FnMut(&str) -> Result<BoxLink, String>) {
        if let Some(p) = &self.port {
            if !ports.iter().any(|x| x == p) {
                self.svc.replace_link(Box::new(NullLink), "the board was unplugged");
                self.svc.clear_reopen();
                self.port = None;
                if self.svc.discreet() && !self.concealed {
                    self.concealed = true;
                    self.ui.push(UiEvent::Conceal);
                }
            }
        }
        if self.port.is_none() && !ports.is_empty() && self.last_try.map_or(true, |t| t.elapsed() >= Duration::from_secs(2)) {
            match opener(&ports[0]) {
                Ok(link) => {
                    self.svc.replace_link(link, "the board was replaced");
                    self.port = Some(ports[0].clone());
                    if let Some(f) = self.opener.clone() {
                        self.svc.set_reopen(Box::new(move || f()));
                    }
                    // Public, signed dashboard image from the board: cached for the next start. Failure is not an error here.
                    let _ = self.svc.sync_assets();
                    if self.concealed {
                        self.concealed = false;
                        self.ui.push(UiEvent::Reveal);
                    }
                }
                Err(e) => {
                    self.last_try = Some(Instant::now());   // back off only after a failure
                    self.notices.push(format!("Could not open the board: {e}"));
                }
            }
        }
        self.svc.tick();
        if self.svc.take_link_failure() && self.port.is_some() {
            // The USB link failed under a live session (the service already locked everything). Drop the dead handle and let
            // the next tick open the key again; this also frees the COM port, which can only be opened once.
            self.svc.replace_link(Box::new(NullLink), "the USB link to the key was lost");
            self.port = None;
            self.last_try = None;
            self.notices.push("The USB link to the key was lost; reconnecting…".into());
        }
        self.reconcile();
    }

    pub fn tick(&mut self) {
        let ports = crate::device::find_ports();
        self.tick_with(&ports, &mut |p| gpkey_host::SerialLink::open(p).map(|l| Box::new(l) as BoxLink).map_err(|e| e.to_string()));
    }

    /// Lock everything and remove all mounts (application exit).
    pub fn shutdown(&mut self) {
        self.svc.lock_all("application closed");
        self.reconcile();
    }
}

impl<M: Mounter> Controller<M> {
    /// The dashboard page to load: the verified cached board image, otherwise the bundled one.
    pub fn dashboard_html(&self, bundled: &str) -> String {
        self.svc.dashboard(bundled).0
    }

    /// "Priya Key: 2 folders unlocked" style text for the tray tooltip.
    pub fn summary(&self) -> String {
        match self.mounts.len() {
            0 => "Priya Key: locked".into(),
            1 => "Priya Key: 1 folder unlocked".into(),
            n => format!("Priya Key: {n} folders unlocked"),
        }
    }
}

impl<M: Mounter> Controller<M> {
    /// Pending window-layer requests (drained).
    pub fn take_ui(&mut self) -> Vec<UiEvent> {
        std::mem::take(&mut self.ui)
    }

    pub fn is_concealed(&self) -> bool {
        self.concealed
    }

    /// Start without a window or tray (autostart in discreet mode with no key attached). The key's arrival reveals.
    pub fn start_concealed(&mut self) {
        self.concealed = self.svc.discreet() && self.port.is_none();
    }

    /// The user launched the app by hand: show it now, whatever the state.
    pub fn manual_show(&mut self) {
        self.concealed = false;
    }
}
