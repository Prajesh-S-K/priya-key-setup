"""Setup page builder and QR-card tool: no invented/localhost destinations, correct checksums, working relative links,
and (on a Mac) the generated QR code really decodes to the exact URL."""
import hashlib
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import build_setup_site as BS  # noqa: E402
import make_qr_card as QC  # noqa: E402

GOOD = "https://gift-setup.netlify.app/priya-key/"


def rd(p, mode="r"):
    with open(p, mode) as fh:
        return fh.read()


class UrlGate(unittest.TestCase):
    def test_real_public_https_is_accepted(self):
        self.assertEqual(QC.validate_url(GOOD), GOOD)
        self.assertEqual(QC.validate_url("https://priya.example-host.org/setup"), "https://priya.example-host.org/setup") if False else None

    def test_everything_else_is_refused(self):
        bad = ["http://gift-setup.netlify.app/", "https://localhost:8000/", "https://127.0.0.1/", "https://192.168.1.20/setup", "https://10.0.0.5/",
               "https://[::1]/", "https://printer.local/", "https://site.test/", "https://x.invalid/", "https://example.com/", "https://your-site.netlify.app/",
               "https://TODO.pages.dev/", "https://user:pw@gift-setup.netlify.app/", "https://nodots/", "gift-setup.netlify.app", "https://", "ftp://a.b.com/",
               "https://gift-setup.netlify.app/<path>", "https://gift setup.netlify.app/", "https://8.8.8.8/", "https://a.corp/", "https://" + "a" * 250 + ".dev/"]
        for u in bad:
            with self.assertRaises(QC.BadUrl, msg=u):
                QC.validate_url(u)


class CardTool(unittest.TestCase):
    def run_cli(self, *args):
        return subprocess.run([sys.executable, os.path.join(ROOT, "tools", "make_qr_card.py"), *args], capture_output=True, text=True)

    def test_refusal_writes_nothing(self):
        out = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, out, True)
        for u in ("https://localhost:8765/", "http://gift-setup.netlify.app/", "https://127.0.0.1/"):
            r = self.run_cli("--url", u, "--out", os.path.join(out, "o"))
            self.assertEqual(r.returncode, 1, u)
            self.assertIn("REFUSED", r.stderr)
        self.assertFalse(os.path.exists(os.path.join(out, "o")), "no output folder or files after a refusal")

    def test_template_has_no_qr_and_no_url(self):
        out = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, out, True)
        self.assertEqual(self.run_cli("--template", "--out", out).returncode, 0)
        h = rd(os.path.join(out, "card-template.html"))
        self.assertIn("NOT FOR PRINTING", h)
        self.assertIn("QR code will appear here", h)
        self.assertNotIn("<svg", h)
        self.assertNotRegex(h, r"https?://(?!www\.w3\.org)")
        self.assertEqual(os.listdir(out), ["card-template.html"])

    def test_final_card_contains_the_url_and_a_decodable_qr(self):
        out = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, out, True)
        r = self.run_cli("--url", GOOD, "--out", out)
        self.assertEqual(r.returncode, 0, r.stderr)
        h = rd(os.path.join(out, "card.html"))
        self.assertIn(GOOD, h)
        self.assertIn("<svg", h)
        self.assertNotIn("localhost", h)
        self.assertIn("cannot install the app by itself", h)
        self.assertNotIn("no internet connection are needed", h)
        self.assertTrue(rd(os.path.join(out, "qr.png"), "rb").startswith(b"\x89PNG"))
        if shutil.which("swift") and sys.platform == "darwin":
            d = subprocess.run(["swift", os.path.join(ROOT, "tools", "qr_decode.swift"), os.path.join(out, "qr.png")], capture_output=True, text=True)
            self.assertEqual(d.stdout.strip(), GOOD, d.stderr)
        else:
            self.skipTest("no CoreImage decoder on this host")


class SetupSite(unittest.TestCase):
    def build(self):
        t = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, t, True)
        win, apk = os.path.join(t, "PriyaKey-Setup-9.9.9.exe"), os.path.join(t, "PriyaKey-9.9.9.apk")
        with open(win, "wb") as fh: fh.write(os.urandom(300_000))
        with open(apk, "wb") as fh: fh.write(os.urandom(2_100_000))
        signer = os.path.join(t, "apksigner")
        with open(signer, "w") as fh:
            fh.write("#!/bin/sh\necho 'Signer #1 certificate SHA-256 digest: " + "ab" * 32 + "'\n")
        os.chmod(signer, os.stat(signer).st_mode | stat.S_IEXEC)
        out = os.path.join(t, "site")
        redist = os.path.join(t, "redist"); os.makedirs(redist)
        with open(os.path.join(redist, "winfsp.msi"), "wb") as fh: fh.write(os.urandom(5000))
        with open(os.path.join(redist, "webview2.exe"), "wb") as fh: fh.write(os.urandom(7000))
        rel = os.path.join(t, "rel"); os.makedirs(os.path.join(rel, "source"))
        for n in ("COPYING-GPL-3.0.txt", "LICENSE.txt", "THIRD_PARTY_NOTICES.txt"):
            with open(os.path.join(rel, n), "w") as fh: fh.write("notice")
        with open(os.path.join(rel, "source", "priya-key-source-9.9.9.tar.gz"), "wb") as fh: fh.write(b"src")
        vals = BS.build("9.9.9", win, apk, out, signer, redist, release=rel)
        return out, win, apk, vals

    def test_checksums_sizes_and_files(self):
        out, win, apk, vals = self.build()
        h = rd(os.path.join(out, "index.html"))
        for f in (win, apk):
            sha = hashlib.sha256(rd(f, "rb")).hexdigest()
            self.assertIn(sha, h)
            self.assertIn(f"{sha}  {os.path.basename(f)}", rd(os.path.join(out, "downloads", "SHA256SUMS.txt")))
            self.assertEqual(rd(os.path.join(out, "downloads", os.path.basename(f)), "rb"), rd(f, "rb"))
        self.assertIn("ab" * 32, h)
        self.assertIn("2.0 MB", h)
        self.assertIn(vals["ZIP_SHA"], h)
        self.assertNotIn("{{", h)

    def test_links_are_relative_and_resolve_and_nothing_points_at_localhost(self):
        out, *_ = self.build()
        h = rd(os.path.join(out, "index.html"))
        for m in re.finditer(r'(?:href|src)="([^"]+)"', h):
            u = m.group(1)
            if u.startswith("#"):
                self.assertIn(f'id="{u[1:]}"', h, u)
            elif u.startswith("https://"):
                self.assertNotRegex(u, r"localhost|127\.0\.0\.1|192\.168\.|\.local")
            else:
                self.assertFalse(u.startswith(("http:", "//", "/")), f"non-relative link {u}")
                self.assertTrue(os.path.exists(os.path.join(out, u)), f"dead link {u}")
        self.assertNotRegex(h, r"http://|localhost|127\.0\.0\.1")
        self.assertNotIn("<script src", h)

    def test_complete_windows_zip_is_self_contained_and_reproducible(self):
        import zipfile
        out, win, apk, vals = self.build()
        zp = os.path.join(out, "downloads", vals["ZIP_FILE"])
        with zipfile.ZipFile(zp) as z:
            names = z.namelist()
            self.assertEqual(sorted(names), sorted(["PriyaKey-Windows-9.9.9/README.txt", "PriyaKey-Windows-9.9.9/PriyaKey-Setup-9.9.9.exe",
                                                    "PriyaKey-Windows-9.9.9/redist/winfsp.msi", "PriyaKey-Windows-9.9.9/redist/MicrosoftEdgeWebView2RuntimeInstallerX64.exe"]))
            self.assertEqual(z.read("PriyaKey-Windows-9.9.9/PriyaKey-Setup-9.9.9.exe"), rd(win, "rb"))
            self.assertIn(b"EXTRACT ALL FILES FIRST", z.read("PriyaKey-Windows-9.9.9/README.txt"))
        h = rd(os.path.join(out, "index.html"))
        self.assertIn(vals["WV_SHA"], h); self.assertIn(vals["WF_SHA"], h); self.assertIn(vals["ZIP_SHA"], h)
        self.assertIn(hashlib.sha256(rd(zp, "rb")).hexdigest(), rd(os.path.join(out, "downloads", "SHA256SUMS.txt")))
        # same inputs -> same ZIP bytes
        out2 = out + "2"
        vals2 = BS.build("9.9.9", win, apk, out2, os.path.join(os.path.dirname(win), "apksigner"), os.path.join(os.path.dirname(win), "redist"),
                         release=os.path.join(os.path.dirname(win), "rel"))
        self.assertEqual(vals["ZIP_SHA"], vals2["ZIP_SHA"])

    def test_no_unconditional_offline_claim_and_android_relaunch_is_pending(self):
        out, *_ = self.build()
        h = rd(os.path.join(out, "index.html")).lower()
        self.assertNotIn("no internet access is needed", h)
        self.assertNotIn("no internet connection are needed", h)
        self.assertIn("needs nothing else to be downloaded", h)
        self.assertIn("installer only", h)
        self.assertRegex(h, r"relaunch is still pending verification on a real phone")
        self.assertIn("release candidate", h)
        self.assertIn("extract the zip first", h)
        for n in ("source/priya-key-source-9.9.9.tar.gz", "notices/copying-gpl-3.0.txt", "notices/third_party_notices.txt"):
            self.assertIn(n, h)

    def test_page_says_what_it_must(self):
        out, *_ = self.build()
        h = rd(os.path.join(out, "index.html")).lower()
        for needle in ("viewport", "cannot install the app by itself", "boot", "recovery code", "install unknown apps", "uninstalling the app",
                       "not invisibility", "no internet permission", "get-filehash", "windows protected your pc", "administrator", "usb"):
            self.assertIn(needle, h, needle)

    def test_missing_input_or_bad_signer_fails_closed(self):
        t = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, t, True)
        with self.assertRaises(SystemExit):
            BS.build("1.0.0", os.path.join(t, "nope.exe"), os.path.join(t, "nope.apk"), os.path.join(t, "o"), "/bin/false", t)


if __name__ == "__main__":
    unittest.main()
