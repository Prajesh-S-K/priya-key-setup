"""Publication tooling: allowlist staging, the post-publication verifier (against a local test server), and the finish step that
generates the final QR card only after verification. No real destination is contacted."""
import functools
import http.server
import os
import shutil
import stat
import sys
import tempfile
import threading
import unittest
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
sys.path.insert(0, os.path.join(ROOT, "tests"))
import build_setup_site as BS  # noqa: E402
import finish_publish as FP  # noqa: E402
import stage_publish as SP  # noqa: E402
import verify_published as VP  # noqa: E402

GOOD = "https://gift-setup.netlify.app/priya-key/"


def wr(p, data, mode="wb"):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, mode) as fh:
        fh.write(data)


def rd(p, mode="rb"):
    with open(p, mode) as fh:
        return fh.read()


def make_site(test):
    t = tempfile.mkdtemp(); test.addCleanup(shutil.rmtree, t, True)
    win, apk = os.path.join(t, "PriyaKey-Setup-9.9.9.exe"), os.path.join(t, "PriyaKey-9.9.9.apk")
    wr(win, os.urandom(300_000)); wr(apk, os.urandom(500_000))
    signer = os.path.join(t, "apksigner")
    wr(signer, "#!/bin/sh\necho 'Signer #1 certificate SHA-256 digest: " + "cd" * 32 + "'\n", "w")
    os.chmod(signer, os.stat(signer).st_mode | stat.S_IEXEC)
    redist = os.path.join(t, "redist")
    wr(os.path.join(redist, "winfsp.msi"), os.urandom(4000)); wr(os.path.join(redist, "webview2.exe"), os.urandom(9000))
    rel = os.path.join(t, "rel")
    for n in ("COPYING-GPL-3.0.txt", "LICENSE.txt", "THIRD_PARTY_NOTICES.txt"):
        wr(os.path.join(rel, n), "notice", "w")
    wr(os.path.join(rel, "source", "priya-key-source-9.9.9.tar.gz"), b"src")
    site = os.path.join(t, "site")
    BS.build("9.9.9", win, apk, site, signer, redist, release=rel)
    return t, site


def serve(test, directory):
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=directory)
    class Quiet(handler.func):
        def log_message(self, *a): pass
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(Quiet, directory=directory))
    th = threading.Thread(target=srv.serve_forever, daemon=True); th.start()
    test.addCleanup(lambda: (srv.shutdown(), srv.server_close(), th.join()))
    return f"http://127.0.0.1:{srv.server_address[1]}/"


class Staging(unittest.TestCase):
    def test_good_site_is_staged_exactly(self):
        t, site = make_site(self)
        out = os.path.join(t, "stage")
        self.assertEqual(SP.main(["--src", site, "--out", out]), 0)
        self.assertEqual(SP.collect(out), SP.collect(site))

    def test_anything_off_the_allowlist_is_refused_and_nothing_is_staged(self):
        for extra in ("signing/assets_ed25519.key", "hardware/backup/flash-backup-full.bin", "release.jks", "keystore.properties", "notes.txt",
                      "downloads/identification.json", "source/host-state/trusted_board.hex", "downloads/backup.zip", ".env", "../x"):
            t, site = make_site(self)
            if extra.startswith(".."):
                continue
            wr(os.path.join(site, extra), b"secret")
            out = os.path.join(t, "stage")
            self.assertEqual(SP.main(["--src", site, "--out", out]), 1, extra)
            self.assertFalse(os.path.exists(out), extra)

    def test_symlinks_and_missing_required_files_are_refused(self):
        t, site = make_site(self)
        os.symlink("/etc/hosts", os.path.join(site, "notices", "LICENSE.txt.bak")) if False else None
        os.remove(os.path.join(site, "notices", "COPYING-GPL-3.0.txt"))
        self.assertEqual(SP.main(["--src", site, "--out", os.path.join(t, "o")]), 1)
        t2, site2 = make_site(self)
        os.remove(os.path.join(site2, "notices", "LICENSE.txt"))
        os.symlink(os.path.join(site2, "index.html"), os.path.join(site2, "notices", "LICENSE.txt"))
        self.assertEqual(SP.main(["--src", site2, "--out", os.path.join(t2, "o")]), 1)


def make_split_site(test):
    """Page built for a split publication: downloads at their own base, page at another."""
    t = tempfile.mkdtemp(); test.addCleanup(shutil.rmtree, t, True)
    t0, site0 = make_site(test)
    return t0, site0


class Split(unittest.TestCase):
    def build(self, base):
        t = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, t, True)
        win, apk = os.path.join(t, "PriyaKey-Setup-9.9.9.exe"), os.path.join(t, "PriyaKey-9.9.9.apk")
        wr(win, os.urandom(300_000)); wr(apk, os.urandom(500_000))
        signer = os.path.join(t, "apksigner")
        wr(signer, "#!/bin/sh\necho 'Signer #1 certificate SHA-256 digest: " + "cd" * 32 + "'\n", "w"); os.chmod(signer, os.stat(signer).st_mode | stat.S_IEXEC)
        redist = os.path.join(t, "redist")
        wr(os.path.join(redist, "winfsp.msi"), os.urandom(4000)); wr(os.path.join(redist, "webview2.exe"), os.urandom(9000))
        rel = os.path.join(t, "rel")
        for n in ("COPYING-GPL-3.0.txt", "LICENSE.txt", "THIRD_PARTY_NOTICES.txt"):
            wr(os.path.join(rel, n), "notice", "w")
        wr(os.path.join(rel, "source", "priya-key-source-9.9.9.tar.gz"), b"src")
        site = os.path.join(t, "site")
        BS.build("9.9.9", win, apk, site, signer, redist, release=rel, downloads_base=base)
        return t, site

    def test_split_staging_separates_page_and_assets_and_refuses_a_relative_page(self):
        t, site = self.build("https://github.com/o/r/releases/download/v1/")
        out = os.path.join(t, "stage")
        self.assertEqual(SP.main(["--src", site, "--out", out, "--split"]), 0)
        self.assertEqual(sorted(os.listdir(os.path.join(out, "release-assets"))), ["PriyaKey-9.9.9.apk", "PriyaKey-Setup-9.9.9.exe", "PriyaKey-Windows-Complete-9.9.9.zip", "SHA256SUMS.txt"])
        self.assertFalse(any(f.endswith((".zip", ".exe", ".apk")) for f in SP.collect(os.path.join(out, "site"))))
        self.assertIn("index.html", os.listdir(os.path.join(out, "site")))
        t2, rel_site = make_site(self)
        self.assertEqual(SP.main(["--src", rel_site, "--out", os.path.join(t2, "o"), "--split"]), 1)

    def test_verifier_follows_the_downloads_base_and_catches_tampering_there(self):
        # two local servers stand in for GitHub Pages (page) and GitHub Releases (downloads)
        SP.ALLOW_INSECURE_LOCAL = True
        self.addCleanup(setattr, SP, 'ALLOW_INSECURE_LOCAL', False)
        assets_dir = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, assets_dir, True)
        dl_base = serve(self, assets_dir)
        t, site = self.build(dl_base)
        out = os.path.join(t, "stage")
        self.assertEqual(SP.main(["--src", site, "--out", out, "--split"]), 0)
        for n in os.listdir(os.path.join(out, "release-assets")):
            shutil.copy(os.path.join(out, "release-assets", n), os.path.join(assets_dir, n))
        page_base = serve(self, os.path.join(out, "site"))
        log = []
        self.assertTrue(VP.verify(page_base, insecure_local=True, say=log.append, extra_bases=[dl_base]), "\n".join(log))
        self.assertIn("inner installer is identical", "\n".join(log))
        z = os.path.join(assets_dir, "PriyaKey-Windows-Complete-9.9.9.zip")
        b = bytearray(rd(z)); b[100] ^= 1; wr(z, bytes(b))
        self.assertFalse(VP.verify(page_base, insecure_local=True, say=lambda m: None, extra_bases=[dl_base]))


class Verifier(unittest.TestCase):
    def run_verify(self, base, **kw):
        log = []
        ok = VP.verify(base, say=log.append, **kw)
        return ok, "\n".join(log)

    def test_good_site_passes_every_check(self):
        t, site = make_site(self)
        ok, log = self.run_verify(serve(self, site), insecure_local=True)
        self.assertTrue(ok, log)
        for needle in ("inner installer is identical", "matches SHA256SUMS.txt", "matches the fingerprint printed on the page", "WebView2", "archive is intact"):
            self.assertIn(needle, log)

    def test_corrupted_download_is_caught(self):
        t, site = make_site(self)
        z = os.path.join(site, "downloads", "PriyaKey-Windows-Complete-9.9.9.zip")
        b = bytearray(rd(z)); b[len(b) // 2] ^= 0xFF; wr(z, bytes(b))
        ok, log = self.run_verify(serve(self, site), insecure_local=True)
        self.assertFalse(ok); self.assertIn("FAIL", log)

    def test_page_fingerprint_mismatch_and_missing_download_and_dead_link(self):
        t, site = make_site(self)
        idx = os.path.join(site, "index.html")
        wr(idx, rd(idx, "r").replace(BS.sha256(os.path.join(site, "downloads", "PriyaKey-9.9.9.apk")), "0" * 64), "w")
        ok, log = self.run_verify(serve(self, site), insecure_local=True)
        self.assertFalse(ok); self.assertIn("matches the fingerprint printed on the page", log)
        t2, site2 = make_site(self)
        os.remove(os.path.join(site2, "downloads", "PriyaKey-9.9.9.apk"))
        ok2, log2 = self.run_verify(serve(self, site2), insecure_local=True)
        self.assertFalse(ok2); self.assertIn("link failed", log2)
        t3, site3 = make_site(self)
        os.remove(os.path.join(site3, "source", "priya-key-source-9.9.9.tar.gz"))
        self.assertFalse(self.run_verify(serve(self, site3), insecure_local=True)[0])

    def test_zip_with_a_different_installer_is_caught(self):
        t, site = make_site(self)
        z = os.path.join(site, "downloads", "PriyaKey-Windows-Complete-9.9.9.zip")
        tmp = z + ".new"
        with zipfile.ZipFile(z) as zin, zipfile.ZipFile(tmp, "w") as zout:
            for i in zin.infolist():
                data = zin.read(i.filename)
                if i.filename.endswith("PriyaKey-Setup-9.9.9.exe"):
                    data = b"evil" + data
                zout.writestr(i, data)
        os.replace(tmp, z)
        # keep the published checksum list consistent with the swapped ZIP so ONLY the inner check can catch it
        sums = os.path.join(site, "downloads", "SHA256SUMS.txt")
        lines = [(BS.sha256(z) + "  " + os.path.basename(z)) if "Complete" in l else l.rstrip("\n") for l in rd(sums, "r").splitlines()]
        wr(sums, "\n".join(lines) + "\n", "w")
        idx = os.path.join(site, "index.html")
        import re
        wr(idx, re.sub(r"[0-9a-f]{64}(?=</td></tr>\n<tr><td>PriyaKey-Setup)", BS.sha256(z), rd(idx, "r"), count=1), "w")
        ok, log = self.run_verify(serve(self, site), insecure_local=True)
        self.assertFalse(ok); self.assertIn("inner installer is identical", log)

    def test_https_is_required_and_localhost_is_not_a_destination(self):
        t, site = make_site(self)
        base = serve(self, site)
        self.assertFalse(self.run_verify(base)[0], "plain http / localhost must fail without the test flag")
        self.assertFalse(self.run_verify("https://localhost:9/")[0])
        self.assertFalse(self.run_verify("http://gift-setup.netlify.app/")[0])


class Finish(unittest.TestCase):
    def test_refuses_localhost_and_failed_verification_without_creating_a_card(self):
        out = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, out, True)
        o = os.path.join(out, "card")
        log = []
        self.assertEqual(FP.run("https://localhost:8767/", o, say=log.append, verify=lambda *a, **k: True), 1)
        self.assertEqual(FP.run("http://gift-setup.netlify.app/", o, say=log.append, verify=lambda *a, **k: True), 1)
        self.assertEqual(FP.run(GOOD, o, say=log.append, verify=lambda *a, **k: False), 1)
        self.assertIn("no QR card was generated", "\n".join(log))
        self.assertFalse(os.path.exists(o))

    def test_card_is_generated_only_after_verification_passes(self):
        out = tempfile.mkdtemp(); self.addCleanup(shutil.rmtree, out, True)
        o = os.path.join(out, "card")
        seen = []
        rc = FP.run(GOOD, o, say=lambda m: None, verify=lambda url, say=None, **k: seen.append(url) or True)
        self.assertEqual(rc, 0)
        self.assertEqual(seen, [GOOD])
        h = rd(os.path.join(o, "card.html"), "r")
        self.assertIn(GOOD, h); self.assertNotIn("TEMPLATE", h)


if __name__ == "__main__":
    unittest.main()
