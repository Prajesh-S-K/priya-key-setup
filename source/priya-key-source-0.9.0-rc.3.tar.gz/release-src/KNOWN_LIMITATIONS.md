# Priya Key {{VERSION}} — known limitations

**Release candidate — physical-device acceptance pending.**

## Security model — read this
- The key protects against someone who has your files but not your key and PIN. It does **not** protect against malware or another person controlling the computer/phone **while a folder is unlocked** — they can read whatever is open. Locking removes the keys from memory as far as the operating system allows; it is not a guarantee against a compromised host.
- The PIN has four digits. The key enforces attempt delays on the board; the failed-attempt count (and therefore the delay tier) is stored, but the current waiting period is measured from power-up, so unplugging and replugging restarts it. If someone **dumps the board's flash**, a four-digit PIN can be brute-forced offline: flash encryption/secure boot are deliberately **not** enabled in this release (they are irreversible eFuse changes). Treat a lost key as compromised-if-also-lost-with-your-vault-files, and rotate: restore the folders with the recovery code onto a new key.
- The offline recovery code can open an encrypted folder that exists. It **cannot recover a vault file that was deleted** (for example by uninstalling the Android app).
- There is no secure erase: deleting files, originals, or encrypted folders is an ordinary delete; SSD/flash wear-levelling and backups may keep copies.
- Editors and the OS keep their own copies (caches, temp files, recent lists, thumbnails, cloud sync, backups of the *unlocked* drive). Exports and restored plaintext copies are outside protection.
- Hiding a folder is presentation only, not a security boundary.
- The BOOT button locks everything and disables service; pressing it again restores service and requires the PIN. This is enforced by the key and the host software; it cannot stop a compromised host that already holds an unlocked folder's keys. The USB serial device itself stays visible to the operating system.

## Discreet mode
- Opt-in only. It closes the dashboard (and the Windows tray icon) and stops Android's connection work when the key is unplugged. It does not hide the app from installed-app lists or app settings, does not hide the USB device from the OS, and does not suppress Android's required notification while the key is connected or the Windows tray icon while it is. It is not invisibility and must not be relied on to conceal the existence of the app or key.
- Windows keeps a background process (no window, no tray) that polls for the key every 2 s while concealed; killing it in Task Manager is possible. Android's launcher entry is kept on purpose (dynamic hiding could break the USB-attach launch, unverified); launcher-specific hiding is optional and manual.
- The behaviours that need a real window/tray/Android task (closing, reappearing at the PIN screen, USB-attach launch) are untested on devices.

## Software
- **Vault format is draft v0 (release-candidate format).** A later version may need a migration; keep plain verified backups of anything important and keep the recovery code. Disk durability is reported as *Unverified* (no real-device evidence for directory-fsync behaviour yet).
- **Windows:** not Authenticode-signed (SmartScreen warning). Volume is case-sensitive; names with characters Windows forbids (imported from Android) may not open; names longer than 255 UTF-16 units are not listed; applications cannot change timestamps; capacity shown is a fixed 1 TiB placeholder. Drive letters only (no folder mount points). Closing the window hides to the tray; *Quit* or unplugging locks. The exe's file properties have an icon but no version resource.
- **Android:** vaults are in app-private storage (deleted on uninstall); provider files cannot be truncated while open except at open time (`wt`); another app's save is durable only after it flushes/closes; some phones stop background services aggressively (see Troubleshooting); the app needs a phone with USB host and a data-capable cable/adapter. Notification permission is needed for the required "key connected" notice.
- **Board-stored dashboard:** the apps use a signed dashboard image from the board when it is newer than the bundled one and the signature verifies; otherwise the bundled dashboard is used. Applying a new image requires flashing.
- **USB:** opening the serial port may pulse the board's reset lines on some hosts; macOS did not, Windows/Android are untested. If the board resets on connect, startup after plugging in takes a few seconds longer.
- Only the supplied board (ESP32, CH340 USB bridge, VID:PID 1A86:7523) is supported. 460800 baud failed on it; 115200 is used.
- No telemetry, no network access, no automatic updates.
