# Priya Key {{VERSION}} — device-independent final-test checklist

**Release candidate — physical-device acceptance pending.** Record Pass/Fail and notes for every step. Use only **disposable** files made by `tools/make-test-files.*`. If a step fails, stop that section, note exact text on screen and the step number, and do not continue with real data.

Conventions: *Key* = the ESP32 board. *BOOT* = the button on the board. Test PIN suggestion: any four digits you do not use elsewhere (write it down for the test). "Dashboard" = the Priya Key window/app screen.

## 0. Preparation (once)
| # | Action | Expected |
|---|---|---|
| 0.1 | Verify SHA-256 of every file against `SHA256SUMS.txt`. | All match. |
| 0.2 | Create test data: Windows `.\make-test-files.ps1`; macOS/Linux `./make-test-files.sh`. Copy the resulting `PriyaKey-TestData` folder to every device under test. | Folders `Docs`, `Pics`, `Nested`, `Big` (40 MB) and `SHA256-originals.txt`. |
| 0.3 | Safe run of the flasher (INSTALL.md §1 step 1). | Package validated; board identified (ESP32, 4MB, security state clean); `backup verified against the board`; message `NOTHING was written`; exit code 3. Backup file is exactly 4,194,304 bytes, owner-only. |
| 0.4 | Authorized write (INSTALL.md §1 step 2). | `written and verified`. Replug: key is detected. Also try: a wrong `--confirm-write` MAC, or a different/short backup file → `STOP`, nothing written. |
| 0.5 | Confirm the board's old pairing survived (only if it was paired before): start an app that was already paired. | Shows `ENTER PIN`, not `NEW KEY`. (If never paired: `NEW KEY`.) |

## 1. Windows 11 (primary)
| # | Action | Expected | If it fails |
|---|---|---|---|
| 1.1 | Run `windows\PriyaKey-Setup-…exe` (admin) with the `redist` folder beside it. | Installs; WinFsp installed or already present; no error boxes. Start-menu entry "Priya Key" with the key icon. | Run the MSI/WebView2 installers in `redist` manually. |
| 1.2 | Plug in the key. Start Priya Key. | Skippable animation (click skips it). First-time check lists: Key detected ✓, Drive support ✓. | See INSTALL troubleshooting. |
| 1.3 | Set up the key: *Set up this key*, choose PIN twice, press BOOT within 90 s. | `PRESS BOOT` appears, then a **recovery code** sheet. Write the code on paper, tick the box, Done. App shows an empty folder list. | If "SETUP FAILED", unplug/replug and retry once; note the text. |
| 1.4 | Add four folders from **different locations** (e.g. `Docs` from Desktop, `Pics` from a second drive/folder, `Nested` from Downloads, `Big` from Documents), each with a name and a location for the encrypted copy (use different locations). | Each import finishes with "verified" and a file count matching the source. The originals are still there. **Do not delete originals yet.** | Note the error text; check disk space. |
| 1.4b | When offered "Delete originals", click *Keep*. | Originals untouched. (You may test deletion later on a copy.) | |
| 1.5 | Hide two folders (`Pics`, `Big`) with *Hide*. | They disappear from the list; a note says "2 hidden folders not shown"; *Show hidden folders* reveals them with the badge `Locked · Hidden`. | |
| 1.6 | Unlock `Docs`. | Badge `Unlocked`; a button `Drive Z:` (letter varies). Explorer shows the drive with the same files. | If "Could not open … as a drive": WinFsp. |
| 1.7 | **External editing:** open `note1.txt` from the drive in Notepad, change text, Ctrl+S, close. Reopen. | Change is kept. In the dashboard, Open ▸ the file shows the new content. | |
| 1.8 | Save-by-rename editor: in WordPad (or any editor that saves via temp file + rename) create `new.rtf`, save, edit, save again. | No error dialogs; content persists. | |
| 1.9 | Copy `Nested` contents out and back; rename a file; delete a file; create a folder. | All succeed; deleted file disappears. | |
| 1.10 | Large file: unlock `Big`, copy `random-40MB.bin` from the drive to the desktop, then compare hashes with `SHA256-originals.txt` (`Get-FileHash`). | Identical hash. | |
| 1.11 | While a file from the drive is open in Notepad, press **Lock** on the card. | Drive disappears; Notepad's next save fails with an error (expected); the last saved version of the file inside the vault is intact after unlocking again. | |
| 1.12 | **Tray:** close the window with ✕. | Window hides; tray icon remains; unlocked folder still available. Tooltip says "1 folder unlocked". | |
| 1.13 | Tray ▸ *Open Priya Key*; start Priya Key a second time from the Start menu. | Window returns; second start just brings it forward (no second tray icon). | |
| 1.14 | Tray ▸ *Lock all folders*. | Drives vanish; dashboard shows the locked screen. Tooltip "locked". | |
| 1.15 | Unlock again, then tray ▸ *Quit*. | Drive disappears; app exits; tray icon gone. | |
| 1.16 | Settings ▸ tick *Start with Windows*, sign out/in. | Priya Key starts in the tray (no window). Untick to remove. | |
| 1.17 | **Disconnect locking:** unlock a folder, unplug the key. | Within ~3 s: drive disappears, dashboard shows `LOCKED` with a reason. Replug: `ENTER PIN` required. | |
| 1.18 | **Unplug during a save:** start copying `random-40MB.bin` **into** the drive, unplug mid-copy. Replug, enter PIN, unlock. | The folder opens with no corruption; the partially copied file is absent or complete-from-an-earlier-commit, never half-visible; other files unchanged. | |
| 1.19 | **Privacy button, first press:** with a folder unlocked press BOOT once. | Everything locks immediately; dashboard shows `PRIVACY MODE — press BOOT again`. The COM port may still be visible to Windows (expected). Entering a PIN is refused/not offered. | |
| 1.20 | **Privacy button, second press.** | The key becomes available; dashboard returns to `ENTER PIN`; **the PIN is required again**; previously unlocked folders stay locked. | |
| 1.21 | Wrong PIN ×4. | After 3 free failures the 4th shows `WRONG PIN … next try allowed in 5 s`; correct PIN is refused during the wait with `PLEASE WAIT`; after the wait the correct PIN works and the counter resets. | |
| 1.22 | Settings ▸ *Change PIN* (old PIN, new PIN). Lock all; enter the **new** PIN. Try the old PIN. | New PIN works; old PIN fails. A wrong old PIN in the change dialog is refused. | |
| 1.23 | Folder controls: Rename a card; Hide/Unhide; Open (browse + preview text and a PNG); More ▸ Back up encrypted folder (folder locked) to a USB stick/folder. | Rename updates card; preview shows text/image; backup says `BACKUP VERIFIED` with file count and size; backing up an *unlocked* folder is refused with "lock the folder first". | |
| 1.24 | Settings ▸ *Replace recovery code*. Write the new code. | New code shown once; old code no longer opens folders made after this (older copies keep their old slots — as warned on screen). | |
| 1.25 | **Recovery:** close the app; delete `%APPDATA%\PriyaKey\registry.json` (this simulates losing the folder list only); start the app, enter PIN, Settings ▸ *Recover a folder…*, choose one `.gpv` folder, enter the recovery code. | Folder returns to the list and unlocks with all files. A wrong code says "that recovery code does not open this folder". | |
| 1.26 | **Remove encryption:** More ▸ Remove encryption… on `Nested` to a new empty folder. Compare hashes with the originals. | `RESTORED AND VERIFIED`; hashes match. The encrypted folder is deleted only if you press *Delete encrypted folder…* and confirm. | |
| 1.27 | Delete originals: for a fresh import, choose *Delete originals* and confirm. | Only files whose content still matches are deleted; a file you modified after import is kept and listed. (Do this only with disposable data.) | |
| 1.28 | Reboot with a folder unlocked. | After reboot all folders are locked; PIN required. | |
| 1.29 | Upgrade test: reinstall the same installer over the existing install. | Settings, folders and pairing remain. | |
| 1.30 | Uninstall from *Apps & features*. | Message says encrypted folders were **not** deleted; `%APPDATA%\PriyaKey` still exists. | |

### 1b. Discreet mode and first-use page (Windows)
| # | Action | Expected |
|---|---|---|
| 1b.1 | Open the setup page (local copy of `setup-site/index.html` or the published address) in a browser on the PC. | Mobile-friendly page; Windows highlighted; SHA-256 of the installer matches `Get-FileHash`. Download link works. |
| 1b.2 | Settings ▸ *Discreet mode* (default off) — confirm it is off, read the text, turn it on. | Toast `Discreet mode on`; text says it is not invisibility. |
| 1b.3 | With a folder unlocked and the window open, unplug the key. | Drive disappears, previews dismissed, window closes, **tray icon removed**. Task Manager still lists `priya-key.exe` (small background watcher). |
| 1b.4 | Plug the key back in. | Window reappears at the **PIN screen**; tray icon returns; nothing is unlocked; PIN required. |
| 1b.5 | Unplug again, then launch Priya Key from the Start menu. | Window shows immediately (manual route works); no key → `PLUG IN THE KEY`. |
| 1b.6 | Turn discreet mode off; unplug the key. | Everything locks but the window and tray icon stay. |
| 1b.7 | Reinstall with *Desktop shortcut* ticked, then untick/uninstall. | Shortcut optional; removed at uninstall. |
| 1b.8 | Enable *Start with Windows* + discreet mode, sign out/in with **no key** attached. | No window, no tray. Plug the key in: window and tray appear at the PIN screen. |

## 2. Windows 10 compatibility (64-bit, 21H2 or newer)
Repeat **1.1–1.7, 1.11, 1.12–1.15, 1.17, 1.19–1.22, 1.25**. Extra checks:
| # | Action | Expected |
|---|---|---|
| 2.1 | Before installing, note whether WebView2 is installed (Settings ▸ Apps). | If absent, the installer runs the offline WebView2 installer from `redist`. |
| 2.2 | Plug in the key on a fresh Windows 10 without internet. | A COM port may need the CH340 driver (Windows Update or WCH driver); note which it was. |
| 2.3 | SmartScreen on first run. | "Unknown publisher" is expected (not signed). |

## 3. Android 11+ (USB, permissions, folders)
| # | Action | Expected | If it fails |
|---|---|---|---|
| 3.1 | Install the APK. Open the app. | App icon is the key on a dark square; animation skippable; *FIRST-TIME CHECK* lists USB host ✓, key plugged in, USB permission, notifications, background use. | |
| 3.2 | Use *Allow* for notifications; *Open* ▸ allow unrestricted background use. Press *Check again*. | Items turn ✓. | Phone makers' own battery lists may need manual changes. |
| 3.3 | Plug in the key (cable/OTG). | The app opens/offers to open; a USB permission prompt appears; choose Allow. A "Key connected" notification appears with a **Lock all** button. Dashboard shows `ENTER PIN`/`NEW KEY`. | Unplug/replug; Settings ▸ First-time check ▸ "Ask now". |
| 3.4 | Set up: PIN twice, press BOOT, write the recovery code. | As 1.3. | |
| 3.5 | Copy `PriyaKey-TestData` to the phone (e.g. Downloads). Add four folders: for each, *Choose…* the source with the system folder picker. | Before importing, the **Stored inside this app** warning is shown and the Encrypt button stays disabled until you tick *I understand*. Imports finish `verified`. Originals untouched. | |
| 3.6 | Hide two folders (`Pics`, `Big`). | As 1.5. | |
| 3.7 | Unlock `Docs`. Open the system *Files* app (or any app's "open file"): look for **Priya Key** roots. | An entry named after the folder appears; its files are listed. | Open the app's *Open in Files* button. |
| 3.8 | **External editing:** open `note1.txt` from that root in a text editor that supports "Open/Save with Documents UI", edit, save. Return to Priya Key ▸ Open ▸ the file. | New text present. Saving also works for a *new* file created in that root. | Some editors only copy; note which. |
| 3.9 | Copy a file out of the root to Downloads and hash it (e.g. with a hash app) or compare size; copy `random-40MB.bin` out. | Sizes/hashes match originals. | |
| 3.10 | Tap **Lock all** in the notification. | Roots disappear from the file picker; open files error out; the dashboard shows the locked screen. | |
| 3.11 | **Disconnect locking:** unlock a folder, unplug the key. | Within ~3 s roots disappear, the notification goes away, dashboard locks with a reason. | |
| 3.12 | **Privacy button** first press then second press. | As 1.19 / 1.20 (`PRIVACY MODE`, then PIN required again). | |
| 3.13 | Wrong-PIN delays and *Change PIN*. | As 1.21 / 1.22. | |
| 3.14 | Screen off for 5 minutes with a folder unlocked and the key attached. | Folder is still unlocked afterwards (if not, the phone's battery settings are killing the service: note the phone brand/Android version). | Troubleshooting in INSTALL.md. |
| 3.15 | **Backup/restore:** lock `Docs`; More ▸ *Back up encrypted folder…*, choose a folder in Downloads. | `BACKUP VERIFIED`, N files; a `<name>.gpv` folder appears there. | |
| 3.16 | **Reinstall scenario:** with that backup saved **outside the app**, uninstall the app (this deletes its folders — disposable data only!), reinstall the APK, enter PIN, Settings ▸ *Restore a backup…*, pick the `.gpv` folder. | Restore says verified; the folder is back, unlocks with all files. If the key were different you would see "made for another board: use the recovery code". | |
| 3.17 | **Recovery code:** Settings ▸ *Recover a folder…*, pick a `.gpv` backup, enter the recovery code. | Folder is linked and opens. Wrong code is refused. | |
| 3.18 | Remove encryption on a folder to a picked folder. | `RESTORED AND VERIFIED`; hashes match originals. Encrypted folder deleted only after you confirm. | |
| 3.19 | Settings ▸ *Replace recovery code*. | As 1.24. | |
| 3.20 | Update test: install the same APK again over the existing one (or a later one signed with the same key). | App data and folders remain. | |

### 3b. Discreet mode and first-use page (Android)
| # | Action | Expected |
|---|---|---|
| 3b.1 | Open the setup page on the phone (local file or published address). | Page fits the screen; Android highlighted; install steps match what you see. |
| 3b.2 | Settings ▸ *Discreet mode* on. Unlock a folder (visible in Files), then unplug the key. | Roots vanish from Files; the connection notification disappears; the Priya Key screen closes and is gone from recents. |
| 3b.3 | Plug the key back in. | Android offers/opens Priya Key (USB attach); PIN screen; nothing unlocked. **If the app does not launch on attach, record this: it decides whether launcher hiding could ever be safe.** |
| 3b.4 | Open Priya Key from the app drawer with no key. | Opens normally (launcher entry is kept). |
| 3b.5 | Discreet mode off: unplug the key. | Folders lock and roots vanish, but the screen stays open on the locked screen. |
| 3b.6 | Check Settings ▸ Apps. | Priya Key is still listed (the app is never hidden from system settings). |

## 4. Cross-checks (optional, same key)
| # | Action | Expected |
|---|---|---|
| 4.1 | Make a backup on Windows (1.23), copy the `.gpv` folder to the phone, *Restore a backup…* there. | Opens with the same key and PIN (formats are identical). |
| 4.2 | Tamper test: in a **copy** of a `.gpv` folder, flip one byte in any one file inside it with a hex editor; restore/recover that copy. | The app refuses or reports corruption; it never shows altered content silently. |

## 5. Pass criteria for this release candidate
All of sections 0, 1 and 3 pass; section 2 passes on at least the listed subset; any failure is recorded with step number and screen text. Anything still failing means the corresponding status in STATUS.md stays *awaiting physical-device testing*.
