#!/usr/bin/env python3
"""Printable gift card with a QR code that links to the published setup page.

usage:  make_qr_card.py --url https://...      writes qr-card/out/{card.html, qr.svg, qr.png}
        make_qr_card.py --template             writes qr-card/out/card-template.html (NO QR code, clearly marked pending)

The tool REFUSES to make a final QR code for anything that is not a real public https address: no localhost, loopback,
private or link-local addresses, .local/.test/.invalid/.example hosts, placeholders, or example domains."""
import argparse
import base64
import html
import ipaddress
import os
import sys
from urllib.parse import urlparse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools", "vendor"))

BAD_TLDS = ("local", "localhost", "test", "invalid", "example", "internal", "lan", "home", "corp", "onion")
PLACEHOLDER_WORDS = ("example", "your-", "yourname", "todo", "tbd", "placeholder", "changeme", "xxx", "<", ">", "{", "}", " ")


class BadUrl(ValueError):
    pass


def validate_url(url):
    u = urlparse(url.strip())
    if any(w in url.lower() for w in PLACEHOLDER_WORDS):
        raise BadUrl("the address looks like a placeholder")
    if u.scheme != "https":
        raise BadUrl("only https addresses are accepted")
    host = (u.hostname or "").lower()
    if not host:
        raise BadUrl("no host in the address")
    if u.username or u.password:
        raise BadUrl("credentials in the address are not allowed")
    try:
        ip = ipaddress.ip_address(host)
        raise BadUrl("IP addresses are not accepted (" + ("loopback/private" if ip.is_private or ip.is_loopback else "use a hostname") + ")")
    except ValueError as e:
        if isinstance(e, BadUrl):
            raise
    if "." not in host or host.endswith(BAD_TLDS) or host.split(".")[-1] in BAD_TLDS or host == "localhost":
        raise BadUrl("not a public hostname")
    if len(url) > 200:
        raise BadUrl("address too long for a printed card")
    return u.geturl()


def icon_data_uri():
    with open(os.path.join(ROOT, "brand", "icon-256.png"), "rb") as fh:
        return "data:image/png;base64," + base64.b64encode(fh.read()).decode()


CSS = """@page{size:105mm 148mm;margin:0}*{box-sizing:border-box}body{margin:0;background:#dfe6ee;font:11pt/1.4 system-ui,-apple-system,Segoe UI,sans-serif;color:#0b1d30}
.page{width:105mm;height:148mm;background:#fff;margin:8mm auto;padding:9mm;position:relative;overflow:hidden;page-break-after:always;border:1px solid #c5d3e0}
.page:before{content:"";position:absolute;inset:3mm;border:.4mm solid #13a8b8;border-radius:4mm;pointer-events:none}
.logo{display:flex;align-items:center;gap:4mm}.logo img{width:15mm;height:15mm;border-radius:3.5mm}.logo b{font-size:15pt;letter-spacing:.18em;font-weight:500}.logo span{display:block;font-size:8pt;color:#52677c;letter-spacing:.02em}
h2{font-size:12pt;margin:6mm 0 2mm;color:#007f8a}ol,ul{margin:1mm 0;padding-left:5mm}li{margin:1.2mm 0;font-size:9.5pt}
.qr{margin:4mm auto 2mm;width:52mm;height:52mm;display:block}.qrbox{border:.3mm solid #cfdbe6;border-radius:3mm;padding:3mm;width:58mm;margin:3mm auto 0;text-align:center}
.url{font:8pt ui-monospace,Menlo,Consolas,monospace;word-break:break-all;text-align:center;color:#0b1d30;margin-top:1mm}
.pending{width:52mm;height:52mm;margin:4mm auto 2mm;border:.5mm dashed #c2185b;color:#c2185b;display:flex;align-items:center;justify-content:center;text-align:center;font-size:9pt;padding:4mm}
.note{font-size:8.5pt;color:#34495e;border:.3mm solid #ffb02e;border-radius:2mm;padding:2mm 3mm;margin-top:3mm}
.small{font-size:8pt;color:#52677c}.stamp{position:absolute;right:7mm;top:7mm;font-size:7pt;color:#c2185b;border:.3mm solid #c2185b;padding:.5mm 2mm;border-radius:1mm}
@media print{body{background:#fff}.page{margin:0;border:0}}"""


def card_html(qr_svg, url, template):
    front = f"""<div class="page"><div class="logo"><img src="{icon_data_uri()}" alt=""><div><b>PRIYA KEY</b><span>a key that locks your private folders</span></div></div>
<h2>Set it up in three steps</h2>
<ol><li><b>Scan</b> this code with the phone or computer you will use.</li><li><b>Install</b> the app from the page that opens.</li><li><b>Then plug the key in</b> and follow the screen.</li></ol>
{('<div class="pending">QR code will appear here once the setup page address is known</div>' if template else '<div class="qrbox">' + qr_svg + '<div class="url">' + html.escape(url) + '</div></div>')}
<p class="note"><b>The key cannot install the app by itself.</b> Opening the setup page first is required. No account is needed and the app never uses the internet. On Windows, choose the <b>complete package</b> if the PC is offline.</p>
{('<div class="stamp">TEMPLATE — NOT FOR PRINTING</div>' if template else '')}</div>"""
    back = """<div class="page"><div class="logo"><img src="%s" alt=""><div><b>PRIYA KEY</b><span>keep this side</span></div></div>
<h2>Good to know</h2>
<ul><li>You choose a <b>four-digit PIN</b> and press the key's <b>BOOT</b> button once during setup.</li>
<li>Write the <b>recovery code</b> on paper and keep it away from the key. It opens a protected folder that still exists; it cannot bring back a deleted one.</li>
<li>Pressing <b>BOOT</b> later locks everything at once; press it again and enter the PIN to continue.</li>
<li>Unplugging the key locks everything.</li>
<li>Your original files are never deleted automatically.</li></ul>
<h2>If the page does not open</h2><p class="small">Check that the address printed on the front is typed exactly, or ask the person who gave you this card.</p></div>""" % icon_data_uri()
    return f'<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Priya Key card</title><style>{CSS}</style></head><body>{front}{back}</body></html>'


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--url")
    g.add_argument("--template", action="store_true")
    ap.add_argument("--out", default=os.path.join(ROOT, "qr-card", "out"))
    a = ap.parse_args(argv)
    if a.url:
        try:
            url = validate_url(a.url)      # validate BEFORE touching the disk
        except BadUrl as e:
            print(f"REFUSED: {e}. No QR code was made.", file=sys.stderr)
            return 1
    os.makedirs(a.out, exist_ok=True)
    if a.template:
        with open(os.path.join(a.out, "card-template.html"), "w", encoding="utf-8") as fh:
            fh.write(card_html("", "", True))
        print("template written (no QR code: the setup page address is not known yet)")
        return 0
    import segno
    q = segno.make(url, error="m", micro=False)
    svg_path, png_path = os.path.join(a.out, "qr.svg"), os.path.join(a.out, "qr.png")
    q.save(svg_path, scale=10, border=4, dark="#0b1d30", xmldecl=False, svgns=True)
    q.save(png_path, scale=12, border=4, dark="#000000")
    with open(svg_path, encoding="utf-8") as fh:
        svg = fh.read().replace("<svg ", '<svg width="52mm" height="52mm" class="qr" ', 1)
    with open(os.path.join(a.out, "card.html"), "w", encoding="utf-8") as fh:
        fh.write(card_html(svg, url, False))
    print(f"card written to {a.out} for {url}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
