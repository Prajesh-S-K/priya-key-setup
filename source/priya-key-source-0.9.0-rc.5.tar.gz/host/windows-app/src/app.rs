use gp_windows::controller::{Controller, Mounter, UiEvent};
use gp_windows::fs::WinFspMounter;
use gp_windows::ui::{self, BRIDGE_JS, DASHBOARD_HTML};
use gp_app::vfs::Vfs;
use std::io::Write;
use std::net::{TcpListener, TcpStream};
use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use std::time::Duration;
use tao::event::{Event, WindowEvent};
use tao::event_loop::{ControlFlow, EventLoopBuilder, EventLoopProxy};
use tao::window::{Icon, WindowBuilder};
use tray_icon::menu::{Menu, MenuEvent, MenuId, MenuItem, PredefinedMenuItem};
use tray_icon::{TrayIconBuilder, TrayIconEvent};
use vault_core::storage::DiskStorage;
use wry::WebViewBuilder;

const ICON_RGBA: &[u8] = include_bytes!("../assets/icon64.rgba");
const INSTANCE_ADDR: &str = "127.0.0.1:47613";

/// WinFsp may be missing; the dashboard still works and reports it when a folder is unlocked.
struct MaybeMounter(Option<WinFspMounter>, String);

impl Mounter for MaybeMounter {
    fn mount(&mut self, id: &str, label: &str, vfs: Arc<Vfs<DiskStorage>>) -> Result<String, String> {
        match &mut self.0 {
            Some(m) => m.mount(id, label, vfs),
            None => Err(self.1.clone()),
        }
    }
    fn unmount(&mut self, id: &str) {
        if let Some(m) = &mut self.0 {
            m.unmount(id);
        }
    }
    fn problem(&self) -> Option<String> {
        self.0.is_none().then(|| self.1.clone())
    }
}

enum Ev {
    Resolve(u64, String),
    Show,
    Lock,
    Quit,
    Tip(String),
    Ui(UiEvent),
}

fn home() -> PathBuf {
    std::env::var_os("APPDATA").map(PathBuf::from).unwrap_or_else(std::env::temp_dir).join("PriyaKey")
}

/// First instance listens on a loopback port; a second start asks it to show its window and exits.
fn single_instance(proxy: EventLoopProxy<Ev>) -> bool {
    match TcpListener::bind(INSTANCE_ADDR) {
        Ok(l) => {
            std::thread::spawn(move || {
                for _ in l.incoming().flatten() {
                    let _ = proxy.send_event(Ev::Show);
                }
            });
            true
        }
        Err(_) => {
            if let Ok(mut s) = TcpStream::connect(INSTANCE_ADDR) {
                let _ = s.write_all(b"show");
            }
            false
        }
    }
}

pub fn run() {
    let start_hidden = std::env::args().any(|a| a == "--tray");
    let event_loop = EventLoopBuilder::<Ev>::with_user_event().build();
    let proxy = event_loop.create_proxy();
    if !single_instance(proxy.clone()) {
        return;
    }

    let mounter = match WinFspMounter::new() {
        Ok(m) => MaybeMounter(Some(m), String::new()),
        Err(e) => MaybeMounter(None, e),
    };
    let ctl = Arc::new(Mutex::new(Controller::new(home(), mounter).expect("cannot open the application folder")));

    let (ticker, tip_proxy) = (ctl.clone(), proxy.clone());
    std::thread::spawn(move || {
        let mut last = String::new();
        loop {
            let slow = ticker.try_lock().map(|c| c.is_concealed()).unwrap_or(false);
            std::thread::sleep(Duration::from_millis(if slow { 2000 } else { 500 }));   // concealed: only watch for the key's return
            if let Ok(mut c) = ticker.try_lock() {
                c.tick();
                for u in c.take_ui() {
                    let _ = tip_proxy.send_event(Ev::Ui(u));
                }
                let t = c.summary();
                if t != last {
                    last = t.clone();
                    let _ = tip_proxy.send_event(Ev::Tip(t));
                }
            }
        }
    });

    let icon = Icon::from_rgba(ICON_RGBA.to_vec(), 64, 64).ok();
    let window = WindowBuilder::new()
        .with_title("Priya Key")
        .with_window_icon(icon)
        .with_visible(!start_hidden)
        .with_inner_size(tao::dpi::LogicalSize::new(1100.0, 760.0))
        .build(&event_loop)
        .unwrap();

    // Tray: left click shows the window; menu has Open / Lock all / Quit. Closing the window only hides it.
    let (open_id, lock_id, quit_id) = (MenuId::new("open"), MenuId::new("lock"), MenuId::new("quit"));
    let (mp, tp) = (proxy.clone(), proxy.clone());
    let (oi, li, qi) = (open_id.clone(), lock_id.clone(), quit_id.clone());
    MenuEvent::set_event_handler(Some(move |e: MenuEvent| {
        let _ = mp.send_event(if e.id == oi { Ev::Show } else if e.id == li { Ev::Lock } else if e.id == qi { Ev::Quit } else { return });
    }));
    TrayIconEvent::set_event_handler(Some(move |e: TrayIconEvent| {
        if let TrayIconEvent::Click { button: tray_icon::MouseButton::Left, button_state: tray_icon::MouseButtonState::Up, .. } = e {
            let _ = tp.send_event(Ev::Show);
        }
    }));
    let make_tray = move || {
        let menu = Menu::new();
        let _ = menu.append_items(&[
            &MenuItem::with_id(open_id.clone(), "Open Priya Key", true, None),
            &MenuItem::with_id(lock_id.clone(), "Lock all folders", true, None),
            &PredefinedMenuItem::separator(),
            &MenuItem::with_id(quit_id.clone(), "Quit (locks everything)", true, None),
        ]);
        TrayIconBuilder::new()
            .with_menu(Box::new(menu))
            .with_menu_on_left_click(false)
            .with_tooltip("Priya Key: locked")
            .with_icon(tray_icon::Icon::from_rgba(ICON_RGBA.to_vec(), 64, 64).expect("icon"))
            .build()
            .ok()
    };
    // Discreet mode + autostart with no key attached: no window and no tray until the key returns (or the user launches by hand).
    ctl.lock().unwrap().start_concealed();
    let mut concealed = ctl.lock().unwrap().is_concealed();
    let mut tray = if concealed { None } else { make_tray() };
    if concealed {
        window.set_visible(false);
    }

    let page = ctl.lock().unwrap().dashboard_html(DASHBOARD_HTML);
    let page2 = page.clone();
    let handler_ctl = ctl.clone();
    let hp = proxy.clone();
    let webview = WebViewBuilder::new()
        .with_html(page.clone())
        .with_initialization_script(BRIDGE_JS)
        .with_navigation_handler(|u| u.starts_with("about:") || u.starts_with("data:") || u.contains("wry.localhost"))
        .with_ipc_handler(move |req| {
            let Some(r) = ui::parse_req(req.body()) else { return };
            let (ctl, proxy) = (handler_ctl.clone(), hp.clone());
            std::thread::spawn(move || {
                let out = match r.kind.as_str() {
                    "api" => ctl.lock().unwrap().handle(&r.body),
                    "native" => ui::native_call(&r.name, &r.body),
                    _ => "null".into(),
                };
                let _ = proxy.send_event(Ev::Resolve(r.id, out));
            });
        })
        .build(&window)
        .expect("The WebView2 runtime is required");

    event_loop.run(move |event, _, flow| {
        *flow = ControlFlow::Wait;
        match event {
            Event::UserEvent(Ev::Resolve(id, text)) => {
                let lit = serde_json::to_string(&text).unwrap();
                let _ = webview.evaluate_script(&format!("window.__gpResolve({id},{lit})"));
            }
            Event::UserEvent(Ev::Show) => {
                // Manual launch / tray click always works, including from the concealed state.
                ctl.lock().unwrap().manual_show();
                if concealed {
                    concealed = false;
                    let _ = webview.load_html(&page2);
                }
                if tray.is_none() {
                    tray = make_tray();
                }
                window.set_visible(true);
                window.set_minimized(false);
                window.set_focus();
            }
            Event::UserEvent(Ev::Lock) => {
                ctl.lock().unwrap().service().lock_all("locked from the tray");
                ctl.lock().unwrap().reconcile();
            }
            Event::UserEvent(Ev::Ui(UiEvent::Conceal)) => {
                // Discreet mode: the key was unplugged and everything is already locked. Dismiss previews and the dashboard
                // (the page is replaced by a blank one), hide the window and remove the tray icon.
                concealed = true;
                let _ = webview.load_url("about:blank");
                window.set_visible(false);
                tray = None;
            }
            Event::UserEvent(Ev::Ui(UiEvent::Reveal)) => {
                // The key is back: show the dashboard again at the PIN screen (nothing is unlocked; the PIN is required).
                concealed = false;
                let _ = webview.load_html(&page2);
                if tray.is_none() {
                    tray = make_tray();
                }
                window.set_visible(true);
                window.set_focus();
            }
            Event::UserEvent(Ev::Tip(t)) => {
                if let Some(tr) = &tray {
                    let _ = tr.set_tooltip(Some(t));
                }
            }
            Event::UserEvent(Ev::Quit) => {
                ctl.lock().unwrap().shutdown();
                *flow = ControlFlow::Exit;
            }
            // The window only hides: unlocked folders stay available from the tray until Quit, unplugging or the privacy button.
            Event::WindowEvent { event: WindowEvent::CloseRequested, .. } => window.set_visible(false),
            _ => {}
        }
    });
}
