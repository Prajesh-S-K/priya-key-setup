use crate::import::{self, ImportReport};
use crate::vfs::Vfs;
use gpkey_host::{AuthResult, DevError, DevState, Device, Link};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::{Duration, Instant};
use vault_core::{crypto, recovery, DiskStorage, SlotKind, Vault};

pub type Err = String;

#[derive(Clone, Debug, Serialize, Deserialize)]
struct RegEntry {
    id: String,
    dir: PathBuf,
}

#[derive(Clone, Debug, Serialize, Deserialize, Default)]
pub struct Meta {
    pub name: String,
    pub hidden: bool,
}

#[derive(Clone, Debug, Serialize)]
pub struct Card {
    pub id: String,
    pub name: String,
    pub hidden: bool,
    /// "Locked", "Locked · Hidden", "Unlocked" or "Saving"
    pub state: String,
    pub dir: String,
}

#[derive(Clone, Debug, Serialize, PartialEq, Eq)]
pub enum Event {
    /// The device or this service locked everything. Reason is for display only.
    Locked(String),
}

/// What a platform file-system layer holds while a folder is unlocked. It MUST check `is_locked()` before every
/// operation and fail the operation once locked; `saving` must bracket every commit so the card can show "Saving".
#[derive(Clone)]
pub struct OpenVault {
    pub vfs: Arc<Vfs<DiskStorage>>,
}

impl OpenVault {
    pub fn is_locked(&self) -> bool {
        self.vfs.is_locked()
    }
}

/// Heartbeat from inside a long operation (import, restore), so the board does not time the session out meanwhile.
fn keepalive<L: Link>(dev: &mut Device<L>, last_hb: &mut Instant) -> bool {
    if last_hb.elapsed() >= Duration::from_millis(1000) {
        *last_hb = Instant::now();
        return matches!(dev.heartbeat(), Ok(true));
    }
    true
}

pub struct Service<L: Link> {
    home: PathBuf,
    dev: Device<L>,
    trusted: Option<[u8; 32]>,
    authed: bool,
    registry: Vec<RegEntry>,
    meta: HashMap<String, Meta>,
    open: HashMap<String, OpenVault>,
    reports: HashMap<String, (PathBuf, ImportReport)>,
    restored: HashMap<String, bool>,
    events: Vec<Event>,
    last_hb: Instant,
    now_fn: fn() -> u64,
}

fn hex(b: &[u8]) -> String {
    b.iter().map(|x| format!("{x:02x}")).collect()
}
fn unhex(s: &str) -> Result<Vec<u8>, Err> {
    if s.len() % 2 != 0 {
        return Err("bad hex".into());
    }
    (0..s.len() / 2).map(|i| u8::from_str_radix(&s[2 * i..2 * i + 2], 16).map_err(|_| "bad hex".to_string())).collect()
}
fn now_secs() -> u64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}
fn de(e: DevError) -> Err {
    format!("device: {e}")
}
fn ve(e: vault_core::Error) -> Err {
    format!("vault: {e}")
}

fn write_atomic(path: &Path, bytes: &[u8]) -> Result<(), Err> {
    let tmp = path.with_extension("tmp");
    std::fs::write(&tmp, bytes).map_err(|e| e.to_string())?;
    std::fs::File::open(&tmp).and_then(|f| f.sync_all()).map_err(|e| e.to_string())?;
    std::fs::rename(&tmp, path).map_err(|e| e.to_string())
}

impl<L: Link> Service<L> {
    pub fn new(home: impl Into<PathBuf>, link: L) -> Result<Self, Err> {
        let home = home.into();
        std::fs::create_dir_all(&home).map_err(|e| e.to_string())?;
        let trusted = std::fs::read_to_string(home.join("trusted_board.hex")).ok().and_then(|s| unhex(s.trim()).ok()).and_then(|v| v.try_into().ok());
        let registry = std::fs::read(home.join("registry.json")).ok().and_then(|b| serde_json::from_slice(&b).ok()).unwrap_or_default();
        let mut dev = Device::new(link);
        dev.timeout = Duration::from_secs(3);
        Ok(Service { home, dev, trusted, authed: false, registry, meta: HashMap::new(), open: HashMap::new(), reports: HashMap::new(), restored: HashMap::new(), events: vec![], last_hb: Instant::now(), now_fn: now_secs })
    }

    /// Swap in a new link (board re-plugged or unplugged). Everything is locked first and the secure session is dropped,
    /// so nothing established on the old link survives.
    pub fn replace_link(&mut self, link: L, reason: &str) {
        if self.authed || !self.open.is_empty() {
            self.lock_all(reason);
        }
        self.dev = Device::new(link);
        self.dev.timeout = Duration::from_secs(3);
    }

    /// Fetch the signed dashboard image from the board and cache it (atomically) if it verifies and is not older than the
    /// cached or bundled one. Public data: works before the PIN. Returns the version now cached.
    pub fn sync_assets(&mut self) -> Result<u16, Err> {
        self.sync_assets_with(&crate::assets::PUBLIC_KEY)
    }

    pub fn sync_assets_with(&mut self, public: &[u8; 32]) -> Result<u16, Err> {
        let img = self.dev.asset_image(crate::assets::MAX_IMAGE).map_err(de)?;
        let v = crate::assets::verify(&img, public)?;
        let cur = std::fs::read(self.home.join("dashboard.gkas")).ok().and_then(|b| crate::assets::verify(&b, public).ok()).map(|i| i.version).unwrap_or(0);
        if v.version < cur.max(crate::assets::BUNDLED_VERSION) {
            return Err(format!("the board's dashboard (v{}) is older than the installed one", v.version));
        }
        write_atomic(&self.home.join("dashboard.gkas"), &img)?;
        Ok(v.version)
    }

    /// The dashboard page to show now: verified cached board image if available, otherwise the bundled page.
    /// Returns (html, source description, version).
    pub fn dashboard(&self, bundled: &str) -> (String, String, u16) {
        crate::assets::choose(std::fs::read(self.home.join("dashboard.gkas")).ok().as_deref(), bundled, &crate::assets::PUBLIC_KEY)
    }

    /// Discreet mode (explicit user setting, default off): when the key disconnects the host closes its window/tray (Windows)
    /// or its activity (Android) in addition to locking. Stored as a tiny settings file next to the pairing record.
    pub fn discreet(&self) -> bool {
        std::fs::read(self.home.join("settings.json")).ok().and_then(|b| serde_json::from_slice::<serde_json::Value>(&b).ok()).and_then(|v| v.get("discreet").and_then(|d| d.as_bool())).unwrap_or(false)
    }

    pub fn set_discreet(&mut self, on: bool) -> Result<(), Err> {
        write_atomic(&self.home.join("settings.json"), serde_json::json!({"discreet": on}).to_string().as_bytes())
    }

    pub fn link_mut(&mut self) -> &mut L {
        &mut self.dev.link
    }
    pub fn device(&mut self) -> &mut Device<L> {
        &mut self.dev
    }
    pub fn is_authenticated(&self) -> bool {
        self.authed
    }
    pub fn is_paired(&self) -> bool {
        self.trusted.is_some()
    }
    pub fn has_recovery(&self) -> bool {
        self.home.join("recovery.pub").exists()
    }
    pub fn take_events(&mut self) -> Vec<Event> {
        std::mem::take(&mut self.events)
    }

    fn save_registry(&self) -> Result<(), Err> {
        write_atomic(&self.home.join("registry.json"), &serde_json::to_vec_pretty(&self.registry).unwrap())
    }

    // ------------------------------------------------------------------ device
    pub fn device_state(&mut self) -> Result<DevState, Err> {
        Ok(self.dev.status().map_err(de)?.state)
    }

    /// First-use pairing and provisioning (architecture 3.4). `wait` is the BOOT-press window. The pending record is
    /// written before PROV_CONFIRM so an interrupted pairing can resume without changing the board.
    pub fn pair(&mut self, pin: &str, wait: Duration, mut on_wait: Option<&mut dyn FnMut(&mut L)>) -> Result<[u8; 32], Err> {
        let st = self.dev.status().map_err(de)?;
        let provisioned = st.provisioned();
        let end = Instant::now() + wait;
        let mut next = Instant::now();
        loop {
            if Instant::now() >= next {
                self.dev.pair_request().map_err(de)?;
                next = Instant::now() + Duration::from_secs(20);
            }
            if self.dev.status().map_err(de)?.pair_authorized() {
                break;
            }
            if Instant::now() > end {
                return Err("the BOOT button was not pressed in time".into());
            }
            if let Some(f) = on_wait.as_mut() {
                f(&mut self.dev.link);
            }
            std::thread::sleep(Duration::from_millis(250));
        }
        let key = self.dev.open_nx().map_err(de)?;
        write_atomic(&self.home.join("pending_pairing.hex"), hex(&key).as_bytes())?;
        if !provisioned {
            let s = self.dev.provision_pin(pin).map_err(de)?;
            if s != 0 {
                return Err(format!("the board refused PIN setup (status {s})"));
            }
        }
        self.dev.open_nk(&key).map_err(de)?;
        match self.dev.auth(pin).map_err(de)? {
            AuthResult::Ok => {}
            other => return Err(format!("authentication failed: {other:?}")),
        }
        if self.dev.confirm().map_err(de)? != 0 {
            return Err("the board did not confirm".into());
        }
        write_atomic(&self.home.join("trusted_board.hex"), hex(&key).as_bytes())?;
        let _ = std::fs::remove_file(self.home.join("pending_pairing.hex"));
        self.trusted = Some(key);
        self.authed = true;
        self.refresh_meta()?;
        Ok(key)
    }

    pub fn auth(&mut self, pin: &str) -> Result<AuthResult, Err> {
        let key = self.trusted.ok_or("this computer is not paired with a board yet")?;
        self.dev.open_nk(&key).map_err(de)?;
        let r = self.dev.auth(pin).map_err(de)?;
        if r == AuthResult::Ok {
            self.authed = true;
            self.last_hb = Instant::now();
            self.refresh_meta()?;
        }
        Ok(r)
    }

    pub fn change_pin(&mut self, old: &str, new: &str) -> Result<AuthResult, Err> {
        if !self.authed {
            return Err("not authenticated".into());
        }
        self.dev.change_pin(old, new).map_err(de)
    }

    /// Call every ~500 ms. Sends heartbeats and turns a device lock, a USB removal or any link error into a full lock.
    pub fn tick(&mut self) {
        if !self.authed {
            return;
        }
        if self.last_hb.elapsed() >= Duration::from_millis(1000) {
            self.last_hb = Instant::now();
            match self.dev.heartbeat() {
                Ok(true) => {}
                Ok(false) => self.lock_all("the board refused the heartbeat"),
                Err(e) => self.lock_all(&format!("link lost or device locked ({e})")),
            }
        }
        if self.authed {
            if self.dev.poll(Duration::from_millis(20)).is_err() {
                self.lock_all("link lost");
            } else if !self.dev.has_session() {
                self.lock_all("the board locked (privacy button)");
            }
        }
    }

    /// Reject new access at once, drop every open vault (keys are zeroized when the vault is dropped), end the session.
    pub fn lock_all(&mut self, reason: &str) {
        for ov in self.open.values() {
            ov.vfs.lock();
        }
        self.open.clear();
        self.meta.clear();
        if self.authed {
            let _ = self.dev.lock();
        }
        self.authed = false;
        self.events.push(Event::Locked(reason.into()));
    }

    // ------------------------------------------------------------------ vault helpers
    fn entry(&self, id: &str) -> Result<RegEntry, Err> {
        self.registry.iter().find(|e| e.id == id).cloned().ok_or_else(|| "unknown folder".to_string())
    }

    fn open_raw(&mut self, id: &str) -> Result<Vault<DiskStorage>, Err> {
        if !self.authed {
            return Err("locked: authenticate first".into());
        }
        let e = self.entry(id)?;
        let vid: [u8; 16] = unhex(id)?.try_into().map_err(|_| "bad id".to_string())?;
        let kek = self.dev.get_kek(&vid).map_err(de)?;
        Vault::open(DiskStorage::open(&e.dir).map_err(ve)?, &kek).map_err(ve)
    }

    fn refresh_meta(&mut self) -> Result<(), Err> {
        self.meta.clear();
        let ids: Vec<String> = self.registry.iter().map(|e| e.id.clone()).collect();
        for id in ids {
            let v = self.open_raw(&id)?;
            let m = v.read_file(".gp/meta.json").ok().and_then(|b| serde_json::from_slice::<Meta>(&b).ok()).unwrap_or(Meta { name: "(unnamed)".into(), hidden: false });
            self.meta.insert(id, m);
        }
        Ok(())
    }

    fn write_meta(v: &mut Vault<DiskStorage>, m: &Meta, now: u64) -> Result<(), Err> {
        v.put_file(".gp/meta.json", &serde_json::to_vec(m).unwrap(), now).map_err(ve)
    }

    // ------------------------------------------------------------------ recovery
    /// Creates the recovery key pair. The secret code is returned ONCE and never stored; only the public key is kept.
    pub fn setup_recovery(&mut self) -> Result<String, Err> {
        if self.has_recovery() {
            return Err("recovery is already set up (use rotate_recovery to replace it)".into());
        }
        let (sk, pk) = recovery::generate();
        write_atomic(&self.home.join("recovery.pub"), hex(&pk).as_bytes())?;
        Ok(recovery::encode_secret(&sk))
    }

    /// New recovery secret; re-wraps every vault. Old copies of vault headers still open with the OLD secret.
    pub fn rotate_recovery(&mut self) -> Result<String, Err> {
        if !self.authed {
            return Err("not authenticated".into());
        }
        let (sk, pk) = recovery::generate();
        let ids: Vec<String> = self.registry.iter().map(|e| e.id.clone()).collect();
        for id in ids {
            let mut v = self.open_raw(&id)?;
            v.replace_recovery_pk(&pk).map_err(ve)?;
        }
        write_atomic(&self.home.join("recovery.pub"), hex(&pk).as_bytes())?;
        Ok(recovery::encode_secret(&sk))
    }

    fn recovery_pk(&self) -> Result<[u8; 32], Err> {
        let s = std::fs::read_to_string(self.home.join("recovery.pub")).map_err(|_| "set up the recovery secret first".to_string())?;
        unhex(s.trim())?.try_into().map_err(|_| "bad recovery key".to_string())
    }

    /// Open a vault (for example one made for a previous board) with the recovery code and re-wrap it for THIS board.
    pub fn recover_vault(&mut self, dir: &Path, code: &str) -> Result<String, Err> {
        if !self.authed {
            return Err("not authenticated".into());
        }
        let sk = recovery::decode_secret(code).map_err(ve)?;
        let mut v = Vault::open_with_recovery_secret(DiskStorage::open(dir).map_err(ve)?, &sk).map_err(|_| "that recovery code does not open this folder".to_string())?;
        let vid = v.vault_id();
        let kek = self.dev.get_kek(&vid).map_err(de)?;
        v.replace_slot(SlotKind::Board, &kek).map_err(ve)?;
        let id = hex(&vid);
        if !self.registry.iter().any(|e| e.id == id) {
            self.registry.push(RegEntry { id: id.clone(), dir: dir.into() });
            self.save_registry()?;
        }
        let m = v.read_file(".gp/meta.json").ok().and_then(|b| serde_json::from_slice::<Meta>(&b).ok()).unwrap_or_default();
        self.meta.insert(id.clone(), m);
        Ok(id)
    }

    /// Verified copy of the encrypted folder into `dest_parent`. The folder must be locked (no writes during the copy).
    pub fn export_vault(&mut self, id: &str, dest_parent: &Path) -> Result<crate::backup::BackupReport, Err> {
        if self.open.contains_key(id) {
            return Err("lock the folder first, then make the backup".into());
        }
        let e = self.entry(id)?;
        let name = e.dir.file_name().ok_or("bad folder")?.to_owned();
        let authed = self.authed;
        let (dev, last_hb) = (&mut self.dev, &mut self.last_hb);
        Ok(crate::backup::copy_verified(&e.dir, &dest_parent.join(name), &mut || !authed || keepalive(dev, last_hb)))
    }

    /// Register an encrypted folder that already sits at `dir` (for example restored from a backup) after proving that THIS
    /// board's key opens it. A folder made for another board needs `recover_vault` with the recovery code instead.
    pub fn link_vault(&mut self, dir: &Path) -> Result<String, Err> {
        if !self.authed {
            return Err("not authenticated".into());
        }
        let mut st = DiskStorage::open(dir).map_err(ve)?;
        let vid = Vault::peek_id(&mut st).map_err(|_| "that folder is not an encrypted Gift Key folder".to_string())?;
        let id = hex(&vid);
        if self.registry.iter().any(|e| e.id == id) {
            return Err("this encrypted folder is already in the list".into());
        }
        let kek = self.dev.get_kek(&vid).map_err(de)?;
        let v = Vault::open(st, &kek).map_err(|_| "this board's key does not open that folder (it was made for another board: use the recovery code)".to_string())?;
        let m = v.read_file(".gp/meta.json").ok().and_then(|b| serde_json::from_slice::<Meta>(&b).ok()).unwrap_or_default();
        self.registry.push(RegEntry { id: id.clone(), dir: dir.into() });
        self.save_registry()?;
        self.meta.insert(id.clone(), m);
        Ok(id)
    }

    /// Restore from a backup made by `export_vault`: verified copy into `vault_parent`, then `link_vault`. The copy is removed
    /// again if this board cannot open it.
    pub fn restore_backup(&mut self, src: &Path, vault_parent: &Path) -> Result<(String, crate::backup::BackupReport), Err> {
        if !self.authed {
            return Err("not authenticated".into());
        }
        let dest = vault_parent.join(src.file_name().ok_or("bad folder")?);
        let (dev, last_hb) = (&mut self.dev, &mut self.last_hb);
        let rep = crate::backup::copy_verified(src, &dest, &mut || keepalive(dev, last_hb));
        if !rep.verified {
            let _ = std::fs::remove_dir_all(&dest);
            return Err(rep.errors.join("; "));
        }
        match self.link_vault(&dest) {
            Ok(id) => Ok((id, rep)),
            Err(e) => {
                let _ = std::fs::remove_dir_all(&dest);
                Err(e)
            }
        }
    }

    // ------------------------------------------------------------------ folders
    pub fn cards(&self, show_hidden: bool) -> Vec<Card> {
        let mut out = vec![];
        for e in &self.registry {
            let Some(m) = self.meta.get(&e.id) else { continue };
            if m.hidden && !show_hidden {
                continue;
            }
            let state = match self.open.get(&e.id) {
                Some(ov) if ov.vfs.is_saving() => "Saving",
                Some(_) => "Unlocked",
                None if m.hidden => "Locked · Hidden",
                None => "Locked",
            };
            out.push(Card { id: e.id.clone(), name: m.name.clone(), hidden: m.hidden, state: state.into(), dir: e.dir.display().to_string() });
        }
        out.sort_by(|a, b| a.name.cmp(&b.name));
        out
    }

    /// Create a protected folder, optionally importing `source`. The original files are NOT touched.
    pub fn add_folder(&mut self, source: Option<&Path>, vault_parent: &Path, name: &str, hidden: bool) -> Result<(String, Option<ImportReport>), Err> {
        if !self.authed {
            return Err("not authenticated".into());
        }
        let pk = self.recovery_pk()?;
        let vid: [u8; 16] = crypto::random();
        let kek = self.dev.get_kek(&vid).map_err(de)?;
        let tag: [u8; 4] = crypto::random();
        let dir = vault_parent.join(format!("{}.gpv", hex(&tag)));
        let mut v = Vault::create_full(DiskStorage::open(&dir).map_err(ve)?, vid, &[(SlotKind::Board, kek)], Some(pk)).map_err(ve)?;
        let m = Meta { name: name.into(), hidden };
        Self::write_meta(&mut v, &m, (self.now_fn)())?;
        let (dev, last_hb) = (&mut self.dev, &mut self.last_hb);
        let report = source.map(|s| import::import_folder(&mut v, s, &mut || keepalive(dev, last_hb)));
        let id = hex(&vid);
        self.registry.push(RegEntry { id: id.clone(), dir });
        self.save_registry()?;
        self.meta.insert(id.clone(), m);
        if let (Some(r), Some(s)) = (&report, source) {
            self.reports.insert(id.clone(), (s.to_path_buf(), r.clone()));
        }
        Ok((id, report))
    }

    pub fn delete_originals(&mut self, id: &str) -> Result<(usize, Vec<String>), Err> {
        let (src, rep) = self.reports.get(id).cloned().ok_or("no verified import to clean up")?;
        let r = import::delete_originals(&src, &rep);
        self.reports.remove(id);
        Ok(r)
    }

    pub fn unlock(&mut self, id: &str) -> Result<OpenVault, Err> {
        if let Some(ov) = self.open.get(id) {
            return Ok(ov.clone());
        }
        let v = self.open_raw(id)?;
        let ov = OpenVault { vfs: Arc::new(Vfs::new(v)) };
        self.open.insert(id.into(), ov.clone());
        Ok(ov)
    }

    pub fn lock(&mut self, id: &str) {
        if let Some(ov) = self.open.remove(id) {
            ov.vfs.lock();
        }
    }

    pub fn open_vault(&self, id: &str) -> Option<OpenVault> {
        self.open.get(id).cloned()
    }

    pub fn set_hidden(&mut self, id: &str, hidden: bool) -> Result<(), Err> {
        let mut m = self.meta.get(id).cloned().ok_or("unknown folder")?;
        m.hidden = hidden;
        let now = (self.now_fn)();
        if let Some(ov) = self.open.get(id) {
            ov.vfs.with_vault(|v| Self::write_meta(v, &m, now)).map_err(|e| format!("{e:?}"))??;
        } else {
            let mut v = self.open_raw(id)?;
            Self::write_meta(&mut v, &m, now)?;
        }
        self.meta.insert(id.into(), m);
        Ok(())
    }

    pub fn rename_folder(&mut self, id: &str, name: &str) -> Result<(), Err> {
        let mut m = self.meta.get(id).cloned().ok_or("unknown folder")?;
        m.name = name.into();
        let now = (self.now_fn)();
        if let Some(ov) = self.open.get(id) {
            ov.vfs.with_vault(|v| Self::write_meta(v, &m, now)).map_err(|e| format!("{e:?}"))??;
        } else {
            let mut v = self.open_raw(id)?;
            Self::write_meta(&mut v, &m, now)?;
        }
        self.meta.insert(id.into(), m);
        Ok(())
    }

    // ------------------------------------------------------------------ browsing and previews
    pub fn browse(&mut self, id: &str, path: &str) -> Result<Vec<vault_core::Entry>, Err> {
        let ov = self.unlock(id)?;
        let mut l = ov.vfs.with_vault(|v| v.list(path).map_err(ve)).map_err(|e| format!("{e:?}"))??;
        if path.is_empty() {
            l.retain(|e| e.name != ".gp");
        }
        Ok(l)
    }

    /// Text up to 64 KiB, images up to 4 MiB (base64). Everything else is reported as binary with no content.
    pub fn preview(&mut self, id: &str, path: &str) -> Result<Preview, Err> {
        let ov = self.unlock(id)?;
        ov.vfs.with_vault(|v| -> Result<Preview, Err> {
            let st = v.stat(path).map_err(ve)?;
            let ext = path.rsplit('.').next().unwrap_or("").to_ascii_lowercase();
            let img = match ext.as_str() {
                "png" => Some("image/png"),
                "jpg" | "jpeg" => Some("image/jpeg"),
                "gif" => Some("image/gif"),
                "webp" => Some("image/webp"),
                _ => None,
            };
            if let Some(mime) = img {
                if st.size > 4 << 20 {
                    return Ok(Preview { kind: "toolarge".into(), mime: mime.into(), size: st.size, text: None, base64: None });
                }
                use base64::Engine;
                let b = v.read_file(path).map_err(ve)?;
                return Ok(Preview { kind: "image".into(), mime: mime.into(), size: st.size, text: None, base64: Some(base64::engine::general_purpose::STANDARD.encode(b)) });
            }
            let head = v.read_range(path, 0, 65536).map_err(ve)?;
            if let Ok(t) = std::str::from_utf8(&head) {
                if !head.contains(&0) {
                    return Ok(Preview { kind: "text".into(), mime: "text/plain".into(), size: st.size, text: Some(t.to_string()), base64: None });
                }
            }
            Ok(Preview { kind: "binary".into(), mime: "application/octet-stream".into(), size: st.size, text: None, base64: None })
        })
        .map_err(|e| format!("{e:?}"))?
    }

    // ------------------------------------------------------------------ remove encryption
    /// Restore the folder to `dest` and verify. The vault is NOT deleted; call `delete_vault` after reviewing the report.
    pub fn restore(&mut self, id: &str, dest: &Path) -> Result<ImportReport, Err> {
        let ov = self.unlock(id)?;
        let (dev, last_hb) = (&mut self.dev, &mut self.last_hb);
        let rep = ov.vfs.with_vault(|v| import::restore_all(v, dest, &mut || keepalive(dev, last_hb))).map_err(|e| format!("{e:?}"))??;
        self.restored.insert(id.into(), rep.verified);
        Ok(rep)
    }

    #[doc(hidden)]
    pub fn delete_vault_unchecked_for_test(&mut self, id: &str) {
        self.lock(id);
        self.registry.retain(|x| x.id != id);
        self.meta.remove(id);
    }

    pub fn mark_restored(&mut self, id: &str, verified: bool) {
        self.restored.insert(id.into(), verified);
    }

    pub fn delete_vault(&mut self, id: &str) -> Result<(), Err> {
        if self.restored.get(id) != Some(&true) {
            return Err("the restored copy has not been verified: the encrypted folder is kept".into());
        }
        let e = self.entry(id)?;
        self.lock(id);
        std::fs::remove_dir_all(&e.dir).map_err(|e| e.to_string())?;
        self.registry.retain(|x| x.id != id);
        self.meta.remove(id);
        self.restored.remove(id);
        self.save_registry()
    }
}

#[derive(Clone, Debug, Serialize)]
pub struct Preview {
    pub kind: String,
    pub mime: String,
    pub size: u64,
    pub text: Option<String>,
    pub base64: Option<String>,
}
