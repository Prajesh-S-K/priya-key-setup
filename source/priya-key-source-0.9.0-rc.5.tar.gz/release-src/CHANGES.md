# Priya Key {{VERSION}} — changes since rc.4

**Release candidate — physical-device acceptance pending.**

## Fixed: "winfsp-x64.dll was not found" at start-up (first real-device report)
- **Cause:** the Windows exe imported `winfsp-x64.dll` as a normal import. (The delay-load flag set by the WinFsp bindings does not reach our executable.) Windows therefore needed the DLL at launch, but WinFsp installs it under its own folder, which is not on PATH, and on a PC without WinFsp it is absent altogether.
- **Fix:** the DLL is now delay-loaded by the exe, and at start-up the app finds the installed copy itself (registry `InstallDir`, then the default WinFsp folders) and loads it by full path before WinFsp is initialised. Without WinFsp the app still starts and shows "WinFsp is not installed or cannot be loaded" with the places it looked in.
- **Guard:** `tools/build_windows.sh` now fails the build unless `winfsp-x64.dll` appears as a delay-load import (checked with llvm-readobj). Cannot be exercised on Windows from the build machine: **pending device verification.**

# Priya Key — changes since rc.3 (kept for history)

**Release candidate — physical-device acceptance pending.** Documentation/page-only update; app, firmware and installer logic are unchanged.

- First real-world report: Windows 11 **Smart App Control** blocked the unsigned download/installer. The setup page, ZIP README, install guide, limitations, test checklist and status now explain it: it has no "Run anyway", options are another PC / Windows 10 / switching it off knowingly (historically irreversible), and SmartScreen's "Run anyway" step is labelled as SmartScreen-only. Android is unaffected. Code signing (the real fix) is **not** done.

# Priya Key {{VERSION}} — changes since rc.2 (and the setup-page handoff update)

**Release candidate — physical-device acceptance pending.** No device was used; the board was not flashed or reconfigured.

## New
- **First-use setup page** (`setup-site/`): mobile-friendly, Windows and Android choices, concise steps, permission guidance, verification fingerprints (SHA-256 of both installers and the Android signing-certificate fingerprint), explicit statement that connecting the key cannot install the app. Relative links only; **not published** (no hosting destination was found).
- **Printable QR card kit** (`qr-card/`): template card (no QR; marked not for printing) and a tool that makes the real card only for a public https address and refuses localhost, IPs, private/placeholder/example names (writes nothing when refusing). **Final QR code: pending the publishing address.**
- **Discreet mode** (Settings, explicit, off by default). On key removal: lock all (as before), dismiss previews, close the dashboard, remove the Windows tray icon (or close the Android task, remove provider roots, stop the connection notification and foreground service). Minimal detection stays (Windows: 2 s polling process; Android: none; the app is designed to be started by Android's USB-attach prompt, which is **pending verification on a real phone**). Reconnection shows the PIN screen; a fresh PIN is always required. Manual launch always works. Not invisibility: app remains in installed-app lists, USB device stays visible, required notification/tray icon remain while connected. Android launcher entry is kept; launcher-specific hiding is documented as optional.
- Windows installer: *Desktop shortcut* is an optional component (off by default).

## Fixed
- Test helper pressed the simulated BOOT button after pairing finished, which could trip the privacy button and make controller tests flaky; presses now stop when pairing completes.
- Board-arrival retry back-off applied after successful opens (could delay a reconnection by 2 s); now only after failures.
- QR tool validated its URL after creating the output folder; it now validates first.

## Verification
See STATUS.md and `source/` logs. New tests: discreet persistence and API (gp-app), conceal/reveal/fresh-auth/manual-launch (Windows controller, against the real device-core simulator), setup-page builder and QR-card tool (Python, including a decode of the generated QR).

## Setup-page handoff (same rc.3 binaries)
- The Windows download is now a **complete ZIP** (`PriyaKey-Windows-Complete-…zip`: installer + `redist/` with WinFsp and the offline WebView2 installer + README that says to extract everything first). The page offers it first and the 2 MB installer-only download second, with accurate instructions.
- The unconditional “no internet needed after download” claim was removed from the page and the card. Now: the app itself never uses the internet; the complete package needs nothing else downloaded; installer-only may need WebView2 from Microsoft; the key's USB serial driver comes from Windows itself (not in the package).
- Android USB-attach relaunch is described everywhere as **pending verification on a real phone**, not guaranteed.
- The page links the GPL source archive and licences; the publish set is an allowlist (`tools/stage_publish.py`); `tools/verify_published.py` checks a live address; `tools/finish_publish.py` makes the final QR card only after that passes.
- Tests added: ZIP contents/reproducibility, page claims, allowlist refusals (keys, backups, host state, extra files, symlinks), verifier against a local server (corrupted download, wrong fingerprint, missing link, swapped inner installer, HTTPS-only), finish step (no card without verification).
