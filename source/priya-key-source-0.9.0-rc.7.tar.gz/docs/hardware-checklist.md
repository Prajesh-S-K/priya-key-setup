# Hardware and phone compatibility checklist

Observed so far (Codex read-only Mac enumeration, port not opened): product `USB Serial`, VID:PID `1A86:7523`, `/dev/cu.usbserial-10`, matching the CH340 family, exact variant unconfirmed. Owner photo: 30-pin board, shield marked `ESP-32`, USB-C, EN and BOOT buttons. Everything else here is still to do; see [reports/m0-hardware-identification.md](../reports/m0-hardware-identification.md). Visual inspection and ordinary OS enumeration are approved. Flashing, erasing and eFuse changes are not. Items are **RUNTIME-TEST** unless labelled otherwise (labels in [README](../README.md)).

## 0. Safety rules for identification

- **Do not flash. Do not erase. Do not write eFuses.**
- **Reset warning:** DTR/RTS toggling by the bridge can reset the ESP32 when a program opens the serial port, and esptool resets the chip on connect (DOC-VERIFIED, [esptool boot-mode page](https://docs.espressif.com/projects/esptool/en/latest/esp32/advanced-topics/boot-mode-selection.html)). So even read-only esptool commands such as `chip_id` or `flash_id` can reset the board or interrupt whatever it is running. They do not modify flash, but only run them with the owner's agreement and with nothing important on the board. Prefer visual and OS-level identification first.
- Never hold BOOT while plugging in unless the step says so (BOOT low at reset enters the ROM download bootloader; DOC-VERIFIED, same page).

## 1. Minimum details to collect

| # | Detail | Why it matters |
|---|---|---|
| 1 | USB-to-serial bridge chip (marking near the USB-C connector) | Driver availability on Windows, Android library support, max baud for dashboard transfer |
| 2 | Bridge USB VID:PID | Windows driver match, Android `device_filter`, shared IDs that make auto-launch ambiguous |
| 3 | ESP32 module marking (on the metal can) | Flash size, PSRAM, chip revision |
| 4 | Chip revision (e.g., rev v1.0 / v3.0) | Some security features exist only on later revisions (DOC-VERIFIED: disabling UART ROM download is possible only on ESP32 V3, [flash encryption page](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/security/flash-encryption.html)). Informational only; we burn nothing. |
| 5 | Flash size | Dashboard partition capacity, A/B slots |
| 6 | BOOT button is wired to GPIO0; EN is the reset line | Privacy-button feasibility |
| 7 | USB-C wiring: does the board enumerate on a C-to-C cable (CC pull-down resistors)? | A board without them often won't power from a C-to-C cable. Phones may need an A-to-C OTG adapter instead. |
| 8 | Does opening the port on each OS reset the board (DTR/RTS)? | Session continuity and our handshake design |
| 9 | Phone model, Android version, USB host support, OTG power behavior | Android compatibility |

## 2. Identify the USB bridge and the ESP32 module (separately)

Two different chips are visible on a 30-pin board:

**A. USB bridge chip, next to the USB-C connector.** Small square or narrow chip. Read the printed marking with a phone camera zoom. Common markings you may see: `CP2102` / `CP2102N` (Silicon Labs), `CH340C` / `CH340G` / `CH9102F` (WCH), `FT232` (FTDI). Write down exactly what is printed. Some boards have no readable marking.

**B. ESP32 module, the metal shielded can with the antenna trace.** The can usually says `ESP32-WROOM-32`, `-32D`, `-32E`, `ESP32-WROVER` and a date code. The marking does not show flash size reliably (flash size is only confirmed by software, step 4).

Confirm with the OS (read-only):

- **Windows 11:** plug in the board with a data cable. Open Device Manager, Ports (COM & LPT), right-click the new port, Properties, Details tab, Property: Hardware Ids. Copy the `VID_xxxx&PID_xxxx` string. Also record the driver name shown on the Driver tab.
- **macOS (dev machine):** `system_profiler SPUSBDataType` lists vendor ID, product ID and name. Safe and read-only. (We will not run it until you say so.)
- **Android:** with USB host working, a USB device info app lists vendor ID and product ID (an installed third-party app is an extra install; ask first).

Commonly documented IDs, for comparison only (DOC-NOT-YET-VERIFIED: vendor documents not read): Silicon Labs CP210x is usually 10C4:EA60, WCH CH340 usually 1A86:7523, WCH CH9102 usually 1A86:55D4, FTDI FT232R usually 0403:6001. Your board may differ.

Confirm flash size and chip revision only if you agree to a reset: `esptool chip_id` and `esptool flash_id` read information from the chip. They do not write flash. They are not run in this phase.

## 3. BOOT / EN behavior checks

| Check | Method | Expected / pass |
|---|---|---|
| BOOT wired to GPIO0 | Inspect schematic or trace the button to the GPIO0 pin, or read GPIO0 in a later disposable firmware (M2/M6, not now) | BOOT low at reset enters download mode (DOC-VERIFIED), high runs flash firmware |
| BOOT readable in normal run | Disposable firmware polling GPIO0 with debounce (M6) | Press detected without resetting the board |
| EN stays reset | Press EN | Board resets (never used as privacy button) |
| Accidental download mode | Reset while BOOT is held | Board stops in ROM bootloader. Document so the owner does not do this by habit. |

## 4. Windows checks (RUNTIME-TEST)

- Driver for the bridge installs on Windows 11 without a manual download? Record driver version.
- COM port number stable across unplug/replug?
- Does opening the port reset the ESP32 (reset-on-open) and does closing it reset it (reset-on-close)? Measured separately with the uptime-based reset probe, not from boot text. Does de-asserting DTR/RTS before opening prevent either?
- Echo reliability at 115200 (the only rate the M1 firmware supports). Higher rates are a later substep (M1d) with a coordinated firmware/client mechanism.
- Behavior when the cable is pulled during a write (error codes, timing).

## 5. Android phone checklist (RUNTIME-TEST; record per phone)

| Check | How |
|---|---|
| USB host feature | `android.hardware.usb.host` present (documented requirement, [Android USB host](https://developer.android.com/develop/connectivity/usb/host)); physical test is the real answer |
| OTG power | Does the board power up from the phone, through which adapter or cable? Does it brown out when Wi-Fi/Bluetooth start (a later concern)? |
| Bridge enumerates | Appears in `UsbManager.getDeviceList()` |
| Library support | `usb-serial-for-android` opens the port, sets baud, reads/writes (it lists CP210x, CH340/CH341, FTDI and CDC/ACM) |
| Permission dialogs | `device_filter` auto-launch dialog and runtime permission dialog behave as expected |
| Reset on open | DTR/RTS behavior on this phone |
| Baud ceiling | Not measured in M1; later substep M1d |
| Background limits | What happens to the connection when the app is backgrounded or the screen is locked? |
| Doze / battery optimization | Does the heartbeat survive? |
| DocumentsProvider path | Opens in the system file picker and in at least three editing apps |

Record results as a table per phone (model, Android version, adapter, bridge, pass/fail per row). Do not generalize to other phones.

## 5b. Additional unknowns this checklist must settle
- Is any pin of the board's analog (ADC) subsystem used by other board hardware? (Our firmware will not use ADC, I2S, Wi-Fi or Bluetooth, to keep the entropy source valid; architecture §3.3.)
- Can the board reach the hardware-RNG entropy path we rely on (firmware call, RUNTIME-TEST in M2).
- Which Android permission/notification behaviors apply to a foreground service on this phone's Android version (DOC-NOT-YET-VERIFIED then RUNTIME-TEST).

## 5c. Compatibility scope and host requirements (targets, not claims)

| Platform | Target | Support claim today |
|---|---|---|
| Windows 11 | Primary | None. Untested; no machine confirmed. |
| Windows 10 | Target | None. Exact supported builds and dependencies (driver for 1A86:7523, WebView2 runtime, WinFsp, .NET/Rust runtime needs) must be verified from documentation and tested before we say it is supported (DOC-NOT-YET-VERIFIED, RUNTIME-TEST). Microsoft's support status for specific Windows 10 builds must be read, not assumed. |
| Android 11+ | Baseline | None. Aim: broad compatibility across newer phones and phones released 3–5 years ago. This is an aim. Support is recorded per tested phone only. |

For each tested Windows machine and phone, record: OS/build, bridge driver source, COM port or USB host behavior, power behavior, baud ceiling, results of the guided-setup checks. Devices not tested stay "unverified".

## 6. Decisions blocked on this checklist

Dashboard-on-board feasibility (flash size and baud), BOOT privacy button (wiring), auto-launch ambiguity (VID:PID), mobile compatibility claims, Android USB library suitability for the bridge found.
