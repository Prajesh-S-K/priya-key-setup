# M1 USB echo protocol, version 1

Status: specified and implemented in three places (Python reference, C firmware code, PowerShell client). The Python reference and the C code pass the same vectors on the Mac. Nothing has run on the board, on Windows, or on a phone. No cryptography. The CRC detects line errors only and provides no authentication or confidentiality. This protocol is a throwaway test link for M1; it is not the Noise-protected channel of the final design.

Reference implementation: [tools/gpecho/framing.py](../tools/gpecho/framing.py). Firmware code: [firmware/m1-echo/main/echo_frame.c](../firmware/m1-echo/main/echo_frame.c). Tests: [tests/test_framing.py](../tests/test_framing.py), [tests/c/test_frame.c](../tests/c/test_frame.c).

## 1. Link

UART0 of the ESP32 through the board's USB bridge. 115200 baud, 8 data bits, no parity, 1 stop bit, no flow control.

**Baud-rate scope.** The M1 firmware supports **115200 baud only**, and both clients refuse any other `--baud` / `-Baud`. Changing only the host rate would make framing failures look like bridge limits, so faster echo tests are a **later M1 substep (M1d)** that needs either a coordinated firmware/client mechanism (for example a negotiated rate change acknowledged at the old rate) or separately built firmware variants with a different compile-time rate flashed deliberately. Until then no statement about the bridge's or the phone's maximum rate is made.

## 2. Raw frame (before COBS)

All multi-byte integers are **little-endian**.

| Offset | Size | Field | Meaning |
|---|---|---|---|
| 0 | 1 | `ver` | Protocol version, must be 1 |
| 1 | 1 | `type` | Message type (section 3). Bit 7 set means the device sent it |
| 2 | 1 | `flags` | Reserved, must be 0 |
| 3 | 4 | `seq` | Sequence number chosen by the requester; a response copies it |
| 7 | 2 | `len` | Payload length in bytes, 0 to 256 |
| 9 | `len` | `payload` | |
| 9+`len` | 4 | `crc` | CRC-32 of bytes 0 through 8+`len` |

Header is 9 bytes, CRC 4 bytes. Raw size is 13 to 269 bytes: `MIN_RAW` = 13, `MAX_RAW` = 269.

## 3. Message types

| Type | Name | Direction | Payload |
|---|---|---|---|
| 0x01 | ECHO_REQ | host to device | 0 to 256 arbitrary bytes |
| 0x81 | ECHO_RSP | device to host | exact copy of the request payload, same `seq` |
| 0x02 | INFO_REQ | host to device | ignored (may be empty) |
| 0x82 | INFO_RSP | device to host | 35-byte info record (section 8), same `seq` |
| 0x83 | HELLO | device to host, unsolicited after boot | 35-byte info record, `seq` = 0 |
| 0xFF | ERR_RSP | device to host | 1 byte error code, same `seq` as the offending frame |

Bit 7 of `type` is the direction/response flag: requests have it clear, everything the device sends has it set. A device never sends a type with bit 7 clear, and treats an incoming type with bit 7 set as unknown.

ERR_RSP codes: 1 unsupported `ver`, 2 non-zero `flags`, 3 unknown `type`.

## 4. CRC variant

CRC-32/ISO-HDLC, the same CRC as zlib `crc32` and Ethernet: width 32, polynomial 0x04C11DB7, reflected input and output (reflected polynomial 0xEDB88320), initial value 0xFFFFFFFF, final XOR 0xFFFFFFFF. It covers every raw byte before the CRC field (`ver` through the last payload byte). The 4 CRC bytes are the result in little-endian order. Check value: CRC of the ASCII string `123456789` is 0xCBF43926. Further pinned values: empty input 0x00000000; `a` 0xE8B7BE43; four zero bytes 0x2144DF1C; `The quick brown fox jumps over the lazy dog` 0x414FA339. The firmware computes it bitwise (no table).

## 5. COBS framing

The raw frame is COBS-encoded (Consistent Overhead Byte Stuffing), so the encoded bytes never contain 0x00, and one 0x00 byte terminates the frame on the wire.

- Encoding: standard COBS. For input length n the output is at most n + floor(n/254) + 1 bytes. For n = 254 non-zero bytes the encoder emits `FF`, the 254 bytes, then `01`.
- Decoding is lenient about that trailing empty block (it accepts the 254-byte case with or without the final `01`) and strict about everything else: a 0x00 inside the encoded data, or a block that runs past the end, is a COBS error.
- Known vectors (raw to encoded): `00` to `01 01`; `00 00` to `01 01 01`; `00 11 00` to `01 02 11 01`; `11 22 00 33` to `03 11 22 02 33`; `11 22 33 44` to `05 11 22 33 44`; `11 00 00 00` to `02 11 01 01 01`.
- Golden frame: ECHO_REQ, `seq` 1, payload `hi` is on the wire as `03 01 01 02 01 01 01 02 02 07 68 69 54 f5 22 ba 00` (raw `01 01 00 01 00 00 00 02 00 68 69` plus CRC 0xBA22F554 little-endian).

## 6. Sizes

| Quantity | Value |
|---|---|
| Maximum payload | 256 bytes |
| Maximum raw frame | 269 bytes |
| Maximum encoded frame excluding the delimiter (`MAX_ENCODED`) | 271 bytes (= 269 + 269/254 + 1, the COBS worst case for any 269-byte input) |
| Maximum encoded frame including the delimiter | 272 bytes |
| Longest valid frame actually possible | Less than the worst case, because every real frame contains at least one zero byte (`flags`). The receive buffer is still sized to the generic bound. |

## 7. Receiver rules (identical in Python, C and PowerShell)

Bytes are accumulated until a 0x00 delimiter arrives. Then:

1. **Empty chunk** (two delimiters in a row, or a leading delimiter): ignored. Idle delimiters are harmless.
2. **Oversize:** if more than 271 non-delimiter bytes arrive before a delimiter, the receiver sets an overflow flag, discards every byte, keeps discarding until the next delimiter, counts one `oversize` error, and then continues normally. The buffer never grows beyond 271 bytes. A chunk of exactly 271 bytes is not oversize; it is decoded and normally fails as a malformed frame.
3. **Decode** the chunk with COBS. Failure is a `cobs` error.
4. **Length validation:** the decoded size must be between 13 and 269, `len` must be at most 256, and 9 + `len` + 4 must equal the decoded size exactly. Failure is a `length` error. (COBS structure errors take precedence over size errors, in every implementation.)
5. **CRC:** compute over all bytes before the CRC field and compare. Failure is a `crc` error.
6. **Version:** `ver` must be 1. Failure is a `version` error. This check comes after the CRC on purpose, so the `seq` of a CRC-valid frame can be trusted.
7. **Flags:** `flags` must be 0. Failure is a `flags` error.
8. Otherwise the frame is valid and is dispatched by `type`.

**Malformed-frame handling.** A malformed chunk is dropped whole and counted. The receiver never guesses at a partial frame, never answers a frame whose CRC failed (its `seq` cannot be trusted), and never tries to realign inside a chunk. The next delimiter is the resynchronization point: the following chunk is parsed independently. The firmware answers only two classes of problem, both after a passing CRC: wrong `ver` or non-zero `flags` (ERR_RSP codes 1 and 2) and unknown `type` (code 3). All other errors are silent drops, visible in the INFO counters.

**Transmit rule.** A sender writes `COBS(raw)` followed by one 0x00. A host should also write a single 0x00 right after opening the port and before its first frame, to end any text the device had in flight. The device writes a 0x00 before HELLO for the same reason.

## 8. INFO record (35 bytes, little-endian)

| Offset | Size | Field |
|---|---|---|
| 0 | 1 | `proto_ver` (1) |
| 1 | 2 | `max_payload` (256) |
| 3 | 4 | `uptime_ms` |
| 7 | 4 | `rx_ok`: valid frames received |
| 11 | 4 | `rx_cobs_err` |
| 15 | 4 | `rx_crc_err` |
| 19 | 4 | `rx_len_err` |
| 23 | 4 | `rx_oversize` |
| 27 | 4 | `rx_uart_err`: UART FIFO overflow, buffer full, frame error, parity error, break |
| 31 | 4 | `tx_frames`: frames sent, counting HELLO |

`rx_ok` counts frames with a valid CRC, version and flags. Frames with a valid CRC but a wrong version or non-zero flags are answered with ERR_RSP and are not included in any INFO counter in this version (the C receiver keeps internal counters for them, but INFO does not export them).

## 9. Resynchronization after ESP32 boot messages

At every reset the ESP32 ROM prints a boot banner on UART0 (for example `ets ... rst:0x1 (POWERON_RESET),boot:0x13 (SPI_FAST_FLASH_BOOT)`), which shares the line with this protocol. We cannot silence the ROM banner without an eFuse change, which is forbidden. The firmware itself prints nothing: console, bootloader and application logging are disabled at build time. The banner is plain ASCII with no 0x00 bytes, so:

- The banner and everything up to the first 0x00 form one chunk that fails decoding (COBS, length or CRC error) and is counted and dropped.
- The firmware sends a single 0x00 before its HELLO frame, which ends the banner chunk, so HELLO arrives as its own chunk.
- If the host's own first frame arrives glued to banner text with no delimiter in between, that one frame is lost with the banner chunk. The host therefore sends 0x00 first and waits for HELLO or retries. Tests cover both cases.
- Bytes received while the device is rebooting are lost; the host treats a HELLO frame appearing mid-run as a device reset.

Host-side expected behavior: after opening the port, wait up to 3 s for HELLO, send 0x00, send INFO_REQ, then proceed. Seeing ROM text after open means opening the port reset the board (this is what the reset probe measures).

## 9b. Startup failure and transmit accounting

- **Fail-stop startup.** The firmware starts in this order: install the UART driver (and require its event queue), configure it, set pins, write the leading 0x00, send HELLO. If any step fails it removes the driver, **never enters the receive loop, and never sends HELLO**; it then parks. The host sees no HELLO and no INFO response and must treat that as "echo firmware not running", not as a bridge problem.
- **`tx_frames` counts only transmissions the UART driver accepted in full.** A failed or short write increments an internal error counter and is not counted. INFO reports `tx_frames` as the number of successful transmissions before that reply (it does not include the INFO response being built, and HELLO counts once).
- All of this is implemented in `firmware/m1-echo/main/echo_app.c`, which is compiled unchanged for the host and tested with mocked hardware (`tests/c/test_app.c`) and against the Python model (`tests/test_firmware_parity.py`).

## 9c. Reset probe semantics

`echo_client.py --reset-probe N` (and `-ResetProbe N` in PowerShell) needs N ≥ 2 and distinguishes **reset-on-open** from **reset-on-close** using the firmware's own uptime (`INFO.uptime_ms`), not boot text. Absence of captured boot text or HELLO is **inconclusive** and is never reported as "no reset". Each cycle opens the port, listens about 1 s, queries INFO (A), waits 0.3 s, queries INFO (B), closes, and waits 3 s before the next open. A cycle is classified by comparing its INFO A with the previous cycle's INFO B and close time: continuous uptime means no reset; a restart after the open is reset-on-open; a restart between the previous close and this open is reset-on-close; a restart that predates the close, or a missing INFO answer, is inconclusive. When both resets occur, only the later one is attributable and the report says the earlier is masked. HELLO or boot text together with continuous uptime is reported as an anomaly. The first cycle is a baseline. See `tools/gpecho/probe.py` and `tests/test_reset_probe.py` (simulated device with a fake clock; nothing here has been run against a board).

## 10. Not specified here

Authentication, encryption, Noise, provisioning, PIN handling, key release, vault operations: none are part of M1. Baud rates other than 115200: later M1 substep M1d (see section 1). Flow control: not used. Multiple outstanding requests: the Python and PowerShell clients send one request and wait for its response.
