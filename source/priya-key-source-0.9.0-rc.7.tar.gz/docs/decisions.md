# Working decisions (routine choices made during implementation; update when evidence changes them)

| Date | Decision | Why / evidence |
|---|---|---|
| 2026-10-19 | Backup/read at 115200 baud (460800 failed with serial noise on this CH340) | M1 bring-up: gate stopped on `Invalid head of packet`; 115200 verified |
| 2026-10-19 | Explicit UART0 pins (GPIO1/3) in firmware | Console disabled leaves TX unrouted; found on hardware |
| 2026-10-19 | Noise library: vendored noise-c with local changes (minimal algorithms, ESP32 random branch, no Ed25519 tables); host uses `snow` | Interop proven: snow (spec rev 34) <-> noise-c (rev 30) for NK and NX in `host/gpkey-host/tests/device_sim.rs` |
| 2026-10-19 | HMAC-SHA256 / HKDF-SHA256 written over noise-c's SHA-256 (RFC 2104/5869), no PSA dependency | Same code must run on the host simulator; needs RFC test vectors (todo in M2 hardening) |
| 2026-10-19 | Vault journal v0: one segment file, no checkpoints, no GC yet; journal-only replay | Architecture 5.5.5 "checkpoints are accelerators"; compaction deferred |
| 2026-10-19 | After `replace_slot` both header copies are rewritten | Test showed the stale copy kept the old recovery secret openable inside the same vault directory |
| 2026-10-19 | Torn-tail classification: zero tail counts only if every non-zero byte lies within one header | Found by the byte-by-byte torn-tail test |
| 2026-10-19 | Delay tiers: 3 free failures, then 5 s, 30 s, 5 min, 30 min, 30 min | Architecture 3.5 |
| 2026-10-19 | Sim-driven integration tests use the REAL device core compiled for the host; hardware acceptance tests remain separate | Working rule: no mocks in place of hardware acceptance |
| 2026-10-19 | Android SDK licenses NOT accepted yet (an accidental acceptance was reverted) | Needs explicit owner consent |
| 2026-10-19 | Windows app: winfsp-rs 0.13 (GPL-3.0) + wry/WebView2 + tao + rfd; project licence is GPL-3.0-or-later (see LICENSE) | WinFsp is GPLv3 with a FLOSS exception; winfsp-rs is GPL-3.0. Owner may still veto. |
| 2026-10-19 | Windows volume is case-sensitive (`case_sensitive_search`), drive-letter mount (Z: downwards), no ACLs, constant 1 TiB capacity | Vault names are case-sensitive; avoids a case-folding layer. Applications that open a file with different letter case will not find it: PENDING Windows test. |
| 2026-10-19 | Windows cleanup flushes (commits) a written file at CloseHandle; `close` later only releases | WinFsp `close` can lag the application's CloseHandle; the user must not lose a save because of that. |
| 2026-10-19 | Board discovery by polling serial ports for 1A86:7523 every 500 ms (Windows); USB attach intent + permission (Android) | Simpler than device-change notifications; 1-2 s arrival delay is acceptable. |
| 2026-10-19 | Long operations (import, restore) send heartbeats from inside their loops; abort if the board session is lost | The board times the session out after 3 s; without this any import longer than 3 s would lose the session. |
| 2026-10-19 | Closing the Windows window locks everything and removes the drives | Nothing stays readable without the app running. Tray/background mode is a later option. |
| 2026-10-19 | Android: Rust core via JNI (`com.giftkey.app.Native`), USB owned by Kotlin (usb-serial-for-android 3.9.0), DocumentsProvider over `openProxyFileDescriptor`, vaults in app-private `filesDir/vaults` | Android has no mounts; the provider is the only way other apps reach decrypted content without writing plaintext to disk. |
| 2026-10-19 | Android import/restore stream through the vault file API (content URIs never reach Rust); hashes taken from the original bytes; originals deleted only if still identical | Same verify-before-delete rule as Windows. |
| 2026-10-19 | Android minSdk 30 (Android 11), targetSdk 36, ABIs arm64-v8a, armeabi-v7a, x86_64; release APK signed with a private project key (android/release.jks, git-ignored) | Baseline requirement; the key must be kept to allow in-place updates. |
| 2026-10-19 | Windows exe/installer cross-built on macOS (xwin SDK + rust-lld + NSIS 3.13 with LC_ALL=en_US.UTF-8) | makensis aborts under the default locale on this Mac. Output untested on Windows. |
