# Architecture (Phase 01, revision 2 — design only, nothing implemented)

Labels (four, see [README](../README.md)):
- **DOC-VERIFIED** — stated by an official or primary source that was read, link given.
- **PROPOSED** — our design or estimate.
- **DOC-NOT-YET-VERIFIED** — depends on a document, specification, license text or API page we have not read yet. Reading is enough to resolve it.
- **RUNTIME-TEST** — can only be settled by running something (board, Windows, phone, editor, library build).

Source-quality note: Android reference pages were too large for the fetch tool, so Android API facts come from AOSP source javadoc. Re-read the rendered pages at review time.

## 1. Components and recommended stack

| Component | Recommendation | Status |
|---|---|---|
| Firmware | ESP-IDF (C). UART link through the board's USB bridge. NVS for state. mbedTLS 4.1 PSA API (HMAC, HKDF, random). Noise responder library (noise-c candidate). No Wi-Fi, no Bluetooth, no ADC, no I2S in the firmware (§3.3). | PROPOSED |
| Shared host core ("vault-core") | Rust library: Noise initiator (`snow`), vault format, AEAD, HKDF, journal, recovery. One implementation reused on Windows and Android. | PROPOSED |
| Windows companion | Tauri 2 shell (Rust + WebView2), WinFsp for the temporary decrypted filesystem, a small always-on per-user agent (§6). | PROPOSED |
| Android companion | Kotlin app: USB host + `usb-serial-for-android`, `DocumentsProvider`, WebView dashboard, vault-core via JNI. | PROPOSED |
| Dashboard | HTML/CSS/JS bundle with a signed manifest (§8). | PROPOSED |

Facts behind this: Android provides generic USB host APIs and no serial drivers, so a library is needed (DOC-VERIFIED, [USB host guide](https://developer.android.com/develop/connectivity/usb/host)). `usb-serial-for-android` is MIT and lists CP210x, CH340/CH341, FTDI and CDC/ACM, with CH9102 listed under CDC (DOC-VERIFIED, [README](https://github.com/mik3y/usb-serial-for-android)). `snow` is Apache-2.0/MIT and states it has had no formal audit (DOC-VERIFIED, [README](https://github.com/mcginty/snow)). noise-c is MIT and describes itself as a reference implementation (DOC-VERIFIED, [README](https://github.com/rweather/noise-c)); its pattern list, hooks for a custom random source, and ESP32 footprint are DOC-NOT-YET-VERIFIED and then RUNTIME-TEST.

Dev environment (DOC-VERIFIED by command lookup, dev Mac): python3, node 22, java present; PlatformIO, esptool, adb, cargo not on PATH; no ESP32 board was enumerated by `system_profiler` or `/dev/cu.*` when checked (read-only). Missing tools are installable and do not block building. Tests of WinFsp, WebView2, Windows USB and Android USB need a Windows 11 PC and a physical phone (RUNTIME-TEST).

## 2. Trust boundaries

| Boundary | Trusted for | Not trusted for |
|---|---|---|
| ESP32 firmware and flash | Holding K_board and the private static key, enforcing PIN delays, reporting BOOT | Resisting flash extraction while flash encryption is off (§3.6) |
| USB cable and bridge chip | Nothing | Confidentiality, integrity, authenticity (Noise provides them) |
| Host native core | Holding vault keys during an unlocked session, all crypto | Anything once the host OS or process is compromised |
| Dashboard JavaScript | Rendering | Keys, paths, or privileged commands without native checks (§8.3) |
| External apps and editors | Nothing; they receive decrypted bytes and may cache them | |
| Vault store on disk | Availability only; contents are ciphertext | Rollback protection (§5.5) |
| Vault header contents (including any board key inside it) | Nothing: it is untrusted input (§7.4) | |

## 3. Authentication, PIN enforcement, entropy

### 3.1 Protocol (PROPOSED)

Noise Protocol Framework, not a custom handshake: `Noise_NK_25519_ChaChaPoly_BLAKE2s` for sessions and `Noise_NX_25519_ChaChaPoly_BLAKE2s` for first-use provisioning. The spec defines NK ("initiator knows responder's static key"), NX ("responder's static key sent encrypted"), the pattern/DH/cipher/hash naming, a 65535-byte message limit, and transport nonce rules (DOC-VERIFIED, [Noise spec](https://noiseprotocol.org/noise.html)). The exact suite strings are not listed in the spec (DOC-NOT-YET-VERIFIED against both libraries, then RUNTIME-TEST with shared vectors). NK properties from the spec table (DOC-VERIFIED): message 1 is encrypted to a known recipient and replayable; the responder's reply has sender authentication; initiator transport messages get strong forward secrecy. A replayed message 1 yields nothing because the board adds a fresh ephemeral key.

Framing (COBS plus CRC-16/32) sits outside Noise and only detects line errors. It provides no authentication.

### 3.2 Roles and what the host never holds

The board holds an X25519 static keypair, K_board (32 bytes), K_pin (32 bytes), a PIN salt and verifier. The host holds only the board's public key (pinned, §7.4). The board proves possession by completing NK. No key is derived from anything transmitted in the clear; a transmitted HMAC is never used as, or to derive, a session key.

### 3.3 Entropy (resolved by documentation; DOC-VERIFIED unless noted)

Source: [ESP-IDF random number generation](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/system/random.html).

Facts:
- `esp_random()` / `esp_fill_random()` read the hardware RNG. Output is true random only if (a) Wi-Fi or Bluetooth is enabled (the RF subsystem enables the high-speed ADC as entropy source), or (b) `bootloader_random_enable()` has been called and not yet disabled, or (c) the second-stage bootloader is running. Otherwise the output must be treated as pseudo-random only.
- The default bootloader enables the SAR-ADC entropy source at start and disables it before the application runs.
- The page notes the internal hardware state is too small for a continuous stream of true random numbers, and recommends a strong software DRBG seeded from true random hardware output when no entropy source is permanently enabled.
- `bootloader_random_enable()` uses the ADC as the entropy source and "is not safe if any other subsystem is accessing the RF subsystem or the ADC at the same time". `bootloader_random_disable()` must be called before using ADC, I2S (ESP32), or Wi-Fi/Bluetooth.

Consequence for our USB-only configuration, where Wi-Fi and Bluetooth are not started: after the application starts, `esp_random()` is pseudo-random unless we enable the entropy source ourselves. Therefore (PROPOSED):

1. **Entropy source lifecycle.** The firmware calls `bootloader_random_enable()` at application start and keeps it enabled for the firmware's lifetime. The build forbids Wi-Fi, Bluetooth, ADC and I2S use (build-time config check plus a source scan in CI). The BOOT button uses a plain GPIO read, not the ADC. If any future feature needs those subsystems, the design must be revisited: `bootloader_random_disable()` must be called first and key generation must not overlap.
2. **Random source for keys (revised after reading the ESP-IDF v6.1 source installed on the dev Mac).** v6.1 ships mbedTLS 4.1.0. Its CTR_DRBG and entropy headers sit under `mbedtls/private/`, which is not public API (DOC-VERIFIED from the local source tree). Its port configuration defines `MBEDTLS_PSA_CRYPTO_EXTERNAL_RNG`, and `mbedtls_psa_external_get_random()` calls `esp_fill_random()` directly, so `psa_generate_random()` reaches the hardware RNG with **no DRBG in between** (DOC-VERIFIED, `components/mbedtls/port/esp_hardware.c` and `esp_config.h`). Design: keep the entropy source enabled for the firmware's lifetime (item 1), which is the documented condition for true-random output; draw all long-term keys and every Noise ephemeral key through `psa_generate_random()` (public API) or `esp_fill_random()`; keep consumption small (about 150 bytes once at provisioning and tens of bytes per session), because the page says the internal hardware state is too small for a continuous true-random stream. No private-API DRBG in the first implementation. A seeded DRBG stays available as defense in depth if the review wants it, at the cost of using private headers (decision).
3. **Noise random hook.** noise-c obtains randomness in `rand_os.c`: `/dev/urandom` on Linux and macOS, `CryptGenRandom` on Windows, and on any other platform it prints "Do not know how to generate random numbers!" and calls `exit(1)`; the source offers no override macro (DOC-VERIFIED from source, [rand_os.c](https://raw.githubusercontent.com/rweather/noise-c/master/src/protocol/rand_os.c)). An ESP-IDF port therefore needs a small patch to a vendored copy adding an ESP32 branch that calls `esp_fill_random()`. RUNTIME-TEST: no code path reaches the `exit(1)` branch, and key generation and handshake randomness all come from that branch.
4. **Subsystem conflicts documented:** ADC users (including touch/hall sensing implemented with the SAR ADC), I2S, Wi-Fi and Bluetooth conflict with the entropy source per the page. We use none.
5. **Verification:** a boot self-check asserts the entropy source is enabled before any key generation. The ESP-IDF mbedTLS/PSA glue has now been read (item 2). Statistical tests (RUNTIME-TEST) are sanity checks only, for example rejecting stuck output, and are not claimed to prove entropy.
6. **Host side:** OS CSPRNG (BCryptGenRandom on Windows, SecureRandom/getrandom on Android). Not a concern of the board.

### 3.4 First-use provisioning (PROPOSED)

State machine in NVS: `EMPTY → COMPLETE_UNCONFIRMED → COMPLETE_CONFIRMED`, plus an explicit `INCONSISTENT` (fail-closed) state. Rules:

1. Provisioning is accepted only in `EMPTY` and only after a physical BOOT press within 30 s of an LED prompt.
2. Material is generated in RAM (§3.3): static keypair, K_board, K_pin, salt, and a random 16-byte `id_nonce`. The host then sends the chosen PIN inside the Noise `NX` transport.
3. **Two-step commit order, with the identity blob last.** (a) Write the PIN-attempt record `att = {version, id_nonce, attempts_since_success=0, generation=0, confirmed=false}` as one NVS blob; `nvs_commit`; read back. (b) Only then write the identity blob `id = {version, id_nonce, static keypair, K_board, K_pin, salt, PIN verifier HMAC-SHA256(K_pin, salt‖PIN)}` as one authenticated NVS blob; `nvs_commit`; read back. The `id` blob is the commit point. NVS puts at risk only the pair being written at power loss (DOC-VERIFIED, [NVS docs](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/storage/nvs_flash.html)), so after a power cut the board holds either no `id` (stale `att` is ignored and overwritten at the next provisioning) or a complete `id` whose `att` already exists with the same `id_nonce`. The PIN-attempt record is therefore initialized before the identity can exist, and an identity can never exist without its counter. If either write or read-back fails the board stays `EMPTY` and reports failure.
4. After the `id` commit the board is `COMPLETE_UNCONFIRMED` and reports success. The host then runs a follow-up `NK` handshake against the key it received, performs `AUTH`, and sends `PROV_CONFIRM`; the board durably sets `att.confirmed = true` (set, commit, read back) and becomes `COMPLETE_CONFIRMED`. The host writes its pin only after it receives the confirmation.
5. Boot rule: `id` absent and storage healthy → `EMPTY`. `id` valid and `att` present with the same `id_nonce` → `COMPLETE_UNCONFIRMED` or `COMPLETE_CONFIRMED` per `att.confirmed`. Anything else (storage init failure, corrupt `id` or `att`, missing `att` with `id` present, `id_nonce` mismatch, unexpected version) → `INCONSISTENT`. **The firmware never regenerates or erases the identity automatically.** Do not copy the ESP-IDF example pattern that calls `nvs_flash_erase()` on `ESP_ERR_NVS_NO_FREE_PAGES` or `ESP_ERR_NVS_NEW_VERSION_FOUND`; those results enter `INCONSISTENT`.
6. **Interrupted pairing: every disconnect point (resolved).** The board identity is never regenerated. The failure cases are:
   - *(a) Disconnect after the `id` commit and before `PROV_CONFIRM` is accepted.* The board is `COMPLETE_UNCONFIRMED` with its identity intact.
   - *(b) Board accepted `PROV_CONFIRM` (so `att.confirmed` is durably true) and the connection fails before the host saved its trusted key.* The board is `COMPLETE_CONFIRMED`; the host has no trusted key.
   **Host-side recoverable pairing state.** The host keeps a protected pairing store (Windows DPAPI-protected file; Android Keystore-encrypted prefs). It holds `pending_pairing = {board public key, fingerprint, created_at}` (no PIN, no secrets) and, once promoted, `trusted_board = {public key, fingerprint}`. Order of operations:
   1. After `NX` reveals the board key, the host **durably writes `pending_pairing`** (write to a temp file, flush, replace; on Android a synchronous `commit()`) **before** sending `PROV_CONFIRM`.
   2. The host sends `PROV_CONFIRM`; on the board's acknowledgment (or on a later successful verification) it **promotes** `pending_pairing` to `trusted_board` with the same durable-replace procedure, then deletes the pending record.
   3. If the host dies or disconnects at any point, startup finds `pending_pairing`. It runs `NK` against that key and `AUTH` with the owner's PIN (through the normal attempt counter). If that succeeds, the board holds the key we recorded, so the host promotes it to `trusted_board` (and sends `PROV_CONFIRM` again if the board still reports unconfirmed; idempotent). Nothing on the board changes in case (b); in case (a) only the `confirmed` bit is set.
   4. If the pending record is lost (disk loss, new computer) the host uses the **PAIR ceremony** below. A key found in a vault header is a *candidate only* and never replaces or creates trust by itself.
   **PAIR ceremony (any `COMPLETE_*` state).** For the owner who needs to pair a host, with identity unchanged:
   - The host sends an unauthenticated `PAIR_REQUEST` (harmless: it only starts a 30 s LED wait and is rate-limited). The board must be in `LOCKED` (not `ACTIVE`; in `ACTIVE` the BOOT press is the privacy button).
   - The owner presses BOOT within the window. Without that press nothing happens.
   - The board runs `NX` and reveals its **existing** static public key. No secret is created, changed or revealed; the key is public.
   - The host displays the fingerprint, requires the owner to compare it with the recovery card if one exists, then runs `NK` + `AUTH` with the PIN (write-ahead counter applies). Only after the PIN succeeds does the host save the key as `trusted_board`.
   - An attacker inside the cable during the ceremony could present a different key; they still cannot pass `AUTH` against the real board, and the fingerprint check against the recovery card catches substitution. Before any vault exists no card exists; that window is the accepted trust-on-first-use of §3.4 item 8.
   - If the PIN is unknown, pairing cannot complete; the only exit is manual reprovisioning (item 7), which destroys K_board. With no vault yet, nothing is lost.
   This replaces the earlier rule that a confirmed board never accepts `NX`: `NX` is now accepted only inside a physical-presence `PAIR_WAIT` window and reveals only the public key.
7. Leaving `INCONSISTENT`, or deliberately starting over, is a manual owner action: erase NVS by reflashing (needs separate approval) and re-provision. It destroys K_board. Vaults are then reachable only via the recovery secret (§5.6). An attacker who erases NVS and re-provisions needs physical access and a BOOT press, and a host's existing pin no longer matches, which the host shows as "board identity changed" and never silently accepts.
8. Provisioning and the unconfirmed pairing ceremony are trust-on-first-use against an attacker inside the cable. Accepted and documented; the host records the fingerprint for the recovery card.

### 3.5 Session authentication and PIN enforcement (fail closed)

Session: host opens the port, runs `Noise_NK` against the pinned key, then sends `AUTH(pin)` inside the transport. Board answers `GET_KEK(vault_id)` only in ACTIVE state:
`KEK_v = HKDF-SHA256(salt=vault_id, ikm=K_board, info="gp-vault-kek-v1")`. Opening the port can reset an ESP32 through DTR/RTS (DOC-VERIFIED, [esptool boot-mode](https://docs.espressif.com/projects/esptool/en/latest/esp32/advanced-topics/boot-mode-selection.html)); a reset ends the session and the host treats it as lock. De-asserting DTR/RTS before open is RUNTIME-TEST.

PIN enforcement algorithm (PROPOSED). Counter record `att` = one NVS blob `{version, id_nonce, attempts_since_success, generation, confirmed}`, created atomically with provisioning (§3.4 item 3). Every rewrite sets and commits the whole blob and reads it back:

1. On `AUTH`, check persisted `attempts_since_success` and the delay tier. If a delay is pending, reply `DELAYED(remaining)` with no PIN comparison.
2. **Write-ahead:** set `attempts_since_success += 1`, `generation += 1`; `nvs_set_blob`; `nvs_commit`; read back and verify. **Only if all three succeed** continue. On any failure reply `ERR_STORAGE`, do not compare the PIN, release nothing, and enter `FAIL_CLOSED` (all privileged commands refused until reboot).
3. Compare `HMAC-SHA256(K_pin, salt‖PIN)` in constant time.
4. On mismatch: reply failure with the delay tier. The persisted counter is already counted.
5. On match: persist `attempts_since_success = 0` (set, commit, read back). **Keys are released only after that succeeds.** If the reset fails or power is cut mid-reset, the counter stays incremented (conservative: the owner loses one attempt of margin), the session is not ACTIVE, and the board enters `FAIL_CLOSED` on a failure or simply reboots to the same state.
6. NVS init failure at boot, read failure of `att`, corrupted `att`, or an `id_nonce` mismatch with `id` → `INCONSISTENT`/`FAIL_CLOSED`. Never default the counter to zero, never erase or reinitialize storage as generic error recovery.
7. Delay schedule (proposed): attempts 1–3 free, then 5 s, 30 s, 5 min, 30 min, then 30 min each. Delay is recomputed from `attempts_since_success` at boot and measured from boot, so reset does not shorten a tier. No automatic wipe.
8. Persistence: the counter survives reset and USB removal. NVS tolerates power loss at any point with only the in-flight pair at risk (DOC-VERIFIED NVS docs). Write endurance: wear-leveling is limited; frequently rewritten data accelerates wear (DOC-VERIFIED NVS docs). Guesses are rare events, so wear is acceptable; confirm by a bounded RUNTIME-TEST.

Honest limit: flash is not encrypted and we will not burn eFuses. Without NVS encryption anyone with physical access can read, alter, erase or add pairs (DOC-VERIFIED NVS docs). The flash-encryption feature is not directly compatible with NVS without separate NVS encryption, release mode is irreversible, and development mode allows three plaintext reflashes (DOC-VERIFIED, [flash encryption](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/security/flash-encryption.html)). A thief with the board and vault files and flash tools can read K_board and reset counters. The 4-digit PIN verifier is brute-forceable from a flash dump and no KDF fixes a 10^4 space. Accepted for development.

### 3.6 Irreversible settings (PROPOSED)

No eFuse writes, secure boot, flash encryption, JTAG disable, or permanent UART-download disable during development. Revisit only with explicit owner approval and a spare board.

### 3.7 Dependency licenses (DOC-NOT-YET-VERIFIED)

Read licenses before relying on: noise-c, snow, RustCrypto crates, usb-serial-for-android, Tauri, WebView2 redistribution, any ESP-IDF components. WinFsp: §9.1. "Personal gift" does not remove obligations that attach when a copy is handed to someone else; legal review is flagged.

## 4. Lifecycle ordering, heartbeat and control path

States (PROPOSED): `EMPTY | LOCKED | AUTHENTICATING | ACTIVE | PRIVACY | FAIL_CLOSED | INCONSISTENT`.

### 4.1 First BOOT press (board side, exact order)
1. Set `privileged_disabled = true` in RAM. Every command handler checks this flag first. `AUTH`, `GET_KEK`, heartbeat-acks and all privileged commands now return `PRIVACY`.
2. Send the authenticated `LOCK` message **using the still-live Noise transport state**. Wait up to 50 ms for the UART TX queue to drain. A failure (cable gone) does not block step 3.
3. Zeroize the Noise session keys and handshake state.
4. Enter `PRIVACY`. The board keeps the physical button watch and an unprivileged status channel (§4.3), and refuses any new handshake.

### 4.2 Heartbeat and timing targets (PROPOSED; RUNTIME-TEST measures them)
- Host sends `HEARTBEAT` every 1 s; board answers. Both are Noise transport messages.
- Board: no valid host message for 3 s → end session, `privileged_disabled = true`, back to `LOCKED`.
- Host: 3 missed heartbeat replies, a `LOCK` message, USB removal notification, or a serial error → start the lock sequence (§6).
- Targets: BOOT press to board `privileged_disabled` ≤ 20 ms; BOOT press to host rejecting new opens ≤ 300 ms with a healthy link; USB removal to host lock ≤ 250 ms after the OS notification; worst case heartbeat-loss to lock ≤ 3.5 s. These are goals, not measurements.

### 4.3 Control path for the second press
"Disabling the application service" must not leave the second press with nobody to hear it. Split the host into two parts:
- **Gatekeeper agent** (Windows per-user background/tray process; Android foreground service with a notification): tiny, holds no vault keys, keeps the port open during `PRIVACY`.
- **Service** (WinFsp mount, DocumentsProvider roots, dashboard window): stopped/hidden on lock.

In `PRIVACY` the board sends an **unauthenticated status event** on press: `STATE=LOCKED`. It confers no privilege: the second press only moves the board `PRIVACY → LOCKED`; entering `ACTIVE` always needs a new Noise session and the PIN. A fake device can at most make the UI show a PIN prompt, after which Noise-to-pinned-key fails. The gatekeeper then restarts the service, which shows the PIN screen.
Android limits (DOC-NOT-YET-VERIFIED): foreground-service types, notification/full-screen-intent permissions, and background activity launch limits on Android 11+ must be read before M6. If the agent cannot show UI from the background, the status is a notification the user taps.

## 5. Keys, vault format, recovery

### 5.1 Granularity
One protected folder is one vault: own `vault_id` (16 random bytes) and vault key VK (32 random bytes from the OS CSPRNG).

### 5.2 Algorithms (PROPOSED; library versions RUNTIME-TEST)

| Purpose | Algorithm | Binding |
|---|---|---|
| Records, chunks, index, wraps | XChaCha20-Poly1305 (IETF, 192-bit nonce) | RustCrypto `chacha20poly1305` in vault-core on both platforms |
| Key derivation | HKDF-SHA256 | `hkdf`/`sha2` in vault-core; mbedTLS on the board |
| Session | Noise NK/NX (ChaChaPoly, BLAKE2s, X25519) | `snow` / noise-c |

libsodium lists XChaCha20-Poly1305-IETF with random nonces safe, and also AES256-GCM, ChaCha20-Poly1305 and AEGIS variants; it does not list AES-GCM-SIV (DOC-VERIFIED, [libsodium AEAD](https://doc.libsodium.org/secret-key_cryptography/aead)). No PIN or recovery KDF is needed (board owns the PIN; recovery secret is generated with 128 bits).

### 5.3 Key hierarchy
```
K_board --HKDF(vault_id)--> KEK_board_v ┐
Recovery secret R --HKDF(vault_id)--> KEK_rec_v ┤ each wraps the same VK
VK --HKDF("meta")--> K_meta (index, journal, checkpoints)
VK --HKDF("jmac")--> K_jmac (journal segment header MAC)
VK --HKDF("file"||file_id)--> K_file
```
Wrap slot: `nonce(24) ‖ AEAD(KEK, VK, aad="gp-wrap-v1"‖vault_id‖slot_type‖slot_id)`. Header is stored A/B; higher valid generation wins.

### 5.4 Chunks and file data
- Chunk: plaintext ≤ 64 KiB. Record `nonce(24) ‖ ciphertext ‖ tag(16)`, fresh random nonce per write, append-only in data segments, never rewritten in place. Random nonces mean a restored older image cannot cause nonce reuse (no counter to roll back).
- Chunk AAD = `"gp-chunk-v1" ‖ vault_id ‖ file_id ‖ logical_index ‖ plaintext_len`.
- A file's root (size, mtime, generation, chunk table `[(segment, offset, len, tag)]`) is carried in journal records (§5.5). The table pins exact chunk versions, so an older valid chunk substituted at the same position fails.
- Names, tree, flags are in the encrypted index (K_meta), physical files have random names.
- Remaining leakage (PROPOSED, documented): approximate sizes (chunk counts), file/directory counts, physical file sizes and timestamps, vault folder name and location, access timing.
- Data order rule: all chunks a commit references are flushed **before** the commit record is appended and flushed.

### 5.5 Journal: layout, recovery, checkpoints, cleanup (PROPOSED, draft v0, not frozen)

**Files.** Per vault: `journal-<n>.log` segments (n = segment index), `ckpt-<seq>.bin` checkpoints, data segments, headers A/B.

**Conventions.** All integers little-endian, fixed width, no implicit padding. Any reserved byte must be zero on write and is rejected if non-zero on read. At implementation time every layout below gets a compile-time assertion on total size and on each field offset (e.g. `static_assert(sizeof(SegmentHeader) == 128)` and offset checks), plus a test that serializes a known header to golden bytes.

#### 5.5.1 Segment header: exactly 128 bytes

| Offset | Size | Field | Notes |
|---|---|---|---|
| 0 | 4 | `magic` | ASCII `GPJ1` |
| 4 | 2 | `version` | u16, = 1 for draft v0 |
| 6 | 2 | `header_len` | u16, = 128 |
| 8 | 4 | `segment_index` | u32 |
| 12 | 1 | `tx_state` | u8, must be 0 (a segment never starts inside a transaction, §5.5.4) |
| 13 | 3 | `reserved` | zero |
| 16 | 16 | `vault_id` | |
| 32 | 8 | `first_seq` | u64 |
| 40 | 8 | `prev_valid_len` | u64: byte length of valid content of segment `segment_index − 1` (the full file size on a normal roll, the recovery boundary after recovery); 0 for the first segment of the vault |
| 48 | 32 | `prev_chain_hash` | chain hash after the last valid record before this segment (or the checkpoint anchor, §5.5.5) |
| 80 | 32 | `ckpt_ref` | hash of the checkpoint this segment starts from, zero if none |
| 112 | 16 | `tag` | MAC |

Sizes: 4+2+2+4+1+3+16+8+8+32+32 = 112, plus 16 tag = **128**. (A recount of the revision-2 field list gives 122 bytes, not 130; the table above is authoritative and padded to 128 through the explicit `header_len` and `reserved` fields. If the owner's count differs, the table's offsets are what the assertion tests.)

Authenticated fields: bytes 0..111, all of them, including `reserved` and `tx_state`. MAC: HMAC-SHA256 keyed with `K_jmac` over those 112 bytes, **truncated to the leftmost 16 bytes**, compared in constant time. A segment whose MAC fails is invalid (§5.5.3).

#### 5.5.2 Record frame: 40-byte header, then ciphertext

| Offset | Size | Field |
|---|---|---|
| 0 | 2 | `magic` = 0x4A47 |
| 2 | 1 | `type` |
| 3 | 1 | `flags` |
| 4 | 8 | `seq` |
| 12 | 4 | `ct_len` (includes the 16-byte AEAD tag; ≤ 2^20 = 1 MiB; larger is corruption; ≥ 16) |
| 16 | 24 | `nonce` (random) |
| 40 | `ct_len` | ciphertext ‖ tag |

AEAD: XChaCha20-Poly1305, key `K_meta`. AAD = `"gp-jrec-v1" ‖ vault_id(16) ‖ segment_index(u32) ‖ type ‖ flags ‖ seq(u64) ‖ ct_len(u32) ‖ prev_chain_hash(32)`, where `prev_chain_hash` is the chain hash after the previous record. `magic` is a constant and is not authenticated; `nonce` is an AEAD input. Chain hash after a record: `H = BLAKE2s-256(H_prev ‖ frame_header(40 bytes, includes nonce) ‖ tag(16))`. Record plaintext ≤ 1 MiB − 16.
Because each record binds its predecessor's chain hash, its sequence number, its segment and its vault (and a record from another vault also fails because `K_meta` differs), records cannot be silently deleted, duplicated, reordered or moved between vaults or segments.

**Sequence continuity.** `seq` starts at the segment header's `first_seq` and increases by exactly 1 across records and across segments. A gap or repeat is an error.

#### 5.5.3 Open, torn-tail rules and recovery

1. Load header A/B, unwrap VK, derive keys. Choose the replay start (§5.5.5): the newest valid checkpoint, or the beginning of the journal if none is usable. A missing or invalid checkpoint is never an error.
2. Walk segments in order. Verify each segment header MAC; that `segment_index` increases by 1; that `prev_chain_hash` and `first_seq` match the verified end of the previous segment; and that the declared `prev_valid_len` does not exceed the previous segment's actual size. Read segment k only up to `prev_valid_len` when a successor k+1 exists; otherwise read to end of file.
3. In the **last segment only**, classify a failure at the end of the file as a **torn tail** when (a) fewer than 40 bytes remain, or fewer than `ct_len` bytes remain, with nothing after, or (b) a complete final frame fails authentication and no bytes follow it (a power cut can extend a file with unwritten bytes). Any failing frame with bytes after its claimed end, any failure in a non-last segment beyond a declared `prev_valid_len`, a bad segment header MAC in a non-last segment, a sequence gap or repeat, or a chain mismatch is **interior corruption**: the vault refuses to open read-write and reports the segment, offset and seq. **Corrupted interior records are never skipped.** A last segment that has an invalid or partial *header* and no valid records is treated as absent and recreated (§5.5.4 recovery algorithm).
4. Committed references are checked for existence: a commit whose chunk segment is shorter than its referenced range is corruption (data is flushed before the commit), not a torn tail.

#### 5.5.4 Transactions, the recovery boundary, and torn-tail recovery

Record types: `COMMIT_SINGLE` (one record, standalone commit), `BEGIN(txid, expected_count)`, `DELTA`, `COMMIT(txid, count, digest of deltas)`, `CKPT_REF`, plus index and root records carried inside commits. A commit larger than one record is `BEGIN ‖ DELTA* ‖ COMMIT`. Rules:
- Transactions never interleave (single writer). A `BEGIN` while another transaction is open, a `DELTA` or `COMMIT` with no matching open `BEGIN` (same `txid`, contiguous `seq`, same segment), or a `COMMIT` with the wrong `count` or digest, is interior corruption.
- **A transaction lives entirely in one segment.** The writer never rolls to a new segment mid-transaction.
- Changes become visible only at `COMMIT` / `COMMIT_SINGLE`.

**Recovery boundary.** Define `last_committed_end` as the byte offset immediately after the last record of the last segment that is *not inside an open transaction*, i.e. the last `COMMIT`, `COMMIT_SINGLE`, `CKPT_REF` or other standalone record. If valid, authenticated bytes follow it that form a `BEGIN ‖ DELTA*` prefix without a `COMMIT` at end of file, that prefix is **treated as a torn tail** even though every record in it authenticates. It is not carried forward, resumed or completed. Its chunks become unreferenced orphans for garbage collection (§5.5.6). Recovery then truncates it away (below).

**Recovery action (revised after the checkpoint-durability review).** A new file's directory entry can be lost at power failure even when its contents were flushed (§5.5.5). Creating a successor segment during recovery would therefore risk losing every commit later written into it. The primary recovery is **in-place truncation of the existing journal file**:
1. Compute `last_committed_end` (above).
2. If bytes exist beyond it, truncate the last segment to exactly `last_committed_end` (Windows `SetEndOfFile`, POSIX/Android `ftruncate`/`FileChannel.truncate`) and flush that file (`FlushFileBuffers` / `fsync`). This changes only an existing file, so no new directory entry is needed.
3. Append later records to the same file. The chain hash continues from the last committed record, `seq` continues at `seq(last committed) + 1`, and later transactions use fresh random 64-bit `txid` values, never one from the discarded prefix. No transaction state is carried over; `tx_state` stays 0.
4. If truncation is not possible on the backend, the vault opens **read-only** with a clear error. No successor segment is created in recovery.
**Idempotence under power loss:** a truncate is a single metadata operation, so after a crash the file either still has the garbage (recovery repeats with the same result) or already ends at `last_committed_end`. A torn first record after truncation is a torn tail again and is handled by the same rule.
`prev_valid_len` in the segment header is retained for normal segment rolls (it equals the previous segment's full length) and is not used for recovery. Segment rolls are rare (segments roll at 256 MiB) and follow the **creation barrier** of §5.5.5.

**Accepted rollback (not detected, documented).** An attacker who can write the store may (a) restore an older complete set of files, or (b) delete the newest whole records at a record boundary of the last segment. Both look like a clean older state or a crash before a commit. v1 does not prevent this (optional host epoch, §5.7). This differs from interior deletion, duplication, reordering and splicing, which **must** fail.

#### 5.5.5 Checkpoints, file-creation durability and cleanup (revised)

**Problem.** Reading a renamed checkpoint back proves only that the running OS sees it, not that its directory entry survives power loss. The same holds for any newly created file: journal segments, data segments, checkpoints. Windows and Android do not give us a portable guarantee that a created file's directory entry is durable after flushing the file alone (RUNTIME-TEST by power-pull or fault-injection; directory-handle flush on NTFS and directory fsync availability through SAF are DOC-NOT-YET-VERIFIED).

**Decision 1: the journal is the complete recovery path; checkpoints are accelerators.**
- State is always reconstructable from the vault header(s) plus the journal chain from its first segment, plus the data segments referenced by the live state. No checkpoint is ever required for recovery.
- **v1 never deletes journal segments automatically.** Journal growth is small (metadata only, a few hundred bytes to a few KB per commit; sizes to be measured in M4). A size warning is shown, and compaction is a reserved, user-triggered future operation whose preconditions are defined below.
- A missing, unreadable or unauthenticated checkpoint, or a `CKPT_REF` pointing to a missing file, is ignored (not an error); replay starts from the next older usable checkpoint or from the journal start.

**Decision 2: checkpoint publication without rename.**
- P1 write the checkpoint directly under its final, content-addressed name `ckpt-<covered_seq>-<hash16>.bin` and flush the file (no temp-then-rename).
- P2 flush the parent directory where the platform provides it (POSIX directory fsync; NTFS directory-handle flush if verified). On backends without it, skip, and rely on Decision 1.
- P3 verify by re-reading (this proves readability only, not durability).
- P4 append `CKPT_REF(ckpt_hash, covered_seq)` to the journal and flush the journal file. Because the journal is complete, a lost checkpoint costs only replay time.

**Creation barrier for files that commits depend on** (journal segments after the first, data segments). A commit may reference a new file only after: create, write header, flush file, **flush the parent directory through a mechanism that has been verified on that backend**. Pre-creating files ahead of need does **not** establish directory-entry durability: a file created earlier can still lose its directory entry if no directory flush ever reached the disk, and waiting a flush cycle proves nothing. Large roll sizes (journal 256 MiB, data segments 1 GiB) only make creation rare; they are not a durability mechanism.

**Durability claim rule (carried forward).** Each storage backend has a durability status:
- **Verified**: a documented directory/metadata flush mechanism exists for that backend AND the fault-injection and power-pull tests (M4 test 17) passed on it. Only then may the product say that an acknowledged save ("Saved") survives power loss or unplug.
- **Unverified**: anything else (including SAF-backed trees and Windows directory flushes until proven). The vault still works, but acknowledged saves are written and flushed on a best-effort basis; **the product must not claim they survive power loss**, the UI says so for that location, and the last-valid-version guarantee is stated only as "a crash or unplug never corrupts the vault or exposes a half-written version; the most recent saves may be missing".
- A missing referenced journal or data segment at open is **corruption** (the vault opens read-only and reports the file), never a silent drop.
RUNTIME-TEST: a fault-injecting storage layer that discards unflushed directory entries, plus a real power-pull on each OS.

**Recovery points and sufficiency.** The vault keeps the two newest *referenced and verified* checkpoints, C_new and C_old, as accelerators. Replay may start at any of C_new, C_old, or the journal start; all reconstruct the identical state. Replay begins at `seq = covered_seq + 1` and checks that the chain hash before it equals the checkpoint's `chain_hash_at_covered_seq`.

**Cleanup stages** (each crash-safe; only checkpoints and data chunks are cleaned in v1):
- G1 delete unreferenced or invalid checkpoint files and leftover temp files.
- G2 delete checkpoints other than {C_new, C_old}, oldest first.
- G3 recompute reachability (§5.5.6), then compact data segments: copy live chunks to a new data segment (creation barrier applies), flush, commit the remapped roots as a normal transaction, and delete the old data segment only after the remap commit is flushed and the old segment is unreferenced by every retained snapshot.
A crash after any single stage, or inside one deletion, leaves a complete recovery path because the journal and all live and snapshot-referenced chunks remain.

**Future journal compaction (not in v1).** Deleting old journal segments is allowed only when all hold: a checkpoint covering them is referenced and verified; it has been observed present across at least one operating-system restart; directory flush is available and verified on the backend; and the vault is otherwise healthy. Until the owner approves that operation, history is kept.

#### 5.5.6 Garbage-collection reachability and historical references (policy, with an executable model)

**Historical-reference policy (carried forward, now defined).**
- **P1 (write time):** a journal record may reference only chunks that are live at that moment or written by the same transaction. A record that names a dead chunk is rejected before it is written.
- **P2 (replay time):** replay rebuilds state from records alone. It does **not** check that chunks referenced by historical (superseded, expired, purged) records still exist. Only references that are live in the *final* reconstructed state (current roots, version store, tombstones) are validated, and a missing live chunk is corruption. Chunk metadata carried in old records (root tables, tags) is kept as records, so replay never needs the data of dead chunks.
- **P3 (GC):** a chunk is live if referenced by any of: (a) the final state's current roots; (b) every root in the version store (last 3 per file) and every root retained by a tombstone; (c) **every root listed inside any retained checkpoint snapshot (C_new and C_old)**, including roots the final state has since expired; those chunks stay until that checkpoint file is deleted (G2) and a later G3 pass may remove them; (d) chunks written by an in-flight transaction. Everything else, including chunks of an abandoned `BEGIN/DELTA` prefix, is garbage.
- **P4 (determinism):** version retention is the last 3 roots per file in commit order and tombstones are retained until a journaled purge, so replay and GC derive the same live set.
- Sweep never runs while the vault is open read-only after corruption. Data is removed only by whole-segment deletion after compaction (G3); chunks are never rewritten in place.

**Status:** these rules are tested today only on an executable reference model, [tests/test_replay_policy_model.py](../tests/test_replay_policy_model.py) (8 tests, passing on the Mac; it is a specification model and shares no code with a future implementation). The model shows journal-only replay stays correct after GC with dangling historical references, that a missing live chunk is detected, that a missing garbage chunk is not corruption, that P1 rejects references to dead chunks, that snapshot-referenced chunks survive GC, and that a GC which ignores snapshots would make retained snapshots unreadable. The same properties must be re-proved on the real implementation (M4 test 19) before it is accepted.

#### 5.5.7 Tests required for this section (details in milestones M4)
Incomplete transaction → truncate recovery → new save → reopen, with power loss at each step; checkpoint publication with the checkpoint file, its directory entry, or the `CKPT_REF` lost independently (journal-only replay gives the identical state); lost directory entry for a new journal or data segment (open fails read-only with a clear error, never silent loss); every cleanup stage and every single deletion; chunks of retained versions, tombstones and retained snapshots survive GC; chunks of an abandoned transaction are collected.

### 5.6 Recovery, PIN change, board replacement (format-level decisions made before freeze)
- **Recovery secret R:** generated on the host, 128 bits, shown once, never stored by the app, written down by the owner. The recovery card also carries the **board fingerprint** (used for pairing a new host, §7.4). `KEK_rec_v = HKDF-SHA256(salt=vault_id, ikm=R, info="gp-recovery-kek-v1")`.
- **PIN change:** current PIN required, board-only operation, no re-wrap (KEKs depend on K_board, not the PIN). Revokes nothing.
- **Board replacement or loss:** provision the new board, ask for R, unwrap VK, write a new board slot, remove the old slot from the current header.
- **Recovery secret replacement:** needs an unlocked session; new recovery slot replaces the old in the current header.
- **Historical copies keep old keys.** Any backup, synced or copied vault contains old ciphertext **and the old key slots**. Those copies stay decryptable with the old recovery secret or the old board's K_board forever. **Rotating VK and re-encrypting the live vault does not and cannot revoke copies that already hold the old ciphertext and old slots.** It only protects data written after the rotation and copies made afterwards. The UI must say so.
- Lost board and lost R means unrecoverable by design.

### 5.7 Tamper vs rollback
Detected (PROPOSED): modification, interior deletion, duplication, reordering, cross-vault, cross-segment splicing, chunk swaps, truncation inside a root, missing referenced data, forged checkpoint (binding mismatch). Not prevented: whole-history rollback and tail deletion at a record boundary. Optional (decision for review): host-side monotonic epoch in DPAPI / Android Keystore detects rollback on the same host after a restore only; a board-held epoch costs NVS wear.

## 6. Emergency lock on the host

Sequence (PROPOSED):
1. T0: state = LOCKING. New opens/creates/lists/queries fail; reads and new writes on existing handles fail (Windows access-denied or device-not-ready; Android I/O error from callbacks, roots removed by change notification).
2. A commit whose final journal append has already started may finish within a 1.5 s grace; otherwise it aborts. By §5.5 the outcome is the old or the new state, never a mix.
3. Uncommitted staged data is not committed by the lock. Optionally sealed as encrypted `DRAFT` records that never replace the current version (decision for review; default off).
4. Zeroize VK, K_file, KEK copies, Noise state (best effort; swap and copies not controlled).
5. Unmount WinFsp or remove Android roots. Editors see errors. Their own backups and temp files elsewhere may hold plaintext.
6. Dashboard hides or returns to PIN (best effort). The gatekeeper agent stays (§4.3).

Enforceable by firmware or honest host software: board disabling privileged commands, authenticated LOCK, refusing new access, unmounting. Best-effort: concealing windows, killing editors, wiping memory, controlling OS caches. Not enforceable: anything against a host that already received session keys. USB bridge remains visible to the OS; we do not claim otherwise. BOOT wiring (BOOT on GPIO0; GPIO0 low at reset enters download mode; internal pull-up about 45 kΩ) is DOC-VERIFIED (esptool page) and board-specific wiring is RUNTIME-TEST.

## 7. Storage placement, memory, pairing

### 7.1 Where vaults live
| | Default | Alternatives |
|---|---|---|
| Windows | Vault directory next to the source folder: `<source parent>\<8-hex-id>.gpv` (opaque name). Same volume, no cross-volume copy. Optional central store `%LOCALAPPDATA%\GiftsPriya\Vaults`. | After verified import and removal of the original, an unlocked vault is presented at a WinFsp mount (drive letter; directory mount over an NTFS directory is RUNTIME-TEST). The tutorial says mount point "can be a drive or directory" (DOC-VERIFIED, [WinFsp tutorial](https://github.com/winfsp/winfsp/blob/master/doc/WinFsp-Tutorial.asciidoc)). |
| Android | App-chosen storage backend (below). | |

The vault stays near the source by default. The vault folder's existence, location and size remain visible. Hidden state does not hide the folder.

### 7.2 Android storage backends and permissions
| Backend | Permission | Notes |
|---|---|---|
| App-private (`filesDir`, `getExternalFilesDir`) | None | Deleted on uninstall; backup behavior must be excluded explicitly (DOC-NOT-YET-VERIFIED: `allowBackup`/data-extraction rules) |
| SAF tree via `ACTION_OPEN_DOCUMENT_TREE` | **None** (DOC-VERIFIED: SAF "doesn't require any system permissions") | Grant lasts until reboot unless `takePersistableUriPermission` is used; persisted access is lost if the directory is moved or deleted; cannot select the internal-storage root, `Download`, `Android/data`, `Android/obb` on Android 11+ (DOC-VERIFIED, [SAF docs](https://developer.android.com/training/data-storage/shared/documents-files)). fsync behavior through the provider is RUNTIME-TEST. |
| Direct file paths in shared storage | `MANAGE_EXTERNAL_STORAGE` (all-files access); excludes `/Android/data` and most of `/sdcard/Android` (DOC-VERIFIED, [manage-all-files](https://developer.android.com/training/data-storage/manage-all-files)) | Optional convenience or performance route, not required for SAF. Play policy is not a gate for direct APK distribution, but the policy list includes disk/file encryption (same page). |

Importing a source folder works from a SAF tree grant (read, and delete the originals only where the provider flags deletion). Protected system folders and other apps' private storage stay unreachable under every backend. Uninstalling removes the app's pin store and any app-private vault; SAF-stored vaults survive, and re-pairing uses the fingerprint on the recovery card (§7.4). Backup tools and cloud sync copy ciphertext and old key slots (§5.6).

### 7.3 Memory limits and staging (PROPOSED)
- Per-handle dirty cap 32 MiB, global cap 128 MiB (tunable). Full chunks that are not being rewritten are sealed and appended (as unreferenced, encrypted) immediately, so large sequential edits do not accumulate in RAM; only partial or hot chunks stay as plaintext in memory.
- If the cap is reached, writes block until sealing frees space; they never drop data. Disk full maps to an I/O error and leaves the last committed state intact.
- Rewrites create dead chunks; space amplification is bounded by compaction at checkpoints.
- v1 maximum file size: 4 GiB until tested. Memory pages are locked best effort only. Windows cache, pagefile and hibernation can hold plaintext (BitLocker recommended).

### 7.4 Pinning and untrusted headers
(The unconfirmed-provisioning pairing ceremony is §3.4 item 6.) The trusted board key lives in the host's protected store (Windows DPAPI-protected file, Android Keystore-protected prefs). A vault header may contain a board fingerprint and public key **for matching only**. A peer-supplied or header-supplied key never replaces an existing pin. If they differ, the host reports "this vault belongs to a different board" and offers the recovery-secret flow; it never overwrites. A new host with no pin may use the header key only as a *candidate* and requires the owner to compare the fingerprint with the recovery card before it becomes a pin (otherwise an attacker's vault copy plus attacker device could capture a typed PIN). Adding or replacing a board is an explicit ceremony authenticated by a PIN session or the recovery secret.

## 8. Dashboard assets and the JavaScript boundary

### 8.1 Board-stored assets remain the preferred requirement
Estimates (PROPOSED; RUNTIME-TEST on the real bridge, board and phone). Comparison:

| Item | Board-stored (preferred) | App-bundled (alternative, not adopted) |
|---|---|---|
| Compressed size | 150–400 KB for a procedural HUD (CSS/canvas/WebGL, no video) | same bundle |
| Flash capacity | 4 MB common (unconfirmed). A raw A/B dashboard partition of ~1 MB (2×~0.5 MB) fits an assumed 4 MB module; a 2 MB module would not | none used |
| First-load time | 300 KB: theoretical ~26 s at 115200 baud, ~3.3 s at 921600, ~1.5 s at 2 Mbaud (10 bits/byte, before overhead); target < 10 s after overhead on both platforms | instant |
| Later loads | Version+hash in handshake; blob fetched only on mismatch; warm cost = handshake + hash compare | none |
| Cache | Versioned by manifest hash in app-private storage after signature check | n/a |
| Update path | Needs flashing or an approved asset-update step | with the app |

If measurements miss the thresholds, the decision returns to the owner; assets are not silently moved into the apps.

### 8.2 Board-stored assets are untrusted until verified
Manifest (version, per-file SHA-256, minimum version) signed with an Ed25519 release key, public key embedded in apps. Verify before rendering, serve from memory (WebView2 resource handlers; Android `WebViewAssetLoader` path handler; both DOC-NOT-YET-VERIFIED), enforce a minimum version.

### 8.3 JavaScript / native boundary (PROPOSED)
Private origin served by native code, strict CSP (no remote loads, no `eval`, no inline script), no file access, locked navigation. One typed message channel with a versioned schema allowlist, enforced against the state machine. JS never receives keys, KEKs, VK or arbitrary paths; native pickers choose folders. Destructive actions (remove encryption, replace recovery secret, rotate VK, delete originals) require a native confirmation outside the WebView. PIN pad in HTML is acceptable only for signed, CSP-locked assets; a native overlay is the alternative (decision). Previews: decrypted bytes via native handlers keyed to the session; HTML/PDF in sandboxed frames without scripts; unknown types not rendered.

## 9. Platform feasibility

### 9.1 Windows 11 (primary) and Windows 10 (target)
- Windows 10 support is a target. Which Windows 10 builds are supported, and whether WebView2, WinFsp, the bridge driver for CH340-family 1A86:7523 and our runtime dependencies run there, is DOC-NOT-YET-VERIFIED and then RUNTIME-TEST. No support is claimed until both are done.
- Port arrival/removal via `CM_Register_Notification` on device interfaces (Windows 8+); existing interfaces must be enumerated separately (DOC-VERIFIED, [docs](https://learn.microsoft.com/en-us/windows/win32/api/cfgmgr32/nf-cfgmgr32-cm_register_notification)). Driver availability per bridge: RUNTIME-TEST.
- Auto-launch: no documented launch-on-serial-plug; the gatekeeper agent (per-user, started at sign-in) detects arrival and opens the dashboard. Store/device-metadata companion apps: DOC-NOT-YET-VERIFIED.
- WinFsp: callbacks `Flush`, `Cleanup` (with `PostCleanupWhenModifiedOnly`), `Close`, `Rename` (`ReplaceIfExists`), `SetFileSize`, `Overwrite` (DOC-VERIFIED, tutorial). Volume parameters include `FlushAndPurgeOnCleanup`, `FileInfoTimeout`, `AlwaysUseDoubleBuffering` (DOC-VERIFIED, [fsctl.h](https://github.com/winfsp/winfsp/blob/master/inc/winfsp/fsctl.h)). Which dirty cached writes arrive before `Cleanup` is RUNTIME-TEST. Services run under WinFsp.Launcher with default control for LocalSystem/Administrators (DOC-VERIFIED, [service architecture](https://winfsp.dev/doc/WinFsp-Service-Architecture/)); install and driver-signing requirements DOC-NOT-YET-VERIFIED.
- **License (DOC-VERIFIED, [License.txt](https://raw.githubusercontent.com/winfsp/winfsp/master/License.txt)):** GPLv3 with FLOSS exception covering linking the DLL and redistributing the unmodified installer for software under an FSD/OSI-conforming license, with a required attribution notice, and not linked or distributed with proprietary software; commercial licensing is available from the author. Whether a given plan complies needs a decision and possibly legal review.
- Plaintext exposure: cache manager, pagefile, hibernation, editor caches/temp/recent lists. BitLocker recommended.

### 9.2 Android 11+
- USB host feature, `USB_DEVICE_ATTACHED` intent filter with device filter launches the app after a system dialog; otherwise `requestPermission`; detach via an in-app receiver (DOC-VERIFIED, USB host guide). OTG power and bridge support: RUNTIME-TEST per phone.
- `DocumentsProvider` offers `createDocument`, `renameDocument`, `deleteDocument`, `removeDocument`, `moveDocument`, `copyDocument`, `isChildDocument`, `findDocumentPath`, `openDocument`; mode `"r"` must be supported, unsupported modes throw, `"rw"` implies a seekable file; the source says nothing on truncation (DOC-VERIFIED from AOSP, [DocumentsProvider.java](https://raw.githubusercontent.com/aosp-mirror/platform_frameworks_base/master/core/java/android/provider/DocumentsProvider.java)).
- `openProxyFileDescriptor(mode, callback, handler)` returns a seekable descriptor; callbacks are `onGetSize`, `onRead`, `onWrite`, `onFsync`, `onRelease`; `onRead` must return the full requested size unless end of file; unoverridden methods throw `EBADF`/`EINVAL`; modes are read-only, write-only, read-write (DOC-VERIFIED from AOSP, [ProxyFileDescriptorCallback.java](https://raw.githubusercontent.com/aosp-mirror/platform_frameworks_base/master/core/java/android/os/ProxyFileDescriptorCallback.java), [StorageManager.java](https://raw.githubusercontent.com/aosp-mirror/platform_frameworks_base/master/core/java/android/os/storage/StorageManager.java)). **No truncate callback exists.** mmap support is not stated (RUNTIME-TEST). Which open modes (`"wt"`, `"rwt"`, `"wa"`) apps pass, and whether the system calls the callbacks on a thread we control, is RUNTIME-TEST.
- Editors need per-app testing for create, rename, delete, seek, truncate and save patterns. Unsupported ones are listed as unsupported.

## 10. External-editing lifecycle and save guarantees

### 10.1 Versions, tombstones and retention (applies to both platforms)
Every commit that replaces a file's root keeps the previous root in a **version store** (default: last 3 roots per file, size-capped). A delete commits a **tombstone** that retains the deleted file's last root in the same store. Retention is bounded; expiry is ordinary deletion, not secure erase. Previous versions are recoverable through vault-core (UI later).

### 10.2 Windows commit points and rules
1. `Flush` (FlushFileBuffers): seal dirty chunks, flush segments, append and flush the journal commit, then return. After success the data is durable to the extent the drive honors flush (DOC-VERIFIED caveats, [FlushFileBuffers](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-flushfilebuffers)).
2. Last-handle `Cleanup` of a modified file: commit synchronously before returning (**policy A**: the closed content becomes the current version; the previous version stays in the version store). This is the durability point only for editors that never flush, and only if WinFsp delivers all dirty cached writes before `Cleanup` (RUNTIME-TEST).
3. `Rename` with `ReplaceIfExists`: one journal record swaps the target's reference, retaining the old root in the version store. Durable on return. This is the one atomic-replace operation we offer.
4. **Delete-then-recreate is not atomic.** Editors that do this produce two separate commits: a delete (tombstone, old version retained in the store) and a later create. An interruption between them leaves the path absent, with the previous version recoverable from the version store until retention expires. We do not claim the previous file remains visible at its path. Keeping the old chunks only keeps the data recoverable, not visible.
5. Truncate (`Overwrite`, `SetFileSize`) is staged and committed only at the points above, so a crash after truncate but before commit leaves the last committed content.
6. `WriteFile` returning success is **not** a durability point. We make no claim of universal application-level save atomicity. Whether an application's own save sequence is safe depends on its pattern; we guarantee only the commit semantics above, tested per editor.
7. ReplaceFile has no write-through option, and MoveFileEx has `MOVEFILE_WRITE_THROUGH` (DOC-VERIFIED, [ReplaceFile](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-replacefilew), [MoveFileEx](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-movefileexw)); our commits use journal append plus flush, not rename.
8. Concurrent handles: one coherent in-memory file object; a commit snapshots the chunk table under a lock.

### 10.3 Android policy (consistent for all events)
Per open handle, state: `{mode, truncated_at_open, dirty, committed_version}`.
- **Open-mode truncation** (`"wt"`, `"rwt"`; `"w"` if the platform truncates): staged. The handle presents an empty file, the committed version is untouched until a commit point. Supported.
- **Later `ftruncate`** after open: there is no callback; behavior is whatever the system returns (expected failure). Editors that need it are unsupported unless tests show otherwise (RUNTIME-TEST). This is separate from open-mode truncation.
- `onWrite`: stage only; never a commit.
- `onFsync`: commit synchronously (policy A commit: current version replaced, previous retained). Return success only after the journal flush. An editor whose fsync returned success has durable data.
- `onRelease`: `onRelease` is called after close and **does not prove the editor finished a good save**; it can follow a client crash, cancel or error. Policy A: if the handle is dirty, commit it as the new current version and keep the previous version in the version store. So partial edits **may** become the current file, and the user can restore the previous version.
- **Client death:** the system closes the descriptor, `onRelease` runs, same as above (a partially written file may be committed; previous version retained).
- **Provider (our process) death:** no callbacks run; staged data in RAM is lost; the last committed version remains; clients get I/O errors.
- **Lock / USB removal:** immediately fail new callbacks with an I/O error; an `onFsync` commit already past its journal-append start may finish within the 1.5 s grace; everything else is aborted; `onRelease` after lock performs no commit (keys gone). Staged data is discarded (or drafted if the optional draft feature is enabled).
- Dirty limits and staging: §7.3.
- Rename: `renameDocument` may keep the document ID; if it changes, grants must be moved per the API contract (DOC-VERIFIED, AOSP source). A rename-over is one journal record with the old root retained.
- Delete-then-recreate follows §10.1/§10.2 rule 4.

### 10.4 Plaintext policy
No plaintext on disk by default. Plaintext lives in RAM only; sealed chunks are ciphertext. Unavoidable exposures, stated to the user: OS caches, pagefile, hibernation, editor autosave/backup/temp files, thumbnails, recent-file lists, clipboard, and exported copies, which cannot be revoked.

### 10.5 Disconnect
Both platforms apply §6. Last committed version remains; version store and optional drafts allow recovery. Journal recovery (§5.5) runs at next mount.

## 11. Data-safety flows (PROPOSED)
- **Import:** read the original, write the vault, verify every chunk decrypts and the plaintext hash equals the original's hash, then offer removal. Removal is an ordinary delete, never secure erasure.
- **Remove encryption:** decrypt to destination, verify against stored hashes, then offer vault deletion.
- **Hide:** presentation only, state in the index.
- **Never claimed:** secure erasure on flash/SSD, revocation of exported or historical copies, protection after keys reached a compromised host.

## 12. Guided setup and compatibility checks (PROPOSED; nothing implemented; documents for several steps not yet read)

### 12.1 Principles
Check first, ask later. Each permission or setting is requested only at the step that needs it, with a plain reason. No permission is offered as a workaround for something a permission cannot fix (§12.4).

### 12.2 Android guided flow
1. **USB host support.** Check `android.hardware.usb.host` (DOC-VERIFIED as the documented feature declaration, [USB host guide](https://developer.android.com/develop/connectivity/usb/host)). If absent, stop with "this phone does not support USB host".
2. **Bridge detection.** On attach or on user request, list devices through `UsbManager`, match VID:PID against the supported list (the observed board is 1A86:7523, CH340 family; the library lists CH340/CH341, DOC-VERIFIED), and probe with `usb-serial-for-android`. If enumeration fails or the device resets, report probable power or cable causes (not asserted as a diagnosis).
3. **USB permission.** Request it only when a matching device is present (via the attach intent flow or `requestPermission`; DOC-VERIFIED guide).
4. **Folder access.** Only when the user adds or imports a folder or chooses a vault location: open the system tree picker (SAF needs no system permission, DOC-VERIFIED). Offer all-files access only if the user chooses a direct-path mode, with a statement of what it cannot reach (`Android/data` and similar, DOC-VERIFIED). If a chosen directory is refused (internal root, `Download`, `Android/data`, `Android/obb`; DOC-VERIFIED), explain that the system forbids it and ask for another.
5. **Background operation.** Explain, at the point it matters, any foreground-service notification, battery-optimization and background-launch behavior needed for heartbeat and the second-press prompt. The exact Android 11+ requirements and OEM variation are DOC-NOT-YET-VERIFIED then RUNTIME-TEST; the flow is written after reading them.
6. **Summary screen** lists each check as pass, fail (with cause), or not yet tested.

### 12.3 Windows guided flow
Check OS build and edition, WebView2 runtime presence, WinFsp presence (explaining its separate driver install and administrator prompt before it appears), and the COM-port driver state for the detected VID:PID. Request elevation only for installing WinFsp or the driver. Offer start-at-sign-in for the gatekeeper agent only when the user wants auto-launch (§9.1). All requirements and support statements for Windows 10 builds are DOC-NOT-YET-VERIFIED.

### 12.4 Unsupported conditions
| Condition | Message to the user | Never offered as a fix |
|---|---|---|
| No USB host feature | "This phone does not support USB host." | any permission or setting |
| Device does not enumerate or resets under load | "The board is not detected or lost power. Try another cable or adapter or a powered one. This phone may not supply enough power." | permission changes |
| Unsupported or unrecognized bridge | "This USB serial chip is not supported on this device." | permissions |
| Windows driver missing or failing | "Windows has no working driver for this bridge." | app permissions |
| USB permission denied | "USB access was refused. Allow it when the board is connected." | |
| Protected directory chosen | "Android does not allow apps to use this folder. Choose another." | all-files access |
| Storage permission denied | Explain which action is blocked and offer another backend | |
| OS restriction (background, driver signing, unsupported OS build) | Name the restriction | |

## 13. Open decisions
See [reports/phase-01-feasibility.md](../reports/phase-01-feasibility.md).
