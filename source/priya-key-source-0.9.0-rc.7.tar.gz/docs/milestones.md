# Milestones — risk first (revision 2)

Nothing below has been started. Each milestone ends with an evidence note in `reports/`. A failed risk milestone stops the plan for a decision. Dashboard polish comes last. **The vault format is not frozen until the crash-recovery review gate M4g.** Labels: see [README](../README.md).

Rules for all milestones: disposable data only (generated files and a scratch vault). No real folder is touched. No eFuse, secure boot, flash encryption or JTAG changes. Flashing only with explicit approval for that milestone.

## M0 — Collect hardware facts (visual + OS enumeration only; approved). STATUS: USB bridge enumerated (1A86:7523, CH340 family, variant unconfirmed); hardware identification partial. See [reports/m0-hardware-identification.md](../reports/m0-hardware-identification.md). Android and Windows behavior unverified.
- Work: [hardware-checklist](hardware-checklist.md) sections 1–3 and 5. No flashing, no esptool (it can reset the board).
- Pass: filled table of bridge chip, VID:PID, module marking, USB-C behavior, phone details. Unknowns listed, not guessed.

## M1 — USB connectivity on Windows and a real Android phone
- Targets: Windows 11 (primary) and Windows 10 (target, unverified until exact builds and dependencies are checked), Android 11+ (baseline). No test machine or phone is confirmed yet.
- Work: minimal Windows program and Android app exchange framed echo messages with throwaway firmware (COBS + CRC, line-error detection only).
- **Scope note:** the M1 firmware is fixed at 115200 baud and the clients refuse other rates; a faster-rate test is substep **M1d** (below). Do not interpret failures at any other host rate as bridge limits.
- Pass: (1) 10,000 echo frames per platform at 115200, CRC failures counted. (2) Android device_filter and permission flows recorded. (3) Reset behavior recorded per OS with the uptime-based reset probe (at least 20 cycles), reporting **reset-on-open and reset-on-close separately**; missing boot text is inconclusive and never counts as "no reset"; the DTR/RTS setting that avoids a reset, if any, is recorded. (4) 20 random cable pulls per platform: removal detected within a measured time, no hang. (5) Phone power behavior recorded.
- Fail response: if Android cannot talk to the bridge, stop and report.

### M1d — Faster-rate echo (later substep, not started)
- Work: either a coordinated rate-change mechanism in firmware and client, or separately built firmware variants at other rates. The host rate is never changed alone.
- Pass: echo frames at each tested rate on Windows and the phone, with failures attributed only after the firmware and host are confirmed to be at the same rate.

### M1b — Dashboard-asset spike (measure only; needs flash approval)
- Work: store a 300 KB dummy blob in a raw partition, read back per baud.
- Pass: first-load time and flash use measured against architecture §8.1 thresholds. Decision returned to the owner; assets are not moved into the apps silently.

## M1c — Guided setup and compatibility checks (before dashboard work)
- Work: Android and Windows setup flows from architecture §12 on throwaway builds, without vault code.
- Pass: each unsupported condition in the §12.4 table is produced deliberately and reported with its specific cause (no USB host, no enumeration/inadequate power, unsupported bridge, USB permission denied, protected directory chosen, storage permission denied, WebView2 or WinFsp missing, unsupported OS build). Permission prompts appear only at the step that needs them. No screen implies a permission can fix hardware, driver, power or OS limits. Results recorded per device in a compatibility matrix; unverified devices are listed as unverified.

## M2 — Entropy, authenticated session, PIN policy
- Work: entropy lifecycle (§3.3), DRBG, provisioning with BOOT confirmation and single-blob atomic write, fail-closed PIN counter, Noise responder/initiator, `AUTH`, heartbeat, PIN change.
- Prerequisites (DOC-NOT-YET-VERIFIED reads): noise-c pattern list and random hook, ESP-IDF mbedTLS entropy glue, NVS API errors.
- Pass tests:
  1. Shared Noise test vectors agree across board, Windows and Android builds for the chosen suites.
  2. Entropy: boot self-check asserts the entropy source is enabled before any key generation; build fails if Wi-Fi, Bluetooth, ADC or I2S are enabled or used; 10,000 handshakes across resets never repeat an ephemeral public key; statistical output tests run as sanity checks only and are not claimed to prove entropy.
  3. Wire capture sanity check: no PIN, key or filename strings, no cleartext vault_id; message lengths and timing are visible and expected. This is a sanity check only, not a proof of security, which rests on Noise.
  4. Second board, replayed capture, modified frame each fail to authenticate.
  5. PIN counter: persisted before comparison, survives reset and cable removal, delay tiers measured. Fault injection: fail `nvs_set`, fail `nvs_commit`, fail read-back, fail NVS init, cut power mid-reset of the counter. Expected: no PIN comparison and no key release on any write failure; the board enters fail-closed; no automatic erase or reinitialization occurs; success path with failed counter reset releases no keys.
  6. Provisioning atomicity: cut power at every injected step of provisioning (before `att` write, between `att` and `id`, after `id`, before and after `PROV_CONFIRM`). The board ends `EMPTY`, `COMPLETE_UNCONFIRMED` or `COMPLETE_CONFIRMED`; the identity is never regenerated; `att` exists with a matching `id_nonce` whenever `id` exists; `INCONSISTENT` is reachable (missing `att`, `id_nonce` mismatch) and never auto-recovers.
  6b. **Every pairing disconnect point.** Cut the link (a) after the `id` commit and before `PROV_CONFIRM`, (b) after the board durably accepted `PROV_CONFIRM` and before the host promotes `pending_pairing` to `trusted_board`, (c) after promotion. Expected: the board identity and public key never change; at (a) and (b) restart finds `pending_pairing`, runs `NK` + `AUTH` through the attempt counter and promotes without changing the board (re-sending `PROV_CONFIRM` is idempotent); with the pending record deleted, the PAIR ceremony (unauthenticated `PAIR_REQUEST`, BOOT press within 30 s, `NX` reveals the existing public key only, fingerprint compare, PIN) recovers; no BOOT press means no `NX`; a key from a vault header is never trusted automatically; the ceremony is refused in `ACTIVE`.
  7. Provisioning refused without a BOOT press. PIN change needs the current PIN.
- Flash approval: required.

## M3 — Disposable encrypted-file round trip (format draft v0, not frozen)
- Work: vault-core draft: header A/B with board and recovery slots, chunks, encrypted index, journal framing per architecture §5.5, `GET_KEK` from the board. Command-line only, scratch vault.
- Pass:
  1. Round trip of 0 byte to 200 MB files: hashes equal after close and reopen.
  2. Byte search of vault files for plaintext content and for original names and structure finds nothing.
  3. Tamper tests (bit flips in chunk, record, header slot, checkpoint) fail closed.
  4. Recovery: unwrap VK with the recovery secret alone; replace the secret; replace the board and re-wrap. Record that old secrets and the old board still open historical copies holding old ciphertext and old slots.
  5. PIN change leaves vaults openable.
  6. Capture of the serial link shows only handshake, key-release and heartbeat traffic, with no file-sized transfers.

## M4 — Crash safety and journal recovery (no filesystem yet)
- Work: fault injection and adversarial tests on the journal and commit protocol.
- Pass tests (all must hold):
  1. **Torn tail at every byte offset** of the final record (partial frame header, partial nonce, partial ciphertext, partial tag, zero-extended tail): reopen succeeds at the previous commit.
  2. **Reopen-after-torn-tail → new save → reopen again**: the second reopen reads both the old history and the new save with no error, using the successor-segment mechanism (§5.5 step 5). Repeat after a second torn tail.
  3. Kill the process during recovery itself (including mid-write of the successor segment header); recovery re-runs and reaches the same result.
  4. **Interior deletion** of one record: open fails with the seq/offset. Never skipped.
  5. **Interior duplication** of a record: fails (sequence repeat).
  6. **Reordering** of two records: fails (chain mismatch).
  7. **Cross-vault splicing** (record from vault B into vault A): fails. Also splice from another segment and forged or old checkpoint (wrong vault, wrong covered_seq/chain): fails.
  8. Referenced chunk data truncated or missing: fails as corruption, not treated as a torn tail.
  9. **Accepted case, distinct from 4–8:** restoring an entire older consistent copy, or deleting trailing whole records of the final segment at a record boundary, opens successfully at the older state. The test records that this is accepted whole-history rollback, not a failure; if the optional host epoch is adopted the test shows it is detected on the same host only.
  10. Multi-record transactions: `BEGIN` without `COMMIT` at the tail is discarded; the same inside the interior fails.
  11. Nonce uniqueness: restore an old copy, write again; no (key, nonce) pair repeats in a large simulated run.
  12. 50 cable-pulls during commits on the real board and host.
  13. **Incomplete transaction → recovery → new save → reopen.** Valid `BEGIN ‖ DELTA*` without `COMMIT` at end of file: open treats it as a torn tail and truncates the journal file in place to `last_committed_end` (flushed). A new save commits with `seq` = last committed + 1, chain continuing from the last committed record, fresh random `txid`s, `tx_state` 0. Reopen shows old history plus the new save and none of the abandoned deltas. Repeat with a large multi-record transaction cut after each record.
  14. **Power loss during that recovery:** kill before the truncate, after the truncate but before the flush, after the flush, and after the first new record. Each reopen reaches the same logical state; a following save and reopen succeed. An incomplete prefix is never resumed and a `txid` from the discarded prefix is never reused. If truncation is made to fail, the vault opens read-only with a clear error and creates no successor segment.
  15. Interior open transaction (BEGIN with later records in the same segment lacking COMMIT, or a segment boundary inside a transaction) fails as corruption.
  16. **Checkpoint publication:** crash at P1 (written), P2 (directory flush), P3 (verified), P4 (`CKPT_REF` appended). Lose independently the checkpoint file, its directory entry, and the `CKPT_REF` record: reopen by journal-only replay gives the identical state every time; a `CKPT_REF` to a missing file is ignored, not an error.
  17. **File-creation durability:** with a fault-injecting storage layer that discards directory entries not flushed, lose the directory entry of a newly created journal segment, data segment and checkpoint at each point. Expected: checkpoint loss costs only replay time; loss of a referenced journal or data segment opens read-only with a clear error and reports the file; no commit is silently dropped. Repeat with a real power-pull on Windows and on the phone's storage once available (RUNTIME-TEST).
  17b. **Durability status per backend:** record Verified or Unverified for each tested backend (Windows NTFS, Android app-private, Android SAF tree) from tests 16–17. The UI and documentation wording must match the status; an Unverified backend never displays an "acknowledged saves survive power loss" claim. Pre-created files are not accepted as a durability mechanism.
  18. **Cleanup stages:** crash at every point of G1 (unreferenced checkpoint removal), G2 (each checkpoint deletion), G3 (reachability recompute, copy, remap commit, old data segment deletion). After each, reopen yields the identical state, all retained and tombstoned versions read back with identical content, and orphan chunks of abandoned transactions are eventually collected. Confirm the journal is never deleted automatically.
  19. **Historical-reference policy (P1–P4, architecture §5.5.6):** re-prove on the real implementation the properties already shown by the reference model in tests/test_replay_policy_model.py: journal-only replay after GC with dangling historical references succeeds; a missing live chunk fails; a missing garbage chunk does not; P1 rejects a record naming a dead chunk; roots in retained snapshots keep their chunks until the checkpoint is deleted.
  19b. **Reachability:** chunks referenced only by a retained version, a tombstone, or a root inside a retained checkpoint snapshot survive GC until that checkpoint is deleted; after its deletion a later G3 pass may remove them; chunks referenced by nothing are collected. Opening from C_new, from C_old, and from the journal start all yield the identical state.
  20. Layout: golden-byte test and `static_assert` on the 128-byte segment header and 40-byte frame header, offsets and little-endian encoding; reserved bytes non-zero rejected; MAC truncation (left 16 bytes of HMAC-SHA256) checked against an independent implementation.

### M4g — Format freeze review gate
- The format is frozen only after Codex reviews the M4 evidence and the journal specification. Until then every format version is a draft. No later milestone starts before this gate.

## M5 — Windows: WinFsp mount and external editing (disposable data)
- Prerequisite: decision on the WinFsp license path; DOC-NOT-YET-VERIFIED reads for installation and driver signing.
- Pass tests (editors chosen from Notepad, Notepad++, VS Code, Word or LibreOffice, an image editor):
  1. Create, edit, save, close, reopen: content equal.
  2. Record per editor which pattern it uses: write-in-place, temp-then-rename-over, delete-then-recreate, truncate-then-write.
  3. Durability tests: kill the host and pull the cable right after the editor reports success, with and without FlushFileBuffers. Record exactly what survives. No durability point is claimed that tests did not confirm.
  4. **Delete/recreate interruption:** inject a kill between the delete commit and the recreate commit. Expected: path absent, previous version recoverable from the version store with identical content. Also test rename-over interruption (old or new, never neither).
  5. Concurrent handles on one file: sharing semantics recorded.
  6. Lock during save at 100 random times: new access fails at once, last committed version intact, no plaintext marker on disk or temp.
  7. Open-handle behavior on forced unmount recorded per editor.
  8. Directory mount over an NTFS directory (original path restored after import) works or is rejected.
- Fail response: if flush/cleanup semantics cannot give a documentable durability point, stop and report options.

## M6 — BOOT privacy button, lifecycle ordering, control path
- Work: debounced GPIO0 read in normal operation, LOCK ordering per §4.1, heartbeat, gatekeeper agent, status event for the second press.
- Pass tests:
  1. Board flags `privileged_disabled` before sending LOCK; LOCK is sent while the transport is live; keys are zeroized afterwards (verify by commands failing in that order using a protocol trace on the board).
  2. Measured timing against the targets in §4.2 (reported, not assumed).
  3. Second press leads to a PIN screen via the gatekeeper while the service is stopped; no restore without a fresh Noise session and the PIN.
  4. A spoofed status event from a fake device only shows a prompt and unlocks nothing.
  5. USB pull locks; killing the service process leaves the gatekeeper able to react; process kill dismounts the volume.
  6. BOOT held at reset enters download mode; firmware never requires BOOT at reset.
  7. Bridge remains visible to the OS after the first press.
  8. Android: foreground-service and notification behavior documented first (DOC-NOT-YET-VERIFIED) and tested on the phone.
  9. Peer-supplied key: a vault header naming a different board key never replaces an existing pin; the new-host pairing needs the fingerprint comparison.

## M7 — Android: USB, DocumentsProvider, editing (disposable data)
- Prerequisite: M1 on the phone.
- Pass tests:
  1. System picker browses, creates, renames, deletes in an unlocked vault.
  2. At least three editors: record per app the open modes used, whether open-mode truncation works, whether later `ftruncate` fails (unsupported, listed), mmap, `onFsync` use, rename behavior.
  3. Policy tests (§10.3): `onWrite` alone never commits; `onFsync` commits; `onRelease` after partial write commits partial content as the new current version with the previous version recoverable; client killed mid-write; provider killed mid-write (last commit intact); lock during `onFsync` and during `onRelease` (no commit after lock).
  4. Storage backend matrix: app-private, SAF tree (persisted grant survives reboot, lost on move/delete, refused roots), direct path with `MANAGE_EXTERNAL_STORAGE`; fsync behavior and permission requirements recorded for each.
  5. Uninstall and backup behavior recorded.
  6. Protected directories show as unreachable under all backends.

## M8 — Import and restore verification
- Pass: injected bit flip in imported ciphertext is detected and removal is never offered. Same for restore. Interrupted import/restore at random points loses nothing and can resume. Wording reviewed for no secure-erase claim. Version store retention and its "not secure erase" text reviewed.

## M9 — Dashboard shell, signed assets, PIN screen, cards
- Work: manifest signing, board-stored assets (if M1b allows), JS/native bridge, PIN screen, four card states, the four-folder scenario with two hidden.
- Pass: tampered bundle refused; forbidden commands rejected by the state machine; native confirmations for destructive actions; cold and warm startup measured.

## M10 — Animation, previews, packaging, honest documentation
- Pass: dependency license audit complete (including the WinFsp decision), limitations screen matches [requirements C](requirements.md), clean-machine installs on Windows 11 and the phone, reviewer sign-off.

## Ordering rationale
USB on both platforms (M1) and the session and PIN design (M2) are the highest unknowns. The format stays draft through M3 and M4 and is frozen only at M4g after adversarial journal tests. Real-filesystem editing (M5, M7) precedes any UI work.


## Status update 2026-10-19
M3 and M4 are implemented and build on the Mac (see reports/m3-m4-result.md). All Windows and phone acceptance tests are PENDING until devices are available. M5: bundled dashboard + installer/APK built; board-stored assets not implemented.
