# Requirements

Status of every item: **not implemented**. Checkboxes are unchecked until a milestone's acceptance test passes with recorded evidence.
Labels: DOC-VERIFIED / PROPOSED / DOC-NOT-YET-VERIFIED / RUNTIME-TEST as defined in [README](../README.md).

## A. Our requirements (from the project brief)

### Hardware
- [ ] R-HW1 Existing basic 30-pin ESP32 board, USB-C, Wi-Fi/BT, EN and BOOT buttons. Exact module, flash size, USB bridge unconfirmed. No ESP32-S3, no extra hardware without discussion.
- [ ] R-HW2 USB data cable is the authentication connection. No internet or Wi-Fi service needed.
- [ ] R-HW3 Only the physically connected device may hold an authenticated session.
- [ ] R-HW4 Files stay on the host. Host encrypts. File contents never pass through the ESP32.

### User experience
- [ ] R-UX1 Connect board, open dashboard. Investigate automatic launch and document OS restrictions.
- [ ] R-UX2 Skippable cinematic HUD startup animation.
- [ ] R-UX3 Four-digit PIN screen with animated frame.
- [ ] R-UX4 Protected-folder cards with states Locked, Locked · Hidden, Unlocked, Saving.
- [ ] R-UX5 Add folders from different locations, encrypt, lock/unlock, change visibility, permanently remove encryption.
- [ ] R-UX6 Change PIN. Set up a separate offline recovery secret.
- [ ] R-UX7 Browse and preview inside the dashboard.
- [ ] R-UX8 External apps can edit and save files during an unlocked session.
- [ ] R-UX9 Guided setup (architecture §12): checks USB-host support, detects the bridge, requests USB permission, guides folder-access grants, and explains any background-operation settings. Permissions are requested only at the step that needs them. Permissions are never presented as bypasses for missing USB-host hardware, inadequate power, unsupported drivers, protected directories, or OS restrictions. Unsupported conditions are reported clearly with the specific cause.
- Example acceptance scenario: four protected folders in different locations, two hidden.

### Privacy button
- [ ] R-PB1 Investigate BOOT during normal operation. EN stays reset.
- [ ] R-PB2 First press: immediately block access, close or conceal the dashboard, disable the application service.
- [ ] R-PB3 Second press: restore service, require the PIN again.
- [ ] R-PB4 USB removal also locks.
- [ ] R-PB5 Never claim the USB bridge disappears from the OS.

### Platforms
- [ ] R-PL1 Windows 11 is the primary target. Assess WinFsp.
- [ ] R-PL1b Windows 10 is a compatibility target. Exact supported builds and dependencies (bridge driver, WebView2 runtime, WinFsp, runtimes) are verified from documentation and tested before any support claim.
- [ ] R-PL2 Android 11+ is the baseline. Assess DocumentsProvider. Aim for broad compatibility across newer phones and phones released 3–5 years ago. This is an aim, not a promise: support is recorded per tested phone, and untested phones are listed as unverified.
- [ ] R-PL2b No Windows test machine and no Android test phone are confirmed yet; no compatibility is claimed.
- [ ] R-PL3 Android may request broad shared-storage permission but cannot reach protected system folders or other apps' private storage.
- [ ] R-PL4 Android needs USB host/OTG, adequate power, supported bridge. No promise every phone works.
- [ ] R-PL5 Android distribution as a directly installed APK.
- [ ] R-PL6 Prefer dashboard assets stored on the ESP32. Assess feasibility and startup cost before committing.

### Security and data safety
- [ ] R-SEC1 Encrypt file contents, original names, and folder structure.
- [ ] R-SEC2 Hiding is presentation only.
- [ ] R-SEC3 Established cryptographic libraries and protocol, fresh authenticated sessions. No invented cryptography. Serial number is never a secret.
- [ ] R-SEC4 Long-term board secrets stay on the ESP32. Host session-key exposure documented.
- [ ] R-SEC5 PIN attempt delays enforced on the board. Persistence and reset behavior explained.
- [ ] R-SEC6 Last valid encrypted file survives an interrupted save (unplug, button).
- [ ] R-SEC7 Encrypted imports verified before offering plaintext removal.
- [ ] R-SEC8 Restored plaintext verified before removing encrypted storage.
- [ ] R-SEC9 No claim of secure erasure on flash.
- [ ] R-SEC10 Explain that external editors may keep cached content and exported copies cannot be revoked.
- [ ] R-SEC11 No claim of continuous hardware enforcement against a compromised host.
- [ ] R-SEC12 No eFuse burning, no permanent debug disable, no irreversible security settings during initial development.

## B. Suggestions or instructions found in reference documents (not requirements)

No reference documents exist in the project folder (verified: folder was empty). Anything we later import from outside material (for example, vendor sample code, Espressif examples, WinFsp samples) is a suggestion and is recorded here before use, with a decision.

| Item | Source | Decision |
|---|---|---|
| WinFsp sample `Rename` uses `MoveFileExW` on a backing store | WinFsp tutorial | Reference only. Our commits do not depend on rename (architecture §4.5). |
| Espressif suggests flash encryption for protecting flash contents | ESP-IDF docs | Not adopted in development because it is irreversible (R-SEC12). Revisit with owner approval. |
| Android suggests SAF / MediaStore over all-files access | Android docs | We use DocumentsProvider for editing. Broad storage permission is optional and only for choosing source folders. |

## C. Limitations we must state to the user (all PROPOSED text for the UI and docs)

1. Once the host holds session keys, a compromised host can copy them. The board cannot recall keys.
2. External editors, the OS cache, the pagefile and hibernation file may retain plaintext. Exported copies cannot be revoked.
3. Deleting plaintext originals or encrypted files on SSD/flash is not secure erasure.
4. Hiding is not security.
5. Four-digit PIN plus delays only stops attackers using the normal protocol. With physical possession of the board and unencrypted flash, an attacker may extract board secrets (flash encryption is deliberately not enabled).
6. Old recovery secrets and old boards still unlock any copy that already holds old ciphertext and old key slots (backups, synced copies, earlier exports). Rotating the vault key protects only data written afterwards and copies made afterwards; it cannot revoke historical copies.
7. Tampering, interior deletion, duplication, reordering and cross-vault splicing of the journal are detected and fail closed. Whole-history rollback and deletion of the newest records at a record boundary are accepted and not detected (except best-effort same-host detection if adopted).
8. Not every Android phone will work. USB host, OTG power, and a supported bridge are required. No permission, setting or app can add USB-host hardware, supply missing power, install an unsupported driver, open a protected directory, or lift an operating-system restriction; the app reports these conditions instead of offering workarounds.
9. Unplug mid-save preserves the last committed version. Unsaved edits are lost unless draft sealing is enabled.
10. We do not promise application-level save atomicity. Only the commit points in architecture §10 are guaranteed. Delete-then-recreate is two separate operations; an interruption between them can leave the path absent, with the previous version recoverable from the version store until retention expires.
11. On Android, closing a file does not prove the editor finished a good save. A partial edit may become the current file; the previous version stays recoverable for the retention period.
12. The PIN board fails closed: if the board cannot durably persist its attempt counter, it refuses PIN checks and key release until the owner intervenes. It never wipes itself automatically.

## D. Acceptance criteria (summary; details in [milestones](milestones.md))

| Req | Pass criterion | Milestone |
|---|---|---|
| R-HW2, R-HW3 | Authenticated Noise session over USB on Windows and on a real Android phone; second device or replayed capture cannot start a session | M1, M2 |
| R-SEC3 | Handshake interoperates with shared test vectors on board and both hosts; entropy source lifecycle checked at build and boot; a capture shows no PIN, key or name strings and no cleartext vault_id (a sanity check, not a proof; security rests on Noise) | M2 |
| R-SEC5 | Wrong-PIN counter persists across reset and unplug; delay tiers observed by stopwatch; injected NVS failures leave the board fail-closed and never erase it; interrupted provisioning leaves the board `EMPTY` or `COMPLETE`, never regenerated | M2 |
| R-SEC1, R-HW4 | Round trip of a disposable file: ciphertext on disk contains no plaintext name or content (byte search); tamper test fails closed; no file bytes appear on the serial link in a capture | M3 |
| R-SEC6 | Journal recovery: reopen after torn tail, save again, reopen again; interior deletion/duplication/reordering/cross-vault splicing fail closed; tail truncation at a record boundary accepted as documented rollback | M4 |
| R-UX8, R-SEC6 | Editors on disposable data survive forced unplug at every injected step with the last committed version recoverable; delete/recreate interruption leaves previous version recoverable | M5 |
| R-PB1–R-PB5 | BOOT press locks within a measured time; second press plus PIN restores; USB pull locks | M6 |
| R-PL2, R-UX8 | Documents opened and saved from at least three Android apps; truncate/rename behavior recorded per app | M7 |
| R-SEC7, R-SEC8 | Import verification detects an injected bit flip; removal never offered before verification passes | M8 |
| R-UX9, R-PL1b, R-PL2 | Each unsupported condition produces its specific message; permission prompts appear only when needed; per-device compatibility matrix records tested devices and keeps the rest unverified | M1c |
| R-UX1–R-UX7 | Dashboard flows work against real vaults | M9–M10 |
| R-PL6 | Asset load time and flash use measured and compared with thresholds in architecture §7.1, then decided by the owner | M1b spike |
