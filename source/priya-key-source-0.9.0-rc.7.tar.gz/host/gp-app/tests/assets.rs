//! Signed dashboard image: pack/verify, tamper detection, board transfer through the real device core, cache choice.
use ed25519_dalek::SigningKey;
use gp_app::assets::*;
use gp_app::Service;
use gpkey_host::SimLink;
use std::path::Path;
use std::process::Command;

fn sim() -> String {
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../firmware");
    let bin = root.join("gpkey/sim/gk_sim");
    if !bin.exists() {
        assert!(Command::new("sh").arg(root.join("gpkey/sim/build.sh")).status().unwrap().success());
    }
    bin.canonicalize().unwrap().to_str().unwrap().to_string()
}

fn key() -> SigningKey {
    SigningKey::from_bytes(&[7u8; 32])
}

#[test]
fn pack_verify_and_tamper() {
    let k = key();
    let pk = k.verifying_key().to_bytes();
    let html = "<html>".to_string() + &"hello dashboard ".repeat(500) + "</html>";
    let img = pack(&html, 3, &k).unwrap();
    let v = verify(&img, &pk).unwrap();
    assert_eq!((v.version, v.html.as_str()), (3, html.as_str()));
    assert!(img.len() < html.len());
    // any changed byte is rejected
    for i in (0..img.len()).step_by(7) {
        let mut b = img.clone();
        b[i] ^= 1;
        assert!(verify(&b, &pk).is_err(), "byte {i}");
    }
    assert!(verify(&img[..img.len() - 1], &pk).is_err());
    assert!(verify(&img, &SigningKey::from_bytes(&[8u8; 32]).verifying_key().to_bytes()).is_err(), "wrong key");
    // choose(): cache wins only when valid and not older than the bundled version
    assert_eq!(choose(Some(&img), "B", &pk).1, "board image (cached)");
    assert_eq!(choose(Some(&img[..50]), "B", &pk).0, "B");
    let old = pack("<html>old</html>", 0, &k).unwrap();
    assert_eq!(choose(Some(&old), "B", &pk).0, "B");
    assert_eq!(choose(None, "B", &pk).2, BUNDLED_VERSION);
}

#[test]
fn board_serves_image_and_service_caches_only_valid_ones() {
    let t = tempfile::tempdir().unwrap();
    let store = t.path().join("board");
    std::fs::create_dir_all(&store).unwrap();
    // The compiled-in public key belongs to the release key, so a test image is not valid for the service: it must be refused.
    let img = pack("<html>x</html>", BUNDLED_VERSION, &key()).unwrap();
    let f = t.path().join("assets.bin");
    std::fs::write(&f, &img).unwrap();
    let link = SimLink::spawn(&sim(), store.to_str().unwrap(), &["--assets", f.to_str().unwrap()]).unwrap();
    let mut svc = Service::new(t.path().join("home"), link).unwrap();
    // raw transfer is byte-exact (several chunks)
    let got = svc.device().asset_image(MAX_IMAGE).unwrap();
    assert_eq!(got, img);
    let e = svc.sync_assets().unwrap_err();
    assert!(e.contains("signature"), "{e}");
    assert!(!t.path().join("home/dashboard.gkas").exists());
    assert_eq!(svc.dashboard("BUNDLED").1, "bundled with the app");

    // with the matching public key the image is accepted, cached, and then used by dashboard()
    let pk = key().verifying_key().to_bytes();
    assert_eq!(svc.sync_assets_with(&pk).unwrap(), BUNDLED_VERSION);
    assert!(t.path().join("home/dashboard.gkas").exists());
    let cached = std::fs::read(t.path().join("home/dashboard.gkas")).unwrap();
    assert_eq!(cached, img);
    assert_eq!(choose(Some(&cached), "BUNDLED", &pk).0, "<html>x</html>");

    // a board without assets reports an error, not data
    let link2 = SimLink::spawn(&sim(), store.to_str().unwrap(), &[]).unwrap();
    let mut svc2 = Service::new(t.path().join("home2"), link2).unwrap();
    assert!(svc2.device().asset_image(MAX_IMAGE).is_err());
}
