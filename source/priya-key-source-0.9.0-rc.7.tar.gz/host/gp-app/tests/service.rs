//! gp-app service tests against the REAL device core (host simulator) and real on-disk vaults in temp directories.
use gp_app::*;
use gpkey_host::{AuthResult, SimLink};
use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::Duration;

fn sim() -> String {
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../firmware");
    let bin = root.join("gpkey/sim/gk_sim");
    if !bin.exists() {
        assert!(Command::new("sh").arg(root.join("gpkey/sim/build.sh")).status().unwrap().success());
    }
    bin.canonicalize().unwrap().to_str().unwrap().to_string()
}

struct Rig {
    _t: tempfile::TempDir,
    home: PathBuf,
    store: PathBuf,
    work: PathBuf,
    svc: Service<SimLink>,
}

fn rig() -> Rig {
    let t = tempfile::tempdir().unwrap();
    let (home, store, work) = (t.path().join("home"), t.path().join("board"), t.path().join("work"));
    std::fs::create_dir_all(&store).unwrap();
    std::fs::create_dir_all(&work).unwrap();
    let link = SimLink::spawn(&sim(), store.to_str().unwrap(), &[]).unwrap();
    let svc = Service::new(&home, link).unwrap();
    Rig { _t: t, home, store, work, svc }
}

fn pair(svc: &mut Service<SimLink>, pin: &str) {
    let mut press = |l: &mut SimLink| {
        let _ = l.button();
    };
    svc.pair(pin, Duration::from_secs(5), Some(&mut press)).unwrap();
}

fn make_source(dir: &Path) {
    std::fs::create_dir_all(dir.join("docs/deep")).unwrap();
    std::fs::write(dir.join("readme.txt"), "hello text file\n".repeat(100)).unwrap();
    std::fs::write(dir.join("docs/deep/notes.md"), "# disposable\nline\n").unwrap();
    std::fs::write(dir.join("docs/empty.bin"), b"").unwrap();
    let big: Vec<u8> = (0..3_000_000u32).map(|i| (i.wrapping_mul(2654435761) >> 13) as u8).collect();
    std::fs::write(dir.join("big.bin"), big).unwrap();
    // a tiny valid PNG (1x1)
    let png: Vec<u8> = vec![0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0, 0, 0, 13, 0x49, 0x48, 0x44, 0x52, 0, 0, 0, 1, 0, 0, 0, 1, 8, 6, 0, 0, 0, 0x1F, 0x15, 0xC4, 0x89, 0, 0, 0, 0x0D, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9C, 0x63, 0xF8, 0xFF, 0xFF, 0x3F, 0, 5, 0xFE, 2, 0xFE, 0xA7, 0x35, 0x81, 0x84, 0, 0, 0, 0, 0x49, 0x45, 0x4E, 0x44, 0xAE, 0x42, 0x60, 0x82];
    std::fs::write(dir.join("pic.png"), png).unwrap();
}

#[test]
fn import_verify_browse_preview_hide_lock_restore_and_remove() {
    let mut r = rig();
    pair(&mut r.svc, "2468");
    assert!(r.svc.add_folder(None, &r.work, "x", false).is_err(), "recovery must be set up first");
    let code = r.svc.setup_recovery().unwrap();
    assert_eq!(code.replace('-', "").len(), 52);
    let src = r.work.join("Taxes");
    make_source(&src);
    let vaults = r.work.join("vaults");
    std::fs::create_dir_all(&vaults).unwrap();
    let (id, rep) = r.svc.add_folder(Some(&src), &vaults, "Taxes 2025", false).unwrap();
    let rep = rep.unwrap();
    assert!(rep.verified && rep.errors.is_empty(), "{:?}", rep.errors);
    assert_eq!(rep.files.len(), 5);
    // originals untouched until explicitly removed
    assert!(src.join("big.bin").exists());
    // ciphertext on disk contains no names
    for e in std::fs::read_dir(vaults.read_dir().unwrap().next().unwrap().unwrap().path()).unwrap() {
        let b = std::fs::read(e.unwrap().path()).unwrap();
        assert!(!b.windows(7).any(|w| w == b"Taxes 2" || w == b"notes.m" || w == b"readme."), "name leaked");
    }
    let cards = r.svc.cards(false);
    assert_eq!(cards.len(), 1);
    assert_eq!(cards[0].state, "Locked");
    // browse and previews through unlock
    let root = r.svc.browse(&id, "").unwrap();
    assert!(root.iter().any(|e| e.name == "docs" && e.is_dir) && !root.iter().any(|e| e.name == ".gp"));
    assert_eq!(r.svc.cards(false)[0].state, "Unlocked");
    let p = r.svc.preview(&id, "readme.txt").unwrap();
    assert_eq!(p.kind, "text");
    assert!(p.text.unwrap().starts_with("hello text file"));
    assert_eq!(r.svc.preview(&id, "pic.png").unwrap().kind, "image");
    assert_eq!(r.svc.preview(&id, "big.bin").unwrap().kind, "binary");
    // hidden
    r.svc.set_hidden(&id, true).unwrap();
    assert!(r.svc.cards(false).is_empty());
    assert_eq!(r.svc.cards(true)[0].hidden, true);
    r.svc.lock(&id);
    assert_eq!(r.svc.cards(true)[0].state, "Locked · Hidden");
    // saving state
    let ov = r.svc.unlock(&id).unwrap();
    ov.vfs.saving().fetch_add(1, std::sync::atomic::Ordering::SeqCst);
    assert_eq!(r.svc.cards(true)[0].state, "Saving");
    ov.vfs.saving().fetch_sub(1, std::sync::atomic::Ordering::SeqCst);
    // delete originals: refused for a changed file, done for unchanged ones
    std::fs::write(src.join("readme.txt"), "changed after import").unwrap();
    let (deleted, kept) = r.svc.delete_originals(&id).unwrap();
    assert_eq!(deleted, 4);
    assert_eq!(kept, vec!["readme.txt".to_string()]);
    assert!(!src.join("big.bin").exists() && src.join("readme.txt").exists());
    // restore + verify, then delete the vault only after verification
    let dest = r.work.join("restored");
    assert!(r.svc.delete_vault(&id).is_err(), "no deletion before a verified restore");
    let rep = r.svc.restore(&id, &dest).unwrap();
    assert!(rep.verified);
    assert_eq!(std::fs::read(dest.join("docs/deep/notes.md")).unwrap(), b"# disposable\nline\n");
    r.svc.delete_vault(&id).unwrap();
    assert!(r.svc.cards(true).is_empty());
    assert!(vaults.read_dir().unwrap().next().is_none());
}

#[test]
fn locking_paths_privacy_button_heartbeat_loss_and_link_loss() {
    let mut r = rig();
    pair(&mut r.svc, "1357");
    r.svc.setup_recovery().unwrap();
    let vaults = r.work.join("v");
    std::fs::create_dir_all(&vaults).unwrap();
    let (id, _) = r.svc.add_folder(None, &vaults, "A", false).unwrap();
    let ov = r.svc.unlock(&id).unwrap();
    assert!(!ov.is_locked());
    // privacy button: first press locks everything via the authenticated notice
    r.svc.link_mut().button().unwrap();
    r.svc.tick();
    assert!(ov.is_locked(), "open vault handles are marked locked at once");
    assert!(!r.svc.is_authenticated());
    assert!(r.svc.cards(true).is_empty());
    assert!(matches!(r.svc.take_events().last(), Some(Event::Locked(_))));
    // the second press restores service but the PIN is required again
    r.svc.link_mut().button().unwrap();
    assert!(r.svc.unlock(&id).is_err());
    assert_eq!(r.svc.auth("1357").unwrap(), AuthResult::Ok);
    assert_eq!(r.svc.cards(false).len(), 1);
    // heartbeat loss on the device side
    let ov2 = r.svc.unlock(&id).unwrap();
    r.svc.link_mut().advance(3500).unwrap();
    std::thread::sleep(Duration::from_millis(1100)); // the next host heartbeat is due
    r.svc.tick();
    assert!(ov2.is_locked() && !r.svc.is_authenticated());
}

#[test]
fn recovery_code_opens_a_vault_for_a_replacement_board() {
    let mut r = rig();
    pair(&mut r.svc, "1111");
    let code = r.svc.setup_recovery().unwrap();
    let vaults = r.work.join("v");
    std::fs::create_dir_all(&vaults).unwrap();
    let src = r.work.join("src");
    make_source(&src);
    let (_id, rep) = r.svc.add_folder(Some(&src), &vaults, "Family", false).unwrap();
    assert!(rep.unwrap().verified);
    let vdir = std::fs::read_dir(&vaults).unwrap().next().unwrap().unwrap().path();
    // a NEW board (empty store) and a new app home: pair, then recover the old vault with the recovery code
    let t2 = tempfile::tempdir().unwrap();
    let store2 = t2.path().join("board2");
    std::fs::create_dir_all(&store2).unwrap();
    let link = SimLink::spawn(&sim(), store2.to_str().unwrap(), &[]).unwrap();
    let mut svc2 = Service::new(t2.path().join("home2"), link).unwrap();
    pair(&mut svc2, "9999");
    assert!(svc2.recover_vault(&vdir, "AAAA-BBBB").is_err(), "a wrong code is refused");
    let wrong = {
        let (sk, _) = vault_core::recovery::generate();
        vault_core::recovery::encode_secret(&sk)
    };
    assert!(svc2.recover_vault(&vdir, &wrong).is_err());
    let id2 = svc2.recover_vault(&vdir, &code).unwrap();
    let names = svc2.browse(&id2, "").unwrap();
    assert!(names.iter().any(|e| e.name == "big.bin"));
    assert_eq!(svc2.cards(false)[0].name, "Family");
    // the old board's KEK no longer opens the (re-wrapped) vault header, the new board's does
    svc2.lock_all("test");
    assert_eq!(svc2.auth("9999").unwrap(), AuthResult::Ok);
    assert!(svc2.browse(&id2, "").is_ok());
    let _ = (&r.home, &r.store);
}

#[test]
fn pairing_is_resumable_and_trust_is_persisted() {
    let mut r = rig();
    pair(&mut r.svc, "2222");
    assert!(r.svc.is_paired());
    assert!(!r.home.join("pending_pairing.hex").exists());
    // a fresh Service with the same home remembers the pinned board key and can authenticate after a lock
    r.svc.lock_all("test");
    let key_file = std::fs::read_to_string(r.home.join("trusted_board.hex")).unwrap();
    assert_eq!(key_file.len(), 64);
    assert_eq!(r.svc.auth("0000").unwrap(), AuthResult::WrongPin { delay_ms: 0 });
    assert_eq!(r.svc.auth("2222").unwrap(), AuthResult::Ok);
}

#[test]
fn json_api_round_trip() {
    let mut r = rig();
    pair(&mut r.svc, "3141");
    let v = |s: String| -> serde_json::Value { serde_json::from_str(&s).unwrap() };
    let rec = v(api::handle(&mut r.svc, r#"{"cmd":"setup_recovery"}"#));
    assert_eq!(rec["ok"], true);
    let parent = r.work.join("vv");
    std::fs::create_dir_all(&parent).unwrap();
    let add = v(api::handle(&mut r.svc, &format!(r#"{{"cmd":"add_folder","source":null,"parent":{:?},"name":"Photos","hidden":false}}"#, parent.to_str().unwrap())));
    assert_eq!(add["ok"], true, "{add}");
    let st = v(api::handle(&mut r.svc, r#"{"cmd":"status"}"#));
    assert_eq!(st["data"]["cards"][0]["name"], "Photos");
    assert_eq!(st["data"]["cards"][0]["state"], "Locked");
    let bad = v(api::handle(&mut r.svc, r#"{"cmd":"nonsense"}"#));
    assert_eq!(bad["ok"], false);
    let wrong = v(api::handle(&mut r.svc, r#"{"cmd":"auth","pin":"0000"}"#));
    assert_eq!(wrong["data"]["result"], "wrong_pin");
    let lock = v(api::handle(&mut r.svc, r#"{"cmd":"lock_all"}"#));
    assert_eq!(lock["ok"], true);
    let st = v(api::handle(&mut r.svc, r#"{"cmd":"status"}"#));
    assert_eq!(st["data"]["authenticated"], false);
    assert_eq!(st["data"]["cards"].as_array().unwrap().len(), 0, "no folder names before authentication");
}

#[test]
fn backup_export_restore_and_wrong_board() {
    let mut r = rig();
    pair(&mut r.svc, "2468");
    r.svc.setup_recovery().unwrap();
    let src = r.work.join("src");
    make_source(&src);
    let (id, rep) = r.svc.add_folder(Some(&src), &r.work, "Docs", false).unwrap();
    assert!(rep.unwrap().verified);
    let dir = r.work.read_dir().unwrap().filter_map(|e| e.ok()).find(|e| e.file_name().to_string_lossy().ends_with(".gpv")).unwrap().path();

    // unlocked folders are refused (no writes during the copy)
    r.svc.unlock(&id).unwrap();
    assert!(r.svc.export_vault(&id, &r.work.join("bk")).unwrap_err().contains("lock"));
    r.svc.lock(&id);
    let bk = r.work.join("bk");
    let rep = r.svc.export_vault(&id, &bk).unwrap();
    assert!(rep.verified && rep.files > 0 && rep.errors.is_empty(), "{rep:?}");
    assert!(r.svc.export_vault(&id, &bk).unwrap().errors[0].contains("already exists"), "never overwrite");

    // simulate "deleted vault + app reinstall": remove the folder and registry entry, then restore the backup
    r.svc.delete_vault_unchecked_for_test(&id);
    std::fs::remove_dir_all(&dir).unwrap();
    assert!(r.svc.cards(true).is_empty());
    let (id2, rep2) = r.svc.restore_backup(&bk.join(dir.file_name().unwrap()), &r.work.join("restored")).unwrap_or_else(|e| panic!("{e}"));
    assert_eq!(id2, id);
    assert!(rep2.verified);
    r.svc.unlock(&id2).unwrap();
    let e = r.svc.browse(&id2, "docs").unwrap();
    assert!(e.iter().any(|x| x.name == "empty.bin"));
    // linking twice is refused
    assert!(r.svc.link_vault(&r.work.join("restored").join(dir.file_name().unwrap())).unwrap_err().contains("already"));
    // a junk folder is refused
    std::fs::create_dir_all(r.work.join("junk")).unwrap();
    assert!(r.svc.link_vault(&r.work.join("junk")).is_err());
}

#[test]
fn discreet_setting_is_explicit_persistent_and_off_by_default() {
    let mut r = rig();
    assert!(!r.svc.discreet(), "off by default");
    let st: serde_json::Value = serde_json::from_str(&api::handle(&mut r.svc, r#"{"cmd":"status"}"#)).unwrap();
    assert_eq!(st["data"]["settings"]["discreet"], false);
    let on: serde_json::Value = serde_json::from_str(&api::handle(&mut r.svc, r#"{"cmd":"set_discreet","on":true}"#)).unwrap();
    assert_eq!(on["ok"], true);
    assert!(r.svc.discreet());
    // survives a restart of the application (new Service on the same home)
    let link = SimLink::spawn(&sim(), r.store.to_str().unwrap(), &[]).unwrap();
    let again = Service::new(&r.home, link).unwrap();
    assert!(again.discreet());
    r.svc.set_discreet(false).unwrap();
    assert!(!r.svc.discreet());
    // a corrupt settings file means "off", never "on"
    std::fs::write(r.home.join("settings.json"), b"{not json").unwrap();
    assert!(!r.svc.discreet());
}

// ---- pairing survives a dropped USB link (Windows 'Access is denied (os error 5)' when BOOT is pressed)
use gpkey_host::{frame::Frame, Link, LinkError};
use std::sync::atomic::{AtomicI32, Ordering};
use std::sync::{Arc, Mutex};

/// Wraps the simulator link; after `fail_after` frames it reports the Windows error once, like a port that vanished.
struct Flaky {
    sim: Arc<Mutex<SimLink>>,
    fail_after: Arc<AtomicI32>,
    closed: Arc<AtomicI32>,
    own: bool,
}
impl Link for Flaky {
    fn send(&mut self, b: &[u8]) -> Result<(), LinkError> {
        self.sim.lock().unwrap().send(b)
    }
    fn recv_frame(&mut self, t: Duration) -> Result<Option<Frame>, LinkError> {
        if self.own && self.fail_after.fetch_sub(1, Ordering::SeqCst) == 1 {
            return Err(LinkError::Io("Access is denied. (os error 5)".into()));
        }
        self.sim.lock().unwrap().recv_frame(t)
    }
    fn close(&mut self) {
        self.closed.fetch_add(1, Ordering::SeqCst);
    }
}

fn flaky_rig(fail_after: i32, reopen_ok: bool, with_reopen: bool) -> (tempfile::TempDir, Service<Flaky>, Arc<Mutex<SimLink>>, Arc<AtomicI32>, Arc<AtomicI32>) {
    let t = tempfile::tempdir().unwrap();
    std::fs::create_dir_all(t.path().join("board")).unwrap();
    let sim = Arc::new(Mutex::new(SimLink::spawn(&sim(), t.path().join("board").to_str().unwrap(), &[]).unwrap()));
    let (fa, closed, reopens) = (Arc::new(AtomicI32::new(fail_after)), Arc::new(AtomicI32::new(0)), Arc::new(AtomicI32::new(0)));
    let link = Flaky { sim: sim.clone(), fail_after: fa.clone(), closed: closed.clone(), own: true };
    let mut svc = Service::new(t.path().join("home"), link).unwrap();
    svc.reopen_delay = Duration::from_millis(5);
    if with_reopen {
        let (s2, c2, r2) = (sim.clone(), closed.clone(), reopens.clone());
        let sim_for_clock = sim.clone();
        svc.set_reopen(Box::new(move || {
            r2.fetch_add(1, Ordering::SeqCst);
            // the real reconnection takes seconds; the key (virtual clock) then drops a session whose host went silent (3 s heartbeat timeout)
            let _ = sim_for_clock.lock().unwrap().advance(5000);
            if reopen_ok {
                Ok(Flaky { sim: s2.clone(), fail_after: Arc::new(AtomicI32::new(i32::MAX)), closed: c2.clone(), own: false })
            } else {
                Err("Access is denied. (os error 5)".into())
            }
        }));
    }
    (t, svc, sim, closed, reopens)
}

fn press_flaky(svc: &mut Service<Flaky>, sim: &Arc<Mutex<SimLink>>) -> Result<[u8; 32], String> {
    let s = sim.clone();
    let mut press = move |_: &mut Flaky| {
        let _ = s.lock().unwrap().button();
    };
    svc.pair("2468", Duration::from_secs(20), Some(&mut press))
}

#[test]
fn pairing_survives_a_link_drop_at_any_point_and_releases_the_old_port_first() {
    let mut hits = 0;
    for fail_after in [2, 3, 4, 5, 6, 7, 8, 9, 10, 12] {
        let (t, mut svc, sim, closed, reopens) = flaky_rig(fail_after, true, true);
        let fa = svc.device().link.fail_after.clone();
        let r = press_flaky(&mut svc, &sim);
        assert!(r.is_ok(), "drop after {fail_after} frames: {r:?}");
        assert!(svc.is_paired() && svc.is_authenticated());
        let triggered = fa.load(Ordering::SeqCst) <= 0;   // the injected drop only happens if pairing is still using the link at that point
        if triggered {
            assert!(reopens.load(Ordering::SeqCst) >= 1, "the link must have been reopened ({fail_after})");
            assert!(closed.load(Ordering::SeqCst) >= 1, "old port must be closed before reopening ({fail_after})");
        } else {
            assert_eq!(reopens.load(Ordering::SeqCst), 0);
        }
        assert!(t.path().join("home/trusted_board.hex").exists());
        assert!(!t.path().join("home/pending_pairing.hex").exists());
        hits += (fa.load(Ordering::SeqCst) <= 0) as i32;
    }
    assert!(hits >= 5, "the drop must be exercised at many different points, got {hits}");
}

#[test]
fn without_a_reopen_hook_or_when_reopening_fails_the_error_is_clear_and_nothing_is_half_paired() {
    for (reopen_ok, with_reopen) in [(true, false), (false, true)] {
        let (t, mut svc, sim, _c, reopens) = flaky_rig(4, reopen_ok, with_reopen);
        let e = press_flaky(&mut svc, &sim).unwrap_err();
        assert!(e.contains("os error 5"), "{e}");
        assert!(e.contains("Unplug and replug the key") && e.contains("another program"), "{e}");
        assert!(!svc.is_paired());
        assert!(!t.path().join("home/trusted_board.hex").exists());
        if with_reopen {
            assert_eq!(reopens.load(Ordering::SeqCst), 8, "bounded number of attempts");
        }
    }
}

#[test]
fn non_link_failures_are_not_retried() {
    let (_t, mut svc, sim, _c, reopens) = flaky_rig(i32::MAX, true, true);
    // no BOOT press: the window runs out; this is a user-level failure, not a link failure
    let r = svc.pair("2468", Duration::from_millis(600), None);
    assert!(r.unwrap_err().contains("BOOT button was not pressed"));
    assert_eq!(reopens.load(Ordering::SeqCst), 0);
    let _ = sim;
}
