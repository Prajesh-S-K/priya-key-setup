//! Editor behavior through the platform-independent VFS: save patterns, concurrent handles, lock during save, and a
//! power-loss sweep over an editing session. Disposable in-memory data.
use gp_app::vfs::*;
use vault_core::{crypto, Loss, MemStorage, SlotKind, Vault};

fn vfs() -> (Vfs<MemStorage>, crypto::Key) {
    let board: crypto::Key = crypto::random();
    let v = Vault::create(MemStorage::new(), &[(SlotKind::Board, board)]).unwrap();
    (Vfs::with_clock(v, || 1000), board)
}

fn w() -> OpenOpts {
    OpenOpts { write: true, ..Default::default() }
}
fn create() -> OpenOpts {
    OpenOpts { create: true, write: true, ..Default::default() }
}
fn read_all(f: &Vfs<MemStorage>, path: &str) -> Vec<u8> {
    let h = f.open(path, OpenOpts::default()).unwrap();
    let n = f.stat_handle(h).unwrap().size as usize;
    let d = f.read(h, 0, n + 10).unwrap();
    f.close(h).unwrap();
    d
}
fn put(f: &Vfs<MemStorage>, path: &str, data: &[u8]) {
    let h = f.open(path, create()).unwrap();
    f.write(h, 0, data).unwrap();
    f.close(h).unwrap();
}
fn into_storage(f: Vfs<MemStorage>) -> MemStorage {
    // lock() drops the vault, so the storage is reopened from a clone taken before: tests clone via with_vault
    f.with_vault(|v| v.storage().clone()).unwrap()
}

#[test]
fn create_write_close_persists_and_empty_files_exist() {
    let (f, _) = vfs();
    put(&f, "a/b.txt", b"hello");
    assert_eq!(read_all(&f, "a/b.txt"), b"hello");
    let h = f.open("empty.txt", create()).unwrap();
    assert_eq!(f.stat("empty.txt").unwrap().size, 0, "a created file is visible before it is committed");
    assert!(f.list("").unwrap().iter().any(|e| e.name == "empty.txt"));
    f.close(h).unwrap();
    assert_eq!(read_all(&f, "empty.txt"), b"");
    assert!(f.open("a/b.txt", OpenOpts { create_new: true, create: true, ..Default::default() }).is_err());
}

#[test]
fn notepad_style_truncate_then_write_keeps_the_previous_version_until_commit() {
    let (f, _) = vfs();
    put(&f, "doc.txt", b"version one");
    let h = f.open("doc.txt", OpenOpts { truncate: true, write: true, ..Default::default() }).unwrap();
    f.write(h, 0, b"version two, longer").unwrap();
    // before any commit point the committed content is still version one (visible through a second, read-only view of the vault)
    let committed = f.with_vault(|v| v.read_file("doc.txt").unwrap()).unwrap();
    assert_eq!(committed, b"version one");
    // but the open handle sees its own writes
    assert_eq!(f.read(h, 0, 100).unwrap(), b"version two, longer");
    f.flush(h).unwrap();
    assert_eq!(f.with_vault(|v| v.read_file("doc.txt").unwrap()).unwrap(), b"version two, longer");
    f.close(h).unwrap();
    assert_eq!(f.with_vault(|v| v.read_version("doc.txt", 0).unwrap()).unwrap(), b"version one");
}

#[test]
fn save_by_rename_replace_is_atomic_and_keeps_the_old_file_as_a_tombstone() {
    let (f, _) = vfs();
    put(&f, "report.docx", b"old content");
    put(&f, "~WRL0001.tmp", b"new content");
    f.rename("~WRL0001.tmp", "report.docx", true).unwrap();
    assert_eq!(read_all(&f, "report.docx"), b"new content");
    assert!(f.stat("~WRL0001.tmp").is_err());
    assert_eq!(f.with_vault(|v| v.tombstones().len()).unwrap(), 1);
    assert!(f.rename("x", "report.docx", false).is_err());
    put(&f, "other.txt", b"o");
    assert_eq!(f.rename("other.txt", "report.docx", false), Err(VfsError::Exists));
}

#[test]
fn delete_then_recreate_is_two_commits_and_the_old_version_stays_recoverable() {
    let (f, _) = vfs();
    put(&f, "photo.jpg", b"original bytes");
    f.delete("photo.jpg").unwrap();
    assert!(f.stat("photo.jpg").is_err());
    let (tomb, content) = f.with_vault(|v| (v.tombstones(), v.read_tombstone(&v.tombstones()[0].0).unwrap())).unwrap();
    assert_eq!(content, b"original bytes");
    assert_eq!(tomb[0].1, "photo.jpg");
    put(&f, "photo.jpg", b"edited bytes");
    assert_eq!(read_all(&f, "photo.jpg"), b"edited bytes");
}

#[test]
fn concurrent_handles_share_one_coherent_view() {
    let (f, _) = vfs();
    put(&f, "shared.bin", &vec![7u8; 100]);
    let a = f.open("shared.bin", w()).unwrap();
    let b = f.open("shared.bin", OpenOpts::default()).unwrap();
    f.write(a, 10, b"ABC").unwrap();
    assert_eq!(&f.read(b, 8, 8).unwrap()[..], &[7, 7, b'A', b'B', b'C', 7, 7, 7], "a second handle sees uncommitted writes");
    f.close(a).unwrap();
    assert_eq!(f.with_vault(|v| v.read_file("shared.bin").unwrap()[10]).unwrap(), 7, "closing one of two handles is not the last close");
    f.close(b).unwrap();
    assert_eq!(read_all(&f, "shared.bin")[10], b'A', "the last close commits");
}

#[test]
fn set_len_extend_truncate_and_read_past_end() {
    let (f, _) = vfs();
    put(&f, "x", b"0123456789");
    let h = f.open("x", w()).unwrap();
    f.set_len(h, 4).unwrap();
    assert_eq!(f.read(h, 0, 100).unwrap(), b"0123");
    f.set_len(h, 8).unwrap();
    assert_eq!(f.read(h, 0, 100).unwrap(), b"0123\0\0\0\0", "growing again reads zeros, not the old bytes");
    assert_eq!(f.read(h, 100, 10).unwrap(), b"");
    f.close(h).unwrap();
    assert_eq!(read_all(&f, "x"), b"0123\0\0\0\0");
}

#[test]
fn delete_on_close_and_open_file_deletion() {
    let (f, _) = vfs();
    put(&f, "t", b"temp");
    let h = f.open("t", OpenOpts { write: true, ..Default::default() }).unwrap();
    f.delete("t").unwrap(); // open elsewhere: deferred
    assert!(f.stat("t").is_ok());
    f.close(h).unwrap();
    assert!(f.stat("t").is_err());
    let h = f.open("scratch", OpenOpts { create: true, write: true, delete_on_close: true, ..Default::default() }).unwrap();
    f.write(h, 0, b"scratch").unwrap();
    f.close(h).unwrap();
    assert!(f.stat("scratch").is_err(), "delete-on-close of a never-committed file leaves nothing behind");
}

#[test]
fn directories_and_renames_with_open_files() {
    let (f, _) = vfs();
    f.mkdir("d").unwrap();
    put(&f, "d/one", b"1");
    assert!(f.rmdir("d").is_err());
    let h = f.open("d/one", w()).unwrap();
    f.write(h, 1, b"2").unwrap();
    f.rename("d", "e", false).unwrap(); // dirty open file is committed first and the handle follows the rename
    f.write(h, 2, b"3").unwrap();
    f.close(h).unwrap();
    assert_eq!(read_all(&f, "e/one"), b"123");
    assert!(f.stat("d").is_err());
    assert_eq!(f.list("e").unwrap().len(), 1);
}

#[test]
fn large_file_with_periodic_flushes() {
    let (f, _) = vfs();
    let h = f.open("big.bin", create()).unwrap();
    let block: Vec<u8> = (0..65536u32).map(|i| (i % 251) as u8).collect();
    for i in 0..40u64 {
        f.write(h, i * 65536, &block).unwrap();
        if i % 10 == 9 {
            f.flush(h).unwrap();
        }
    }
    f.close(h).unwrap();
    let d = read_all(&f, "big.bin");
    assert_eq!(d.len(), 40 * 65536);
    assert_eq!(&d[65536 * 17..65536 * 18], &block[..]);
}

#[test]
fn lock_rejects_new_work_and_discards_uncommitted_edits_keeping_the_last_version() {
    let (f, board) = vfs();
    put(&f, "keep.txt", b"last good version");
    let h = f.open("keep.txt", OpenOpts { truncate: true, write: true, ..Default::default() }).unwrap();
    f.write(h, 0, b"half-typed replacement").unwrap();
    let storage = f.with_vault(|v| v.storage().clone()).unwrap();
    f.lock();
    assert!(f.is_locked());
    assert_eq!(f.read(h, 0, 10), Err(VfsError::Locked));
    assert_eq!(f.write(h, 0, b"x"), Err(VfsError::Locked));
    assert_eq!(f.open("keep.txt", OpenOpts::default()), Err(VfsError::Locked));
    assert_eq!(f.flush(h), Err(VfsError::Locked));
    assert_eq!(f.close(h), Err(VfsError::Locked), "no commit after the lock");
    // the committed state is the last good version
    let v = Vault::open(storage, &board).unwrap();
    assert_eq!(v.read_file("keep.txt").unwrap(), b"last good version");
}

#[test]
fn power_loss_sweep_over_an_editing_session_never_corrupts_or_mixes_versions() {
    // script: save v1; open-truncate-write v2 + flush; save-by-rename of v3; delete+recreate v4
    let run = |crash: Option<u64>, loss: Loss| -> (Vec<u8>, bool) {
        let board: crypto::Key = crypto::random();
        let v = Vault::create(MemStorage::new(), &[(SlotKind::Board, board)]).unwrap();
        let mut st = v.into_storage();
        st.set_crash_at(crash);
        let f = Vfs::with_clock(Vault::open(st, &board).unwrap(), || 7);
        let steps: Vec<Box<dyn Fn(&Vfs<MemStorage>) -> VResult<()>>> = vec![
            Box::new(|f| {
                let h = f.open("f", create())?;
                f.write(h, 0, b"v1-aaaaaaaaaaaa")?;
                f.close(h)
            }),
            Box::new(|f| {
                let h = f.open("f", OpenOpts { truncate: true, write: true, ..Default::default() })?;
                f.write(h, 0, b"v2-bbbbbbbbbbbbbbbb")?;
                f.flush(h)?;
                f.close(h)
            }),
            Box::new(|f| {
                let h = f.open("f.tmp", create())?;
                f.write(h, 0, b"v3-cc")?;
                f.close(h)?;
                f.rename("f.tmp", "f", true)
            }),
            Box::new(|f| {
                f.delete("f")?;
                let h = f.open("f", create())?;
                f.write(h, 0, b"v4-ddddddd")?;
                f.close(h)
            }),
        ];
        let mut acked = 0usize;
        for s in &steps {
            if s(&f).is_err() {
                break;
            }
            acked += 1;
        }
        let mut st = f.with_vault(|v| v.storage().clone()).unwrap_or_else(|_| MemStorage::new());
        st.power_loss(loss);
        let v = Vault::open(st, &board).expect("reopen after power loss");
        let content = v.read_file("f").unwrap_or_default();
        let _ = acked;
        (content, v.verify_all().is_ok())
    };
    // baseline run (no crash) to count storage ops would need hooks; sweep a generous range instead
    let valid: [&[u8]; 6] = [b"", b"v1-aaaaaaaaaaaa", b"v2-bbbbbbbbbbbbbbbb", b"v3-cc", b"v4-ddddddd", b"v3-cc"];
    let mut checked = 0;
    for crash in 1..120u64 {
        for loss in [Loss::Clean, Loss::TornPrefix(40), Loss::ZeroTail] {
            let (content, ok) = run(Some(crash), loss);
            assert!(ok, "crash {crash} {loss:?}: data does not authenticate");
            assert!(valid.contains(&content.as_slice()), "crash {crash} {loss:?}: content {:?} is not one of the committed versions", String::from_utf8_lossy(&content));
            checked += 1;
        }
    }
    let (content, ok) = run(None, Loss::Clean);
    assert!(ok && content == b"v4-ddddddd");
    eprintln!("vfs power-loss sweep: {checked} crash scenarios checked");
}

#[test]
fn memory_cap_refuses_writes_instead_of_dropping_data() {
    let (f, _) = vfs();
    let h = f.open("huge", create()).unwrap();
    // writing at a far offset allocates only the touched chunk, so this stays cheap; the cap trips on dirty chunk count
    let mut off = 0u64;
    let mut refused = false;
    for _ in 0..5000 {
        match f.write(h, off, &[1u8; 16]) {
            Ok(_) => off += 65536,
            Err(VfsError::NoSpace) => {
                refused = true;
                break;
            }
            Err(e) => panic!("{e:?}"),
        }
    }
    assert!(refused, "the per-file dirty memory cap must refuse further writes");
    let _ = into_storage;
}
