//! Folder import and restore with verification. Never deletes anything by itself: removal of originals (and of the
//! vault after a restore) are separate explicit steps and are ordinary deletes, never secure erasure.
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use vault_core::{DiskStorage, Vault};

pub const IO_BLOCK: usize = 1 << 20;

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct FileRecord {
    pub path: String,
    pub size: u64,
    pub sha256: String,
}

#[derive(Clone, Debug, Serialize, Deserialize, Default)]
pub struct ImportReport {
    pub files: Vec<FileRecord>,
    pub skipped: Vec<String>,
    pub errors: Vec<String>,
    pub verified: bool,
    pub bytes: u64,
}

fn hex(b: &[u8]) -> String {
    b.iter().map(|x| format!("{x:02x}")).collect()
}

fn walk(root: &Path, rel: &str, out: &mut Vec<(String, PathBuf)>, dirs: &mut Vec<String>, skipped: &mut Vec<String>) {
    let Ok(rd) = std::fs::read_dir(root) else {
        skipped.push(format!("{rel}: unreadable directory"));
        return;
    };
    let mut entries: Vec<_> = rd.flatten().collect();
    entries.sort_by_key(|e| e.file_name());
    for e in entries {
        let name = e.file_name().to_string_lossy().into_owned();
        let r = if rel.is_empty() { name.clone() } else { format!("{rel}/{name}") };
        let Ok(ft) = e.file_type() else { continue };
        if ft.is_symlink() {
            skipped.push(format!("{r}: symbolic link not followed"));
        } else if ft.is_dir() {
            dirs.push(r.clone());
            walk(&e.path(), &r, out, dirs, skipped);
        } else if ft.is_file() {
            out.push((r, e.path()));
        } else {
            skipped.push(format!("{r}: special file"));
        }
    }
}

fn mtime_secs(p: &Path) -> u64 {
    std::fs::metadata(p).and_then(|m| m.modified()).ok().and_then(|t| t.duration_since(std::time::UNIX_EPOCH).ok()).map(|d| d.as_secs()).unwrap_or(0)
}

/// Copy every file of `source` into the vault (one durable commit per file), then verify by re-reading from the vault.
/// `alive` is called between blocks; it keeps the board session alive and returns false once the session is lost, which
/// aborts the operation (the caller then reports the failure and nothing is verified).
pub fn import_folder(vault: &mut Vault<DiskStorage>, source: &Path, alive: &mut dyn FnMut() -> bool) -> ImportReport {
    let mut rep = ImportReport::default();
    let (mut files, mut dirs) = (vec![], vec![]);
    walk(source, "", &mut files, &mut dirs, &mut rep.skipped);
    for d in &dirs {
        if let Err(e) = vault.mkdir(d) {
            rep.errors.push(format!("{d}: {e}"));
        }
    }
    for (rel, path) in &files {
        match import_one(vault, rel, path, alive) {
            Ok(rec) => {
                rep.bytes += rec.size;
                rep.files.push(rec);
            }
            Err(e) => rep.errors.push(format!("{rel}: {e}")),
        }
    }
    // Verification: decrypt every imported file from the vault and compare with the hash of the ORIGINAL bytes.
    rep.verified = rep.errors.is_empty() && rep.files.iter().all(|f| verify_in_vault(vault, f, alive).unwrap_or(false));
    rep
}

fn import_one(vault: &mut Vault<DiskStorage>, rel: &str, path: &Path, alive: &mut dyn FnMut() -> bool) -> Result<FileRecord, String> {
    let mut f = std::fs::File::open(path).map_err(|e| e.to_string())?;
    let mut ed = vault.edit(rel, true, true).map_err(|e| e.to_string())?;
    let mut h = Sha256::new();
    let mut buf = vec![0u8; IO_BLOCK];
    let mut off = 0u64;
    loop {
        let n = f.read(&mut buf).map_err(|e| e.to_string())?;
        if n == 0 {
            break;
        }
        if !alive() {
            return Err("the board session was lost".into());
        }
        h.update(&buf[..n]);
        vault.editor_write(&mut ed, off, &buf[..n]).map_err(|e| e.to_string())?;
        off += n as u64;
    }
    vault.commit_editor(ed, mtime_secs(path)).map_err(|e| e.to_string())?;
    Ok(FileRecord { path: rel.into(), size: off, sha256: hex(&h.finalize()) })
}

pub fn verify_in_vault(vault: &Vault<DiskStorage>, rec: &FileRecord, alive: &mut dyn FnMut() -> bool) -> Result<bool, String> {
    let st = vault.stat(&rec.path).map_err(|e| e.to_string())?;
    if st.size != rec.size {
        return Ok(false);
    }
    let mut h = Sha256::new();
    let mut off = 0u64;
    while off < rec.size {
        if !alive() {
            return Err("the board session was lost".into());
        }
        let b = vault.read_range(&rec.path, off, IO_BLOCK).map_err(|e| e.to_string())?;
        if b.is_empty() {
            return Ok(false);
        }
        h.update(&b);
        off += b.len() as u64;
    }
    Ok(hex(&h.finalize()) == rec.sha256)
}

/// Remove the ORIGINAL files after a verified import. Re-checks each source file against the recorded hash first, so a
/// file changed since the import is left alone. Ordinary delete; not secure erasure on SSD/flash.
pub fn delete_originals(source: &Path, rep: &ImportReport) -> (usize, Vec<String>) {
    let mut deleted = 0;
    let mut kept = vec![];
    if !rep.verified {
        return (0, vec!["import was not verified: nothing deleted".into()]);
    }
    for f in &rep.files {
        let p = source.join(&f.path);
        let same = std::fs::File::open(&p)
            .ok()
            .map(|mut fh| {
                let mut h = Sha256::new();
                let mut buf = vec![0u8; IO_BLOCK];
                while let Ok(n) = fh.read(&mut buf) {
                    if n == 0 {
                        break;
                    }
                    h.update(&buf[..n]);
                }
                hex(&h.finalize()) == f.sha256
            })
            .unwrap_or(false);
        if same && std::fs::remove_file(&p).is_ok() {
            deleted += 1;
        } else {
            kept.push(f.path.clone());
        }
    }
    // remove now-empty directories, deepest first
    let mut dirs: Vec<&str> = rep.files.iter().filter_map(|f| f.path.rsplit_once('/').map(|x| x.0)).collect();
    dirs.sort_by_key(|d| std::cmp::Reverse(d.len()));
    dirs.dedup();
    for d in dirs {
        let _ = std::fs::remove_dir(source.join(d));
    }
    (deleted, kept)
}

/// Decrypt the whole vault into `dest` and verify each restored file against the vault content.
pub fn restore_all(vault: &Vault<DiskStorage>, dest: &Path, alive: &mut dyn FnMut() -> bool) -> Result<ImportReport, String> {
    let mut rep = ImportReport::default();
    std::fs::create_dir_all(dest).map_err(|e| e.to_string())?;
    let mut paths: Vec<String> = vault.all_files().into_iter().filter(|p| !p.starts_with(".gp/")).collect();
    paths.sort();
    for p in &paths {
        let out = dest.join(p);
        if let Some(parent) = out.parent() {
            std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        }
        let st = vault.stat(p).map_err(|e| e.to_string())?;
        let mut fh = std::fs::File::create(&out).map_err(|e| e.to_string())?;
        let mut h = Sha256::new();
        let mut off = 0u64;
        while off < st.size {
            if !alive() {
                return Err("the board session was lost".into());
            }
            let b = vault.read_range(p, off, IO_BLOCK).map_err(|e| e.to_string())?;
            fh.write_all(&b).map_err(|e| e.to_string())?;
            h.update(&b);
            off += b.len() as u64;
        }
        fh.sync_all().map_err(|e| e.to_string())?;
        rep.bytes += st.size;
        rep.files.push(FileRecord { path: p.clone(), size: st.size, sha256: hex(&h.finalize()) });
    }
    // verify the files on disk (re-read from the destination)
    rep.verified = rep.files.iter().all(|f| {
        std::fs::read(dest.join(&f.path)).map(|b| b.len() as u64 == f.size && hex(&Sha256::digest(&b)) == f.sha256).unwrap_or(false)
    });
    Ok(rep)
}
