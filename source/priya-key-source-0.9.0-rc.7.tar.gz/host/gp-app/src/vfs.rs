//! Platform-independent virtual file system over an unlocked vault. The WinFsp adapter (Windows) and the
//! DocumentsProvider adapter (Android) are thin layers over this, so editor behavior is tested once, on the Mac.
//!
//! Commit points (architecture 10): `flush` commits synchronously; the last `close` of a modified file commits
//! (policy A: the closed content becomes the current version, the previous version stays in the version store);
//! `rename` is one atomic journal record; plain `write` is never a durability point. Dirty data lives in memory only
//! (no plaintext on disk). `lock` rejects new work at once, drops the vault (zeroizing its keys) and discards uncommitted
//! edits; the last committed version is untouched.
use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use vault_core::{Editor, Entry, Storage, Vault};

pub const MAX_DIRTY_PER_FILE: usize = 256 << 20;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum VfsError {
    Locked,
    NotFound,
    Exists,
    IsDir,
    NotDir,
    NotEmpty,
    NoSpace,
    BadHandle,
    ReadOnly,
    Io(String),
}

impl From<vault_core::Error> for VfsError {
    fn from(e: vault_core::Error) -> Self {
        use vault_core::Error as E;
        match e {
            E::NotFound(_) => VfsError::NotFound,
            E::Exists(_) => VfsError::Exists,
            E::ReadOnly(_) => VfsError::ReadOnly,
            E::InvalidArgument(m) if m.contains("not empty") => VfsError::NotEmpty,
            E::InvalidArgument(m) if m.contains("directory") => VfsError::IsDir,
            other => VfsError::Io(other.to_string()),
        }
    }
}
pub type VResult<T> = Result<T, VfsError>;

#[derive(Clone, Copy, Debug, Default)]
pub struct OpenOpts {
    pub create: bool,
    pub create_new: bool,
    pub truncate: bool,
    pub write: bool,
    pub delete_on_close: bool,
}

struct OpenFile {
    editor: Option<Editor>,
    dirty: bool,
    is_new: bool,
    refs: usize,
    delete_on_close: bool,
}

struct Handle {
    path: String,
    is_dir: bool,
    write: bool,
}

struct State<S: Storage> {
    vault: Option<Vault<S>>,
    files: HashMap<String, OpenFile>,
    handles: HashMap<u64, Handle>,
}

pub struct Vfs<S: Storage> {
    st: Mutex<State<S>>,
    locked: AtomicBool,
    next: AtomicU64,
    saving: Arc<AtomicUsize>,
    now: fn() -> u64,
}

fn clock() -> u64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

impl<S: Storage> Vfs<S> {
    pub fn new(vault: Vault<S>) -> Self {
        Self::with_clock(vault, clock)
    }
    pub fn with_clock(vault: Vault<S>, now: fn() -> u64) -> Self {
        Vfs { st: Mutex::new(State { vault: Some(vault), files: HashMap::new(), handles: HashMap::new() }), locked: AtomicBool::new(false), next: AtomicU64::new(1), saving: Arc::new(AtomicUsize::new(0)), now }
    }
    pub fn is_locked(&self) -> bool {
        self.locked.load(Ordering::SeqCst)
    }
    pub fn saving(&self) -> Arc<AtomicUsize> {
        self.saving.clone()
    }
    pub fn is_saving(&self) -> bool {
        self.saving.load(Ordering::SeqCst) > 0
    }

    /// Reject new work immediately, discard uncommitted edits, drop the vault (keys zeroized).
    pub fn lock(&self) {
        self.locked.store(true, Ordering::SeqCst); // new operations fail from this instant
        let mut g = self.st.lock().unwrap(); // an in-flight commit finishes first (it holds this lock)
        g.files.clear();
        g.handles.clear();
        g.vault = None;
    }

    fn guard(&self) -> VResult<std::sync::MutexGuard<'_, State<S>>> {
        if self.is_locked() {
            return Err(VfsError::Locked);
        }
        let g = self.st.lock().unwrap();
        if g.vault.is_none() || self.is_locked() {
            return Err(VfsError::Locked);
        }
        Ok(g)
    }

    /// Run a closure with the vault (browsing, previews).
    pub fn with_vault<R>(&self, f: impl FnOnce(&mut Vault<S>) -> R) -> VResult<R> {
        let mut g = self.guard()?;
        Ok(f(g.vault.as_mut().unwrap()))
    }

    fn commit_file(&self, g: &mut State<S>, path: &str) -> VResult<()> {
        let now = (self.now)();
        let Some(of) = g.files.get_mut(path) else { return Ok(()) };
        if !of.dirty && !of.is_new {
            return Ok(());
        }
        let Some(ed) = of.editor.take() else { return Ok(()) };
        self.saving.fetch_add(1, Ordering::SeqCst);
        let r = g.vault.as_mut().unwrap().commit_editor(ed, now);
        self.saving.fetch_sub(1, Ordering::SeqCst);
        let of = g.files.get_mut(path).unwrap();
        match r {
            Ok(()) => {
                of.dirty = false;
                of.is_new = false;
                Ok(())
            }
            Err(e) => {
                // The editor was consumed by the failed commit; the committed version is untouched. Report the failure.
                of.dirty = false;
                Err(e.into())
            }
        }
    }

    fn ensure_editor(&self, g: &mut State<S>, path: &str) -> VResult<()> {
        let of = g.files.get_mut(path).ok_or(VfsError::BadHandle)?;
        if of.editor.is_none() {
            let v = g.vault.as_ref().unwrap();
            let ed = v.edit(path, false, false)?;
            g.files.get_mut(path).unwrap().editor = Some(ed);
        }
        Ok(())
    }

    // ------------------------------------------------------------------ open / close
    pub fn open(&self, path: &str, opts: OpenOpts) -> VResult<u64> {
        let mut g = self.guard()?;
        let p = vault_core::vault::norm_path(path).map_err(VfsError::from)?;
        let v = g.vault.as_ref().unwrap();
        let existing = g.files.contains_key(&p) || v.stat(&p).is_ok();
        let is_dir = !g.files.contains_key(&p) && v.stat(&p).map(|e| e.is_dir).unwrap_or(false);
        if opts.create_new && existing {
            return Err(VfsError::Exists);
        }
        if !existing && !opts.create {
            return Err(VfsError::NotFound);
        }
        if is_dir {
            let id = self.next.fetch_add(1, Ordering::SeqCst);
            g.handles.insert(id, Handle { path: p, is_dir: true, write: false });
            return Ok(id);
        }
        if !g.files.contains_key(&p) {
            let (editor, is_new) = if existing {
                (None, false)
            } else {
                (Some(g.vault.as_ref().unwrap().edit(&p, true, false)?), true)
            };
            g.files.insert(p.clone(), OpenFile { editor, dirty: false, is_new, refs: 0, delete_on_close: false });
        }
        {
            let of = g.files.get_mut(&p).unwrap();
            of.refs += 1;
            of.delete_on_close |= opts.delete_on_close;
        }
        if opts.truncate && existing {
            self.ensure_editor(&mut g, &p)?;
            // open-mode truncation is staged: nothing is committed until a commit point
            let st = &mut *g;
            let vault = st.vault.as_ref().unwrap();
            let of = st.files.get_mut(&p).unwrap();
            vault.editor_set_len(of.editor.as_mut().unwrap(), 0)?;
            of.dirty = true;
        }
        let id = self.next.fetch_add(1, Ordering::SeqCst);
        g.handles.insert(id, Handle { path: p, is_dir: false, write: opts.write || opts.create || opts.truncate });
        Ok(id)
    }

    pub fn close(&self, h: u64) -> VResult<()> {
        let mut g = self.guard()?;
        let hd = g.handles.remove(&h).ok_or(VfsError::BadHandle)?;
        if hd.is_dir {
            return Ok(());
        }
        let last = {
            let of = g.files.get_mut(&hd.path).ok_or(VfsError::BadHandle)?;
            of.refs -= 1;
            of.refs == 0
        };
        if !last {
            return Ok(());
        }
        let del = g.files.get(&hd.path).map(|f| f.delete_on_close).unwrap_or(false);
        if del {
            let existed = g.vault.as_ref().unwrap().stat(&hd.path).is_ok();
            g.files.remove(&hd.path);
            if existed {
                g.vault.as_mut().unwrap().delete(&hd.path)?;
            }
            return Ok(());
        }
        let r = self.commit_file(&mut g, &hd.path); // policy A: closed content becomes current, previous kept
        g.files.remove(&hd.path);
        r
    }

    pub fn set_delete_on_close(&self, h: u64, on: bool) -> VResult<()> {
        let mut g = self.guard()?;
        let path = g.handles.get(&h).ok_or(VfsError::BadHandle)?.path.clone();
        if let Some(of) = g.files.get_mut(&path) {
            of.delete_on_close = on;
        }
        Ok(())
    }

    // ------------------------------------------------------------------ data
    pub fn read(&self, h: u64, off: u64, len: usize) -> VResult<Vec<u8>> {
        let g = self.guard()?;
        let hd = g.handles.get(&h).ok_or(VfsError::BadHandle)?;
        if hd.is_dir {
            return Err(VfsError::IsDir);
        }
        let v = g.vault.as_ref().unwrap();
        if let Some(ed) = g.files.get(&hd.path).and_then(|f| f.editor.as_ref()) {
            return Ok(v.editor_read(ed, off, len)?);
        }
        if g.files.get(&hd.path).map(|f| f.is_new).unwrap_or(false) {
            return Ok(vec![]);
        }
        Ok(v.read_range(&hd.path, off, len)?)
    }

    pub fn write(&self, h: u64, off: u64, data: &[u8]) -> VResult<usize> {
        let mut g = self.guard()?;
        let (path, writable) = {
            let hd = g.handles.get(&h).ok_or(VfsError::BadHandle)?;
            (hd.path.clone(), hd.write)
        };
        if !writable {
            return Err(VfsError::ReadOnly);
        }
        self.ensure_editor(&mut g, &path)?;
        let st = &mut *g;
        let vault = st.vault.as_ref().unwrap();
        let of = st.files.get_mut(&path).unwrap();
        let ed = of.editor.as_mut().unwrap();
        if ed.dirty_bytes() > MAX_DIRTY_PER_FILE {
            return Err(VfsError::NoSpace);
        }
        vault.editor_write(ed, off, data)?;
        of.dirty = true;
        Ok(data.len())
    }

    pub fn set_len(&self, h: u64, len: u64) -> VResult<()> {
        let mut g = self.guard()?;
        let path = g.handles.get(&h).ok_or(VfsError::BadHandle)?.path.clone();
        self.ensure_editor(&mut g, &path)?;
        let st = &mut *g;
        let vault = st.vault.as_ref().unwrap();
        let of = st.files.get_mut(&path).unwrap();
        vault.editor_set_len(of.editor.as_mut().unwrap(), len)?;
        of.dirty = true;
        Ok(())
    }

    /// FlushFileBuffers / fsync: commit now. Success means the commit is as durable as the storage backend allows.
    pub fn flush(&self, h: u64) -> VResult<()> {
        let mut g = self.guard()?;
        let path = g.handles.get(&h).ok_or(VfsError::BadHandle)?.path.clone();
        if g.handles.get(&h).map(|x| x.is_dir).unwrap_or(false) {
            return Ok(());
        }
        self.commit_file(&mut g, &path)?;
        // keep editing after the commit: the next write re-opens an editor from the new committed root
        Ok(())
    }

    // ------------------------------------------------------------------ metadata and namespace
    pub fn stat_handle(&self, h: u64) -> VResult<Entry> {
        let g = self.guard()?;
        let hd = g.handles.get(&h).ok_or(VfsError::BadHandle)?;
        self.stat_in(&g, &hd.path)
    }

    pub fn stat(&self, path: &str) -> VResult<Entry> {
        let g = self.guard()?;
        let p = vault_core::vault::norm_path(path).map_err(VfsError::from)?;
        self.stat_in(&g, &p)
    }

    fn stat_in(&self, g: &State<S>, p: &str) -> VResult<Entry> {
        if let Some(of) = g.files.get(p) {
            if let Some(ed) = &of.editor {
                return Ok(Entry { name: p.rsplit('/').next().unwrap().into(), is_dir: false, size: ed.size(), mtime: (self.now)() });
            }
        }
        Ok(g.vault.as_ref().unwrap().stat(p)?)
    }

    pub fn list(&self, dir: &str) -> VResult<Vec<Entry>> {
        let g = self.guard()?;
        let mut l = g.vault.as_ref().unwrap().list(dir)?;
        if dir.is_empty() {
            l.retain(|e| e.name != ".gp");
        }
        // include files created and not yet committed
        let prefix = if dir.is_empty() { String::new() } else { format!("{}/", vault_core::vault::norm_path(dir).map_err(VfsError::from)?) };
        for (p, of) in &g.files {
            if of.is_new {
                if let Some(rest) = p.strip_prefix(&prefix) {
                    if !rest.contains('/') && !l.iter().any(|e| e.name == rest) {
                        l.push(Entry { name: rest.into(), is_dir: false, size: of.editor.as_ref().map(|e| e.size()).unwrap_or(0), mtime: (self.now)() });
                    }
                }
            }
        }
        l.sort_by(|a, b| a.name.cmp(&b.name));
        Ok(l)
    }

    pub fn mkdir(&self, path: &str) -> VResult<()> {
        let mut g = self.guard()?;
        let p = vault_core::vault::norm_path(path).map_err(VfsError::from)?;
        if g.vault.as_ref().unwrap().exists(&p)? {
            return Err(VfsError::Exists);
        }
        Ok(g.vault.as_mut().unwrap().mkdir(&p)?)
    }

    pub fn rmdir(&self, path: &str) -> VResult<()> {
        let mut g = self.guard()?;
        Ok(g.vault.as_mut().unwrap().rmdir(path)?)
    }

    /// Delete a file (or defer to the last close if it is open elsewhere).
    pub fn delete(&self, path: &str) -> VResult<()> {
        let mut g = self.guard()?;
        let p = vault_core::vault::norm_path(path).map_err(VfsError::from)?;
        if let Some(of) = g.files.get_mut(&p) {
            if of.refs > 0 {
                of.delete_on_close = true;
                return Ok(());
            }
        }
        Ok(g.vault.as_mut().unwrap().delete(&p)?)
    }

    /// Atomic rename (one journal record). Dirty open files under `from` are committed first so the new name carries
    /// their content; open handles follow the rename.
    pub fn rename(&self, from: &str, to: &str, replace: bool) -> VResult<()> {
        let mut g = self.guard()?;
        let f = vault_core::vault::norm_path(from).map_err(VfsError::from)?;
        let t = vault_core::vault::norm_path(to).map_err(VfsError::from)?;
        let affected: Vec<String> = g.files.keys().filter(|k| **k == f || k.starts_with(&format!("{f}/"))).cloned().collect();
        for a in &affected {
            self.commit_file(&mut g, a)?;
        }
        let v = g.vault.as_ref().unwrap();
        if v.exists(&t)? && !replace {
            return Err(VfsError::Exists);
        }
        if let Some(of) = g.files.get(&t) {
            if of.refs > 0 {
                return Err(VfsError::Io("target is open".into()));
            }
        }
        g.vault.as_mut().unwrap().rename(&f, &t)?;
        for a in affected {
            let nk = format!("{t}{}", &a[f.len()..]);
            if let Some(of) = g.files.remove(&a) {
                g.files.insert(nk.clone(), of);
            }
            for hd in g.handles.values_mut() {
                if hd.path == a {
                    hd.path = nk.clone();
                }
            }
        }
        Ok(())
    }

    pub fn open_handle_count(&self) -> usize {
        self.st.lock().unwrap().handles.len()
    }
}
