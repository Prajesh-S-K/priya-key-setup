//! Signed dashboard image stored on the board (partition "assets") and cached by the app.
//!
//! Image layout (little endian): "GKAS" | version u16 | flags u16 | total u32 | sha256(payload) [32] | ed25519 signature [64]
//! | payload (gzip of the dashboard HTML). The signature covers bytes 0..12 followed by the SHA-256. The board only serves
//! the bytes; trust comes from the signature, checked against the public key compiled into the app.
use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use flate2::{read::GzDecoder, write::GzEncoder, Compression};
use sha2::{Digest, Sha256};
use std::io::{Read, Write};

pub const MAGIC: &[u8; 4] = b"GKAS";
pub const HEADER: usize = 12 + 32 + 64;
pub const MAX_IMAGE: usize = 0x10000;
/// Version of the dashboard bundled in this build. The board/cached copy is used only if its version is not lower.
pub const BUNDLED_VERSION: u16 = 1;
/// Public key of the release signing key (the private key never ships; see tools/release.sh).
pub const PUBLIC_KEY: [u8; 32] = include!("assets_pub.in");

pub struct Image {
    pub version: u16,
    pub html: String,
}

fn signed_part(head: &[u8], sha: &[u8]) -> Vec<u8> {
    let mut m = head[..12].to_vec();
    m.extend_from_slice(sha);
    m
}

pub fn pack(html: &str, version: u16, key: &SigningKey) -> Result<Vec<u8>, String> {
    let mut gz = GzEncoder::new(Vec::new(), Compression::best());
    gz.write_all(html.as_bytes()).map_err(|e| e.to_string())?;
    let payload = gz.finish().map_err(|e| e.to_string())?;
    let total = HEADER + payload.len();
    if total > MAX_IMAGE {
        return Err(format!("image is {total} bytes, the partition holds {MAX_IMAGE}"));
    }
    let mut img = Vec::with_capacity(total);
    img.extend_from_slice(MAGIC);
    img.extend_from_slice(&version.to_le_bytes());
    img.extend_from_slice(&0u16.to_le_bytes());
    img.extend_from_slice(&(total as u32).to_le_bytes());
    let sha = Sha256::digest(&payload);
    img.extend_from_slice(&sha);
    let sig = key.sign(&signed_part(&img, &sha));
    img.extend_from_slice(&sig.to_bytes());
    img.extend_from_slice(&payload);
    Ok(img)
}

pub fn verify(img: &[u8], public: &[u8; 32]) -> Result<Image, String> {
    if img.len() < HEADER || img.len() > MAX_IMAGE || &img[..4] != MAGIC {
        return Err("not a dashboard image".into());
    }
    let total = u32::from_le_bytes(img[8..12].try_into().unwrap()) as usize;
    if total != img.len() {
        return Err("length mismatch".into());
    }
    let payload = &img[HEADER..];
    let sha = Sha256::digest(payload);
    if sha.as_slice() != &img[12..44] {
        return Err("checksum mismatch".into());
    }
    let vk = VerifyingKey::from_bytes(public).map_err(|e| e.to_string())?;
    let sig = Signature::from_slice(&img[44..108]).map_err(|e| e.to_string())?;
    vk.verify(&signed_part(img, &sha), &sig).map_err(|_| "signature is not valid".to_string())?;
    let mut html = String::new();
    GzDecoder::new(payload).take(1 << 20).read_to_string(&mut html).map_err(|e| e.to_string())?;
    Ok(Image { version: u16::from_le_bytes(img[4..6].try_into().unwrap()), html })
}

/// Choose what to show: the cached copy if it is valid and not older than the bundled one, else the bundled page.
pub fn choose(cache: Option<&[u8]>, bundled: &str, public: &[u8; 32]) -> (String, String, u16) {
    if let Some(c) = cache {
        if let Ok(i) = verify(c, public) {
            if i.version >= BUNDLED_VERSION {
                return (i.html, "board image (cached)".into(), i.version);
            }
        }
    }
    (bundled.to_string(), "bundled with the app".into(), BUNDLED_VERSION)
}
