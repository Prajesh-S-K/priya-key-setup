//! gp-app: platform-independent application service for the Windows and Android apps.
//! Owns the device session, the registry of protected folders, import/restore with verification, previews and locking.
//! Platform layers (WinFsp, DocumentsProvider, UI) call `Service` and honor `OpenVault::is_locked()` on every operation.
pub mod api;
pub mod assets;
pub mod backup;
pub mod import;
pub mod service;
pub mod vfs;

pub use service::*;
