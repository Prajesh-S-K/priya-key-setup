//! JSON command interface used by the dashboard through the native bridge (WebView2 / Android WebView).
//! One request -> one response. The dashboard never sees keys, KEKs or arbitrary file paths it did not pick through a
//! native picker; destructive commands are expected to be confirmed natively by the host before this is called.
use crate::service::{Event, Service};
use gpkey_host::{AuthResult, Link};
use serde::Deserialize;
use serde_json::{json, Value};
use std::path::Path;
use std::time::Duration;

#[derive(Deserialize)]
#[serde(tag = "cmd", rename_all = "snake_case")]
pub enum Request {
    Status,
    Pair { pin: String },
    Auth { pin: String },
    LockAll,
    ChangePin { old: String, new: String },
    SetupRecovery,
    RotateRecovery,
    RecoverVault { dir: String, code: String },
    AddFolder { source: Option<String>, parent: String, name: String, hidden: bool },
    DeleteOriginals { id: String },
    Unlock { id: String },
    Lock { id: String },
    SetHidden { id: String, hidden: bool },
    Rename { id: String, name: String },
    Browse { id: String, path: String },
    Preview { id: String, path: String },
    Restore { id: String, dest: String },
    DeleteVault { id: String },
    /// Platform layers that restore through their own file API (Android) report the result of their verification here.
    MarkRestored { id: String, verified: bool },
    SetDiscreet { on: bool },
    ExportVault { id: String, dest: String },
    RestoreBackup { src: String, parent: String },
    LinkVault { dir: String },
    Events,
}

fn auth_json(r: AuthResult) -> Value {
    match r {
        AuthResult::Ok => json!({"result": "ok"}),
        AuthResult::WrongPin { delay_ms } => json!({"result": "wrong_pin", "delay_ms": delay_ms}),
        AuthResult::Delayed { remaining_ms } => json!({"result": "delayed", "remaining_ms": remaining_ms}),
        AuthResult::Storage => json!({"result": "storage_error"}),
        AuthResult::NotReady => json!({"result": "not_ready"}),
        AuthResult::BadArg => json!({"result": "bad_pin"}),
        AuthResult::Forbidden => json!({"result": "forbidden"}),
    }
}

pub fn handle<L: Link>(svc: &mut Service<L>, req: &str) -> String {
    let r: Request = match serde_json::from_str(req) {
        Ok(r) => r,
        Err(e) => return json!({"ok": false, "error": format!("bad request: {e}")}).to_string(),
    };
    let out: Result<Value, String> = (|| {
        Ok(match r {
            Request::Status => {
                let st = svc.device_state().map(|s| format!("{s:?}")).unwrap_or_else(|e| format!("Unavailable: {e}"));
                json!({"device": st, "paired": svc.is_paired(), "authenticated": svc.is_authenticated(), "recovery": svc.has_recovery(),
                       "cards": svc.cards(true), "settings": {"discreet": svc.discreet()}})
            }
            Request::Pair { pin } => {
                svc.pair(&pin, Duration::from_secs(90), None)?;
                json!({"paired": true})
            }
            Request::Auth { pin } => auth_json(svc.auth(&pin)?),
            Request::LockAll => {
                svc.lock_all("locked by you");
                json!({})
            }
            Request::ChangePin { old, new } => auth_json(svc.change_pin(&old, &new)?),
            Request::SetupRecovery => json!({"code": svc.setup_recovery()?}),
            Request::RotateRecovery => json!({"code": svc.rotate_recovery()?}),
            Request::RecoverVault { dir, code } => json!({"id": svc.recover_vault(Path::new(&dir), &code)?}),
            Request::AddFolder { source, parent, name, hidden } => {
                let (id, rep) = svc.add_folder(source.as_deref().map(Path::new), Path::new(&parent), &name, hidden)?;
                json!({"id": id, "import": rep})
            }
            Request::DeleteOriginals { id } => {
                let (n, kept) = svc.delete_originals(&id)?;
                json!({"deleted": n, "kept": kept, "note": "Ordinary delete; this is not secure erasure on SSD or flash storage."})
            }
            Request::Unlock { id } => {
                svc.unlock(&id)?;
                json!({})
            }
            Request::Lock { id } => {
                svc.lock(&id);
                json!({})
            }
            Request::SetHidden { id, hidden } => {
                svc.set_hidden(&id, hidden)?;
                json!({})
            }
            Request::Rename { id, name } => {
                svc.rename_folder(&id, &name)?;
                json!({})
            }
            Request::Browse { id, path } => json!({"entries": svc.browse(&id, &path)?.iter().map(|e| json!({"name": e.name, "dir": e.is_dir, "size": e.size, "mtime": e.mtime})).collect::<Vec<_>>()}),
            Request::Preview { id, path } => serde_json::to_value(svc.preview(&id, &path)?).unwrap(),
            Request::Restore { id, dest } => serde_json::to_value(svc.restore(&id, Path::new(&dest))?).unwrap(),
            Request::DeleteVault { id } => {
                svc.delete_vault(&id)?;
                json!({"note": "Ordinary delete; this is not secure erasure on SSD or flash storage."})
            }
            Request::ExportVault { id, dest } => {
                let r = svc.export_vault(&id, Path::new(&dest))?;
                json!({"report": r, "note": "This is a copy of the ENCRYPTED folder. Keep it somewhere safe; the recovery code cannot recreate a folder file that was deleted."})
            }
            Request::RestoreBackup { src, parent } => {
                let (id, r) = svc.restore_backup(Path::new(&src), Path::new(&parent))?;
                json!({"id": id, "report": r})
            }
            Request::LinkVault { dir } => json!({"id": svc.link_vault(Path::new(&dir))?}),
            Request::SetDiscreet { on } => {
                svc.set_discreet(on)?;
                json!({"discreet": on})
            }
            Request::MarkRestored { id, verified } => {
                svc.mark_restored(&id, verified);
                json!({})
            }
            Request::Events => json!({"events": svc.take_events().iter().map(|Event::Locked(r)| json!({"type": "locked", "reason": r})).collect::<Vec<_>>()}),
        })
    })();
    match out {
        Ok(v) => json!({"ok": true, "data": v}).to_string(),
        Err(e) => json!({"ok": false, "error": e}).to_string(),
    }
}
