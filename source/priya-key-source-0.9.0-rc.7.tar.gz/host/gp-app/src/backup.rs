//! Verified copies of the ENCRYPTED vault folder (backup / move to another device). Only ciphertext is copied; every file is
//! hashed on both sides and compared. A backup is only as safe as where you keep it, and the recovery code cannot replace a
//! vault file that no longer exists.
use serde::Serialize;
use sha2::{Digest, Sha256};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};

#[derive(Clone, Debug, Serialize, Default)]
pub struct BackupReport {
    pub dest: String,
    pub files: usize,
    pub bytes: u64,
    pub verified: bool,
    pub errors: Vec<String>,
}

fn walk(root: &Path, rel: &Path, out: &mut Vec<PathBuf>) -> std::io::Result<()> {
    for e in std::fs::read_dir(root.join(rel))? {
        let e = e?;
        let r = rel.join(e.file_name());
        if e.file_type()?.is_dir() {
            walk(root, &r, out)?;
        } else {
            out.push(r);
        }
    }
    Ok(())
}

fn hash_file(p: &Path) -> std::io::Result<([u8; 32], u64)> {
    let mut f = std::fs::File::open(p)?;
    let (mut h, mut n, mut buf) = (Sha256::new(), 0u64, vec![0u8; 1 << 16]);
    loop {
        let k = f.read(&mut buf)?;
        if k == 0 {
            break;
        }
        h.update(&buf[..k]);
        n += k as u64;
    }
    Ok((h.finalize().into(), n))
}

/// Copy `src` (a `.gpv` directory) to `dest` (must not exist), fsync, then compare every file's hash and the file lists.
pub fn copy_verified(src: &Path, dest: &Path, alive: &mut dyn FnMut() -> bool) -> BackupReport {
    let mut rep = BackupReport { dest: dest.display().to_string(), ..Default::default() };
    let r: Result<(), String> = (|| {
        if dest.exists() {
            return Err("the destination already exists".into());
        }
        let mut files = vec![];
        walk(src, Path::new(""), &mut files).map_err(|e| e.to_string())?;
        for rel in &files {
            if !alive() {
                return Err("the board session was lost".into());
            }
            let to = dest.join(rel);
            std::fs::create_dir_all(to.parent().unwrap()).map_err(|e| e.to_string())?;
            let mut i = std::fs::File::open(src.join(rel)).map_err(|e| e.to_string())?;
            let mut o = std::fs::File::create(&to).map_err(|e| e.to_string())?;
            std::io::copy(&mut i, &mut o).map_err(|e| e.to_string())?;
            o.flush().map_err(|e| e.to_string())?;
            o.sync_all().map_err(|e| e.to_string())?;
        }
        let mut copied = vec![];
        walk(dest, Path::new(""), &mut copied).map_err(|e| e.to_string())?;
        let (mut a, mut b) = (files.clone(), copied);
        a.sort();
        b.sort();
        if a != b {
            return Err("the copied file list differs from the original".into());
        }
        for rel in &files {
            let (h1, n1) = hash_file(&src.join(rel)).map_err(|e| e.to_string())?;
            let (h2, n2) = hash_file(&dest.join(rel)).map_err(|e| e.to_string())?;
            if h1 != h2 || n1 != n2 {
                return Err(format!("{} differs after copying", rel.display()));
            }
            rep.bytes += n2;
        }
        rep.files = files.len();
        Ok(())
    })();
    match r {
        Ok(()) => rep.verified = true,
        Err(e) => rep.errors.push(e),
    }
    rep
}
