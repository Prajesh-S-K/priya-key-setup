//! Controller behaviour against the real device core (host simulator) with a recording mounter.
use gp_app::vfs::Vfs;
use gp_windows::controller::{BoxLink, Controller, Mounter, UiEvent};
use gpkey_host::frame::Frame;
use gpkey_host::{Link, LinkError, SimLink};
use serde_json::{json, Value};
use std::path::Path;
use std::process::Command;
use std::sync::{Arc, Mutex};
use std::time::Duration;
use vault_core::storage::DiskStorage;

#[derive(Default, Clone)]
struct Rec(Arc<Mutex<Vec<String>>>);
impl Mounter for Rec {
    fn mount(&mut self, _id: &str, label: &str, vfs: Arc<Vfs<DiskStorage>>) -> Result<String, String> {
        assert!(!vfs.is_locked());
        self.0.lock().unwrap().push(format!("mount {label}"));
        Ok("Z:".into())
    }
    fn unmount(&mut self, _id: &str) {
        self.0.lock().unwrap().push("unmount".into());
    }
}

/// Lets the test press the simulated BOOT button while the controller owns the link.
struct Shared(Arc<Mutex<SimLink>>);
impl Link for Shared {
    fn send(&mut self, b: &[u8]) -> Result<(), LinkError> {
        self.0.lock().unwrap().send(b)
    }
    fn recv_frame(&mut self, t: Duration) -> Result<Option<Frame>, LinkError> {
        self.0.lock().unwrap().recv_frame(t)
    }
}

fn sim() -> String {
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../firmware");
    let bin = root.join("gpkey/sim/gk_sim");
    if !bin.exists() {
        assert!(Command::new("sh").arg(root.join("gpkey/sim/build.sh")).status().unwrap().success());
    }
    bin.canonicalize().unwrap().to_str().unwrap().to_string()
}

fn call(c: &mut Controller<Rec>, v: Value) -> Value {
    serde_json::from_str(&c.handle(&v.to_string())).unwrap()
}

fn rig() -> (tempfile::TempDir, Controller<Rec>, Rec, Arc<Mutex<SimLink>>) {
    let t = tempfile::tempdir().unwrap();
    std::fs::create_dir_all(t.path().join("board")).unwrap();
    let sl = Arc::new(Mutex::new(SimLink::spawn(&sim(), t.path().join("board").to_str().unwrap(), &[]).unwrap()));
    let rec = Rec::default();
    let c = Controller::with_link(t.path().join("home"), rec.clone(), Box::new(Shared(sl.clone())) as BoxLink).unwrap();
    (t, c, rec, sl)
}

fn setup(t: &tempfile::TempDir, c: &mut Controller<Rec>, sl: &Arc<Mutex<SimLink>>) -> String {
    let src = t.path().join("src");
    std::fs::create_dir_all(&src).unwrap();
    std::fs::write(src.join("a.txt"), "hello").unwrap();
    let sl2 = sl.clone();
    let done = Arc::new(std::sync::atomic::AtomicBool::new(false));
    let d2 = done.clone();
    let presser = std::thread::spawn(move || {
        // press BOOT only until pairing has finished: a later press would be a privacy-button press
        while !d2.load(std::sync::atomic::Ordering::SeqCst) {
            std::thread::sleep(Duration::from_millis(150));
            if d2.load(std::sync::atomic::Ordering::SeqCst) { break; }
            let _ = sl2.lock().unwrap().button();
        }
    });
    let r = call(c, json!({"cmd":"pair","pin":"2468"}));
    assert!(r["ok"].as_bool().unwrap(), "{r}");
    done.store(true, std::sync::atomic::Ordering::SeqCst);
    presser.join().unwrap();
    assert!(call(c, json!({"cmd":"setup_recovery"}))["ok"].as_bool().unwrap());
    let r = call(c, json!({"cmd":"add_folder","source":src.to_str().unwrap(),"parent":t.path().to_str().unwrap(),"name":"Docs","hidden":false}));
    assert!(r["ok"].as_bool().unwrap(), "{r}");
    r["data"]["id"].as_str().unwrap().to_string()
}

#[test]
fn unlock_mounts_lock_unmounts_and_removal_locks() {
    let (t, mut c, rec, sl) = rig();
    let id = setup(&t, &mut c, &sl);
    let r = call(&mut c, json!({"cmd":"unlock","id":id}));
    assert!(r["ok"].as_bool().unwrap(), "{r}");
    assert_eq!(c.mounts().get(&id).map(String::as_str), Some("Z:"));
    let st = call(&mut c, json!({"cmd":"status"}));
    assert_eq!(st["data"]["mounts"][&id], "Z:");

    call(&mut c, json!({"cmd":"lock","id":id}));
    assert!(c.mounts().is_empty());
    assert_eq!(*rec.0.lock().unwrap(), vec!["mount Docs".to_string(), "unmount".to_string()]);

    call(&mut c, json!({"cmd":"unlock","id":id}));
    assert_eq!(c.mounts().len(), 1);
    let ov = c.service().open_vault(&id).unwrap();
    // the board disappears from the port list: everything locks and unmounts
    c.tick_with(&[], &mut |_| Err("none".into()));
    // (port was never set by discovery in this rig, so force the removal path through a real arrival first)
    let mut opened = 0;
    let sl2 = sl.clone();
    c.tick_with(&["COM9".to_string()], &mut |_| {
        opened += 1;
        Ok(Box::new(Shared(sl2.clone())) as BoxLink)
    });
    assert_eq!(opened, 1);
    assert!(ov.is_locked(), "arrival of a new link must drop the old session");
    assert!(c.mounts().is_empty());
    assert!(!c.service().is_authenticated());
    c.tick_with(&[], &mut |_| Err("none".into()));
    assert!(c.port().is_none());
}

#[test]
fn discreet_mode_conceals_on_removal_and_reveals_on_return_with_a_locked_session() {
    let (t, mut c, _rec, sl) = rig();
    let id = setup(&t, &mut c, &sl);
    // discreet mode is an explicit setting
    assert!(call(&mut c, json!({"cmd":"set_discreet","on":true}))["ok"].as_bool().unwrap());
    assert_eq!(call(&mut c, json!({"cmd":"status"}))["data"]["settings"]["discreet"], true);
    call(&mut c, json!({"cmd":"unlock","id":id}));
    let ov = c.service().open_vault(&id).unwrap();
    // the key "arrives" through discovery, then is unplugged
    let sl2 = sl.clone();
    c.tick_with(&["COM9".to_string()], &mut |_| Ok(Box::new(Shared(sl2.clone())) as BoxLink));
    assert!(c.take_ui().is_empty(), "arrival without a prior conceal shows nothing new");
    c.tick_with(&[], &mut |_| Err("none".into()));
    assert_eq!(c.take_ui(), vec![UiEvent::Conceal]);
    assert!(ov.is_locked(), "everything locked");
    assert!(c.mounts().is_empty());
    assert!(c.is_concealed());
    c.tick_with(&[], &mut |_| Err("none".into()));
    assert!(c.take_ui().is_empty(), "no repeated conceal while the key stays away");
    // reconnection: reveal, but nothing is unlocked and a fresh PIN is required
    let sl3 = sl.clone();
    c.tick_with(&["COM9".to_string()], &mut |_| Ok(Box::new(Shared(sl3.clone())) as BoxLink));
    assert_eq!(c.take_ui(), vec![UiEvent::Reveal]);
    assert!(!c.is_concealed());
    assert!(!c.service().is_authenticated(), "reconnection requires fresh authentication");
    assert!(c.mounts().is_empty());
    let r = call(&mut c, json!({"cmd":"unlock","id":id}));
    assert!(!r["ok"].as_bool().unwrap(), "unlock without a new PIN must be refused: {r}");
}

#[test]
fn without_discreet_mode_removal_only_locks() {
    let (t, mut c, _rec, sl) = rig();
    let id = setup(&t, &mut c, &sl);
    call(&mut c, json!({"cmd":"unlock","id":id}));
    let ov = c.service().open_vault(&id).unwrap();
    let sl2 = sl.clone();
    c.tick_with(&["COM9".to_string()], &mut |_| Ok(Box::new(Shared(sl2.clone())) as BoxLink));
    c.tick_with(&[], &mut |_| Err("none".into()));
    assert!(ov.is_locked());
    assert!(c.take_ui().is_empty(), "off by default: no conceal");
    assert!(!c.is_concealed());
}

#[test]
fn manual_launch_always_shows_and_start_concealed_needs_the_setting() {
    let (_t, mut c, _rec, _sl) = rig();
    c.start_concealed();
    assert!(!c.is_concealed(), "setting off: autostart is not concealed");
    call(&mut c, json!({"cmd":"set_discreet","on":true}));
    c.start_concealed();
    assert!(c.is_concealed());
    c.manual_show();
    assert!(!c.is_concealed(), "the documented manual launch route always works");
}
