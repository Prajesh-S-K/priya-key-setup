fn main() {
    // winfsp-sys asks the linker to delay-load winfsp-x64.dll, but a link argument from a dependency's build script does not
    // reach OUR executable, so the DLL ended up as a normal import: the app then failed to start with "winfsp-x64.dll was not
    // found" (WinFsp's bin folder is not on PATH, and WinFsp may not be installed at all). Delay-load it for the exe itself;
    // `winfsp::winfsp_init()` then loads the DLL by its registered install path before the first WinFsp call.
    // (Cannot use winfsp::build::winfsp_link_delayload(): this script runs on the build host, which may not be Windows.)
    if std::env::var("CARGO_CFG_TARGET_OS").as_deref() == Ok("windows") {
        println!("cargo:rustc-link-lib=dylib=delayimp");
        println!("cargo:rustc-link-arg-bins=/DELAYLOAD:winfsp-x64.dll");
        let res = std::path::Path::new(&std::env::var("CARGO_MANIFEST_DIR").unwrap()).join("assets/app.res");
        println!("cargo:rustc-link-arg-bins={}", res.display());
        println!("cargo:rerun-if-changed=assets/app.res");
    }
}
