//! Windows application: WinFsp mount of unlocked folders, WebView2 dashboard, board discovery.
//! Everything that does not touch Windows APIs (`map`, `device`, `controller`) builds and is tested on any host.
pub mod controller;
pub mod device;
pub mod map;

#[cfg(windows)]
pub mod fs;
#[cfg(windows)]
pub mod ui;
