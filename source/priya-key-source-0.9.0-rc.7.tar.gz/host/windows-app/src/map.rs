//! Pure translations between the platform-neutral VFS and Windows conventions.
use gp_app::vfs::VfsError;

pub const STATUS_INVALID_HANDLE: i32 = 0xC000_0008u32 as i32;
pub const STATUS_ACCESS_DENIED: i32 = 0xC000_0022u32 as i32;
pub const STATUS_OBJECT_NAME_NOT_FOUND: i32 = 0xC000_0034u32 as i32;
pub const STATUS_OBJECT_NAME_COLLISION: i32 = 0xC000_0035u32 as i32;
pub const STATUS_DISK_FULL: i32 = 0xC000_007Fu32 as i32;
pub const STATUS_MEDIA_WRITE_PROTECTED: i32 = 0xC000_00A2u32 as i32;
pub const STATUS_DEVICE_NOT_READY: i32 = 0xC000_00A3u32 as i32;
pub const STATUS_FILE_IS_A_DIRECTORY: i32 = 0xC000_00BAu32 as i32;
pub const STATUS_UNEXPECTED_IO_ERROR: i32 = 0xC000_00E9u32 as i32;
pub const STATUS_DIRECTORY_NOT_EMPTY: i32 = 0xC000_0101u32 as i32;
pub const STATUS_NOT_A_DIRECTORY: i32 = 0xC000_0103u32 as i32;
pub const STATUS_END_OF_FILE: i32 = 0xC000_0011u32 as i32;

pub const FILE_DIRECTORY_FILE: u32 = 0x1;
pub const FILE_NON_DIRECTORY_FILE: u32 = 0x40;
pub const FILE_DELETE_ON_CLOSE: u32 = 0x1000;
pub const FILE_WRITE_DATA: u32 = 0x2;
pub const FILE_APPEND_DATA: u32 = 0x4;
pub const FILE_ATTRIBUTE_DIRECTORY: u32 = 0x10;
pub const FILE_ATTRIBUTE_ARCHIVE: u32 = 0x20;
pub const FSP_CLEANUP_DELETE: u32 = 0x1;

/// A locked folder fails every operation with "device not ready" (the volume is being removed as well).
pub fn status_of(e: &VfsError) -> i32 {
    match e {
        VfsError::Locked => STATUS_DEVICE_NOT_READY,
        VfsError::NotFound => STATUS_OBJECT_NAME_NOT_FOUND,
        VfsError::Exists => STATUS_OBJECT_NAME_COLLISION,
        VfsError::IsDir => STATUS_FILE_IS_A_DIRECTORY,
        VfsError::NotDir => STATUS_NOT_A_DIRECTORY,
        VfsError::NotEmpty => STATUS_DIRECTORY_NOT_EMPTY,
        VfsError::NoSpace => STATUS_DISK_FULL,
        VfsError::BadHandle => STATUS_INVALID_HANDLE,
        VfsError::ReadOnly => STATUS_MEDIA_WRITE_PROTECTED,
        VfsError::Io(_) => STATUS_UNEXPECTED_IO_ERROR,
    }
}

/// Seconds since the Unix epoch to a Windows FILETIME (100 ns ticks since 1601).
pub fn unix_to_filetime(secs: u64) -> u64 {
    (secs.saturating_add(11_644_473_600)).saturating_mul(10_000_000)
}

/// "\dir\file.txt" -> "dir/file.txt". The root is the empty string. The vault is case-sensitive (volume flag set).
pub fn to_vault_path(win: &str) -> String {
    win.trim_start_matches('\\').replace('\\', "/")
}

pub fn parent_and_name(vault_path: &str) -> (&str, &str) {
    match vault_path.rfind('/') {
        Some(i) => (&vault_path[..i], &vault_path[i + 1..]),
        None => ("", vault_path),
    }
}

pub fn allocation_size(size: u64) -> u64 {
    size.div_ceil(4096) * 4096
}

/// Stable per-path index number (FNV-1a). WinFsp does not require uniqueness; applications only use it as a hint.
pub fn index_number(path: &str) -> u64 {
    let mut h = 0xcbf29ce484222325u64;
    for b in path.bytes() {
        h ^= b as u64;
        h = h.wrapping_mul(0x100000001b3);
    }
    h
}

pub fn wants_write(granted_access: u32) -> bool {
    granted_access & (FILE_WRITE_DATA | FILE_APPEND_DATA) != 0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn statuses_and_times() {
        assert_eq!(status_of(&VfsError::NotFound) as u32, 0xC0000034);
        assert_eq!(status_of(&VfsError::Locked) as u32, 0xC00000A3);
        assert_eq!(unix_to_filetime(0), 116_444_736_000_000_000);
        assert_eq!(unix_to_filetime(1_700_000_000), 133_444_736_000_000_000);
    }

    #[test]
    fn paths() {
        assert_eq!(to_vault_path("\\"), "");
        assert_eq!(to_vault_path("\\a\\b c\\d.txt"), "a/b c/d.txt");
        assert_eq!(parent_and_name("a/b/c.txt"), ("a/b", "c.txt"));
        assert_eq!(parent_and_name("c.txt"), ("", "c.txt"));
        assert_eq!(allocation_size(0), 0);
        assert_eq!(allocation_size(1), 4096);
        assert_eq!(allocation_size(4097), 8192);
        assert_eq!(index_number("a"), index_number("a"));
        assert_ne!(index_number("a"), index_number("b"));
        assert!(wants_write(FILE_WRITE_DATA));
        assert!(!wants_write(0x1));
    }
}
