#![cfg_attr(windows, windows_subsystem = "windows")]
#[cfg(windows)]
mod app;

#[cfg(windows)]
fn main() {
    app::run();
}

#[cfg(not(windows))]
fn main() {
    eprintln!("priya-key is the Windows application; build it for a Windows target.");
    std::process::exit(2);
}
