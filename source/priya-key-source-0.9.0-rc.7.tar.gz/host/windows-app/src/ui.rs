//! Native bridge for the dashboard: `window.__gpBridge(json)` -> API response string, `window.__gpNative(name, json)` ->
//! value from a native dialog. Requests run on worker threads; results come back through the event loop.
use std::path::PathBuf;

pub const DASHBOARD_HTML: &str = include_str!("../../../dashboard/index.html");

/// Installed before the page scripts. `prompt` is answered by the WebView's own dialog; everything else round-trips.
pub const BRIDGE_JS: &str = r#"(function(){
  let n=0; const waiting=new Map();
  const ask=(kind,name,body)=>new Promise(res=>{const id=++n;waiting.set(id,res);window.ipc.postMessage(JSON.stringify({id,kind,name,body}))});
  window.__gpBridge=(json)=>ask('api','',json);
  window.__gpNative=(name,json)=>{
    if(name==='prompt'){const a=JSON.parse(json||'{}');return Promise.resolve(window.prompt(a.title||'',a.value||''))}
    return ask('native',name,json).then(t=>JSON.parse(t));
  };
  window.__gpResolve=(id,text)=>{const r=waiting.get(id);waiting.delete(id);if(r)r(text)};
})();"#;

pub struct Req {
    pub id: u64,
    pub kind: String,
    pub name: String,
    pub body: String,
}

pub fn parse_req(s: &str) -> Option<Req> {
    let v: serde_json::Value = serde_json::from_str(s).ok()?;
    Some(Req { id: v["id"].as_u64()?, kind: v["kind"].as_str()?.to_string(), name: v["name"].as_str().unwrap_or("").to_string(), body: v["body"].as_str().unwrap_or("").to_string() })
}

/// JSON text of the native result (a string, a boolean or null).
pub fn native_call(name: &str, body: &str) -> String {
    let a: serde_json::Value = serde_json::from_str(body).unwrap_or_default();
    let title = a["title"].as_str().unwrap_or("").to_string();
    match name {
        "pick_folder" => {
            let p: Option<PathBuf> = rfd::FileDialog::new().set_title(&title).pick_folder();
            serde_json::to_string(&p.map(|p| p.to_string_lossy().to_string())).unwrap()
        }
        "confirm" => {
            let r = rfd::MessageDialog::new()
                .set_title(&title)
                .set_description(a["text"].as_str().unwrap_or(""))
                .set_level(rfd::MessageLevel::Warning)
                .set_buttons(rfd::MessageButtons::OkCancelCustom(a["ok"].as_str().unwrap_or("OK").to_string(), "Cancel".to_string()))
                .show();
            let yes = matches!(r, rfd::MessageDialogResult::Custom(ref s) if s != "Cancel") || matches!(r, rfd::MessageDialogResult::Ok);
            yes.to_string()
        }
        "capabilities" => serde_json::json!({"platform": "windows", "backup": true, "open_path": true, "autostart": true, "discreet": true}).to_string(),
        "autostart_get" => autostart_enabled().to_string(),
        "autostart_set" => set_autostart(a["on"].as_bool().unwrap_or(false)).to_string(),
        "open_path" => {
            if let Some(p) = a["path"].as_str() {
                // Only a mounted drive root such as "Z:" is opened; arbitrary paths from the page are ignored.
                if p.len() == 2 && p.as_bytes()[1] == b':' && p.as_bytes()[0].is_ascii_alphabetic() {
                    let _ = std::process::Command::new("explorer").arg(format!("{p}\\")).spawn();
                }
            }
            "null".into()
        }
        _ => "null".into(),
    }
}

const RUN_KEY: &str = r"HKCU\Software\Microsoft\Windows\CurrentVersion\Run";

fn autostart_enabled() -> bool {
    std::process::Command::new("reg").args(["query", RUN_KEY, "/v", "PriyaKey"]).output().map(|o| o.status.success()).unwrap_or(false)
}

fn set_autostart(on: bool) -> bool {
    let ok = if on {
        let Ok(exe) = std::env::current_exe() else { return false };
        std::process::Command::new("reg").args(["add", RUN_KEY, "/v", "PriyaKey", "/t", "REG_SZ", "/d", &format!("\"{}\" --tray", exe.display()), "/f"]).status().map(|s| s.success()).unwrap_or(false)
    } else {
        // deleting a value that does not exist is also "off"
        let _ = std::process::Command::new("reg").args(["delete", RUN_KEY, "/v", "PriyaKey", "/f"]).status();
        true
    };
    ok && autostart_enabled() == on
}
