//! Board discovery by USB VID:PID (CH340 bridge on the supplied board). Port polling, not device-change notifications:
//! simpler and adequate for a 1-2 s arrival delay. Any serial port with this VID:PID counts; the Noise handshake and the
//! trusted board key decide whether it is the paired board.
use serialport::SerialPortType;

pub const VID: u16 = 0x1A86;
pub const PID: u16 = 0x7523;

pub fn is_board(vid: u16, pid: u16) -> bool {
    vid == VID && pid == PID
}

/// Names of the ports that look like the board, sorted for a stable choice.
pub fn find_ports() -> Vec<String> {
    let mut v: Vec<String> = serialport::available_ports()
        .unwrap_or_default()
        .into_iter()
        .filter(|p| matches!(&p.port_type, SerialPortType::UsbPort(u) if is_board(u.vid, u.pid)))
        .map(|p| p.port_name)
        .collect();
    v.sort();
    v
}

#[cfg(test)]
mod tests {
    #[test]
    fn ids() {
        assert!(super::is_board(0x1A86, 0x7523));
        assert!(!super::is_board(0x1A86, 0x55D4));
        assert!(!super::is_board(0x10C4, 0xEA60));
    }
}
