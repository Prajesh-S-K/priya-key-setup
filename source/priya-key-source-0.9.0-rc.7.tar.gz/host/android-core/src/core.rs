//! Platform-neutral core used by the JNI layer (and tested on the host with the simulator link).
use gp_app::api;
use gp_app::service::Service;
use gp_app::vfs::{OpenOpts, Vfs, VfsError};
use gpkey_host::{Link, NullLink};
use serde_json::{json, Value};
use std::sync::{Arc, Mutex};
use vault_core::storage::DiskStorage;

pub type BoxLink = Box<dyn Link + Send>;
pub type V = Vfs<DiskStorage>;

pub const OPEN_WRITE: i32 = 1;
pub const OPEN_CREATE: i32 = 2;
pub const OPEN_TRUNCATE: i32 = 4;
pub const OPEN_CREATE_NEW: i32 = 8;

/// Negative codes returned to Kotlin (mapped to errno / exceptions there).
pub fn code(e: &VfsError) -> i64 {
    match e {
        VfsError::Locked => -1,
        VfsError::NotFound => -2,
        VfsError::Exists => -3,
        VfsError::IsDir => -4,
        VfsError::NotDir => -5,
        VfsError::NotEmpty => -6,
        VfsError::NoSpace => -7,
        VfsError::BadHandle => -8,
        VfsError::ReadOnly => -9,
        VfsError::Io(_) => -10,
    }
}

fn rc<T>(r: Result<T, VfsError>, f: impl FnOnce(T) -> i64) -> i64 {
    match r {
        Ok(v) => f(v),
        Err(e) => code(&e),
    }
}

pub struct Core {
    svc: Mutex<Service<BoxLink>>,
}

impl Core {
    pub fn new(home: &str, link: BoxLink) -> Result<Core, String> {
        Ok(Core { svc: Mutex::new(Service::new(home, link)?) })
    }

    pub fn offline(home: &str) -> Result<Core, String> {
        Self::new(home, Box::new(NullLink))
    }

    pub fn replace_link(&self, link: BoxLink, reason: &str) {
        let mut g = self.svc.lock().unwrap();
        g.replace_link(link, reason);
    }

    /// After a board is attached: fetch and cache the signed dashboard image (public data). Errors are not fatal.
    pub fn sync_assets(&self) -> Result<u16, String> {
        self.svc.lock().unwrap().sync_assets()
    }

    pub fn dashboard(&self, bundled: &str) -> String {
        self.svc.lock().unwrap().dashboard(bundled).0
    }

    /// One dashboard request. `status` also lists the unlocked folders (the DocumentsProvider roots).
    pub fn request(&self, req: &str) -> String {
        let is_status = serde_json::from_str::<Value>(req).ok().and_then(|v| v.get("cmd").and_then(|c| c.as_str().map(|s| s == "status"))).unwrap_or(false);
        let mut g = self.svc.lock().unwrap();
        let out = api::handle(&mut g, req);
        if !is_status {
            return out;
        }
        let Ok(mut v) = serde_json::from_str::<Value>(&out) else { return out };
        if let Some(d) = v.get_mut("data").and_then(|d| d.as_object_mut()) {
            let un: Vec<Value> = g.cards(true).into_iter().filter(|c| c.state == "Unlocked" || c.state == "Saving").map(|c| json!({"id": c.id, "name": c.name})).collect();
            d.insert("unlocked".into(), Value::Array(un));
            let (_, source, version) = g.dashboard("");
            d.insert("app".into(), json!({"version": env!("CARGO_PKG_VERSION"), "platform": "Android", "dashboard_source": source, "dashboard_version": version}));
        }
        v.to_string()
    }

    pub fn discreet(&self) -> bool {
        self.svc.lock().unwrap().discreet()
    }

    pub fn tick(&self) {
        self.svc.lock().unwrap().tick();
    }

    /// Unlocked folders as [{"id","name"}] without the full status round trip to the board.
    pub fn unlocked(&self) -> String {
        let g = self.svc.lock().unwrap();
        let un: Vec<Value> = g.cards(true).into_iter().filter(|c| c.state == "Unlocked" || c.state == "Saving").map(|c| json!({"id": c.id, "name": c.name})).collect();
        Value::Array(un).to_string()
    }

    fn vfs(&self, id: &str) -> Option<Arc<V>> {
        self.svc.lock().unwrap().open_vault(id).map(|o| o.vfs.clone())
    }

    fn with<T>(&self, id: &str, f: impl FnOnce(&V) -> Result<T, VfsError>) -> Result<T, VfsError> {
        match self.vfs(id) {
            Some(v) => f(&v),
            None => Err(VfsError::Locked),
        }
    }

    // --- file operations (the vfs lock is not held while waiting on the service lock)
    pub fn v_open(&self, id: &str, path: &str, flags: i32) -> i64 {
        let o = OpenOpts { create: flags & (OPEN_CREATE | OPEN_CREATE_NEW) != 0, create_new: flags & OPEN_CREATE_NEW != 0, truncate: flags & OPEN_TRUNCATE != 0, write: flags & OPEN_WRITE != 0, delete_on_close: false };
        rc(self.with(id, |v| v.open(path, o)), |h| h as i64)
    }
    pub fn v_read(&self, id: &str, h: i64, off: i64, len: usize) -> Result<Vec<u8>, i64> {
        self.with(id, |v| v.read(h as u64, off as u64, len)).map_err(|e| code(&e))
    }
    pub fn v_write(&self, id: &str, h: i64, off: i64, data: &[u8]) -> i64 {
        rc(self.with(id, |v| v.write(h as u64, off as u64, data)), |n| n as i64)
    }
    pub fn v_size(&self, id: &str, h: i64) -> i64 {
        rc(self.with(id, |v| v.stat_handle(h as u64)), |e| e.size as i64)
    }
    pub fn v_set_len(&self, id: &str, h: i64, len: i64) -> i64 {
        rc(self.with(id, |v| v.set_len(h as u64, len as u64)), |_| 0)
    }
    pub fn v_flush(&self, id: &str, h: i64) -> i64 {
        rc(self.with(id, |v| v.flush(h as u64)), |_| 0)
    }
    pub fn v_close(&self, id: &str, h: i64) -> i64 {
        rc(self.with(id, |v| v.close(h as u64)), |_| 0)
    }
    pub fn v_mkdir(&self, id: &str, path: &str) -> i64 {
        rc(self.with(id, |v| v.mkdir(path)), |_| 0)
    }
    /// Deletes a file or an empty directory.
    pub fn v_delete(&self, id: &str, path: &str) -> i64 {
        rc(
            self.with(id, |v| match v.stat(path) {
                Ok(e) if e.is_dir => v.rmdir(path),
                Ok(_) => v.delete(path),
                Err(e) => Err(e),
            }),
            |_| 0,
        )
    }
    pub fn v_rename(&self, id: &str, from: &str, to: &str) -> i64 {
        rc(self.with(id, |v| v.rename(from, to, false)), |_| 0)
    }
    /// {"name","dir","size","mtime"} or an error code as {"err":n}.
    pub fn v_stat(&self, id: &str, path: &str) -> String {
        if path.is_empty() {
            return json!({"name": "", "dir": true, "size": 0, "mtime": 0}).to_string();
        }
        match self.with(id, |v| v.stat(path)) {
            Ok(e) => json!({"name": e.name, "dir": e.is_dir, "size": e.size, "mtime": e.mtime}).to_string(),
            Err(e) => json!({"err": code(&e)}).to_string(),
        }
    }
    pub fn v_list(&self, id: &str, dir: &str) -> String {
        match self.with(id, |v| v.list(dir)) {
            Ok(es) => Value::Array(es.iter().map(|e| json!({"name": e.name, "dir": e.is_dir, "size": e.size, "mtime": e.mtime})).collect()).to_string(),
            Err(e) => json!({"err": code(&e)}).to_string(),
        }
    }
    /// Re-read the file from the vault and compare with the hash of the original bytes (1 = identical).
    pub fn v_verify(&self, id: &str, path: &str, size: i64, sha256_hex: &str) -> i64 {
        rc(
            self.with(id, |v| v.with_vault(|vault| gp_app::import::verify_in_vault(vault, &gp_app::import::FileRecord { path: path.into(), size: size as u64, sha256: sha256_hex.into() }, &mut || true))),
            |r| match r {
                Ok(true) => 1,
                _ => 0,
            },
        )
    }
}
