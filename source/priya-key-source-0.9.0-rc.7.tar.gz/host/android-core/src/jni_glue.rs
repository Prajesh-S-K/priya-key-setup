//! JNI entry points for `com.giftkey.app.Native`. No logic lives here: every function forwards to `core::Core`.
//! Panics are caught and turned into an error value; they never unwind into the JVM.
use crate::core::{BoxLink, Core};
use gpkey_host::{ByteIo, FramedLink, LinkError, NullLink};
use jni::objects::{GlobalRef, JByteArray, JClass, JObject, JString, JValue};
use jni::sys::{jboolean, jint, jlong, jstring, JNI_FALSE, JNI_TRUE};
use jni::{JNIEnv, JavaVM};
use std::sync::OnceLock;
use std::time::Duration;

static CORE: OnceLock<Core> = OnceLock::new();

fn core() -> Option<&'static Core> {
    CORE.get()
}

fn s(env: &mut JNIEnv, j: &JString) -> String {
    env.get_string(j).map(|x| x.into()).unwrap_or_default()
}

fn out(env: &mut JNIEnv, v: &str) -> jstring {
    env.new_string(v).map(|j| j.into_raw()).unwrap_or(std::ptr::null_mut())
}

fn guard<T>(default: T, f: impl FnOnce() -> T + std::panic::UnwindSafe) -> T {
    std::panic::catch_unwind(f).unwrap_or(default)
}

/// The USB serial port lives in Kotlin (`UsbIo`): `write(byte[]): boolean`, `read(int timeoutMs): byte[]` (empty when
/// nothing arrived, null when the port is gone).
struct JavaIo {
    vm: JavaVM,
    obj: GlobalRef,
}

impl ByteIo for JavaIo {
    fn write_all(&mut self, bytes: &[u8]) -> Result<(), LinkError> {
        let mut env = self.vm.attach_current_thread().map_err(|e| LinkError::Io(e.to_string()))?;
        let arr = env.byte_array_from_slice(bytes).map_err(|e| LinkError::Io(e.to_string()))?;
        let ok = env.call_method(&self.obj, "write", "([B)Z", &[JValue::Object(&arr)]).and_then(|v| v.z()).map_err(|e| LinkError::Io(e.to_string()))?;
        if ok {
            Ok(())
        } else {
            Err(LinkError::Closed)
        }
    }

    fn read(&mut self, buf: &mut [u8], timeout: Duration) -> Result<usize, LinkError> {
        let mut env = self.vm.attach_current_thread().map_err(|e| LinkError::Io(e.to_string()))?;
        let r = env.call_method(&self.obj, "read", "(I)[B", &[JValue::Int(timeout.as_millis().min(1000) as jint)]).and_then(|v| v.l()).map_err(|e| LinkError::Io(e.to_string()))?;
        if r.is_null() {
            return Err(LinkError::Closed);
        }
        let arr = JByteArray::from(r);
        let v = env.convert_byte_array(&arr).map_err(|e| LinkError::Io(e.to_string()))?;
        let n = v.len().min(buf.len());
        buf[..n].copy_from_slice(&v[..n]);
        Ok(n)
    }
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_init(mut env: JNIEnv, _c: JClass, home: JString) -> jboolean {
    let home = s(&mut env, &home);
    guard(JNI_FALSE, || {
        if CORE.get().is_some() {
            return JNI_TRUE;
        }
        match Core::offline(&home) {
            Ok(c) => {
                let _ = CORE.set(c);
                JNI_TRUE
            }
            Err(_) => JNI_FALSE,
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_attach(env: JNIEnv, _c: JClass, io: JObject) -> jboolean {
    let (Ok(vm), Ok(obj)) = (env.get_java_vm(), env.new_global_ref(&io)) else { return JNI_FALSE };
    guard(JNI_FALSE, || match core() {
        Some(c) => {
            c.replace_link(Box::new(FramedLink::new(JavaIo { vm, obj })) as BoxLink, "the board was replaced");
            let _ = c.sync_assets();
            JNI_TRUE
        }
        None => JNI_FALSE,
    })
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_detach(_env: JNIEnv, _c: JClass) {
    guard((), || {
        if let Some(c) = core() {
            c.replace_link(Box::new(NullLink), "the board was unplugged");
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_request(mut env: JNIEnv, _c: JClass, req: JString) -> jstring {
    let req = s(&mut env, &req);
    let r = guard(r#"{"ok":false,"error":"core not ready"}"#.to_string(), || core().map(|c| c.request(&req)).unwrap_or_else(|| r#"{"ok":false,"error":"core not ready"}"#.to_string()));
    out(&mut env, &r)
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_tick(_env: JNIEnv, _c: JClass) {
    guard((), || {
        if let Some(c) = core() {
            c.tick();
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_dashboard(mut env: JNIEnv, _c: JClass, bundled: JString) -> jstring {
    let b = s(&mut env, &bundled);
    let r = guard(b.clone(), || core().map(|c| c.dashboard(&b)).unwrap_or_else(|| b.clone()));
    out(&mut env, &r)
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_isDiscreet(_env: JNIEnv, _c: JClass) -> jboolean {
    if guard(false, || core().map(|c| c.discreet()).unwrap_or(false)) { JNI_TRUE } else { JNI_FALSE }
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_unlocked(mut env: JNIEnv, _c: JClass) -> jstring {
    let r = guard("[]".to_string(), || core().map(|c| c.unlocked()).unwrap_or_else(|| "[]".into()));
    out(&mut env, &r)
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_vOpen(mut env: JNIEnv, _c: JClass, id: JString, path: JString, flags: jint) -> jlong {
    let (id, path) = (s(&mut env, &id), s(&mut env, &path));
    guard(-10, || core().map(|c| c.v_open(&id, &path, flags)).unwrap_or(-1))
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_vRead(mut env: JNIEnv, _c: JClass, id: JString, h: jlong, off: jlong, buf: JByteArray, len: jint) -> jint {
    let id = s(&mut env, &id);
    let r = guard(Err(-10), || core().map(|c| c.v_read(&id, h, off, len.max(0) as usize)).unwrap_or(Err(-1)));
    match r {
        Ok(data) => {
            let bytes: Vec<i8> = data.iter().map(|b| *b as i8).collect();
            if env.set_byte_array_region(&buf, 0, &bytes).is_err() {
                return -10;
            }
            data.len() as jint
        }
        Err(e) => e as jint,
    }
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_vWrite(mut env: JNIEnv, _c: JClass, id: JString, h: jlong, off: jlong, buf: JByteArray, len: jint) -> jint {
    let id = s(&mut env, &id);
    let Ok(all) = env.convert_byte_array(&buf) else { return -10 };
    let data = &all[..(len.max(0) as usize).min(all.len())];
    guard(-10, || core().map(|c| c.v_write(&id, h, off, data)).unwrap_or(-1)) as jint
}

macro_rules! simple_h {
    ($name:ident, $method:ident) => {
        #[no_mangle]
        pub extern "system" fn $name(mut env: JNIEnv, _c: JClass, id: JString, h: jlong) -> jlong {
            let id = s(&mut env, &id);
            guard(-10, || core().map(|c| c.$method(&id, h)).unwrap_or(-1))
        }
    };
}
simple_h!(Java_com_giftkey_app_Native_vSize, v_size);
simple_h!(Java_com_giftkey_app_Native_vFlush, v_flush);
simple_h!(Java_com_giftkey_app_Native_vClose, v_close);

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_vSetLen(mut env: JNIEnv, _c: JClass, id: JString, h: jlong, len: jlong) -> jlong {
    let id = s(&mut env, &id);
    guard(-10, || core().map(|c| c.v_set_len(&id, h, len)).unwrap_or(-1))
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_vMkdir(mut env: JNIEnv, _c: JClass, id: JString, path: JString) -> jlong {
    let (id, path) = (s(&mut env, &id), s(&mut env, &path));
    guard(-10, || core().map(|c| c.v_mkdir(&id, &path)).unwrap_or(-1))
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_vDelete(mut env: JNIEnv, _c: JClass, id: JString, path: JString) -> jlong {
    let (id, path) = (s(&mut env, &id), s(&mut env, &path));
    guard(-10, || core().map(|c| c.v_delete(&id, &path)).unwrap_or(-1))
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_vRename(mut env: JNIEnv, _c: JClass, id: JString, from: JString, to: JString) -> jlong {
    let (id, from, to) = (s(&mut env, &id), s(&mut env, &from), s(&mut env, &to));
    guard(-10, || core().map(|c| c.v_rename(&id, &from, &to)).unwrap_or(-1))
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_vStat(mut env: JNIEnv, _c: JClass, id: JString, path: JString) -> jstring {
    let (id, path) = (s(&mut env, &id), s(&mut env, &path));
    let r = guard(r#"{"err":-10}"#.to_string(), || core().map(|c| c.v_stat(&id, &path)).unwrap_or_else(|| r#"{"err":-1}"#.into()));
    out(&mut env, &r)
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_vList(mut env: JNIEnv, _c: JClass, id: JString, dir: JString) -> jstring {
    let (id, dir) = (s(&mut env, &id), s(&mut env, &dir));
    let r = guard(r#"{"err":-10}"#.to_string(), || core().map(|c| c.v_list(&id, &dir)).unwrap_or_else(|| r#"{"err":-1}"#.into()));
    out(&mut env, &r)
}

#[no_mangle]
pub extern "system" fn Java_com_giftkey_app_Native_vVerify(mut env: JNIEnv, _c: JClass, id: JString, path: JString, size: jlong, sha: JString) -> jlong {
    let (id, path, sha) = (s(&mut env, &id), s(&mut env, &path), s(&mut env, &sha));
    guard(-10, || core().map(|c| c.v_verify(&id, &path, size, &sha)).unwrap_or(-1))
}
