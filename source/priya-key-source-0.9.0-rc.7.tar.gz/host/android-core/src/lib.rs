//! Android core: the same Service/Vfs as the Windows app, exposed to Kotlin through JNI. The Kotlin side owns USB, the
//! foreground service and the DocumentsProvider; this crate owns keys, vaults, the board protocol and the VFS.
pub mod core;
pub mod jni_glue;
