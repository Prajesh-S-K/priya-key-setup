//! Core behaviour against the real device core (host simulator): import through the file API, hash verify, lock.
use gpandroid::core::*;
use gpkey_host::SimLink;
use serde_json::{json, Value};
use std::path::Path;
use std::process::Command;
use std::sync::{Arc, Mutex};
use std::time::Duration;

fn sim() -> String {
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../firmware");
    let bin = root.join("gpkey/sim/gk_sim");
    if !bin.exists() {
        assert!(Command::new("sh").arg(root.join("gpkey/sim/build.sh")).status().unwrap().success());
    }
    bin.canonicalize().unwrap().to_str().unwrap().to_string()
}

struct Shared(Arc<Mutex<SimLink>>);
impl gpkey_host::Link for Shared {
    fn send(&mut self, b: &[u8]) -> Result<(), gpkey_host::LinkError> {
        self.0.lock().unwrap().send(b)
    }
    fn recv_frame(&mut self, t: Duration) -> Result<Option<gpkey_host::frame::Frame>, gpkey_host::LinkError> {
        self.0.lock().unwrap().recv_frame(t)
    }
}

fn call(c: &Core, v: Value) -> Value {
    serde_json::from_str(&c.request(&v.to_string())).unwrap()
}

#[test]
fn file_api_roundtrip_verify_and_lock() {
    let t = tempfile::tempdir().unwrap();
    std::fs::create_dir_all(t.path().join("board")).unwrap();
    let sl = Arc::new(Mutex::new(SimLink::spawn(&sim(), t.path().join("board").to_str().unwrap(), &[]).unwrap()));
    let core = Core::new(t.path().join("home").to_str().unwrap(), Box::new(Shared(sl.clone()))).unwrap();
    let sl2 = sl.clone();
    let done = Arc::new(std::sync::atomic::AtomicBool::new(false));
    let d2 = done.clone();
    let presser = std::thread::spawn(move || {
        while !d2.load(std::sync::atomic::Ordering::SeqCst) {
            std::thread::sleep(Duration::from_millis(150));
            if d2.load(std::sync::atomic::Ordering::SeqCst) { break; }
            let _ = sl2.lock().unwrap().button();
        }
    });
    assert!(call(&core, json!({"cmd":"pair","pin":"2468"}))["ok"].as_bool().unwrap());
    done.store(true, std::sync::atomic::Ordering::SeqCst);
    presser.join().unwrap();
    assert!(call(&core, json!({"cmd":"setup_recovery"}))["ok"].as_bool().unwrap());
    let r = call(&core, json!({"cmd":"add_folder","source":null,"parent":t.path().to_str().unwrap(),"name":"Phone","hidden":false}));
    let id = r["data"]["id"].as_str().unwrap().to_string();
    assert_eq!(core.v_open(&id, "a.txt", OPEN_WRITE | OPEN_CREATE), -1, "locked until unlocked");
    assert!(call(&core, json!({"cmd":"unlock","id":id}))["ok"].as_bool().unwrap());
    let st = call(&core, json!({"cmd":"status"}));
    assert_eq!(st["data"]["unlocked"][0]["id"], id.as_str());

    assert_eq!(core.v_mkdir(&id, "d"), 0);
    let h = core.v_open(&id, "d/a.txt", OPEN_WRITE | OPEN_CREATE_NEW);
    assert!(h > 0, "{h}");
    assert_eq!(core.v_write(&id, h, 0, b"hello world"), 11);
    assert_eq!(core.v_size(&id, h), 11);
    assert_eq!(core.v_flush(&id, h), 0);
    assert_eq!(core.v_close(&id, h), 0);
    let sha = "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9"; // "hello world"
    assert_eq!(core.v_verify(&id, "d/a.txt", 11, sha), 1);
    assert_eq!(core.v_verify(&id, "d/a.txt", 11, &sha.replace('b', "c")), 0);
    let l: Value = serde_json::from_str(&core.v_list(&id, "d")).unwrap();
    assert_eq!(l[0]["name"], "a.txt");
    let h = core.v_open(&id, "d/a.txt", 0);
    assert_eq!(core.v_read(&id, h, 6, 100).unwrap(), b"world");
    core.v_close(&id, h);
    assert_eq!(core.v_rename(&id, "d/a.txt", "d/b.txt"), 0);
    assert_eq!(core.v_delete(&id, "d/b.txt"), 0);
    assert_eq!(core.v_delete(&id, "d"), 0);

    call(&core, json!({"cmd":"lock_all"}));
    assert_eq!(core.v_open(&id, "x", OPEN_CREATE), -1);
    assert_eq!(core.unlocked(), "[]");
}
