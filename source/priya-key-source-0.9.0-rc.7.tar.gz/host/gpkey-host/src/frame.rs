//! COBS + CRC-32 framing, identical to docs/echo-protocol.md and tools/gpecho/framing.py.
use std::collections::VecDeque;

pub const PROTO_VERSION: u8 = 1;
pub const HEADER_LEN: usize = 9;
pub const MAX_PAYLOAD: usize = 256;
pub const MIN_RAW: usize = 13;
pub const MAX_RAW: usize = 269;
pub const MAX_ENCODED: usize = MAX_RAW + MAX_RAW / 254 + 1;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Frame {
    pub ftype: u8,
    pub seq: u32,
    pub payload: Vec<u8>,
}

pub fn cobs_encode(data: &[u8]) -> Vec<u8> {
    let mut out = vec![0u8];
    let (mut code_idx, mut code) = (0usize, 1u8);
    for &b in data {
        if b == 0 {
            out[code_idx] = code;
            code_idx = out.len();
            out.push(0);
            code = 1;
        } else {
            out.push(b);
            code += 1;
            if code == 0xFF {
                out[code_idx] = code;
                code_idx = out.len();
                out.push(0);
                code = 1;
            }
        }
    }
    out[code_idx] = code;
    out
}

pub fn cobs_decode(enc: &[u8]) -> Option<Vec<u8>> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < enc.len() {
        let code = enc[i] as usize;
        if code == 0 {
            return None;
        }
        i += 1;
        let end = i + code - 1;
        if end > enc.len() || enc[i..end].contains(&0) {
            return None;
        }
        out.extend_from_slice(&enc[i..end]);
        i = end;
        if code < 0xFF && i < enc.len() {
            out.push(0);
        }
    }
    Some(out)
}

pub fn encode_frame(ftype: u8, seq: u32, payload: &[u8]) -> Vec<u8> {
    assert!(payload.len() <= MAX_PAYLOAD);
    let mut raw = vec![PROTO_VERSION, ftype, 0];
    raw.extend_from_slice(&seq.to_le_bytes());
    raw.extend_from_slice(&(payload.len() as u16).to_le_bytes());
    raw.extend_from_slice(payload);
    let crc = crc32fast::hash(&raw);
    raw.extend_from_slice(&crc.to_le_bytes());
    let mut w = cobs_encode(&raw);
    w.push(0);
    w
}

fn parse_raw(raw: &[u8]) -> Option<Frame> {
    if raw.len() < MIN_RAW || raw.len() > MAX_RAW {
        return None;
    }
    let len = u16::from_le_bytes([raw[7], raw[8]]) as usize;
    if len > MAX_PAYLOAD || HEADER_LEN + len + 4 != raw.len() {
        return None;
    }
    let crc = u32::from_le_bytes(raw[raw.len() - 4..].try_into().unwrap());
    if crc32fast::hash(&raw[..raw.len() - 4]) != crc || raw[0] != PROTO_VERSION || raw[2] != 0 {
        return None;
    }
    Some(Frame { ftype: raw[1], seq: u32::from_le_bytes(raw[3..7].try_into().unwrap()), payload: raw[HEADER_LEN..HEADER_LEN + len].to_vec() })
}

/// Streaming receiver with delimiter resynchronization (same rules as the firmware).
#[derive(Default)]
pub struct Decoder {
    buf: Vec<u8>,
    overflow: bool,
    pub frames: VecDeque<Frame>,
    pub dropped: u64,
}

impl Decoder {
    pub fn feed(&mut self, data: &[u8]) {
        for &b in data {
            if b != 0 {
                if !self.overflow {
                    if self.buf.len() >= MAX_ENCODED {
                        self.overflow = true;
                        self.buf.clear();
                    } else {
                        self.buf.push(b);
                    }
                }
                continue;
            }
            if self.overflow {
                self.overflow = false;
                self.buf.clear();
                self.dropped += 1;
                continue;
            }
            if self.buf.is_empty() {
                continue;
            }
            let chunk = std::mem::take(&mut self.buf);
            match cobs_decode(&chunk).and_then(|r| parse_raw(&r)) {
                Some(f) => self.frames.push_back(f),
                None => self.dropped += 1,
            }
        }
    }
}
