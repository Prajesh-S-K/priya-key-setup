//! gpkey-host: host side of the GPKEY USB protocol (Noise sessions over COBS+CRC frames).
pub mod device;
pub mod frame;
pub mod link;

pub use device::*;
pub use link::*;
