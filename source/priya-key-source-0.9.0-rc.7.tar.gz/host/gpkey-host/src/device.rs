//! Device protocol client: Noise_NK / Noise_NX sessions, PIN commands, KEK release (architecture 3, 4).
use crate::frame::Frame;
use crate::link::{Link, LinkError};
use std::time::Duration;

pub const T_PAIR_REQ: u8 = 0x10;
pub const T_STATUS_REQ: u8 = 0x11;
pub const T_HS_NK_1: u8 = 0x20;
pub const T_TRANSPORT: u8 = 0x21;
pub const T_HS_NX_1: u8 = 0x22;
pub const T_ASSET_INFO_REQ: u8 = 0x12;
pub const T_ASSET_READ_REQ: u8 = 0x13;
pub const T_ASSET_INFO: u8 = 0x92;
pub const T_ASSET_DATA: u8 = 0x93;
pub const ASSET_CHUNK: usize = 192;
pub const T_STATUS: u8 = 0x90;
pub const T_HS_2: u8 = 0xA0;
pub const T_TRANSPORT_R: u8 = 0xA1;
pub const T_ERR: u8 = 0xFF;

pub const C_AUTH: u8 = 1;
pub const C_GET_KEK: u8 = 2;
pub const C_HEARTBEAT: u8 = 3;
pub const C_CHANGE_PIN: u8 = 4;
pub const C_PROV_PIN: u8 = 5;
pub const C_PROV_CONFIRM: u8 = 6;
pub const C_LOCK: u8 = 7;
pub const C_INFO: u8 = 8;
pub const C_LOCK_NOTICE: u8 = 0x84;

const NK: &str = "Noise_NK_25519_ChaChaPoly_BLAKE2s";
const NX: &str = "Noise_NX_25519_ChaChaPoly_BLAKE2s";

#[derive(Debug)]
pub enum DevError {
    Link(LinkError),
    Noise(String),
    Protocol(String),
    Timeout,
    /// The device announced a lock (privacy button or heartbeat loss) or dropped the session.
    Locked,
    /// Error frame from the device (code).
    Device(u8),
}
impl std::fmt::Display for DevError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{:?}", self)
    }
}
impl std::error::Error for DevError {}
impl From<LinkError> for DevError {
    fn from(e: LinkError) -> Self {
        DevError::Link(e)
    }
}
impl From<snow::Error> for DevError {
    fn from(e: snow::Error) -> Self {
        DevError::Noise(format!("{e:?}"))
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DevState {
    Empty,
    Locked,
    Active,
    Privacy,
    FailClosed,
    Inconsistent,
    Unknown(u8),
}

#[derive(Clone, Copy, Debug)]
pub struct Status {
    pub state: DevState,
    pub flags: u8,
    pub delay_ms: u32,
}
impl Status {
    pub fn pair_wait(&self) -> bool {
        self.flags & 1 != 0
    }
    pub fn pair_authorized(&self) -> bool {
        self.flags & 2 != 0
    }
    pub fn confirmed(&self) -> bool {
        self.flags & 4 != 0
    }
    pub fn provisioned(&self) -> bool {
        self.flags & 8 != 0
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum AuthResult {
    Ok,
    WrongPin { delay_ms: u32 },
    Delayed { remaining_ms: u32 },
    Storage,
    NotReady,
    BadArg,
    Forbidden,
}

pub struct Response {
    pub status: u8,
    pub data: Vec<u8>,
}

pub struct Device<L: Link> {
    pub link: L,
    seq: u32,
    transport: Option<snow::TransportState>,
    pub events: Vec<Status>,
    pub timeout: Duration,
}

fn parse_status(p: &[u8]) -> Option<Status> {
    if p.len() < 7 {
        return None;
    }
    let state = match p[0] {
        0 => DevState::Empty,
        1 => DevState::Locked,
        2 => DevState::Active,
        3 => DevState::Privacy,
        4 => DevState::FailClosed,
        5 => DevState::Inconsistent,
        x => DevState::Unknown(x),
    };
    Some(Status { state, flags: p[1], delay_ms: u32::from_le_bytes(p[2..6].try_into().unwrap()) })
}

impl<L: Link> Device<L> {
    pub fn new(link: L) -> Self {
        Device { link, seq: 0, transport: None, events: vec![], timeout: Duration::from_secs(2) }
    }

    fn next_seq(&mut self) -> u32 {
        self.seq = self.seq.wrapping_add(1).max(1);
        self.seq
    }

    fn unsolicited(&mut self, f: Frame) {
        match f.ftype {
            T_STATUS => {
                if let Some(s) = parse_status(&f.payload) {
                    self.events.push(s);
                }
            }
            T_TRANSPORT_R => {
                if let Some(t) = self.transport.as_mut() {
                    let mut out = vec![0u8; 300];
                    if let Ok(n) = t.read_message(&f.payload, &mut out) {
                        if n >= 1 && out[0] == C_LOCK_NOTICE {
                            self.transport = None;
                        }
                    }
                }
            }
            _ => {}
        }
    }

    fn exchange(&mut self, ftype: u8, payload: &[u8]) -> Result<Frame, DevError> {
        let seq = self.next_seq();
        self.link.send(&crate::frame::encode_frame(ftype, seq, payload))?;
        let end = std::time::Instant::now() + self.timeout;
        loop {
            let left = end.saturating_duration_since(std::time::Instant::now());
            let f = self.link.recv_frame(left)?.ok_or(DevError::Timeout)?;
            if f.seq == seq {
                if f.ftype == T_ERR {
                    return Err(DevError::Device(f.payload.first().copied().unwrap_or(0)));
                }
                return Ok(f);
            }
            self.unsolicited(f);
        }
    }

    /// Read unsolicited frames (button presses, lock notices) for up to `wait`.
    pub fn poll(&mut self, wait: Duration) -> Result<(), DevError> {
        let end = std::time::Instant::now() + wait;
        loop {
            let left = end.saturating_duration_since(std::time::Instant::now());
            match self.link.recv_frame(left)? {
                Some(f) => self.unsolicited(f),
                None => return Ok(()),
            }
        }
    }

    pub fn has_session(&self) -> bool {
        self.transport.is_some()
    }

    pub fn status(&mut self) -> Result<Status, DevError> {
        let f = self.exchange(T_STATUS_REQ, &[])?;
        parse_status(&f.payload).ok_or_else(|| DevError::Protocol("bad status".into()))
    }

    /// Read the signed dashboard image stored on the board (public data; the caller verifies the signature).
    pub fn asset_image(&mut self, max: usize) -> Result<Vec<u8>, DevError> {
        let f = self.exchange(T_ASSET_INFO_REQ, &[])?;
        if f.ftype != T_ASSET_INFO || f.payload.len() != 4 {
            return Err(DevError::Protocol("bad asset info".into()));
        }
        let total = u32::from_le_bytes(f.payload[..4].try_into().unwrap()) as usize;
        if total == 0 || total > max {
            return Err(DevError::Protocol(format!("no usable asset image ({total} bytes)")));
        }
        let mut out = Vec::with_capacity(total);
        while out.len() < total {
            let n = ASSET_CHUNK.min(total - out.len());
            let mut req = (out.len() as u32).to_le_bytes().to_vec();
            req.extend_from_slice(&(n as u16).to_le_bytes());
            let r = self.exchange(T_ASSET_READ_REQ, &req)?;
            if r.ftype != T_ASSET_DATA || r.payload.len() != 4 + n || r.payload[..4] != req[..4] {
                return Err(DevError::Protocol("bad asset data".into()));
            }
            out.extend_from_slice(&r.payload[4..]);
        }
        Ok(out)
    }

    /// Ask the device to open its 30 s physical-presence window (it then waits for a BOOT press).
    pub fn pair_request(&mut self) -> Result<Status, DevError> {
        let f = self.exchange(T_PAIR_REQ, &[])?;
        parse_status(&f.payload).ok_or_else(|| DevError::Protocol("bad status".into()))
    }

    fn handshake(&mut self, pattern: &str, first: u8, prologue: &[u8], pinned: Option<&[u8; 32]>) -> Result<Option<[u8; 32]>, DevError> {
        self.transport = None;
        let params: snow::params::NoiseParams = pattern.parse().map_err(|e| DevError::Noise(format!("{e:?}")))?;
        let mut b = snow::Builder::new(params).prologue(prologue);
        if let Some(p) = pinned {
            b = b.remote_public_key(p);
        }
        let mut hs = b.build_initiator()?;
        let mut buf = [0u8; 256];
        let n = hs.write_message(&[], &mut buf)?;
        let resp = self.exchange(first, &buf[..n])?;
        if resp.ftype != T_HS_2 {
            return Err(DevError::Protocol("expected handshake reply".into()));
        }
        let mut out = [0u8; 256];
        hs.read_message(&resp.payload, &mut out)?;
        let remote = hs.get_remote_static().map(|s| {
            let mut k = [0u8; 32];
            k.copy_from_slice(s);
            k
        });
        self.transport = Some(hs.into_transport_mode()?);
        Ok(remote)
    }

    /// Noise_NX: reveals the device's static public key (needs the BOOT-press window). Returns that key.
    pub fn open_nx(&mut self) -> Result<[u8; 32], DevError> {
        self.handshake(NX, T_HS_NX_1, b"GPKEY1|NX", None)?.ok_or_else(|| DevError::Protocol("no static key".into()))
    }

    /// Noise_NK against the pinned device key.
    pub fn open_nk(&mut self, pinned: &[u8; 32]) -> Result<(), DevError> {
        self.handshake(NK, T_HS_NK_1, b"GPKEY1|NK", Some(pinned))?;
        Ok(())
    }

    pub fn command(&mut self, cmd: u8, args: &[u8]) -> Result<Response, DevError> {
        let t = self.transport.as_mut().ok_or(DevError::Locked)?;
        let mut plain = vec![cmd];
        plain.extend_from_slice(args);
        let mut ct = vec![0u8; plain.len() + 16];
        let n = t.write_message(&plain, &mut ct)?;
        let f = self.exchange(T_TRANSPORT, &ct[..n])?;
        if f.ftype != T_TRANSPORT_R {
            return Err(DevError::Protocol("expected transport reply".into()));
        }
        let t = self.transport.as_mut().ok_or(DevError::Locked)?;
        let mut out = vec![0u8; 300];
        let m = t.read_message(&f.payload, &mut out).map_err(|e| DevError::Noise(format!("{e:?}")))?;
        if m < 2 || out[0] != (cmd | 0x80) {
            return Err(DevError::Protocol("unexpected response".into()));
        }
        Ok(Response { status: out[1], data: out[2..m].to_vec() })
    }

    pub fn auth(&mut self, pin: &str) -> Result<AuthResult, DevError> {
        let r = self.command(C_AUTH, pin.as_bytes())?;
        Ok(decode_auth(&r))
    }

    pub fn get_kek(&mut self, vault_id: &[u8; 16]) -> Result<[u8; 32], DevError> {
        let r = self.command(C_GET_KEK, vault_id)?;
        if r.status != 0 || r.data.len() != 32 {
            return Err(DevError::Protocol(format!("GET_KEK refused (status {})", r.status)));
        }
        let mut k = [0u8; 32];
        k.copy_from_slice(&r.data);
        Ok(k)
    }

    pub fn heartbeat(&mut self) -> Result<bool, DevError> {
        Ok(self.command(C_HEARTBEAT, &[])?.status == 0)
    }

    pub fn change_pin(&mut self, old: &str, new: &str) -> Result<AuthResult, DevError> {
        let mut a = old.as_bytes().to_vec();
        a.extend_from_slice(new.as_bytes());
        Ok(decode_auth(&self.command(C_CHANGE_PIN, &a)?))
    }

    pub fn provision_pin(&mut self, pin: &str) -> Result<u8, DevError> {
        Ok(self.command(C_PROV_PIN, pin.as_bytes())?.status)
    }

    pub fn confirm(&mut self) -> Result<u8, DevError> {
        Ok(self.command(C_PROV_CONFIRM, &[])?.status)
    }

    pub fn lock(&mut self) -> Result<(), DevError> {
        let _ = self.command(C_LOCK, &[]);
        self.transport = None;
        Ok(())
    }
}

fn decode_auth(r: &Response) -> AuthResult {
    let d = if r.data.len() >= 4 { u32::from_le_bytes(r.data[..4].try_into().unwrap()) } else { 0 };
    match r.status {
        0 => AuthResult::Ok,
        1 => AuthResult::WrongPin { delay_ms: d },
        2 => AuthResult::Delayed { remaining_ms: d },
        3 => AuthResult::Storage,
        4 => AuthResult::NotReady,
        5 => AuthResult::BadArg,
        _ => AuthResult::Forbidden,
    }
}
