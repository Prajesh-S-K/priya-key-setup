//! Byte links to a device: the real serial port, and a simulator child process for tests.
use crate::frame::{Decoder, Frame};
use std::io::{BufRead, BufReader, Read, Write};
use std::process::{Child, ChildStdin, ChildStdout, Command, Stdio};
use std::sync::mpsc::{channel, Receiver};
use std::time::{Duration, Instant};

#[derive(Debug)]
pub enum LinkError {
    Io(String),
    Closed,
}
impl std::fmt::Display for LinkError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{:?}", self)
    }
}
impl std::error::Error for LinkError {}

pub trait Link {
    fn send(&mut self, bytes: &[u8]) -> Result<(), LinkError>;
    /// Wait up to `timeout` for the next frame.
    fn recv_frame(&mut self, timeout: Duration) -> Result<Option<Frame>, LinkError>;
    /// Release the underlying port NOW (a serial port is exclusive: it must be closed before it can be reopened). Default: nothing.
    fn close(&mut self) {}
}

// ------------------------------------------------------------------------------------------ serial
pub struct SerialLink {
    port: Option<Box<dyn serialport::SerialPort>>,
    dec: Decoder,
}

impl SerialLink {
    /// 115200 8N1. NOTE: opening may pulse DTR/RTS; on macOS the default state did not reset the M1 board (reports/m1-result.md).
    pub fn open(path: &str) -> Result<Self, LinkError> {
        // Do not let the driver assert DTR on open, and release RTS: on boards with an auto-reset circuit those two lines drive
        // EN/GPIO0, so asserting them can reset the key or put it into its boot loader.
        let mut port = serialport::new(path, 115_200)
            .timeout(Duration::from_millis(20))
            .dtr_on_open(false)
            .open()
            .map_err(|e| LinkError::Io(e.to_string()))?;
        let _ = port.write_request_to_send(false);
        let _ = port.write_data_terminal_ready(false);
        Ok(SerialLink { port: Some(port), dec: Decoder::default() })
    }
}

impl SerialLink {
    /// Pulse RTS (EN on the dev board) to reset the board, as esptool does; DTR is left deasserted.
    pub fn reset_device(&mut self) -> Result<(), LinkError> {
        let m = |e: serialport::Error| LinkError::Io(e.to_string());
        let port = self.port.as_mut().ok_or(LinkError::Closed)?;
        port.write_data_terminal_ready(false).map_err(m)?;
        port.write_request_to_send(true).map_err(m)?;
        std::thread::sleep(Duration::from_millis(120));
        port.write_request_to_send(false).map_err(m)?;
        self.dec = Decoder::default();
        Ok(())
    }
}

impl Link for SerialLink {
    fn send(&mut self, bytes: &[u8]) -> Result<(), LinkError> {
        let port = self.port.as_mut().ok_or(LinkError::Closed)?;
        port.write_all(bytes).map_err(|e| LinkError::Io(e.to_string()))?;
        port.flush().map_err(|e| LinkError::Io(e.to_string()))
    }
    fn close(&mut self) {
        self.port = None;   // dropping the handle closes the COM port
    }
    fn recv_frame(&mut self, timeout: Duration) -> Result<Option<Frame>, LinkError> {
        let end = Instant::now() + timeout;
        let mut buf = [0u8; 512];
        loop {
            if let Some(f) = self.dec.frames.pop_front() {
                return Ok(Some(f));
            }
            if Instant::now() >= end {
                return Ok(None);
            }
            let Some(port) = self.port.as_mut() else { return Err(LinkError::Closed) };
            match port.read(&mut buf) {
                Ok(n) if n > 0 => self.dec.feed(&buf[..n]),
                Ok(_) => {}
                Err(e) if e.kind() == std::io::ErrorKind::TimedOut => {}
                Err(e) => return Err(LinkError::Io(e.to_string())),
            }
        }
    }
}

// ------------------------------------------------------------------------------------------ generic byte link
/// A raw byte pipe to the board (Android: the USB serial port owned by the Kotlin side).
pub trait ByteIo {
    fn write_all(&mut self, bytes: &[u8]) -> Result<(), LinkError>;
    /// Read what is available, waiting up to `timeout`. `Ok(0)` means nothing arrived.
    fn read(&mut self, buf: &mut [u8], timeout: Duration) -> Result<usize, LinkError>;
}

pub struct FramedLink<B: ByteIo> {
    io: B,
    dec: Decoder,
}

impl<B: ByteIo> FramedLink<B> {
    pub fn new(io: B) -> Self {
        FramedLink { io, dec: Decoder::default() }
    }
}

impl<B: ByteIo> Link for FramedLink<B> {
    fn send(&mut self, bytes: &[u8]) -> Result<(), LinkError> {
        self.io.write_all(bytes)
    }
    fn recv_frame(&mut self, timeout: Duration) -> Result<Option<Frame>, LinkError> {
        let end = Instant::now() + timeout;
        let mut buf = [0u8; 512];
        loop {
            if let Some(f) = self.dec.frames.pop_front() {
                return Ok(Some(f));
            }
            let left = end.saturating_duration_since(Instant::now());
            if left.is_zero() {
                return Ok(None);
            }
            let n = self.io.read(&mut buf, left.min(Duration::from_millis(50)))?;
            if n > 0 {
                self.dec.feed(&buf[..n]);
            }
        }
    }
}

// ------------------------------------------------------------------------------------------ simulator
/// Drives `firmware/gpkey/sim/gk_sim` (the real device core) over pipes. Has a virtual clock and fault injection.
pub struct SimLink {
    child: Child,
    stdin: ChildStdin,
    rx: Receiver<String>,
    dec: Decoder,
}

impl SimLink {
    pub fn spawn(sim: &str, store_dir: &str, extra: &[&str]) -> Result<Self, LinkError> {
        let mut child = Command::new(sim)
            .arg(store_dir)
            .args(extra)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .spawn()
            .map_err(|e| LinkError::Io(format!("{sim}: {e}")))?;
        let stdin = child.stdin.take().unwrap();
        let stdout: ChildStdout = child.stdout.take().unwrap();
        let (tx, rx) = channel();
        std::thread::spawn(move || {
            for line in BufReader::new(stdout).lines().map_while(Result::ok) {
                if tx.send(line).is_err() {
                    break;
                }
            }
        });
        Ok(SimLink { child, stdin, rx, dec: Decoder::default() })
    }

    fn line(&mut self, s: &str) -> Result<(), LinkError> {
        writeln!(self.stdin, "{s}").map_err(|e| LinkError::Io(e.to_string()))?;
        self.stdin.flush().map_err(|e| LinkError::Io(e.to_string()))
    }
    fn drain(&mut self, wait: Duration) {
        while let Ok(l) = self.rx.recv_timeout(wait) {
            self.absorb(&l);
        }
    }
    fn absorb(&mut self, l: &str) {
        if let Some(hex) = l.strip_prefix("O ") {
            let bytes: Vec<u8> = (0..hex.len() / 2).map(|i| u8::from_str_radix(&hex[2 * i..2 * i + 2], 16).unwrap()).collect();
            self.dec.feed(&bytes);
        }
    }
    /// Advance the device's virtual clock (runs its periodic tick).
    pub fn advance(&mut self, ms: u32) -> Result<(), LinkError> {
        self.line(&format!("T {ms}"))?;
        self.drain(Duration::from_millis(30));
        Ok(())
    }
    pub fn button(&mut self) -> Result<(), LinkError> {
        self.line("B")?;
        self.drain(Duration::from_millis(30));
        Ok(())
    }
    pub fn reboot(&mut self) -> Result<(), LinkError> {
        self.line("R")?;
        self.dec = Decoder::default();
        self.drain(Duration::from_millis(30));
        Ok(())
    }
    pub fn fail_set(&mut self, n: u32) -> Result<(), LinkError> {
        self.line(&format!("FAILSET {n}"))
    }
    pub fn crash_set(&mut self, n: u32) -> Result<(), LinkError> {
        self.line(&format!("CRASHSET {n}"))
    }
    /// (state, flags, attempts, delay_until)
    pub fn state(&mut self) -> Result<(u32, u32, u32, u32), LinkError> {
        self.line("?")?;
        loop {
            let l = self.rx.recv_timeout(Duration::from_secs(2)).map_err(|_| LinkError::Closed)?;
            if let Some(rest) = l.strip_prefix("STATE ") {
                let v: Vec<u32> = rest.split_whitespace().map(|x| x.parse().unwrap()).collect();
                return Ok((v[0], v[1], v[2], v[3]));
            }
            self.absorb(&l);
        }
    }
    pub fn exited(&mut self) -> Option<i32> {
        self.child.try_wait().ok().flatten().and_then(|s| s.code())
    }
    pub fn wait_exit(&mut self) -> Option<i32> {
        self.child.wait().ok().and_then(|s| s.code())
    }
}

impl Drop for SimLink {
    fn drop(&mut self) {
        let _ = self.child.kill();
    }
}

impl Link for SimLink {
    fn send(&mut self, bytes: &[u8]) -> Result<(), LinkError> {
        let hex: String = bytes.iter().map(|b| format!("{b:02x}")).collect();
        self.line(&format!("F {hex}"))
    }
    fn recv_frame(&mut self, timeout: Duration) -> Result<Option<Frame>, LinkError> {
        let end = Instant::now() + timeout;
        loop {
            if let Some(f) = self.dec.frames.pop_front() {
                return Ok(Some(f));
            }
            let now = Instant::now();
            if now >= end {
                return Ok(None);
            }
            match self.rx.recv_timeout(end - now) {
                Ok(l) => self.absorb(&l),
                Err(std::sync::mpsc::RecvTimeoutError::Timeout) => return Ok(None),
                Err(_) => return Err(LinkError::Closed),
            }
        }
    }
}

/// Stand-in used while no board is connected: every operation fails, so the service stays locked.
pub struct NullLink;

impl Link for NullLink {
    fn send(&mut self, _bytes: &[u8]) -> Result<(), LinkError> {
        Err(LinkError::Io("no board connected".into()))
    }
    fn recv_frame(&mut self, _timeout: Duration) -> Result<Option<Frame>, LinkError> {
        Err(LinkError::Io("no board connected".into()))
    }
}

impl Link for Box<dyn Link + Send> {
    fn close(&mut self) {
        (**self).close()
    }
    fn send(&mut self, bytes: &[u8]) -> Result<(), LinkError> {
        (**self).send(bytes)
    }
    fn recv_frame(&mut self, timeout: Duration) -> Result<Option<Frame>, LinkError> {
        (**self).recv_frame(timeout)
    }
}
