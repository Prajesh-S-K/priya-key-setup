//! Integration tests: the Rust host (snow Noise initiator) against the REAL device core (firmware/gpkey/components/gkcore,
//! compiled for the host as gk_sim). Exercises provisioning, PIN policy, KEK release, the privacy button, pairing
//! recovery, storage-failure behavior, and a vault unlocked by the device-released key.
//! This is protocol/interop evidence; it is NOT a hardware test (that runs on the board separately).
use gpkey_host::*;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::Duration;
use vault_core::{crypto, MemStorage, SlotKind, Vault};

fn sim_path() -> PathBuf {
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../firmware");
    let bin = root.join("gpkey/sim/gk_sim");
    if !bin.exists() {
        let st = Command::new("sh").arg(root.join("gpkey/sim/build.sh")).status().expect("build.sh");
        assert!(st.success(), "gk_sim build failed");
    }
    bin.canonicalize().unwrap()
}

fn dev(dir: &Path, extra: &[&str]) -> Device<SimLink> {
    let mut d = Device::new(SimLink::spawn(sim_path().to_str().unwrap(), dir.to_str().unwrap(), extra).unwrap());
    d.timeout = Duration::from_secs(3);
    d
}

fn provision(d: &mut Device<SimLink>, pin: &str) -> [u8; 32] {
    let s = d.pair_request().unwrap();
    assert!(s.pair_wait());
    d.link.button().unwrap();
    d.poll(Duration::from_millis(100)).unwrap();
    let key = d.open_nx().unwrap();
    assert_eq!(d.provision_pin(pin).unwrap(), 0);
    key
}

fn session(d: &mut Device<SimLink>, key: &[u8; 32], pin: &str) -> AuthResult {
    d.open_nk(key).unwrap();
    d.auth(pin).unwrap()
}

#[test]
fn provisioning_pairing_auth_and_kek_release_unlock_a_vault() {
    let dir = tempfile::tempdir().unwrap();
    let mut d = dev(dir.path(), &[]);
    let s = d.status().unwrap();
    assert_eq!(s.state, DevState::Empty);
    assert!(!s.provisioned());
    // NX needs the physical press
    assert!(matches!(d.open_nx(), Err(DevError::Device(10))), "NX must be refused without the BOOT press");
    let key = provision(&mut d, "4321");
    assert_eq!(d.status().unwrap().state, DevState::Locked);
    assert!(d.status().unwrap().provisioned());
    assert!(!d.status().unwrap().confirmed());
    // reboot: the identity survives
    d.link.reboot().unwrap();
    assert_eq!(d.status().unwrap().state, DevState::Locked);
    // wrong key pinned: the NK handshake cannot complete
    assert!(d.open_nk(&[7u8; 32]).is_err() || d.auth("4321").is_err());
    // right key
    assert_eq!(session(&mut d, &key, "0000"), AuthResult::WrongPin { delay_ms: 0 });
    assert_eq!(d.auth("4321").unwrap(), AuthResult::Ok);
    assert_eq!(d.status().unwrap().state, DevState::Active);
    assert_eq!(d.confirm().unwrap(), 0);
    assert_eq!(d.confirm().unwrap(), 0, "idempotent");
    // KEK release is deterministic per vault and different across vaults
    let v1: [u8; 16] = crypto::random();
    let v2: [u8; 16] = crypto::random();
    let k1 = d.get_kek(&v1).unwrap();
    assert_eq!(k1, d.get_kek(&v1).unwrap());
    assert_ne!(k1, d.get_kek(&v2).unwrap());
    // create a vault whose board slot is wrapped under the device KEK, then reopen it in a NEW session after a reboot
    // The vault id is chosen first; the device is asked for the KEK of THAT vault id; the board slot is wrapped under it.
    let vault_id: [u8; 16] = crypto::random();
    let kek = d.get_kek(&vault_id).unwrap();
    let recov: crypto::Key = crypto::random();
    let mut vault = Vault::create_with_id(MemStorage::new(), vault_id, &[(SlotKind::Board, kek), (SlotKind::Recovery, recov)]).unwrap();
    vault.put_file("disposable/hello.txt", b"hello from a disposable vault", 1).unwrap();
    let st = vault.into_storage();
    // lock, reboot the device, authenticate again in a NEW session: the device releases the same KEK and the vault opens
    d.lock().unwrap();
    d.link.reboot().unwrap();
    assert_eq!(session(&mut d, &key, "4321"), AuthResult::Ok);
    let kek2 = d.get_kek(&vault_id).unwrap();
    let v = Vault::open(st.clone(), &kek2).unwrap();
    assert_eq!(v.read_file("disposable/hello.txt").unwrap(), b"hello from a disposable vault");
    // a different vault id yields a different KEK, which does not open this vault
    let other = d.get_kek(&crypto::random()).unwrap();
    assert!(Vault::open(st, &other).is_err());
    d.lock().unwrap();
}

#[test]
fn pin_attempt_policy_persists_across_reboots_and_delays_apply() {
    let dir = tempfile::tempdir().unwrap();
    let mut d = dev(dir.path(), &[]);
    let key = provision(&mut d, "1111");
    d.link.reboot().unwrap();
    // three free failures
    for i in 0..3 {
        d.open_nk(&key).unwrap();
        assert_eq!(d.auth("9999").unwrap(), AuthResult::WrongPin { delay_ms: 0 }, "failure {i}");
    }
    // the fourth failure imposes 5 s
    assert_eq!(d.auth("9999").unwrap(), AuthResult::WrongPin { delay_ms: 5000 });
    // inside the delay even the right PIN is refused without being compared
    match d.auth("1111").unwrap() {
        AuthResult::Delayed { remaining_ms } => assert!(remaining_ms > 0 && remaining_ms <= 5000),
        other => panic!("expected Delayed, got {other:?}"),
    }
    d.link.advance(5100).unwrap();
    d.open_nk(&key).unwrap(); // session may have timed out; open a fresh one
    // reboot restarts the delay from boot: the counter is persisted (4 failures) and the tier re-applies
    d.link.reboot().unwrap();
    let (_, _, attempts, delay_until) = d.link.state().unwrap();
    assert_eq!(attempts, 4);
    assert_eq!(delay_until, 5000);
    d.open_nk(&key).unwrap();
    assert!(matches!(d.auth("1111").unwrap(), AuthResult::Delayed { .. }));
    d.link.advance(5001).unwrap();
    d.open_nk(&key).unwrap();
    assert_eq!(d.auth("1111").unwrap(), AuthResult::Ok);
    let (_, _, attempts, _) = d.link.state().unwrap();
    assert_eq!(attempts, 0, "success resets the counter");
}

#[test]
fn storage_failures_fail_closed_and_never_release_keys() {
    let dir = tempfile::tempdir().unwrap();
    let mut d = dev(dir.path(), &[]);
    let key = provision(&mut d, "2222");
    d.open_nk(&key).unwrap();
    // the write-ahead counter cannot be persisted: refuse, do not compare, fail closed
    d.link.fail_set(1).unwrap();
    assert_eq!(d.auth("2222").unwrap(), AuthResult::Storage, "even the right PIN is refused");
    assert_eq!(d.status().unwrap().state, DevState::FailClosed);
    assert!(d.get_kek(&[1u8; 16]).is_err());
    assert!(matches!(d.auth("2222").unwrap(), AuthResult::Storage | AuthResult::Forbidden), "still refused while fail-closed");
    // reboot recovers (nothing was erased or regenerated)
    d.link.reboot().unwrap();
    assert_eq!(d.status().unwrap().state, DevState::Locked);
    d.open_nk(&key).unwrap();
    // the success-reset write fails: no keys, fail closed
    d.link.fail_set(2).unwrap();
    assert_eq!(d.auth("2222").unwrap(), AuthResult::Storage);
    assert!(d.get_kek(&[1u8; 16]).is_err());
    assert_eq!(d.status().unwrap().state, DevState::FailClosed);
    d.link.reboot().unwrap();
    d.open_nk(&key).unwrap();
    // the counter stayed incremented by the interrupted success (conservative): two guesses counted
    let (_, _, attempts, _) = d.link.state().unwrap();
    assert!(attempts >= 1);
    d.link.advance(1).unwrap();
    assert_eq!(d.auth("2222").unwrap(), AuthResult::Ok);
}

#[test]
fn interrupted_provisioning_never_yields_a_half_provisioned_identity() {
    // power lost before the attempt record is written, and before the identity (commit point) is written
    for crash in [1u32, 2] {
        let dir = tempfile::tempdir().unwrap();
        {
            let mut d = dev(dir.path(), &[]);
            d.pair_request().unwrap();
            d.link.button().unwrap();
            d.open_nx().unwrap();
            d.link.crash_set(crash).unwrap();
            let _ = d.provision_pin("3333"); // the device dies inside this command
            assert_eq!(d.link.wait_exit(), Some(42));
        }
        let mut d = dev(dir.path(), &[]);
        assert_eq!(d.status().unwrap().state, DevState::Empty, "crash {crash}: board must still be EMPTY");
        // provisioning can simply be repeated
        let key = provision(&mut d, "3333");
        d.link.reboot().unwrap();
        assert_eq!(session(&mut d, &key, "3333"), AuthResult::Ok);
    }
}

#[test]
fn inconsistent_storage_is_reported_and_never_erased() {
    let dir = tempfile::tempdir().unwrap();
    {
        let mut d = dev(dir.path(), &[]);
        provision(&mut d, "5555");
    }
    let before = std::fs::read(dir.path().join("id.bin")).unwrap();
    // missing counter with an identity present
    std::fs::remove_file(dir.path().join("att.bin")).unwrap();
    let mut d = dev(dir.path(), &[]);
    assert_eq!(d.status().unwrap().state, DevState::Inconsistent);
    assert!(matches!(d.open_nk(&[1u8; 32]), Err(DevError::Device(10))));
    assert!(matches!(d.pair_request(), Err(DevError::Device(10))), "no re-provisioning from INCONSISTENT");
    assert_eq!(std::fs::read(dir.path().join("id.bin")).unwrap(), before, "identity must not be touched");
    assert!(!dir.path().join("att.bin").exists(), "and no counter may be invented");
    drop(d);
    // storage init failure and read failure
    let dir2 = tempfile::tempdir().unwrap();
    let mut d = dev(dir2.path(), &["--fail-init"]);
    assert_eq!(d.status().unwrap().state, DevState::Inconsistent);
    drop(d);
    let dir3 = tempfile::tempdir().unwrap();
    {
        let mut d = dev(dir3.path(), &[]);
        provision(&mut d, "6666");
    }
    let mut d = dev(dir3.path(), &["--fail-get", "att"]);
    assert_eq!(d.status().unwrap().state, DevState::Inconsistent);
    // corrupt identity blob
    let mut idb = std::fs::read(dir3.path().join("id.bin")).unwrap();
    idb[40] ^= 1;
    std::fs::write(dir3.path().join("id.bin"), idb).unwrap();
    drop(d);
    let mut d = dev(dir3.path(), &[]);
    assert_eq!(d.status().unwrap().state, DevState::Inconsistent);
}

#[test]
fn privacy_button_locks_in_the_required_order_and_second_press_needs_the_pin() {
    let dir = tempfile::tempdir().unwrap();
    let mut d = dev(dir.path(), &[]);
    let key = provision(&mut d, "7777");
    assert_eq!(session(&mut d, &key, "7777"), AuthResult::Ok);
    let vid = [9u8; 16];
    let kek_before = d.get_kek(&vid).unwrap();
    d.link.button().unwrap(); // first press
    d.poll(Duration::from_millis(200)).unwrap();
    assert!(!d.has_session(), "the authenticated LOCK notice must have been received and decrypted");
    assert!(d.events.iter().any(|s| s.state == DevState::Privacy), "status event announces PRIVACY");
    // privileged commands are dead; no new session either
    assert!(matches!(d.get_kek(&vid), Err(DevError::Locked)));
    assert!(matches!(d.open_nk(&key), Err(DevError::Device(10))));
    assert_eq!(d.status().unwrap().state, DevState::Privacy);
    d.link.button().unwrap(); // second press: restore service, PIN required again
    d.poll(Duration::from_millis(200)).unwrap();
    assert_eq!(d.status().unwrap().state, DevState::Locked);
    d.open_nk(&key).unwrap();
    assert!(d.get_kek(&vid).is_err(), "no key without a fresh PIN");
    assert_eq!(d.auth("7777").unwrap(), AuthResult::Ok);
    assert_eq!(d.get_kek(&vid).unwrap(), kek_before, "same vault key material after re-authentication");
}

#[test]
fn heartbeat_loss_locks_and_a_heartbeat_keeps_the_session() {
    let dir = tempfile::tempdir().unwrap();
    let mut d = dev(dir.path(), &[]);
    let key = provision(&mut d, "1212");
    assert_eq!(session(&mut d, &key, "1212"), AuthResult::Ok);
    d.link.advance(2500).unwrap();
    assert!(d.heartbeat().unwrap());
    d.link.advance(2500).unwrap();
    assert!(d.heartbeat().unwrap(), "a heartbeat inside the timeout keeps the session");
    d.link.advance(3500).unwrap();
    assert_eq!(d.status().unwrap().state, DevState::Locked);
    assert!(d.heartbeat().is_err(), "the session is gone");
}

#[test]
fn pairing_ceremony_reveals_only_the_existing_key_and_is_one_use() {
    let dir = tempfile::tempdir().unwrap();
    let mut d = dev(dir.path(), &[]);
    let key = provision(&mut d, "4545");
    // a fresh host with no pin: PAIR_REQUEST + BOOT press, then NX reveals the same public key; the PIN is still needed
    let mut d2 = dev(dir.path(), &[]);
    assert!(matches!(d2.open_nx(), Err(DevError::Device(10))), "no window, no NX");
    d2.pair_request().unwrap();
    assert!(matches!(d2.open_nx(), Err(DevError::Device(10))), "window without the press, no NX");
    d2.link.button().unwrap();
    let revealed = d2.open_nx().unwrap();
    assert_eq!(revealed, key, "identity is never regenerated");
    assert!(matches!(d2.open_nx(), Err(DevError::Device(10))), "authorization is one use");
    // NX session cannot do privileged things
    assert!(d2.get_kek(&[0u8; 16]).is_err());
    // the PIN still gates everything
    assert_eq!(session(&mut d2, &revealed, "0000"), AuthResult::WrongPin { delay_ms: 0 });
    assert_eq!(d2.auth("4545").unwrap(), AuthResult::Ok);
    // authorization expires after 30 s
    drop(d);
    let mut d3 = dev(dir.path(), &[]);
    d3.pair_request().unwrap();
    d3.link.button().unwrap();
    d3.link.advance(31_000).unwrap();
    assert!(matches!(d3.open_nx(), Err(DevError::Device(10))));
}

#[test]
fn confirm_survives_a_lost_host_record_and_change_pin_works() {
    let dir = tempfile::tempdir().unwrap();
    let mut d = dev(dir.path(), &[]);
    let key = provision(&mut d, "1357");
    // host 'crashes' before saving the key; the board was confirmed anyway (case b of architecture 3.4 item 6)
    assert_eq!(session(&mut d, &key, "1357"), AuthResult::Ok);
    assert_eq!(d.confirm().unwrap(), 0);
    d.link.reboot().unwrap();
    assert!(d.status().unwrap().confirmed());
    // pending record resumes: NK + AUTH against the recorded key, board unchanged
    assert_eq!(session(&mut d, &key, "1357"), AuthResult::Ok);
    assert_eq!(d.change_pin("1357", "2468").unwrap(), AuthResult::Ok);
    d.lock().unwrap();
    d.open_nk(&key).unwrap();
    assert_eq!(d.auth("1357").unwrap(), AuthResult::WrongPin { delay_ms: 0 });
    assert_eq!(d.auth("2468").unwrap(), AuthResult::Ok);
    // wrong old PIN does not change anything
    assert_eq!(d.change_pin("0000", "9999").unwrap(), AuthResult::WrongPin { delay_ms: 0 });
    assert_eq!(d.auth("2468").unwrap(), AuthResult::Ok);
}
