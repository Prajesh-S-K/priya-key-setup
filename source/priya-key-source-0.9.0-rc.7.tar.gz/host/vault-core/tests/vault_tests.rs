//! Functional, adversarial and fault-injection tests for vault-core on DISPOSABLE in-memory data.
use rand::{Rng, SeedableRng};
use std::collections::BTreeMap;
use vault_core::crypto::{self, Key};
use vault_core::ops::CHUNK_SIZE;
use vault_core::*;

const J: &str = "journal-000000.log";
const D: &str = "data-000000.seg";

fn keys() -> (Key, Key) {
    (crypto::random(), crypto::random())
}

fn new_vault() -> (Vault<MemStorage>, Key, Key) {
    let (board, recov) = keys();
    let v = Vault::create(MemStorage::new(), &[(SlotKind::Board, board), (SlotKind::Recovery, recov)]).unwrap();
    (v, board, recov)
}

fn rnd(seed: u64, n: usize) -> Vec<u8> {
    let mut r = rand::rngs::StdRng::seed_from_u64(seed);
    (0..n).map(|_| r.gen()).collect()
}

fn snapshot(v: &Vault<MemStorage>) -> BTreeMap<String, Vec<u8>> {
    v.all_files().into_iter().map(|p| (p.clone(), v.read_file(&p).unwrap())).collect()
}

// ---------------------------------------------------------------------------------------------- basics
#[test]
fn round_trip_all_sizes_and_reopen_with_either_key() {
    let (mut v, board, recov) = new_vault();
    let sizes = [0usize, 1, 100, CHUNK_SIZE - 1, CHUNK_SIZE, CHUNK_SIZE + 1, 3 * CHUNK_SIZE + 17, 700_000];
    for (i, n) in sizes.iter().enumerate() {
        v.put_file(&format!("dir{}/file{}.bin", i % 2, i), &rnd(i as u64, *n), 1000 + i as u64).unwrap();
    }
    let want = snapshot(&v);
    assert_eq!(want.len(), sizes.len());
    assert_eq!(v.verify_all().unwrap() > 0, true);
    let st = v.into_storage();
    for kek in [board, recov] {
        let v2 = Vault::open(st.clone(), &kek).unwrap();
        assert_eq!(snapshot(&v2), want);
        assert!(!v2.recovered_torn_tail());
    }
    assert!(matches!(Vault::open(st.clone(), &crypto::random()), Err(Error::BadKey)));
}

#[test]
fn ciphertext_contains_no_names_or_content() {
    let (mut v, _, _) = new_vault();
    let secret = b"TOP-SECRET-MARKER-0123456789-TOP-SECRET".repeat(100);
    v.put_file("Taxes 2025/passport scan.pdf", &secret, 1).unwrap();
    let st = v.into_storage();
    for name in st.list().unwrap() {
        let bytes = st.read_all(&name).unwrap().unwrap();
        for needle in [&b"TOP-SECRET"[..], b"passport", b"Taxes", b".pdf"] {
            assert!(!bytes.windows(needle.len()).any(|w| w == needle), "{name} leaks {:?}", String::from_utf8_lossy(needle));
        }
    }
}

#[test]
fn random_access_editing_matches_a_model() {
    let (mut v, _, _) = new_vault();
    let mut r = rand::rngs::StdRng::seed_from_u64(7);
    let mut model: Vec<u8> = vec![];
    let mut e = v.edit("a/b.txt", true, false).unwrap();
    for step in 0..120 {
        match r.gen_range(0..4) {
            0 | 1 => {
                let off = r.gen_range(0..(model.len() + 3 * CHUNK_SIZE)) as u64;
                let data = rnd(step, r.gen_range(1..70_000));
                if (off as usize) > model.len() {
                    model.resize(off as usize, 0);
                }
                if off as usize + data.len() > model.len() {
                    model.resize(off as usize + data.len(), 0);
                }
                model[off as usize..off as usize + data.len()].copy_from_slice(&data);
                v.editor_write(&mut e, off, &data).unwrap();
            }
            2 => {
                let n = r.gen_range(0..model.len() + 1000);
                model.resize(n, 0);
                v.editor_set_len(&mut e, n as u64).unwrap();
            }
            _ => {
                let got = v.editor_read(&e, 0, model.len() + 10).unwrap();
                assert_eq!(got, model);
            }
        }
        assert_eq!(e.size() as usize, model.len());
        if step % 40 == 39 {
            v.commit_editor(e, step).unwrap();
            assert_eq!(v.read_file("a/b.txt").unwrap(), model);
            e = v.edit("a/b.txt", false, false).unwrap();
        }
    }
    v.commit_editor(e, 9999).unwrap();
    assert_eq!(v.read_file("a/b.txt").unwrap(), model);
}

#[test]
fn rename_delete_versions_and_tombstones() {
    let (mut v, board, _) = new_vault();
    v.put_file("doc.txt", b"v1", 1).unwrap();
    v.put_file("doc.txt", b"v2", 2).unwrap();
    v.put_file("doc.txt", b"v3", 3).unwrap();
    assert_eq!(v.versions("doc.txt").unwrap().len(), 2);
    assert_eq!(v.read_version("doc.txt", 0).unwrap(), b"v1");
    // editor save-by-rename: write a temp file, rename over the target
    v.put_file("doc.txt.tmp", b"v4", 4).unwrap();
    v.rename("doc.txt.tmp", "doc.txt").unwrap();
    assert_eq!(v.read_file("doc.txt").unwrap(), b"v4");
    assert!(!v.exists("doc.txt.tmp").unwrap());
    let tomb = v.tombstones();
    assert_eq!(tomb.len(), 1, "the replaced file is kept as a tombstone");
    assert_eq!(v.read_tombstone(&tomb[0].0).unwrap(), b"v3");
    // delete then recreate: two separate commits; the old content stays recoverable
    v.delete("doc.txt").unwrap();
    assert!(!v.exists("doc.txt").unwrap());
    let id = v.tombstones().iter().find(|t| v.read_tombstone(&t.0).unwrap() == b"v4").unwrap().0;
    v.undelete(&id, "recovered.txt").unwrap();
    assert_eq!(v.read_file("recovered.txt").unwrap(), b"v4");
    // restore an old version
    v.put_file("x", b"a", 1).unwrap();
    v.put_file("x", b"b", 2).unwrap();
    v.restore_version("x", 0, 3).unwrap();
    assert_eq!(v.read_file("x").unwrap(), b"a");
    // survives reopen
    let want = snapshot(&v);
    let v2 = Vault::open(v.into_storage(), &board).unwrap();
    assert_eq!(snapshot(&v2), want);
    // directories
    let (mut v, _, _) = new_vault();
    v.put_file("d/e/f.txt", b"1", 1).unwrap();
    v.rename("d", "g").unwrap();
    assert_eq!(v.read_file("g/e/f.txt").unwrap(), b"1");
    assert!(v.rmdir("g/e").is_err());
}

#[test]
fn tampering_is_detected() {
    let (mut v, board, _) = new_vault();
    v.put_file("a", &rnd(1, 100_000), 1).unwrap();
    let mut st = v.into_storage();
    // flip a bit in a data chunk
    st.raw_mut(D).unwrap()[500] ^= 1;
    let v2 = Vault::open(st.clone(), &board).unwrap();
    assert!(matches!(v2.read_file("a"), Err(Error::Corrupt(_))));
    // swap two chunk records of the same file: the pinned tags catch the substitution
    let (mut v, board, _) = new_vault();
    v.put_file("a", &rnd(2, 2 * CHUNK_SIZE), 1).unwrap();
    let mut st = v.into_storage();
    let rec = 24 + CHUNK_SIZE + 16;
    let data = st.raw_mut(D).unwrap();
    let (first, second) = (data[..rec].to_vec(), data[rec..2 * rec].to_vec());
    data[..rec].copy_from_slice(&second);
    data[rec..2 * rec].copy_from_slice(&first);
    let v2 = Vault::open(st, &board).unwrap();
    assert!(v2.read_file("a").is_err());
}

#[test]
fn missing_live_data_is_reported_not_skipped() {
    let (mut v, board, _) = new_vault();
    v.put_file("a", &rnd(3, 200_000), 1).unwrap();
    let mut st = v.into_storage();
    let n = st.raw_mut(D).unwrap().len();
    st.raw_mut(D).unwrap().truncate(n - 10);
    assert!(matches!(Vault::open(st, &board), Err(Error::MissingFile(_))));
}

// ---------------------------------------------------------------------------------------------- journal
fn record_offsets(journal: &[u8]) -> Vec<(usize, usize)> {
    let mut v = vec![];
    let mut pos = 128;
    while pos + 40 <= journal.len() {
        let ct = u32::from_le_bytes(journal[pos + 12..pos + 16].try_into().unwrap()) as usize;
        v.push((pos, pos + 40 + ct));
        pos += 40 + ct;
    }
    v
}

fn vault_with_commits(n: usize) -> (MemStorage, Key, BTreeMap<String, Vec<u8>>) {
    let (mut v, board, _) = new_vault();
    for i in 0..n {
        v.put_file(&format!("f{i}"), format!("content {i}").as_bytes(), i as u64).unwrap();
    }
    let snap = snapshot(&v);
    (v.into_storage(), board, snap)
}

#[test]
fn torn_tail_at_every_byte_then_save_then_reopen_again() {
    let (st, board, snap) = vault_with_commits(4);
    let j = st.read_all(J).unwrap().unwrap();
    let recs = record_offsets(&j);
    let (last_start, _last_end) = *recs.last().unwrap();
    let mut before_last = snap.clone();
    before_last.remove("f3");
    for cut in 1..(j.len() - last_start) {
        for mode in 0..2 {
            let mut s = st.clone();
            if mode == 0 {
                s.raw_mut(J).unwrap().truncate(last_start + cut); // partial write
            } else {
                let b = s.raw_mut(J).unwrap();
                for x in &mut b[last_start + cut..] {
                    *x = 0; // zero-extended tail
                }
            }
            let mut v = Vault::open(s, &board).unwrap_or_else(|e| panic!("cut {cut} mode {mode}: {e:?}"));
            assert!(v.recovered_torn_tail(), "cut {cut} mode {mode}");
            assert_eq!(snapshot(&v), before_last, "cut {cut} mode {mode}");
            // new save after recovery, then reopen again: the history stays readable
            v.put_file("after-recovery", b"new data", 99).unwrap();
            let mut want = before_last.clone();
            want.insert("after-recovery".into(), b"new data".to_vec());
            let v2 = Vault::open(v.into_storage(), &board).unwrap();
            assert!(!v2.recovered_torn_tail(), "second open must be clean (cut {cut} mode {mode})");
            assert_eq!(snapshot(&v2), want);
        }
    }
}

#[test]
fn incomplete_multi_record_transaction_is_discarded_and_never_carried_forward() {
    let (board, recov) = keys();
    let mut v = Vault::create(MemStorage::new(), &[(SlotKind::Board, board), (SlotKind::Recovery, recov)]).unwrap();
    v.test_set_max_record(64); // force BEGIN / DELTA* / COMMIT
    v.put_file("small", b"s", 1).unwrap();
    v.put_file("big", &rnd(5, 3 * CHUNK_SIZE), 2).unwrap();
    let mut st = v.into_storage();
    let j = st.read_all(J).unwrap().unwrap();
    let recs = record_offsets(&j);
    assert!(recs.len() >= 6, "expected a multi-record transaction, got {} records", recs.len());
    // find the last COMMIT (type 4) and cut at every earlier record boundary inside the big transaction
    let commits: Vec<usize> = recs.iter().enumerate().filter(|(_, (s, _))| j[s + 2] == 4 || j[s + 2] == 1).map(|(i, _)| i).collect();
    let commit_idx = *commits.last().unwrap();
    let small_commit = commits[commits.len() - 2];
    for keep in (small_commit + 1)..=commit_idx {
        let mut s = st.clone();
        let cut = recs[keep - 1].1;
        s.raw_mut(J).unwrap().truncate(cut);
        let mut v = Vault::open(s, &board).unwrap();
        let files = v.all_files();
        let expect_big = false;
        assert_eq!(files.contains(&"big".to_string()), expect_big, "keep {keep}");
        assert!(files.contains(&"small".to_string()));
        v.put_file("next", b"n", 3).unwrap();
        let v2 = Vault::open(v.into_storage(), &board).unwrap();
        assert!(!v2.recovered_torn_tail());
        assert_eq!(v2.read_file("next").unwrap(), b"n");
        assert!(!v2.exists("big").unwrap());
    }
    // the whole transaction present: big is visible
    let v = Vault::open(st.clone(), &board).unwrap();
    assert_eq!(v.read_file("big").unwrap().len(), 3 * CHUNK_SIZE);
    st.raw_mut(J).unwrap();
}

#[test]
fn interior_deletion_duplication_reordering_and_splicing_fail_closed() {
    let (st, board, _) = vault_with_commits(6);
    let j = st.read_all(J).unwrap().unwrap();
    let recs = record_offsets(&j);
    assert!(recs.len() >= 6);
    let open = |s: MemStorage| Vault::open(s, &board);
    // deletion of an interior record
    let mut s = st.clone();
    let (a, b) = recs[1];
    s.raw_mut(J).unwrap().drain(a..b);
    assert!(matches!(open(s), Err(Error::Corrupt(_))), "interior deletion");
    // duplication of an interior record
    let mut s = st.clone();
    let dup = j[recs[1].0..recs[1].1].to_vec();
    let at = recs[1].1;
    s.raw_mut(J).unwrap().splice(at..at, dup);
    assert!(matches!(open(s), Err(Error::Corrupt(_))), "interior duplication");
    // reordering two interior records
    let mut s = st.clone();
    let (r1, r2) = (j[recs[1].0..recs[1].1].to_vec(), j[recs[2].0..recs[2].1].to_vec());
    let mut swapped = r2.clone();
    swapped.extend_from_slice(&r1);
    s.raw_mut(J).unwrap().splice(recs[1].0..recs[2].1, swapped);
    assert!(matches!(open(s), Err(Error::Corrupt(_))), "reordering");
    // bit flip in an interior record
    let mut s = st.clone();
    s.raw_mut(J).unwrap()[recs[2].0 + 60] ^= 1;
    assert!(matches!(open(s), Err(Error::Corrupt(_))), "interior corruption");
    // corrupted interior record header
    let mut s = st.clone();
    s.raw_mut(J).unwrap()[recs[2].0] ^= 0xff;
    assert!(matches!(open(s), Err(Error::Corrupt(_))), "interior header corruption");
    // cross-vault splicing: a valid record from another vault
    let (other, _, _) = vault_with_commits(6);
    let oj = other.read_all(J).unwrap().unwrap();
    let orecs = record_offsets(&oj);
    let mut s = st.clone();
    let foreign = oj[orecs[2].0..orecs[2].1].to_vec();
    s.raw_mut(J).unwrap().splice(recs[2].0..recs[2].1, foreign);
    assert!(matches!(open(s), Err(Error::Corrupt(_))), "cross-vault splice");
    // header of another vault's journal
    let mut s = st.clone();
    let foreign_hdr = oj[..128].to_vec();
    s.raw_mut(J).unwrap().splice(0..128, foreign_hdr);
    assert!(matches!(open(s), Err(Error::Corrupt(_))));
}

#[test]
fn accepted_rollback_is_distinct_from_corruption() {
    // Deleting the newest whole records at a record boundary looks like a crash before those commits: it opens cleanly
    // at the older state. This is the documented, accepted whole-history/tail rollback (architecture 5.5.4).
    let (st, board, snap) = vault_with_commits(5);
    let j = st.read_all(J).unwrap().unwrap();
    let recs = record_offsets(&j);
    let mut s = st.clone();
    s.raw_mut(J).unwrap().truncate(recs[2].1);
    let v = Vault::open(s, &board).unwrap();
    let mut want = snap.clone();
    want.remove("f3");
    want.remove("f4");
    assert_eq!(snapshot(&v), want);
}

// ---------------------------------------------------------------------------------------------- fault injection
type Snap = BTreeMap<String, Vec<u8>>;

/// A scripted sequence of saves, edits, save-by-rename, delete and recreate, on a vault that may crash anywhere.
fn scenario(v: &mut Vault<MemStorage>, acked: &mut Vec<Snap>) -> Result<()> {
    macro_rules! step {
        ($e:expr) => {{
            $e?;
            acked.push(snapshot(v));
        }};
    }
    step!(v.put_file("notes/a.txt", &rnd(1, 1000), 1));
    step!(v.put_file("notes/b.bin", &rnd(2, CHUNK_SIZE + 500), 2));
    // in-place edit of the middle of a multi-chunk file
    let mut e = v.edit("notes/b.bin", false, false)?;
    v.editor_write(&mut e, 100, &rnd(3, 50))?;
    v.editor_write(&mut e, CHUNK_SIZE as u64 + 10, &rnd(4, 20))?;
    step!(v.commit_editor(e, 3));
    // truncate-then-rewrite save (open-mode truncation staged until commit)
    let mut e = v.edit("notes/a.txt", false, true)?;
    v.editor_write(&mut e, 0, &rnd(5, 2000))?;
    step!(v.commit_editor(e, 4));
    // save-by-rename
    step!(v.put_file("notes/a.txt.tmp", &rnd(6, 1500), 5));
    step!(v.rename("notes/a.txt.tmp", "notes/a.txt"));
    // delete then recreate (two commits)
    step!(v.delete("notes/b.bin"));
    step!(v.put_file("notes/b.bin", &rnd(7, 300), 6));
    step!(v.mkdir("empty/dir"));
    Ok(())
}

fn fresh() -> (Vault<MemStorage>, Key) {
    let (v, board, _) = new_vault();
    (v, board)
}

#[test]
fn interrupted_save_sweep_preserves_the_last_valid_version() {
    // Baseline: how many storage operations does the scenario perform, and what are the committed states?
    let (mut base, _) = fresh();
    let mut states: Vec<Snap> = vec![snapshot(&base)];
    scenario(&mut base, &mut states).unwrap();
    let total_ops = base.storage().ops();
    assert!(total_ops > 30, "scenario too small: {total_ops}");
    let mut checked = 0;
    for crash_at in 1..=total_ops + 1 {
        for loss in [Loss::Clean, Loss::TornPrefix(50), Loss::ZeroTail] {
            let (mut v, board) = fresh();
            // the vault is created before the crash point is armed: creation is not part of this sweep
            let storage = v.into_storage();
            let mut st = storage;
            st.set_crash_at(Some(crash_at));
            let mut v = Vault::open(st, &board).unwrap();
            v.storage(); // keep the borrow checker honest
            let mut acked: Vec<Snap> = vec![snapshot(&v)];
            let _ = scenario(&mut v, &mut acked);
            let mut st = v.into_storage();
            st.power_loss(loss);
            let v2 = Vault::open(st, &board).unwrap_or_else(|e| panic!("reopen failed after crash at op {crash_at} ({loss:?}): {e:?}"));
            let got = snapshot(&v2);
            let n_acked = acked.len() - 1; // committed steps acknowledged before the crash
            // Every acknowledged save survives, and at most the one in flight may also have landed; never a mixture.
            let ok = got == states[n_acked] || (n_acked + 1 < states.len() && got == states[n_acked + 1]);
            assert!(ok, "crash at op {crash_at} ({loss:?}): state matches neither step {n_acked} nor {}", n_acked + 1);
            assert!(v2.verify_all().is_ok(), "crash at op {crash_at} ({loss:?}): stored data does not authenticate");
            // the vault stays usable: save again and reopen once more
            let mut v2 = v2;
            v2.put_file("post-crash", b"ok", 1000).unwrap();
            let v3 = Vault::open(v2.into_storage(), &board).unwrap();
            assert_eq!(v3.read_file("post-crash").unwrap(), b"ok");
            checked += 1;
        }
    }
    eprintln!("fault sweep: {checked} crash points checked over {total_ops} storage operations");
}

#[test]
fn previous_version_remains_recoverable_after_an_interrupted_overwrite() {
    let (mut v, board, _) = new_vault();
    v.put_file("doc", b"the last good version", 1).unwrap();
    let st = v.into_storage();
    // overwrite that dies after the data was appended but before the journal commit is durable
    for crash_at in 1..12 {
        let mut s = st.clone();
        s.set_crash_at(Some(crash_at));
        let mut v = Vault::open(s, &board).unwrap();
        let _ = v.put_file("doc", b"half written replacement that must never be seen alone", 2);
        let mut s = v.into_storage();
        s.power_loss(Loss::TornPrefix(60));
        let v2 = Vault::open(s, &board).unwrap();
        let cur = v2.read_file("doc").unwrap();
        assert!(cur == b"the last good version" || cur == b"half written replacement that must never be seen alone".to_vec());
        if cur != b"the last good version" {
            assert_eq!(v2.read_version("doc", 0).unwrap(), b"the last good version");
        }
    }
}

#[test]
fn unverified_backend_is_flagged_and_can_lose_new_files() {
    let (board, _) = keys();
    let mut st = MemStorage::new();
    st.verified_dir_sync = false;
    let v = Vault::create(st, &[(SlotKind::Board, board)]).unwrap();
    assert_eq!(v.durability(), Durability::Unverified);
    let (v, _, _) = new_vault();
    assert_eq!(v.durability(), Durability::Verified);
}

#[test]
fn recovery_slot_replacement_changes_who_can_open() {
    let (mut v, board, old_recovery) = new_vault();
    v.put_file("a", b"1", 1).unwrap();
    let new_recovery: Key = crypto::random();
    v.replace_slot(SlotKind::Recovery, &new_recovery).unwrap();
    let st = v.into_storage();
    assert!(Vault::open(st.clone(), &new_recovery).is_ok());
    assert!(Vault::open(st.clone(), &board).is_ok());
    // the old recovery secret no longer opens the CURRENT header, but any older copy of the header still would
    assert!(matches!(Vault::open(st, &old_recovery), Err(Error::BadKey)));
}

#[test]
fn header_torn_write_falls_back_to_the_other_copy() {
    let (mut v, board, _) = new_vault();
    v.put_file("a", b"1", 1).unwrap();
    let new_recovery: Key = crypto::random();
    v.replace_slot(SlotKind::Recovery, &new_recovery).unwrap(); // generation 2 -> HDR_B
    let mut st = v.into_storage();
    let b = st.raw_mut("vault.hdr.B").unwrap();
    let n = b.len();
    b.truncate(n / 2); // torn
    let v2 = Vault::open(st, &board).unwrap(); // falls back to the other copy
    assert_eq!(v2.read_file("a").unwrap(), b"1");
}

#[test]
fn disk_storage_round_trip() {
    let dir = std::env::temp_dir().join(format!("gp-vault-test-{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    let (board, _) = keys();
    {
        let mut v = Vault::create(DiskStorage::open(&dir).unwrap(), &[(SlotKind::Board, board)]).unwrap();
        v.put_file("x/y.txt", b"on disk", 1).unwrap();
        assert_eq!(v.durability(), Durability::Unverified);
    }
    let v = Vault::open(DiskStorage::open(&dir).unwrap(), &board).unwrap();
    assert_eq!(v.read_file("x/y.txt").unwrap(), b"on disk");
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn recovery_by_public_key_slot_and_board_replacement() {
    let (sk, pk) = recovery::generate();
    assert_eq!(recovery::public_from_secret(&sk).unwrap(), pk);
    let board: Key = crypto::random();
    let vid: [u8; 16] = crypto::random();
    let mut v = Vault::create_full(MemStorage::new(), vid, &[(SlotKind::Board, board)], Some(pk)).unwrap();
    v.put_file("a/secret.txt", b"keep me", 1).unwrap();
    let st = v.into_storage();
    // the host only ever needed the PUBLIC key to add this slot; the secret opens it
    let mut v2 = Vault::open_with_recovery_secret(st.clone(), &sk).unwrap();
    assert_eq!(v2.read_file("a/secret.txt").unwrap(), b"keep me");
    // wrong secret
    let (other_sk, _) = recovery::generate();
    assert!(Vault::open_with_recovery_secret(st.clone(), &other_sk).is_err());
    // board replacement: re-wrap the board slot under a NEW board KEK, old board KEK stops working on the current header
    let new_board: Key = crypto::random();
    v2.replace_slot(SlotKind::Board, &new_board).unwrap();
    let st2 = v2.into_storage();
    assert!(Vault::open(st2.clone(), &new_board).is_ok());
    assert!(matches!(Vault::open(st2.clone(), &board), Err(Error::BadKey)));
    // recovery secret replacement
    let mut v3 = Vault::open(st2, &new_board).unwrap();
    let (sk2, pk2) = recovery::generate();
    v3.replace_recovery_pk(&pk2).unwrap();
    let st3 = v3.into_storage();
    assert!(Vault::open_with_recovery_secret(st3.clone(), &sk2).is_ok());
    assert!(Vault::open_with_recovery_secret(st3, &sk).is_err(), "old recovery secret no longer opens the current header");
}

#[test]
fn recovery_code_text_round_trips() {
    let (sk, _) = recovery::generate();
    let text = recovery::encode_secret(&sk);
    assert_eq!(text.replace('-', "").len(), 52);
    assert_eq!(recovery::decode_secret(&text).unwrap(), sk);
    assert_eq!(recovery::decode_secret(&text.to_lowercase()).unwrap(), sk);
    assert!(recovery::decode_secret("not a code").is_err());
}
