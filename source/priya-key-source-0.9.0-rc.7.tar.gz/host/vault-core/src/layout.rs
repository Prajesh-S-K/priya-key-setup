//! Byte layouts of the journal (draft v0). Little-endian, no implicit padding. Sizes are asserted at compile time.

pub const SEGMENT_HEADER_LEN: usize = 128;
pub const RECORD_HEADER_LEN: usize = 40;
pub const SEGMENT_MAGIC: [u8; 4] = *b"GPJ1";
pub const RECORD_MAGIC: u16 = 0x4A47;
pub const MAX_RECORD_CT: u32 = 1 << 20;
pub const TAG_LEN: usize = 16;
pub const NONCE_LEN: usize = 24;

/// Offsets inside the 128-byte segment header (architecture 5.5.1).
pub mod seg {
    pub const MAGIC: usize = 0;
    pub const VERSION: usize = 4;
    pub const HEADER_LEN: usize = 6;
    pub const SEGMENT_INDEX: usize = 8;
    pub const TX_STATE: usize = 12;
    pub const RESERVED: usize = 13;
    pub const VAULT_ID: usize = 16;
    pub const FIRST_SEQ: usize = 32;
    pub const PREV_VALID_LEN: usize = 40;
    pub const PREV_CHAIN_HASH: usize = 48;
    pub const CKPT_REF: usize = 80;
    pub const TAG: usize = 112;
    pub const AUTHENTICATED_LEN: usize = 112;
}

/// Offsets inside the 40-byte record header (architecture 5.5.2).
pub mod rec {
    pub const MAGIC: usize = 0;
    pub const TYPE: usize = 2;
    pub const FLAGS: usize = 3;
    pub const SEQ: usize = 4;
    pub const CT_LEN: usize = 12;
    pub const NONCE: usize = 16;
}

const _: () = assert!(seg::TAG + TAG_LEN == SEGMENT_HEADER_LEN);
const _: () = assert!(seg::AUTHENTICATED_LEN == seg::TAG);
const _: () = assert!(rec::NONCE + NONCE_LEN == RECORD_HEADER_LEN);
