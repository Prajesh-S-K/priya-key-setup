//! Recovery key pair (architecture 4.6, revised): the recovery secret is an X25519 private key shown once to the owner;
//! the host keeps only the public key, so new vaults can be given a recovery slot without the secret.
//! The vault key is wrapped with HPKE (RFC 9180: X25519-HKDF-SHA256 / HKDF-SHA256 / ChaCha20-Poly1305), not a custom scheme.
use crate::crypto::Key;
use crate::error::{Error, Result};
use hpke::aead::ChaCha20Poly1305;
use hpke::kdf::HkdfSha256;
use hpke::kem::X25519HkdfSha256;
use hpke::{Deserializable, Kem, OpModeR, OpModeS, Serializable};

type K = X25519HkdfSha256;

pub fn generate() -> ([u8; 32], [u8; 32]) {
    let (sk, pk) = K::gen_keypair(&mut rand::rngs::OsRng);
    (sk.to_bytes().into(), pk.to_bytes().into())
}

pub fn public_from_secret(secret: &[u8; 32]) -> Result<[u8; 32]> {
    let sk = <K as Kem>::PrivateKey::from_bytes(secret).map_err(|_| Error::BadKey)?;
    Ok(K::sk_to_pk(&sk).to_bytes().into())
}

fn info(vault_id: &[u8; 16]) -> Vec<u8> {
    let mut i = b"gp-recovery-hpke-v1".to_vec();
    i.extend_from_slice(vault_id);
    i
}

/// Returns (encapsulated key, ciphertext||tag).
pub fn seal_vk(pk: &[u8; 32], vault_id: &[u8; 16], aad: &[u8], vk: &Key) -> Result<(Vec<u8>, Vec<u8>)> {
    let pk = <K as Kem>::PublicKey::from_bytes(pk).map_err(|_| Error::InvalidArgument("bad recovery public key".into()))?;
    let (enc, ct) = hpke::single_shot_seal::<ChaCha20Poly1305, HkdfSha256, K, _>(
        &OpModeS::Base, &pk, &info(vault_id), vk, aad, &mut rand::rngs::OsRng,
    )
    .map_err(|_| Error::InvalidArgument("recovery wrap failed".into()))?;
    Ok((enc.to_bytes().to_vec(), ct))
}

pub fn open_vk(secret: &[u8; 32], vault_id: &[u8; 16], aad: &[u8], enc: &[u8], ct: &[u8]) -> Result<Key> {
    let sk = <K as Kem>::PrivateKey::from_bytes(secret).map_err(|_| Error::BadKey)?;
    let enc = <K as Kem>::EncappedKey::from_bytes(enc).map_err(|_| Error::BadKey)?;
    let pt = hpke::single_shot_open::<ChaCha20Poly1305, HkdfSha256, K>(&OpModeR::Base, &sk, &enc, &info(vault_id), ct, aad)
        .map_err(|_| Error::BadKey)?;
    pt.try_into().map_err(|_| Error::BadKey)
}

/// 52 Crockford-style base32 characters in groups of 4, for writing down.
pub fn encode_secret(secret: &[u8; 32]) -> String {
    const A: &[u8] = b"0123456789ABCDEFGHJKMNPQRSTVWXYZ";
    let mut out = String::new();
    let (mut acc, mut bits) = (0u32, 0u32);
    let mut n = 0;
    for &b in secret.iter() {
        acc = (acc << 8) | b as u32;
        bits += 8;
        while bits >= 5 {
            bits -= 5;
            out.push(A[((acc >> bits) & 31) as usize] as char);
            n += 1;
            if n % 4 == 0 {
                out.push('-');
            }
        }
    }
    if bits > 0 {
        out.push(A[((acc << (5 - bits)) & 31) as usize] as char);
    }
    out.trim_end_matches('-').to_string()
}

pub fn decode_secret(s: &str) -> Result<[u8; 32]> {
    let mut bits = 0u32;
    let mut acc = 0u32;
    let mut out = Vec::new();
    for c in s.chars().filter(|c| *c != '-' && !c.is_whitespace()) {
        let c = match c.to_ascii_uppercase() {
            'O' => '0',
            'I' | 'L' => '1',
            x => x,
        };
        let v = "0123456789ABCDEFGHJKMNPQRSTVWXYZ".find(c).ok_or_else(|| Error::InvalidArgument("not a recovery code".into()))? as u32;
        acc = (acc << 5) | v;
        bits += 5;
        if bits >= 8 {
            bits -= 8;
            out.push(((acc >> bits) & 0xff) as u8);
        }
    }
    out.truncate(32);
    out.try_into().map_err(|_| Error::InvalidArgument("recovery code has the wrong length".into()))
}
