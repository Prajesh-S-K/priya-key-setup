//! Thin wrappers over audited RustCrypto primitives. No custom cryptography.
use crate::error::{Error, Result};
use blake2::{Blake2s256, Digest};
use chacha20poly1305::aead::{Aead, KeyInit, Payload};
use chacha20poly1305::{XChaCha20Poly1305, XNonce};
use hkdf::Hkdf;
use hmac::{Hmac, Mac};
use sha2::Sha256;
use subtle::ConstantTimeEq;
use zeroize::Zeroize;

pub const KEY_LEN: usize = 32;
pub const NONCE_LEN: usize = 24;
pub const TAG_LEN: usize = 16;
pub type Key = [u8; KEY_LEN];

pub fn random<const N: usize>() -> [u8; N] {
    let mut b = [0u8; N];
    getrandom::getrandom(&mut b).expect("OS random source unavailable");
    b
}

/// XChaCha20-Poly1305 seal. Returns ciphertext || tag. Nonce must be fresh random per (key, message).
pub fn seal(key: &Key, nonce: &[u8; NONCE_LEN], aad: &[u8], plaintext: &[u8]) -> Vec<u8> {
    let c = XChaCha20Poly1305::new(key.into());
    c.encrypt(XNonce::from_slice(nonce), Payload { msg: plaintext, aad }).expect("encrypt")
}

pub fn open(key: &Key, nonce: &[u8; NONCE_LEN], aad: &[u8], ct: &[u8]) -> Result<Vec<u8>> {
    let c = XChaCha20Poly1305::new(key.into());
    c.decrypt(XNonce::from_slice(nonce), Payload { msg: ct, aad })
        .map_err(|_| Error::Corrupt("authentication failed".into()))
}

pub fn hkdf32(ikm: &[u8], salt: &[u8], info: &[u8]) -> Key {
    let h = Hkdf::<Sha256>::new(Some(salt), ikm);
    let mut out = [0u8; 32];
    h.expand(info, &mut out).expect("hkdf length");
    out
}

pub fn hmac16(key: &Key, data: &[u8]) -> [u8; 16] {
    let mut m = <Hmac<Sha256> as Mac>::new_from_slice(key).expect("hmac key");
    m.update(data);
    let full = m.finalize().into_bytes();
    let mut out = [0u8; 16];
    out.copy_from_slice(&full[..16]);
    out
}

pub fn ct_eq(a: &[u8], b: &[u8]) -> bool {
    a.len() == b.len() && bool::from(a.ct_eq(b))
}

pub fn blake2s(parts: &[&[u8]]) -> [u8; 32] {
    let mut h = Blake2s256::new();
    for p in parts {
        h.update(p);
    }
    h.finalize().into()
}

/// Keys derived from the vault key (architecture 5.3).
pub struct VaultKeys {
    pub vk: Key,
    pub meta: Key,
    pub jmac: Key,
    pub hdr: Key,
}

impl VaultKeys {
    pub fn derive(vk: Key, vault_id: &[u8; 16]) -> Self {
        VaultKeys {
            meta: hkdf32(&vk, vault_id, b"gp-meta-v1"),
            jmac: hkdf32(&vk, vault_id, b"gp-jmac-v1"),
            hdr: hkdf32(&vk, vault_id, b"gp-hdr-v1"),
            vk,
        }
    }
    pub fn file_key(&self, vault_id: &[u8; 16], file_id: &[u8; 16]) -> Key {
        let mut info = Vec::with_capacity(32);
        info.extend_from_slice(b"gp-file-v1");
        info.extend_from_slice(file_id);
        hkdf32(&self.vk, vault_id, &info)
    }
}

impl Drop for VaultKeys {
    fn drop(&mut self) {
        self.vk.zeroize();
        self.meta.zeroize();
        self.jmac.zeroize();
        self.hdr.zeroize();
    }
}

/// KEK for a vault from board secret K_board (architecture 3.5).
pub fn kek_from_board(k_board: &Key, vault_id: &[u8; 16]) -> Key {
    hkdf32(k_board, vault_id, b"gp-vault-kek-v1")
}

/// KEK from the offline recovery secret (architecture 4.6).
pub fn kek_from_recovery(secret: &[u8], vault_id: &[u8; 16]) -> Key {
    hkdf32(secret, vault_id, b"gp-recovery-kek-v1")
}
