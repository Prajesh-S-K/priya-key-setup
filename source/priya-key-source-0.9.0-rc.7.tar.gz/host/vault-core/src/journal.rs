//! Authenticated append-only journal (architecture 5.5, draft v0). One segment file per vault in this version.
use crate::codec::{Reader, Writer};
use crate::crypto::{self, Key, VaultKeys};
use crate::error::{Error, Result};
use crate::layout::*;
use crate::storage::Storage;

pub const T_COMMIT_SINGLE: u8 = 1;
pub const T_BEGIN: u8 = 2;
pub const T_DELTA: u8 = 3;
pub const T_COMMIT: u8 = 4;
pub const MAX_PLAINTEXT: usize = MAX_RECORD_CT as usize - TAG_LEN;

pub struct Journal {
    name: String,
    vault_id: [u8; 16],
    k_meta: Key,
    seg_index: u32,
    next_seq: u64,
    chain: [u8; 32],
    len: u64,
    poisoned: bool,
    max_plaintext: usize,
    /// Set when recovery could not complete: commits are refused (architecture 5.5.4 step 4).
    pub read_only: Option<String>,
    /// True if opening discarded a torn tail or an incomplete transaction.
    pub recovered: bool,
}

pub fn genesis_chain(vault_id: &[u8; 16]) -> [u8; 32] {
    crypto::blake2s(&[b"gp-genesis-v1", vault_id])
}

fn segment_header(vault_id: &[u8; 16], seg_index: u32, first_seq: u64, prev_chain: &[u8; 32], keys: &VaultKeys) -> [u8; SEGMENT_HEADER_LEN] {
    let mut h = [0u8; SEGMENT_HEADER_LEN];
    h[seg::MAGIC..seg::MAGIC + 4].copy_from_slice(&SEGMENT_MAGIC);
    h[seg::VERSION..seg::VERSION + 2].copy_from_slice(&1u16.to_le_bytes());
    h[seg::HEADER_LEN..seg::HEADER_LEN + 2].copy_from_slice(&(SEGMENT_HEADER_LEN as u16).to_le_bytes());
    h[seg::SEGMENT_INDEX..seg::SEGMENT_INDEX + 4].copy_from_slice(&seg_index.to_le_bytes());
    h[seg::TX_STATE] = 0;
    h[seg::VAULT_ID..seg::VAULT_ID + 16].copy_from_slice(vault_id);
    h[seg::FIRST_SEQ..seg::FIRST_SEQ + 8].copy_from_slice(&first_seq.to_le_bytes());
    h[seg::PREV_VALID_LEN..seg::PREV_VALID_LEN + 8].copy_from_slice(&0u64.to_le_bytes());
    h[seg::PREV_CHAIN_HASH..seg::PREV_CHAIN_HASH + 32].copy_from_slice(prev_chain);
    let tag = crypto::hmac16(&keys.jmac, &h[..seg::AUTHENTICATED_LEN]);
    h[seg::TAG..seg::TAG + 16].copy_from_slice(&tag);
    h
}

fn record_aad(vault_id: &[u8; 16], seg_index: u32, typ: u8, flags: u8, seq: u64, ct_len: u32, prev_chain: &[u8; 32]) -> Vec<u8> {
    let mut a = Vec::with_capacity(80);
    a.extend_from_slice(b"gp-jrec-v1");
    a.extend_from_slice(vault_id);
    a.extend_from_slice(&seg_index.to_le_bytes());
    a.push(typ);
    a.push(flags);
    a.extend_from_slice(&seq.to_le_bytes());
    a.extend_from_slice(&ct_len.to_le_bytes());
    a.extend_from_slice(prev_chain);
    a
}

struct Built {
    bytes: Vec<u8>,
    chain: [u8; 32],
    next_seq: u64,
}

impl Journal {
    pub fn create<S: Storage>(storage: &mut S, name: &str, vault_id: [u8; 16], keys: &VaultKeys) -> Result<Journal> {
        let chain = genesis_chain(&vault_id);
        let hdr = segment_header(&vault_id, 0, 1, &chain, keys);
        storage.create_new(name)?;
        storage.append(name, &hdr)?;
        storage.sync(name)?;
        storage.sync_dir()?; // creation barrier (architecture 5.5.5)
        Ok(Journal { name: name.into(), vault_id, k_meta: keys.meta, seg_index: 0, next_seq: 1, chain, len: SEGMENT_HEADER_LEN as u64, poisoned: false, max_plaintext: MAX_PLAINTEXT, read_only: None, recovered: false })
    }

    fn build(&self, typ_payloads: &[(u8, Vec<u8>)]) -> Built {
        let mut bytes = Vec::new();
        let mut chain = self.chain;
        let mut seq = self.next_seq;
        for (typ, pt) in typ_payloads {
            let nonce: [u8; NONCE_LEN] = crypto::random();
            let ct_len = (pt.len() + TAG_LEN) as u32;
            let aad = record_aad(&self.vault_id, self.seg_index, *typ, 0, seq, ct_len, &chain);
            let ct = crypto::seal(&self.k_meta, &nonce, &aad, pt);
            let mut hdr = [0u8; RECORD_HEADER_LEN];
            hdr[rec::MAGIC..rec::MAGIC + 2].copy_from_slice(&RECORD_MAGIC.to_le_bytes());
            hdr[rec::TYPE] = *typ;
            hdr[rec::FLAGS] = 0;
            hdr[rec::SEQ..rec::SEQ + 8].copy_from_slice(&seq.to_le_bytes());
            hdr[rec::CT_LEN..rec::CT_LEN + 4].copy_from_slice(&ct_len.to_le_bytes());
            hdr[rec::NONCE..rec::NONCE + NONCE_LEN].copy_from_slice(&nonce);
            chain = crypto::blake2s(&[&chain, &hdr, &ct[ct.len() - TAG_LEN..]]);
            bytes.extend_from_slice(&hdr);
            bytes.extend_from_slice(&ct);
            seq += 1;
        }
        Built { bytes, chain, next_seq: seq }
    }

    /// Append one committed transaction (a blob of encoded operations) and make it durable.
    /// On any failure the journal is poisoned: reopen the vault to run recovery.
    pub fn commit<S: Storage>(&mut self, storage: &mut S, ops: &[u8]) -> Result<()> {
        if self.poisoned {
            return Err(Error::ReadOnly("journal poisoned by an earlier failure; reopen to recover".into()));
        }
        if let Some(r) = &self.read_only {
            return Err(Error::ReadOnly(r.clone()));
        }
        let records: Vec<(u8, Vec<u8>)> = if ops.len() <= self.max_plaintext {
            vec![(T_COMMIT_SINGLE, ops.to_vec())]
        } else {
            let txid: u64 = u64::from_le_bytes(crypto::random::<8>());
            let pieces: Vec<&[u8]> = ops.chunks(self.max_plaintext - 8).collect();
            let mut v = Vec::new();
            let mut w = Writer::new();
            w.u64(txid).u32(pieces.len() as u32);
            v.push((T_BEGIN, w.0));
            for p in &pieces {
                let mut w = Writer::new();
                w.u64(txid).raw(p);
                v.push((T_DELTA, w.0));
            }
            let digest = crypto::blake2s(&[ops]);
            let mut w = Writer::new();
            w.u64(txid).u32(pieces.len() as u32).raw(&digest);
            v.push((T_COMMIT, w.0));
            v
        };
        let built = self.build(&records);
        let r = storage.append(&self.name, &built.bytes).and_then(|_| storage.sync(&self.name));
        match r {
            Ok(()) => {
                self.chain = built.chain;
                self.next_seq = built.next_seq;
                self.len += built.bytes.len() as u64;
                Ok(())
            }
            Err(e) => {
                self.poisoned = true;
                Err(e)
            }
        }
    }

    /// Open, authenticate, replay and recover. Returns the journal and the committed transactions in order.
    pub fn open<S: Storage>(storage: &mut S, name: &str, vault_id: [u8; 16], keys: &VaultKeys) -> Result<(Journal, Vec<Vec<u8>>)> {
        let data = storage.read_all(name)?.ok_or_else(|| Error::MissingFile(name.into()))?;
        if data.len() < SEGMENT_HEADER_LEN {
            return Err(Error::Corrupt("journal segment header truncated".into()));
        }
        let h = &data[..SEGMENT_HEADER_LEN];
        if h[seg::MAGIC..seg::MAGIC + 4] != SEGMENT_MAGIC
            || u16::from_le_bytes([h[seg::VERSION], h[seg::VERSION + 1]]) != 1
            || u16::from_le_bytes([h[seg::HEADER_LEN], h[seg::HEADER_LEN + 1]]) as usize != SEGMENT_HEADER_LEN
            || h[seg::TX_STATE] != 0
            || h[seg::RESERVED..seg::RESERVED + 3] != [0, 0, 0]
            || h[seg::CKPT_REF..seg::CKPT_REF + 32] != [0u8; 32]
        {
            return Err(Error::Corrupt("bad journal segment header".into()));
        }
        let tag = crypto::hmac16(&keys.jmac, &h[..seg::AUTHENTICATED_LEN]);
        if !crypto::ct_eq(&tag, &h[seg::TAG..seg::TAG + 16]) {
            return Err(Error::Corrupt("journal segment header MAC failed".into()));
        }
        if h[seg::VAULT_ID..seg::VAULT_ID + 16] != vault_id {
            return Err(Error::Corrupt("journal belongs to a different vault".into()));
        }
        let seg_index = u32::from_le_bytes(h[seg::SEGMENT_INDEX..seg::SEGMENT_INDEX + 4].try_into().unwrap());
        let first_seq = u64::from_le_bytes(h[seg::FIRST_SEQ..seg::FIRST_SEQ + 8].try_into().unwrap());
        let mut chain: [u8; 32] = h[seg::PREV_CHAIN_HASH..seg::PREV_CHAIN_HASH + 32].try_into().unwrap();

        struct Tx {
            txid: u64,
            expected: u32,
            pieces: Vec<Vec<u8>>,
        }
        let mut pos = SEGMENT_HEADER_LEN;
        let mut seq_expected = first_seq;
        let (mut committed_end, mut committed_chain, mut committed_seq) = (pos, chain, seq_expected);
        let mut open_tx: Option<Tx> = None;
        let mut out: Vec<Vec<u8>> = Vec::new();
        let mut torn = false;

        loop {
            if pos == data.len() {
                break;
            }
            let rem = data.len() - pos;
            if rem < RECORD_HEADER_LEN {
                torn = true;
                break;
            }
            let hdr = &data[pos..pos + RECORD_HEADER_LEN];
            let magic = u16::from_le_bytes([hdr[rec::MAGIC], hdr[rec::MAGIC + 1]]);
            let ct_len = u32::from_le_bytes(hdr[rec::CT_LEN..rec::CT_LEN + 4].try_into().unwrap());
            if magic != RECORD_MAGIC || (ct_len as usize) < TAG_LEN || ct_len > MAX_RECORD_CT {
                // A torn write can leave a prefix of a record header followed by zeros (zero-extended tail). That is a
                // torn tail only if every non-zero byte lies inside one header's worth of bytes; anything else is interior
                // corruption and is never skipped.
                let last_nonzero = data[pos..].iter().rposition(|b| *b != 0);
                if last_nonzero.map(|i| i < RECORD_HEADER_LEN).unwrap_or(true) {
                    torn = true;
                    break;
                }
                return Err(Error::Corrupt(format!("invalid record header at offset {pos}")));
            }
            let end = pos + RECORD_HEADER_LEN + ct_len as usize;
            if end > data.len() {
                torn = true;
                break;
            }
            let typ = hdr[rec::TYPE];
            let flags = hdr[rec::FLAGS];
            let seq = u64::from_le_bytes(hdr[rec::SEQ..rec::SEQ + 8].try_into().unwrap());
            let nonce: [u8; NONCE_LEN] = hdr[rec::NONCE..rec::NONCE + NONCE_LEN].try_into().unwrap();
            let ct = &data[pos + RECORD_HEADER_LEN..end];
            let aad = record_aad(&vault_id, seg_index, typ, flags, seq, ct_len, &chain);
            let pt = match crypto::open(&keys.meta, &nonce, &aad, ct) {
                Ok(p) => p,
                Err(_) if end == data.len() => {
                    torn = true; // final frame failed authentication: torn write
                    break;
                }
                Err(_) => {
                    return Err(Error::Corrupt(format!(
                        "record at offset {pos} (expected seq {seq_expected}) failed authentication with data after it: deletion, duplication, reordering or corruption"
                    )))
                }
            };
            if seq != seq_expected || flags != 0 {
                return Err(Error::Corrupt(format!("sequence {seq} where {seq_expected} was expected")));
            }
            chain = crypto::blake2s(&[&chain, hdr, &ct[ct.len() - TAG_LEN..]]);
            seq_expected += 1;
            pos = end;
            match typ {
                T_COMMIT_SINGLE => {
                    if open_tx.is_some() {
                        return Err(Error::Corrupt("standalone commit inside an open transaction".into()));
                    }
                    out.push(pt);
                    (committed_end, committed_chain, committed_seq) = (pos, chain, seq_expected);
                }
                T_BEGIN => {
                    if open_tx.is_some() {
                        return Err(Error::Corrupt("BEGIN inside an open transaction".into()));
                    }
                    let mut r = Reader::new(&pt);
                    open_tx = Some(Tx { txid: r.u64()?, expected: r.u32()?, pieces: vec![] });
                }
                T_DELTA => {
                    let tx = open_tx.as_mut().ok_or_else(|| Error::Corrupt("DELTA without BEGIN".into()))?;
                    let mut r = Reader::new(&pt);
                    if r.u64()? != tx.txid {
                        return Err(Error::Corrupt("DELTA transaction id mismatch".into()));
                    }
                    tx.pieces.push(pt[8..].to_vec());
                }
                T_COMMIT => {
                    let tx = open_tx.take().ok_or_else(|| Error::Corrupt("COMMIT without BEGIN".into()))?;
                    let mut r = Reader::new(&pt);
                    let (txid, count, digest) = (r.u64()?, r.u32()?, r.arr::<32>()?);
                    let all: Vec<u8> = tx.pieces.concat();
                    if txid != tx.txid || count != tx.expected || count as usize != tx.pieces.len() || digest != crypto::blake2s(&[&all]) {
                        return Err(Error::Corrupt("transaction COMMIT does not match its BEGIN/DELTA records".into()));
                    }
                    out.push(all);
                    (committed_end, committed_chain, committed_seq) = (pos, chain, seq_expected);
                }
                other => return Err(Error::Corrupt(format!("unknown record type {other}"))),
            }
        }
        if open_tx.is_some() {
            torn = true; // valid BEGIN/DELTA prefix without COMMIT: discard it (architecture 5.5.4)
        }
        let mut j = Journal {
            name: name.into(),
            vault_id,
            k_meta: keys.meta,
            seg_index,
            next_seq: committed_seq,
            chain: committed_chain,
            len: committed_end as u64,
            poisoned: false,
            max_plaintext: MAX_PLAINTEXT,
            read_only: None,
            recovered: torn,
        };
        if torn || committed_end != data.len() {
            // Primary recovery: truncate the existing file to the last committed boundary and flush it.
            let r = storage.truncate(name, committed_end as u64).and_then(|_| storage.sync(name));
            if let Err(e) = r {
                if e == Error::Crash {
                    return Err(e);
                }
                j.read_only = Some(format!("torn tail could not be truncated: {e}"));
            }
        }
        Ok((j, out))
    }

    /// Test hook: force multi-record transactions with small records.
    pub fn set_max_plaintext(&mut self, n: usize) {
        self.max_plaintext = n.clamp(16, MAX_PLAINTEXT);
    }
    pub fn seq(&self) -> u64 {
        self.next_seq
    }
    pub fn len(&self) -> u64 {
        self.len
    }
}
