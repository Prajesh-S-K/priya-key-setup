use std::fmt;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Error {
    /// Underlying storage failure (message kept for diagnostics).
    Io(String),
    /// Injected by the fault-injecting test storage: the "process" died here.
    Crash,
    /// Authentication failed or a structure is invalid in a way that is NOT a torn tail. Never skipped.
    Corrupt(String),
    /// Wrong key (slot unwrap or header MAC failed).
    BadKey,
    NotFound(String),
    Exists(String),
    InvalidArgument(String),
    /// The vault was opened read-only because recovery could not complete safely.
    ReadOnly(String),
    /// A file or segment the journal references is missing (never silently dropped).
    MissingFile(String),
}

pub type Result<T> = std::result::Result<T, Error>;

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{:?}", self)
    }
}
impl std::error::Error for Error {}
impl From<std::io::Error> for Error {
    fn from(e: std::io::Error) -> Self {
        Error::Io(e.to_string())
    }
}
