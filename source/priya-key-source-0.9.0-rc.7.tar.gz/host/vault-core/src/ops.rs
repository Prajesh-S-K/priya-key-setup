//! Journal operations and the in-memory state they build (architecture 5.4-5.5, P1-P4 in 5.5.6).
use crate::codec::{Reader, Writer};
use crate::error::{Error, Result};
use std::collections::{BTreeMap, BTreeSet, HashMap};

pub const CHUNK_SIZE: usize = 64 * 1024;
pub const VERSION_KEEP: usize = 3;
pub type FileId = [u8; 16];

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ChunkRef {
    /// Offset of the chunk record (nonce || ciphertext || tag) in the data segment.
    pub off: u64,
    pub plain_len: u32,
    pub tag: [u8; 16],
}

impl ChunkRef {
    pub fn record_len(&self) -> u64 {
        24 + self.plain_len as u64 + 16
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Root {
    pub gen: u64,
    pub size: u64,
    pub mtime: u64,
    pub chunks: Vec<ChunkRef>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Op {
    Root { file_id: FileId, root: Root },
    Link { path: String, file_id: FileId },
    Unlink { path: String },
    Rename { from: String, to: String },
    Purge { file_id: FileId },
    Mkdir { path: String },
    Rmdir { path: String },
}

pub fn encode_ops(ops: &[Op]) -> Vec<u8> {
    let mut w = Writer::new();
    for op in ops {
        match op {
            Op::Root { file_id, root } => {
                w.u8(1).raw(file_id).u64(root.gen).u64(root.size).u64(root.mtime).u32(root.chunks.len() as u32);
                for c in &root.chunks {
                    w.u64(c.off).u32(c.plain_len).raw(&c.tag);
                }
            }
            Op::Link { path, file_id } => {
                w.u8(2).str(path).raw(file_id);
            }
            Op::Unlink { path } => {
                w.u8(3).str(path);
            }
            Op::Rename { from, to } => {
                w.u8(4).str(from).str(to);
            }
            Op::Purge { file_id } => {
                w.u8(5).raw(file_id);
            }
            Op::Mkdir { path } => {
                w.u8(6).str(path);
            }
            Op::Rmdir { path } => {
                w.u8(7).str(path);
            }
        }
    }
    w.0
}

pub fn decode_ops(blob: &[u8]) -> Result<Vec<Op>> {
    let mut r = Reader::new(blob);
    let mut out = vec![];
    while r.remaining() > 0 {
        let op = match r.u8()? {
            1 => {
                let file_id = r.arr::<16>()?;
                let (gen, size, mtime, n) = (r.u64()?, r.u64()?, r.u64()?, r.u32()? as usize);
                if n > r.remaining() / 28 + 1 {
                    return Err(Error::Corrupt("chunk table length".into()));
                }
                let mut chunks = Vec::with_capacity(n);
                for _ in 0..n {
                    chunks.push(ChunkRef { off: r.u64()?, plain_len: r.u32()?, tag: r.arr::<16>()? });
                }
                Op::Root { file_id, root: Root { gen, size, mtime, chunks } }
            }
            2 => Op::Link { path: r.string()?, file_id: r.arr::<16>()? },
            3 => Op::Unlink { path: r.string()? },
            4 => Op::Rename { from: r.string()?, to: r.string()? },
            5 => Op::Purge { file_id: r.arr::<16>()? },
            6 => Op::Mkdir { path: r.string()? },
            7 => Op::Rmdir { path: r.string()? },
            t => return Err(Error::Corrupt(format!("unknown operation {t}"))),
        };
        out.push(op);
    }
    Ok(out)
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct FileState {
    pub current: Option<Root>,
    /// Previous roots, oldest first, at most VERSION_KEEP (P4: deterministic retention).
    pub versions: Vec<Root>,
    /// Path the file had when it was unlinked or replaced (a tombstone), if any.
    pub tombstone_path: Option<String>,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct State {
    pub names: BTreeMap<String, FileId>,
    pub dirs: BTreeSet<String>,
    pub files: HashMap<FileId, FileState>,
}

impl State {
    pub fn apply(&mut self, op: &Op) {
        match op {
            Op::Root { file_id, root } => {
                let fs = self.files.entry(*file_id).or_default();
                if let Some(prev) = fs.current.take() {
                    fs.versions.push(prev);
                    while fs.versions.len() > VERSION_KEEP {
                        fs.versions.remove(0);
                    }
                }
                fs.current = Some(root.clone());
            }
            Op::Link { path, file_id } => {
                if let Some(old) = self.names.insert(path.clone(), *file_id) {
                    if old != *file_id {
                        if let Some(f) = self.files.get_mut(&old) {
                            f.tombstone_path = Some(path.clone());
                        }
                    }
                }
                if let Some(f) = self.files.get_mut(file_id) {
                    f.tombstone_path = None;
                }
            }
            Op::Unlink { path } => {
                if let Some(fid) = self.names.remove(path) {
                    if let Some(f) = self.files.get_mut(&fid) {
                        f.tombstone_path = Some(path.clone());
                    }
                }
            }
            Op::Rename { from, to } => {
                // files and whole directory subtrees
                let moved: Vec<(String, FileId)> = self
                    .names
                    .iter()
                    .filter(|(k, _)| *k == from || k.starts_with(&format!("{from}/")))
                    .map(|(k, v)| (k.clone(), *v))
                    .collect();
                for (k, _) in &moved {
                    self.names.remove(k);
                }
                for (k, fid) in moved {
                    let nk = format!("{to}{}", &k[from.len()..]);
                    if let Some(old) = self.names.insert(nk.clone(), fid) {
                        if old != fid {
                            if let Some(f) = self.files.get_mut(&old) {
                                f.tombstone_path = Some(nk);
                            }
                        }
                    }
                }
                let dmoved: Vec<String> = self.dirs.iter().filter(|d| *d == from || d.starts_with(&format!("{from}/"))).cloned().collect();
                for d in &dmoved {
                    self.dirs.remove(d);
                }
                for d in dmoved {
                    self.dirs.insert(format!("{to}{}", &d[from.len()..]));
                }
            }
            Op::Purge { file_id } => {
                if !self.names.values().any(|v| v == file_id) {
                    self.files.remove(file_id);
                }
            }
            Op::Mkdir { path } => {
                self.dirs.insert(path.clone());
            }
            Op::Rmdir { path } => {
                self.dirs.remove(path);
            }
        }
    }

    /// All chunk references that must stay readable (P3): current roots, version store, tombstones.
    pub fn live_refs(&self) -> impl Iterator<Item = &ChunkRef> {
        self.files.values().flat_map(|f| f.current.iter().chain(f.versions.iter())).flat_map(|r| r.chunks.iter())
    }
}
