//! Storage abstraction. A backend either has a verified directory-flush mechanism or it does not
//! (`dir_sync_verified`), which decides whether acknowledged saves may be claimed durable (architecture 5.5.5).
use crate::error::{Error, Result};
use std::collections::HashMap;
use std::io::{Read, Seek, SeekFrom, Write};
use std::path::PathBuf;

pub trait Storage {
    fn exists(&self, name: &str) -> Result<bool>;
    fn len(&self, name: &str) -> Result<Option<u64>>;
    fn read_all(&self, name: &str) -> Result<Option<Vec<u8>>>;
    fn read_at(&self, name: &str, off: u64, len: usize) -> Result<Vec<u8>>;
    /// Create an empty file; error if it exists.
    fn create_new(&mut self, name: &str) -> Result<()>;
    fn append(&mut self, name: &str, data: &[u8]) -> Result<()>;
    /// Replace the whole content (used for the A/B headers).
    fn write_replace(&mut self, name: &str, data: &[u8]) -> Result<()>;
    fn truncate(&mut self, name: &str, len: u64) -> Result<()>;
    /// Flush file data and metadata of one file to stable storage.
    fn sync(&mut self, name: &str) -> Result<()>;
    /// Flush the directory so newly created/removed entries survive power loss, where the platform can.
    fn sync_dir(&mut self) -> Result<()>;
    fn remove(&mut self, name: &str) -> Result<()>;
    fn list(&self) -> Result<Vec<String>>;
    /// True only if sync_dir is a verified durability mechanism on this backend.
    fn dir_sync_verified(&self) -> bool;
}

// ---------------------------------------------------------------------------------------- disk
pub struct DiskStorage {
    dir: PathBuf,
}

impl DiskStorage {
    pub fn open(dir: impl Into<PathBuf>) -> Result<Self> {
        let dir = dir.into();
        std::fs::create_dir_all(&dir)?;
        Ok(DiskStorage { dir })
    }
    fn p(&self, name: &str) -> PathBuf {
        self.dir.join(name)
    }
}

impl Storage for DiskStorage {
    fn exists(&self, name: &str) -> Result<bool> {
        Ok(self.p(name).exists())
    }
    fn len(&self, name: &str) -> Result<Option<u64>> {
        match std::fs::metadata(self.p(name)) {
            Ok(m) => Ok(Some(m.len())),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(None),
            Err(e) => Err(e.into()),
        }
    }
    fn read_all(&self, name: &str) -> Result<Option<Vec<u8>>> {
        match std::fs::read(self.p(name)) {
            Ok(v) => Ok(Some(v)),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(None),
            Err(e) => Err(e.into()),
        }
    }
    fn read_at(&self, name: &str, off: u64, len: usize) -> Result<Vec<u8>> {
        let mut f = std::fs::File::open(self.p(name))?;
        f.seek(SeekFrom::Start(off))?;
        let mut buf = vec![0u8; len];
        f.read_exact(&mut buf)?;
        Ok(buf)
    }
    fn create_new(&mut self, name: &str) -> Result<()> {
        std::fs::OpenOptions::new().write(true).create_new(true).open(self.p(name))?;
        Ok(())
    }
    fn append(&mut self, name: &str, data: &[u8]) -> Result<()> {
        let mut f = std::fs::OpenOptions::new().append(true).open(self.p(name))?;
        f.write_all(data)?;
        Ok(())
    }
    fn write_replace(&mut self, name: &str, data: &[u8]) -> Result<()> {
        let mut f = std::fs::OpenOptions::new().write(true).create(true).truncate(true).open(self.p(name))?;
        f.write_all(data)?;
        Ok(())
    }
    fn truncate(&mut self, name: &str, len: u64) -> Result<()> {
        let f = std::fs::OpenOptions::new().write(true).open(self.p(name))?;
        f.set_len(len)?;
        Ok(())
    }
    fn sync(&mut self, name: &str) -> Result<()> {
        let f = std::fs::OpenOptions::new().write(true).open(self.p(name))?;
        f.sync_all()?;
        Ok(())
    }
    fn sync_dir(&mut self) -> Result<()> {
        #[cfg(unix)]
        {
            let d = std::fs::File::open(&self.dir)?;
            d.sync_all()?;
        }
        Ok(())
    }
    fn remove(&mut self, name: &str) -> Result<()> {
        std::fs::remove_file(self.p(name))?;
        Ok(())
    }
    fn list(&self) -> Result<Vec<String>> {
        let mut v = vec![];
        for e in std::fs::read_dir(&self.dir)? {
            v.push(e?.file_name().to_string_lossy().into_owned());
        }
        v.sort();
        Ok(v)
    }
    fn dir_sync_verified(&self) -> bool {
        false // Not verified by power-pull tests yet (architecture 5.5.5): the product must not claim durability.
    }
}

// ---------------------------------------------------------------------------------------- fault model
#[derive(Clone, Debug)]
struct MemFile {
    durable: Vec<u8>,
    volatile: Vec<u8>,
    /// Directory entry has been made durable (sync_dir after creation).
    dirent_durable: bool,
    removed_volatile: bool,
}

/// How unsynced data looks after a simulated power loss.
#[derive(Clone, Copy, Debug)]
pub enum Loss {
    /// Everything not synced is gone.
    Clean,
    /// A prefix of the unsynced bytes reached the medium (fraction in 0..=100 percent).
    TornPrefix(u32),
    /// The file length grew but the new bytes are zeros (extended before data was written).
    ZeroTail,
}

/// In-memory storage with a crash point and a power-loss model. Used by the fault-injection tests.
#[derive(Clone, Debug)]
pub struct MemStorage {
    files: HashMap<String, MemFile>,
    ops: u64,
    crash_at: Option<u64>,
    crashed: bool,
    pub verified_dir_sync: bool,
    pub trace: Vec<String>,
}

impl MemStorage {
    pub fn new() -> Self {
        MemStorage { files: HashMap::new(), ops: 0, crash_at: None, crashed: false, verified_dir_sync: true, trace: vec![] }
    }
    pub fn set_crash_at(&mut self, op: Option<u64>) {
        self.crash_at = op;
        self.ops = 0;
        self.crashed = false;
    }
    pub fn ops(&self) -> u64 {
        self.ops
    }
    pub fn crashed(&self) -> bool {
        self.crashed
    }
    fn tick(&mut self, what: &str) -> Result<()> {
        if self.crashed {
            return Err(Error::Crash);
        }
        self.ops += 1;
        if let Some(c) = self.crash_at {
            if self.ops >= c {
                self.crashed = true;
                self.trace.push(format!("CRASH before {what}"));
                return Err(Error::Crash);
            }
        }
        Ok(())
    }
    /// Simulate power loss and "reboot": unsynced state is reduced to what could be on the medium.
    pub fn power_loss(&mut self, loss: Loss) {
        let verified = self.verified_dir_sync;
        let mut names: Vec<String> = self.files.keys().cloned().collect();
        names.sort();
        for n in names {
            let f = self.files.get_mut(&n).unwrap();
            if !f.dirent_durable && !f.removed_volatile && verified {
                // created since the last directory sync: the entry may not exist at all after power loss
                self.files.remove(&n);
                continue;
            }
            if f.removed_volatile && verified {
                f.removed_volatile = false; // removal was not durable: the file is back with its durable content
                f.volatile = f.durable.clone();
            }
            let f = self.files.get_mut(&n).unwrap();
            let nv = f.volatile.clone();
            let d = f.durable.clone();
            let persisted = if nv == d {
                d
            } else if nv.len() >= d.len() && nv[..d.len()] == d[..] {
                let extra = nv.len() - d.len();
                match loss {
                    Loss::Clean => d,
                    Loss::TornPrefix(p) => nv[..d.len() + extra * p as usize / 100].to_vec(),
                    Loss::ZeroTail => {
                        let mut v = d;
                        v.extend(std::iter::repeat(0u8).take(extra));
                        v
                    }
                }
            } else {
                // overwrite or truncate that was not synced
                match loss {
                    Loss::Clean | Loss::ZeroTail => d,
                    Loss::TornPrefix(p) => {
                        let cut = nv.len() * p as usize / 100;
                        let mut v = d.clone();
                        for i in 0..cut.min(nv.len()) {
                            if i < v.len() {
                                v[i] = nv[i];
                            } else {
                                v.push(nv[i]);
                            }
                        }
                        v
                    }
                }
            };
            f.durable = persisted.clone();
            f.volatile = persisted;
            f.dirent_durable = true;
        }
        self.crashed = false;
        self.crash_at = None;
        self.ops = 0;
    }
    /// Direct access for corruption tests (bypasses the fault model).
    pub fn raw_mut(&mut self, name: &str) -> Option<&mut Vec<u8>> {
        self.files.get_mut(name).map(|f| {
            f.dirent_durable = true;
            &mut f.volatile
        })
    }
    pub fn raw_commit(&mut self, name: &str) {
        if let Some(f) = self.files.get_mut(name) {
            f.durable = f.volatile.clone();
        }
    }
    pub fn insert_raw(&mut self, name: &str, data: Vec<u8>) {
        self.files.insert(name.into(), MemFile { durable: data.clone(), volatile: data, dirent_durable: true, removed_volatile: false });
    }
}

impl Default for MemStorage {
    fn default() -> Self {
        Self::new()
    }
}

impl Storage for MemStorage {
    fn exists(&self, name: &str) -> Result<bool> {
        Ok(self.files.get(name).map(|f| !f.removed_volatile).unwrap_or(false))
    }
    fn len(&self, name: &str) -> Result<Option<u64>> {
        Ok(self.files.get(name).filter(|f| !f.removed_volatile).map(|f| f.volatile.len() as u64))
    }
    fn read_all(&self, name: &str) -> Result<Option<Vec<u8>>> {
        Ok(self.files.get(name).filter(|f| !f.removed_volatile).map(|f| f.volatile.clone()))
    }
    fn read_at(&self, name: &str, off: u64, len: usize) -> Result<Vec<u8>> {
        let f = self.files.get(name).filter(|f| !f.removed_volatile).ok_or_else(|| Error::MissingFile(name.into()))?;
        let off = off as usize;
        if off + len > f.volatile.len() {
            return Err(Error::Io(format!("short read in {name}")));
        }
        Ok(f.volatile[off..off + len].to_vec())
    }
    fn create_new(&mut self, name: &str) -> Result<()> {
        self.tick("create")?;
        if self.files.get(name).map(|f| !f.removed_volatile).unwrap_or(false) {
            return Err(Error::Exists(name.into()));
        }
        self.files.insert(name.into(), MemFile { durable: vec![], volatile: vec![], dirent_durable: false, removed_volatile: false });
        Ok(())
    }
    fn append(&mut self, name: &str, data: &[u8]) -> Result<()> {
        self.tick("append")?;
        let f = self.files.get_mut(name).ok_or_else(|| Error::MissingFile(name.into()))?;
        f.volatile.extend_from_slice(data);
        Ok(())
    }
    fn write_replace(&mut self, name: &str, data: &[u8]) -> Result<()> {
        self.tick("write_replace")?;
        match self.files.get_mut(name) {
            Some(f) => {
                f.volatile = data.to_vec();
                f.removed_volatile = false;
            }
            None => {
                self.files.insert(name.into(), MemFile { durable: vec![], volatile: data.to_vec(), dirent_durable: false, removed_volatile: false });
            }
        }
        Ok(())
    }
    fn truncate(&mut self, name: &str, len: u64) -> Result<()> {
        self.tick("truncate")?;
        let f = self.files.get_mut(name).ok_or_else(|| Error::MissingFile(name.into()))?;
        f.volatile.truncate(len as usize);
        Ok(())
    }
    fn sync(&mut self, name: &str) -> Result<()> {
        self.tick("sync")?;
        let f = self.files.get_mut(name).ok_or_else(|| Error::MissingFile(name.into()))?;
        f.durable = f.volatile.clone();
        Ok(())
    }
    fn sync_dir(&mut self) -> Result<()> {
        self.tick("sync_dir")?;
        let mut gone = vec![];
        for (n, f) in self.files.iter_mut() {
            f.dirent_durable = true;
            if f.removed_volatile {
                gone.push(n.clone());
            }
        }
        for n in gone {
            self.files.remove(&n);
        }
        Ok(())
    }
    fn remove(&mut self, name: &str) -> Result<()> {
        self.tick("remove")?;
        let f = self.files.get_mut(name).ok_or_else(|| Error::MissingFile(name.into()))?;
        f.removed_volatile = true;
        Ok(())
    }
    fn list(&self) -> Result<Vec<String>> {
        let mut v: Vec<String> = self.files.iter().filter(|(_, f)| !f.removed_volatile).map(|(n, _)| n.clone()).collect();
        v.sort();
        Ok(v)
    }
    fn dir_sync_verified(&self) -> bool {
        self.verified_dir_sync
    }
}
