//! vault-core: shared encrypted-vault core (draft v0; the on-disk format is not frozen until the M4g review gate).
pub mod codec;
pub mod crypto;
pub mod error;
pub mod journal;
pub mod layout;
pub mod ops;
pub mod recovery;
pub mod storage;
pub mod vault;

pub use error::{Error, Result};
pub use storage::{DiskStorage, Loss, MemStorage, Storage};
pub use vault::{Durability, Editor, Entry, SlotKind, Vault, VersionInfo};
