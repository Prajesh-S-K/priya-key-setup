//! The vault: header with key-wrap slots, chunked encrypted file data, journaled metadata.
use crate::codec::{Reader, Writer};
use crate::crypto::{self, Key, VaultKeys, NONCE_LEN, TAG_LEN};
use crate::error::{Error, Result};
use crate::journal::Journal;
use crate::ops::*;
use crate::storage::Storage;
use std::collections::BTreeMap;

const HDR_MAGIC: &[u8; 4] = b"GPV1";
const HDR_A: &str = "vault.hdr.A";
const HDR_B: &str = "vault.hdr.B";
const JOURNAL: &str = "journal-000000.log";
const DATA: &str = "data-000000.seg";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SlotKind {
    Board = 1,
    /// Symmetric recovery slot (tests and simple setups).
    Recovery = 2,
    /// Recovery by public key (HPKE): the recovery secret is an offline private key.
    RecoveryPk = 3,
}

#[derive(Clone, Debug)]
struct Slot {
    kind: u8,
    id: [u8; 16],
    enc: Vec<u8>,
    nonce: [u8; NONCE_LEN],
    ct: Vec<u8>,
}

#[derive(Clone, Debug)]
struct Header {
    vault_id: [u8; 16],
    generation: u64,
    slots: Vec<Slot>,
}

fn wrap_aad(vault_id: &[u8; 16], kind: u8, id: &[u8; 16]) -> Vec<u8> {
    let mut a = b"gp-wrap-v1".to_vec();
    a.extend_from_slice(vault_id);
    a.push(kind);
    a.extend_from_slice(id);
    a
}

fn encode_header(h: &Header, keys: &VaultKeys) -> Vec<u8> {
    let mut w = Writer::new();
    w.raw(HDR_MAGIC).u16(2).raw(&h.vault_id).u64(h.generation).u8(h.slots.len() as u8);
    for s in &h.slots {
        w.u8(s.kind).raw(&s.id).u8(s.enc.len() as u8).raw(&s.enc).raw(&s.nonce).u8(s.ct.len() as u8).raw(&s.ct);
    }
    let mac = crypto::hmac16(&keys.hdr, &w.0);
    w.raw(&mac);
    w.0
}

fn parse_header(b: &[u8]) -> Result<(Header, usize)> {
    let mut r = Reader::new(b);
    if r.take(4)? != HDR_MAGIC || r.u16()? != 2 {
        return Err(Error::Corrupt("bad vault header".into()));
    }
    let vault_id = r.arr::<16>()?;
    let generation = r.u64()?;
    let n = r.u8()? as usize;
    let mut slots = vec![];
    for _ in 0..n {
        let kind = r.u8()?;
        let id = r.arr::<16>()?;
        let el = r.u8()? as usize;
        let enc = r.take(el)?.to_vec();
        let nonce = r.arr::<NONCE_LEN>()?;
        let cl = r.u8()? as usize;
        slots.push(Slot { kind, id, enc, nonce, ct: r.take(cl)?.to_vec() });
    }
    Ok((Header { vault_id, generation, slots }, r.pos))
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Entry {
    pub name: String,
    pub is_dir: bool,
    pub size: u64,
    pub mtime: u64,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct VersionInfo {
    pub index: usize,
    pub gen: u64,
    pub size: u64,
    pub mtime: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Durability {
    /// Directory-entry durability verified on this backend: acknowledged saves may be claimed to survive power loss.
    Verified,
    /// Not verified: saves are flushed best-effort; the product must not claim they survive power loss.
    Unverified,
}

pub struct Vault<S: Storage> {
    storage: S,
    vault_id: [u8; 16],
    keys: VaultKeys,
    header: Header,
    journal: Journal,
    state: State,
    data_len: u64,
    poisoned: bool,
}

pub fn norm_path(p: &str) -> Result<String> {
    if p.is_empty() || p.len() > 1024 || p.contains('\0') {
        return Err(Error::InvalidArgument("invalid path".into()));
    }
    let comps: Vec<&str> = p.trim_matches('/').split('/').collect();
    if comps.iter().any(|c| c.is_empty() || *c == "." || *c == "..") {
        return Err(Error::InvalidArgument(format!("invalid path component in {p:?}")));
    }
    Ok(comps.join("/"))
}

fn parents(path: &str) -> Vec<String> {
    let parts: Vec<&str> = path.split('/').collect();
    (1..parts.len()).map(|i| parts[..i].join("/")).collect()
}

pub struct Editor {
    path: String,
    file_id: FileId,
    is_new: bool,
    base: Option<Root>,
    size: u64,
    dirty: BTreeMap<u32, Vec<u8>>, // idx -> CHUNK_SIZE bytes (zero padded)
}

impl Editor {
    pub fn size(&self) -> u64 {
        self.size
    }
    pub fn path(&self) -> &str {
        &self.path
    }
    /// Bytes of decrypted/modified chunk data held in memory for this editor.
    pub fn dirty_bytes(&self) -> usize {
        self.dirty.len() * CHUNK_SIZE
    }
}

impl<S: Storage> Vault<S> {
    // ------------------------------------------------------------------ create / open
    pub fn create(storage: S, slots: &[(SlotKind, Key)]) -> Result<Vault<S>> {
        Self::create_with_id(storage, crypto::random(), slots)
    }

    /// Create a vault with a chosen id, so the board KEK (which depends on the vault id) can be requested first.
    pub fn create_with_id(storage: S, vault_id: [u8; 16], slots: &[(SlotKind, Key)]) -> Result<Vault<S>> {
        Self::create_full(storage, vault_id, slots, None)
    }

    /// As `create_with_id`, plus an optional recovery public key (HPKE slot; the secret stays offline).
    pub fn create_full(mut storage: S, vault_id: [u8; 16], slots: &[(SlotKind, Key)], recovery_pk: Option<[u8; 32]>) -> Result<Vault<S>> {
        if slots.is_empty() {
            return Err(Error::InvalidArgument("a vault needs at least one key slot".into()));
        }
        if storage.exists(HDR_A)? || storage.exists(HDR_B)? {
            return Err(Error::Exists("vault header".into()));
        }
        let vk: Key = crypto::random();
        let keys = VaultKeys::derive(vk, &vault_id);
        // Data and journal first, the header last: a vault exists only once its header is durable.
        storage.create_new(DATA)?;
        storage.sync(DATA)?;
        storage.sync_dir()?;
        let journal = Journal::create(&mut storage, JOURNAL, vault_id, &keys)?;
        let mut hslots = vec![];
        for (kind, kek) in slots {
            hslots.push(make_slot(&vault_id, *kind as u8, kek, &keys.vk));
        }
        if let Some(pk) = recovery_pk {
            hslots.push(make_pk_slot(&vault_id, &pk, &keys.vk)?);
        }
        let header = Header { vault_id, generation: 1, slots: hslots };
        storage.write_replace(HDR_A, &encode_header(&header, &keys))?;
        storage.sync(HDR_A)?;
        storage.sync_dir()?;
        Ok(Vault { storage, vault_id, keys, header, journal, state: State::default(), data_len: 0, poisoned: false })
    }

    pub fn open(storage: S, kek: &Key) -> Result<Vault<S>> {
        Self::open_with(storage, &|h: &Header, s: &Slot| {
            crypto::open(kek, &s.nonce, &wrap_aad(&h.vault_id, s.kind, &s.id), &s.ct).ok()
        })
    }

    /// The vault id from the (unauthenticated) header, without opening the vault.
    pub fn peek_id(storage: &mut S) -> Result<[u8; 16]> {
        for name in [HDR_A, HDR_B] {
            if let Some(bytes) = storage.read_all(name)? {
                if let Ok((h, _)) = parse_header(&bytes) {
                    return Ok(h.vault_id);
                }
            }
        }
        Err(Error::Corrupt("no readable vault header".into()))
    }

    /// Open with the offline recovery secret (private key).
    pub fn open_with_recovery_secret(storage: S, secret: &[u8; 32]) -> Result<Vault<S>> {
        Self::open_with(storage, &|h: &Header, s: &Slot| {
            if s.kind != SlotKind::RecoveryPk as u8 {
                return None;
            }
            crate::recovery::open_vk(secret, &h.vault_id, &wrap_aad(&h.vault_id, s.kind, &s.id), &s.enc, &s.ct).ok().map(|k| k.to_vec())
        })
    }

    fn open_with(mut storage: S, unwrap: &dyn Fn(&Header, &Slot) -> Option<Vec<u8>>) -> Result<Vault<S>> {
        let mut best: Option<(Header, VaultKeys)> = None;
        let mut saw_header = false;
        for name in [HDR_A, HDR_B] {
            let Some(bytes) = storage.read_all(name)? else { continue };
            let Ok((h, used)) = parse_header(&bytes) else { continue };
            saw_header = true;
            let mut keys = None;
            for s in &h.slots {
                if let Some(vk) = unwrap(&h, s) {
                    if vk.len() == 32 {
                        let mut k = [0u8; 32];
                        k.copy_from_slice(&vk);
                        keys = Some(VaultKeys::derive(k, &h.vault_id));
                        break;
                    }
                }
            }
            let Some(keys) = keys else { continue };
            // header MAC covers everything before it
            if bytes.len() < used + 16 || !crypto::ct_eq(&crypto::hmac16(&keys.hdr, &bytes[..used]), &bytes[used..used + 16]) {
                continue;
            }
            if best.as_ref().map(|(b, _)| h.generation > b.generation).unwrap_or(true) {
                best = Some((h, keys));
            }
        }
        let Some((header, keys)) = best else {
            return Err(if saw_header { Error::BadKey } else { Error::Corrupt("no valid vault header".into()) });
        };
        let vault_id = header.vault_id;
        let (journal, txs) = Journal::open(&mut storage, JOURNAL, vault_id, &keys)?;
        let mut state = State::default();
        for blob in &txs {
            for op in decode_ops(blob)? {
                state.apply(&op);
            }
        }
        let data_len = storage.len(DATA)?.ok_or_else(|| Error::MissingFile(DATA.into()))?;
        // P2: only references that are live in the final state must exist.
        for r in state.live_refs() {
            if r.off + r.record_len() > data_len {
                return Err(Error::MissingFile(format!("{DATA}: committed chunk at {} is beyond the end of the data segment", r.off)));
            }
        }
        Ok(Vault { storage, vault_id, keys, header, journal, state, data_len, poisoned: false })
    }

    #[doc(hidden)]
    pub fn test_set_max_record(&mut self, n: usize) {
        self.journal.set_max_plaintext(n);
    }
    pub fn vault_id(&self) -> [u8; 16] {
        self.vault_id
    }
    pub fn recovered_torn_tail(&self) -> bool {
        self.journal.recovered
    }
    pub fn read_only_reason(&self) -> Option<String> {
        self.journal.read_only.clone()
    }
    pub fn durability(&self) -> Durability {
        if self.storage.dir_sync_verified() {
            Durability::Verified
        } else {
            Durability::Unverified
        }
    }
    pub fn into_storage(self) -> S {
        self.storage
    }
    pub fn storage(&self) -> &S {
        &self.storage
    }

    // ------------------------------------------------------------------ key slots (PIN change needs none; recovery/board replacement do)
    /// Replace all slots of one kind (e.g. new recovery secret, or a replacement board). Needs the vault open.
    pub fn replace_slot(&mut self, kind: SlotKind, new_kek: &Key) -> Result<()> {
        let slot = make_slot(&self.vault_id, kind as u8, new_kek, &self.keys.vk);
        self.rewrite_header(|h| {
            h.slots.retain(|s| s.kind != kind as u8);
            h.slots.push(slot.clone());
        })
    }

    fn rewrite_header(&mut self, f: impl FnOnce(&mut Header)) -> Result<()> {
        let mut h = self.header.clone();
        f(&mut h);
        h.generation += 1;
        let target = if h.generation % 2 == 1 { HDR_A } else { HDR_B };
        let bytes = encode_header(&h, &self.keys);
        self.storage.write_replace(target, &bytes)?;
        self.storage.sync(target)?;
        self.storage.sync_dir()?;
        // Overwrite the other copy too, so no stale key slot (e.g. an old recovery secret) stays in this vault directory.
        // A crash between the two writes leaves the old copy, which is the documented historical-copy limit.
        let other = if target == HDR_A { HDR_B } else { HDR_A };
        self.storage.write_replace(other, &bytes)?;
        self.storage.sync(other)?;
        self.storage.sync_dir()?;
        self.header = h;
        Ok(())
    }

    /// Replace the recovery public-key slot (new recovery secret).
    pub fn replace_recovery_pk(&mut self, pk: &[u8; 32]) -> Result<()> {
        let slot = make_pk_slot(&self.vault_id, pk, &self.keys.vk)?;
        self.rewrite_header(|h| {
            h.slots.retain(|s| s.kind != SlotKind::RecoveryPk as u8);
            h.slots.push(slot.clone());
        })
    }

    // ------------------------------------------------------------------ queries
    pub fn exists(&self, path: &str) -> Result<bool> {
        let p = norm_path(path)?;
        Ok(self.state.names.contains_key(&p) || self.state.dirs.contains(&p))
    }

    pub fn stat(&self, path: &str) -> Result<Entry> {
        let p = norm_path(path)?;
        if let Some(fid) = self.state.names.get(&p) {
            let r = self.state.files[fid].current.as_ref().ok_or_else(|| Error::Corrupt("linked file without root".into()))?;
            return Ok(Entry { name: p.rsplit('/').next().unwrap().into(), is_dir: false, size: r.size, mtime: r.mtime });
        }
        if self.state.dirs.contains(&p) {
            return Ok(Entry { name: p.rsplit('/').next().unwrap().into(), is_dir: true, size: 0, mtime: 0 });
        }
        Err(Error::NotFound(p))
    }

    /// List the direct children of a directory ("" = root).
    pub fn list(&self, dir: &str) -> Result<Vec<Entry>> {
        let d = if dir.is_empty() { String::new() } else { norm_path(dir)? };
        if !d.is_empty() && !self.state.dirs.contains(&d) {
            return Err(Error::NotFound(d));
        }
        let prefix = if d.is_empty() { String::new() } else { format!("{d}/") };
        let mut out = vec![];
        for (name, fid) in &self.state.names {
            if let Some(rest) = name.strip_prefix(&prefix) {
                if !rest.contains('/') {
                    let r = self.state.files[fid].current.as_ref().unwrap();
                    out.push(Entry { name: rest.into(), is_dir: false, size: r.size, mtime: r.mtime });
                }
            }
        }
        for dd in &self.state.dirs {
            if let Some(rest) = dd.strip_prefix(&prefix) {
                if !rest.contains('/') && !rest.is_empty() {
                    out.push(Entry { name: rest.into(), is_dir: true, size: 0, mtime: 0 });
                }
            }
        }
        out.sort_by(|a, b| a.name.cmp(&b.name));
        Ok(out)
    }

    pub fn all_files(&self) -> Vec<String> {
        self.state.names.keys().cloned().collect()
    }

    pub fn read_file(&self, path: &str) -> Result<Vec<u8>> {
        let e = self.stat(path)?;
        self.read_range(path, 0, e.size as usize)
    }

    pub fn read_range(&self, path: &str, off: u64, len: usize) -> Result<Vec<u8>> {
        let p = norm_path(path)?;
        let fid = *self.state.names.get(&p).ok_or_else(|| Error::NotFound(p.clone()))?;
        let root = self.state.files[&fid].current.as_ref().ok_or_else(|| Error::Corrupt("no root".into()))?;
        self.read_root(&fid, root, off, len)
    }

    fn read_root(&self, fid: &FileId, root: &Root, off: u64, len: usize) -> Result<Vec<u8>> {
        if off >= root.size {
            return Ok(vec![]);
        }
        let end = (off + len as u64).min(root.size);
        let mut out = Vec::with_capacity((end - off) as usize);
        let mut pos = off;
        while pos < end {
            let idx = (pos / CHUNK_SIZE as u64) as usize;
            let in_chunk = (pos % CHUNK_SIZE as u64) as usize;
            let take = ((CHUNK_SIZE - in_chunk) as u64).min(end - pos) as usize;
            let chunk = self.load_chunk(fid, root, idx)?;
            out.extend_from_slice(&chunk[in_chunk..in_chunk + take]);
            pos += take as u64;
        }
        Ok(out)
    }

    /// Decrypts chunk `idx` of `root`, zero padded to CHUNK_SIZE.
    fn load_chunk(&self, fid: &FileId, root: &Root, idx: usize) -> Result<Vec<u8>> {
        let mut buf = vec![0u8; CHUNK_SIZE];
        if let Some(r) = root.chunks.get(idx) {
            let rec = self.storage.read_at(DATA, r.off, r.record_len() as usize)?;
            let nonce: [u8; NONCE_LEN] = rec[..NONCE_LEN].try_into().unwrap();
            let ct = &rec[NONCE_LEN..];
            if ct[ct.len() - TAG_LEN..] != r.tag {
                return Err(Error::Corrupt("chunk tag does not match the file root (substituted chunk)".into()));
            }
            let pt = crypto::open(&self.keys.file_key(&self.vault_id, fid), &nonce, &self.chunk_aad(fid, idx as u32, r.plain_len), ct)?;
            buf[..pt.len()].copy_from_slice(&pt);
        }
        Ok(buf)
    }

    fn chunk_aad(&self, fid: &FileId, idx: u32, plain_len: u32) -> Vec<u8> {
        let mut a = b"gp-chunk-v1".to_vec();
        a.extend_from_slice(&self.vault_id);
        a.extend_from_slice(fid);
        a.extend_from_slice(&idx.to_le_bytes());
        a.extend_from_slice(&plain_len.to_le_bytes());
        a
    }

    // ------------------------------------------------------------------ commit plumbing
    fn check_writable(&self) -> Result<()> {
        if self.poisoned {
            return Err(Error::ReadOnly("an earlier storage failure poisoned this session; reopen the vault to recover".into()));
        }
        if let Some(r) = &self.journal.read_only {
            return Err(Error::ReadOnly(r.clone()));
        }
        Ok(())
    }

    /// Data first (flushed), then the journal commit (flushed). Nothing is visible until the commit record is durable.
    fn commit(&mut self, new_chunks: Vec<u8>, ops: Vec<Op>) -> Result<()> {
        self.check_writable()?;
        let r = (|| -> Result<()> {
            if !new_chunks.is_empty() {
                self.storage.append(DATA, &new_chunks)?;
                self.storage.sync(DATA)?;
            }
            self.journal.commit(&mut self.storage, &encode_ops(&ops))
        })();
        match r {
            Ok(()) => {
                self.data_len += new_chunks.len() as u64;
                for op in &ops {
                    self.state.apply(op);
                }
                Ok(())
            }
            Err(e) => {
                self.poisoned = true;
                Err(e)
            }
        }
    }

    fn seal_chunk(&self, fid: &FileId, idx: u32, plain: &[u8], out: &mut Vec<u8>, base_off: u64) -> ChunkRef {
        let nonce: [u8; NONCE_LEN] = crypto::random();
        let ct = crypto::seal(&self.keys.file_key(&self.vault_id, fid), &nonce, &self.chunk_aad(fid, idx, plain.len() as u32), plain);
        let off = base_off + out.len() as u64;
        out.extend_from_slice(&nonce);
        out.extend_from_slice(&ct);
        let mut tag = [0u8; 16];
        tag.copy_from_slice(&ct[ct.len() - TAG_LEN..]);
        ChunkRef { off, plain_len: plain.len() as u32, tag }
    }

    // ------------------------------------------------------------------ namespace operations
    pub fn mkdir(&mut self, path: &str) -> Result<()> {
        let p = norm_path(path)?;
        if self.state.names.contains_key(&p) {
            return Err(Error::Exists(p));
        }
        let mut ops = vec![];
        for d in parents(&p).into_iter().chain(std::iter::once(p.clone())) {
            if self.state.names.contains_key(&d) {
                return Err(Error::InvalidArgument(format!("{d} is a file")));
            }
            if !self.state.dirs.contains(&d) {
                ops.push(Op::Mkdir { path: d });
            }
        }
        if ops.is_empty() {
            return Ok(());
        }
        self.commit(vec![], ops)
    }

    pub fn rmdir(&mut self, path: &str) -> Result<()> {
        let p = norm_path(path)?;
        if !self.state.dirs.contains(&p) {
            return Err(Error::NotFound(p));
        }
        let prefix = format!("{p}/");
        if self.state.names.keys().any(|k| k.starts_with(&prefix)) || self.state.dirs.iter().any(|d| d.starts_with(&prefix)) {
            return Err(Error::InvalidArgument("directory not empty".into()));
        }
        self.commit(vec![], vec![Op::Rmdir { path: p }])
    }

    pub fn delete(&mut self, path: &str) -> Result<()> {
        let p = norm_path(path)?;
        if !self.state.names.contains_key(&p) {
            return Err(Error::NotFound(p));
        }
        self.commit(vec![], vec![Op::Unlink { path: p }])
    }

    /// Atomic rename (one journal record). Replaces an existing file at `to`; the replaced file is tombstoned.
    pub fn rename(&mut self, from: &str, to: &str) -> Result<()> {
        let (f, t) = (norm_path(from)?, norm_path(to)?);
        let is_file = self.state.names.contains_key(&f);
        let is_dir = self.state.dirs.contains(&f);
        if !is_file && !is_dir {
            return Err(Error::NotFound(f));
        }
        if t == f || t.starts_with(&format!("{f}/")) {
            return Err(Error::InvalidArgument("cannot rename onto itself".into()));
        }
        if self.state.dirs.contains(&t) || (is_dir && self.state.names.contains_key(&t)) {
            return Err(Error::Exists(t));
        }
        let mut ops = vec![];
        for d in parents(&t) {
            if self.state.names.contains_key(&d) {
                return Err(Error::InvalidArgument(format!("{d} is a file")));
            }
            if !self.state.dirs.contains(&d) {
                ops.push(Op::Mkdir { path: d });
            }
        }
        ops.push(Op::Rename { from: f, to: t });
        self.commit(vec![], ops)
    }

    // ------------------------------------------------------------------ file editing (random access)
    /// Open a file for editing. `create`: allow a new file. `truncate`: start empty (open-mode truncation is staged;
    /// the committed version is untouched until `commit_editor`).
    pub fn edit(&self, path: &str, create: bool, truncate: bool) -> Result<Editor> {
        let p = norm_path(path)?;
        if self.state.dirs.contains(&p) {
            return Err(Error::InvalidArgument("is a directory".into()));
        }
        match self.state.names.get(&p) {
            Some(fid) => {
                let base = self.state.files[fid].current.clone();
                let size = if truncate { 0 } else { base.as_ref().map(|r| r.size).unwrap_or(0) };
                Ok(Editor { path: p, file_id: *fid, is_new: false, base: if truncate { None } else { base }, size, dirty: BTreeMap::new() })
            }
            None if create => {
                for d in parents(&p) {
                    if self.state.names.contains_key(&d) {
                        return Err(Error::InvalidArgument(format!("{d} is a file")));
                    }
                }
                Ok(Editor { path: p, file_id: crypto::random(), is_new: true, base: None, size: 0, dirty: BTreeMap::new() })
            }
            None => Err(Error::NotFound(p)),
        }
    }

    fn editor_chunk(&self, e: &Editor, idx: u32) -> Result<Vec<u8>> {
        if let Some(d) = e.dirty.get(&idx) {
            return Ok(d.clone());
        }
        match &e.base {
            Some(b) => self.load_chunk(&e.file_id, b, idx as usize),
            None => Ok(vec![0u8; CHUNK_SIZE]),
        }
    }

    pub fn editor_read(&self, e: &Editor, off: u64, len: usize) -> Result<Vec<u8>> {
        if off >= e.size {
            return Ok(vec![]);
        }
        let end = (off + len as u64).min(e.size);
        let mut out = Vec::with_capacity((end - off) as usize);
        let mut pos = off;
        while pos < end {
            let idx = (pos / CHUNK_SIZE as u64) as u32;
            let in_chunk = (pos % CHUNK_SIZE as u64) as usize;
            let take = ((CHUNK_SIZE - in_chunk) as u64).min(end - pos) as usize;
            let c = self.editor_chunk(e, idx)?;
            out.extend_from_slice(&c[in_chunk..in_chunk + take]);
            pos += take as u64;
        }
        Ok(out)
    }

    pub fn editor_write(&self, e: &mut Editor, off: u64, data: &[u8]) -> Result<()> {
        let mut pos = off;
        let mut rest = data;
        while !rest.is_empty() {
            let idx = (pos / CHUNK_SIZE as u64) as u32;
            let in_chunk = (pos % CHUNK_SIZE as u64) as usize;
            let take = (CHUNK_SIZE - in_chunk).min(rest.len());
            if !e.dirty.contains_key(&idx) {
                let c = self.editor_chunk(e, idx)?;
                e.dirty.insert(idx, c);
            }
            e.dirty.get_mut(&idx).unwrap()[in_chunk..in_chunk + take].copy_from_slice(&rest[..take]);
            pos += take as u64;
            rest = &rest[take..];
        }
        e.size = e.size.max(off + data.len() as u64);
        Ok(())
    }

    /// Set the length (truncate or zero-extend). Bytes beyond a shrunk length read as zero if the file grows again.
    pub fn editor_set_len(&self, e: &mut Editor, new_len: u64) -> Result<()> {
        if new_len < e.size {
            let keep_chunks = new_len.div_ceil(CHUNK_SIZE as u64) as u32;
            e.dirty.retain(|idx, _| *idx < keep_chunks);
            if let Some(b) = &mut e.base {
                b.chunks.truncate(keep_chunks as usize);
            }
            let rem = (new_len % CHUNK_SIZE as u64) as usize;
            if rem != 0 {
                let idx = (new_len / CHUNK_SIZE as u64) as u32;
                let mut c = self.editor_chunk(e, idx)?;
                c[rem..].iter_mut().for_each(|b| *b = 0);
                e.dirty.insert(idx, c);
            }
        }
        e.size = new_len;
        Ok(())
    }

    /// Seal the dirty chunks and commit the new root atomically (one journal commit). The previous root is kept in
    /// the version store, so a failure or crash at any point leaves the last committed version intact.
    pub fn commit_editor(&mut self, e: Editor, mtime: u64) -> Result<()> {
        self.check_writable()?;
        if e.is_new && self.state.names.contains_key(&e.path) {
            return Err(Error::Exists(e.path));
        }
        if !e.is_new && self.state.names.get(&e.path) != Some(&e.file_id) {
            return Err(Error::NotFound(format!("{} changed while it was open", e.path)));
        }
        let nchunks = e.size.div_ceil(CHUNK_SIZE as u64) as usize;
        let mut buf = Vec::new();
        let mut refs = Vec::with_capacity(nchunks);
        for idx in 0..nchunks {
            let expected = ((e.size - (idx * CHUNK_SIZE) as u64) as usize).min(CHUNK_SIZE);
            let base_ref = e.base.as_ref().and_then(|b| b.chunks.get(idx));
            if let (Some(r), false) = (base_ref, e.dirty.contains_key(&(idx as u32))) {
                if r.plain_len as usize == expected {
                    refs.push(r.clone());
                    continue;
                }
            }
            let mut plain = self.editor_chunk(&e, idx as u32)?;
            plain.truncate(expected);
            refs.push(self.seal_chunk(&e.file_id, idx as u32, &plain, &mut buf, self.data_len));
        }
        let gen = self.state.files.get(&e.file_id).and_then(|f| f.current.as_ref()).map(|r| r.gen + 1).unwrap_or(1);
        let mut ops = vec![];
        if e.is_new {
            for d in parents(&e.path) {
                if !self.state.dirs.contains(&d) {
                    ops.push(Op::Mkdir { path: d });
                }
            }
        }
        ops.push(Op::Root { file_id: e.file_id, root: Root { gen, size: e.size, mtime, chunks: refs } });
        if e.is_new {
            ops.push(Op::Link { path: e.path.clone(), file_id: e.file_id });
        }
        self.commit(buf, ops)
    }

    /// Convenience: create or replace a whole file.
    pub fn put_file(&mut self, path: &str, data: &[u8], mtime: u64) -> Result<()> {
        let mut e = self.edit(path, true, true)?;
        self.editor_write(&mut e, 0, data)?;
        self.commit_editor(e, mtime)
    }

    // ------------------------------------------------------------------ versions and tombstones
    pub fn versions(&self, path: &str) -> Result<Vec<VersionInfo>> {
        let p = norm_path(path)?;
        let fid = self.state.names.get(&p).ok_or_else(|| Error::NotFound(p.clone()))?;
        Ok(self.state.files[fid].versions.iter().enumerate().map(|(i, r)| VersionInfo { index: i, gen: r.gen, size: r.size, mtime: r.mtime }).collect())
    }

    pub fn read_version(&self, path: &str, index: usize) -> Result<Vec<u8>> {
        let p = norm_path(path)?;
        let fid = *self.state.names.get(&p).ok_or_else(|| Error::NotFound(p.clone()))?;
        let root = self.state.files[&fid].versions.get(index).ok_or_else(|| Error::NotFound("version".into()))?.clone();
        self.read_root(&fid, &root, 0, root.size as usize)
    }

    pub fn restore_version(&mut self, path: &str, index: usize, mtime: u64) -> Result<()> {
        let p = norm_path(path)?;
        let fid = *self.state.names.get(&p).ok_or_else(|| Error::NotFound(p.clone()))?;
        let fs = &self.state.files[&fid];
        let old = fs.versions.get(index).ok_or_else(|| Error::NotFound("version".into()))?.clone();
        let gen = fs.current.as_ref().map(|r| r.gen + 1).unwrap_or(1);
        self.commit(vec![], vec![Op::Root { file_id: fid, root: Root { gen, size: old.size, mtime, chunks: old.chunks } }])
    }

    /// Files that were deleted or replaced and are still recoverable: (file id, last path, size).
    pub fn tombstones(&self) -> Vec<(FileId, String, u64)> {
        let mut v: Vec<_> = self
            .state
            .files
            .iter()
            .filter_map(|(id, f)| f.tombstone_path.clone().map(|p| (*id, p, f.current.as_ref().map(|r| r.size).unwrap_or(0))))
            .collect();
        v.sort();
        v
    }

    pub fn read_tombstone(&self, id: &FileId) -> Result<Vec<u8>> {
        let f = self.state.files.get(id).filter(|f| f.tombstone_path.is_some()).ok_or_else(|| Error::NotFound("tombstone".into()))?;
        let r = f.current.as_ref().ok_or_else(|| Error::Corrupt("no root".into()))?;
        self.read_root(id, r, 0, r.size as usize)
    }

    pub fn undelete(&mut self, id: &FileId, to: &str) -> Result<()> {
        let p = norm_path(to)?;
        if self.state.names.contains_key(&p) || self.state.dirs.contains(&p) {
            return Err(Error::Exists(p));
        }
        let f = self.state.files.get(id).filter(|f| f.tombstone_path.is_some()).ok_or_else(|| Error::NotFound("tombstone".into()))?;
        let _ = f;
        let mut ops = vec![];
        for d in parents(&p) {
            if !self.state.dirs.contains(&d) {
                ops.push(Op::Mkdir { path: d });
            }
        }
        ops.push(Op::Link { path: p, file_id: *id });
        self.commit(vec![], ops)
    }

    /// Verify every live chunk authenticates (used after import and in tests).
    pub fn verify_all(&self) -> Result<u64> {
        let mut n = 0;
        for (fid, f) in &self.state.files {
            for root in f.current.iter().chain(f.versions.iter()) {
                for idx in 0..root.chunks.len() {
                    self.load_chunk(fid, root, idx)?;
                    n += 1;
                }
            }
        }
        Ok(n)
    }
}

fn make_slot(vault_id: &[u8; 16], kind: u8, kek: &Key, vk: &Key) -> Slot {
    let id: [u8; 16] = crypto::random();
    let nonce: [u8; NONCE_LEN] = crypto::random();
    let ct = crypto::seal(kek, &nonce, &wrap_aad(vault_id, kind, &id), vk);
    Slot { kind, id, enc: vec![], nonce, ct }
}

fn make_pk_slot(vault_id: &[u8; 16], pk: &[u8; 32], vk: &Key) -> Result<Slot> {
    let id: [u8; 16] = crypto::random();
    let (enc, ct) = crate::recovery::seal_vk(pk, vault_id, &wrap_aad(vault_id, SlotKind::RecoveryPk as u8, &id), vk)?;
    Ok(Slot { kind: SlotKind::RecoveryPk as u8, id, enc, nonce: [0u8; NONCE_LEN], ct })
}
