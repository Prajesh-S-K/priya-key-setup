# M2 result: security and encrypted storage (hardware-verified core)

Date: 2026-10-19. Disposable data only. No personal folder touched. No eFuse/secure-boot/flash-encryption change (eFuse summary re-read after the tests: unchanged).

## What works (evidence)
**Device firmware `firmware/gpkey` (flashed, 170,832 bytes)**: Noise_NK/NX sessions (vendored noise-c, minimal build), PIN setup/change, write-ahead persistent attempt counter with delays, KEK release, heartbeat lock, physical privacy toggle (GPIO0), pairing ceremony. Never erases NVS; INCONSISTENT/FAIL_CLOSED states.

**Verified on the real board (Mac, `host/target/release/gpkey`):**
- First-use provisioning with a physical BOOT press, NX key reveal, PIN set, NK+AUTH verification, confirm.
- Wrong PIN counted; 3 free failures then 5 s delay; delay and counter survive a board reset (delay restarts from boot); success resets the counter.
- Device-released vault key opened a vault in a new session (vault created and reopened with the device KEK).
- Privacy toggle: first BOOT press delivered an authenticated LOCK notice, privileged commands and new sessions were refused; second press restored service and required the PIN; same vault key after re-authentication.
- Heartbeat loss (4.2 s silent) locked the session; PIN change and restore worked.

**Host/protocol interop (real device core compiled for the host, 9 tests):** snow (host) <-> noise-c (device) for NK and NX; provisioning interrupted by power loss at both commit points leaves EMPTY; missing/corrupt/unreadable storage -> INCONSISTENT and nothing erased or invented; storage write failures fail closed with no key release; pairing recovery (pending record case, PAIR ceremony reveals the same key, one-use, 30 s expiry).

**Vault core `host/vault-core` (16 tests):** XChaCha20-Poly1305 chunked storage, encrypted names/structure, authenticated journal with torn-tail recovery (every byte offset), incomplete transactions, interior deletion/duplication/reordering/cross-vault splice rejected, accepted-rollback case distinguished, a fault sweep that crashes at every storage operation of a save/edit/rename/delete scenario under three power-loss models (last committed version always survives, previous versions recoverable, vault usable afterwards), recovery-slot replacement, random-access editing against a model.

## Blockers / pending
- Durability claim: disk backend is *Unverified* (no power-pull test on Windows/Android); product must not claim saves survive power loss.
- USB-removal lock and automatic dashboard behavior: M3/M5 (host service). Windows/Android USB behavior still untested (no devices confirmed).
- RFC test vectors for the C HMAC/HKDF: to add in hardening (cross-checked indirectly: device KEK matches host expectation only via vault open).
- Android SDK licenses accepted by the owner; SDK install is the next step for M4.

## Next
M3: Windows application (WinFsp mount, import, editing, previews, locking). Needs a Windows machine for acceptance; Mac-side scaffolding continues.
