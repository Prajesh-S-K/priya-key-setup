# Pre-M1 readiness review

Date: 2026-10-19. Scope: documentation research, a read-only inventory of the dev Mac, and two design fixes. **Nothing was flashed, reset, installed, built or run against the board. The serial port was not opened. No vault code was written. No personal folder was touched.** Labels as in the [README](../README.md): DOC-VERIFIED, PROPOSED, DOC-NOT-YET-VERIFIED, RUNTIME-TEST.

## 1. Summary

- Both open design items are resolved on paper and sent to review: interrupted pairing (architecture §3.4 item 6) and checkpoint durability (architecture §5.5.5–5.5.6). The checkpoint fix exposed one necessary change: journal torn-tail recovery now truncates the existing file instead of creating a successor segment (§5.5.4).
- Reading the primary sources changed the entropy design. ESP-IDF v6.1 ships mbedTLS 4.1, whose DRBG is a private API, and its PSA random path calls the hardware RNG directly. The earlier "seeded CTR_DRBG" plan is replaced (architecture §3.3).
- noise-c supports the needed patterns and algorithms, but it has no embedded random source and needs a small port. It follows an older Noise spec revision than `snow`, so interoperability needs vector tests.
- The dev Mac already has a complete ESP-IDF v6.1 install, so firmware can be built with no installation. Rust, the Android SDK and JDK 17 are not installed; only 25 GB of disk is free (88% used).
- M1 can be prepared on the Mac without installing anything. Flashing needs your approval of the exact commands in section 8.

## 2. Resolved versus still open

| Item | Status | Where |
|---|---|---|
| Pairing: board accepted `PROV_CONFIRM`, link failed before the host saved its key | **Resolved (pending review).** Host writes a durable `pending_pairing` record (board public key and fingerprint, no secrets) before sending `PROV_CONFIRM`; restart verifies it with `NK` + `AUTH` and promotes it. If the record is lost, a physical-presence `PAIR` ceremony re-reveals the existing public key. The board identity is never regenerated and no header or peer key is trusted automatically. | architecture §3.4 item 6; milestones M2 test 6b |
| Checkpoint publication durability | **Resolved (pending review).** Checkpoints are accelerators, not recovery paths. No rename. Journal history is never auto-deleted in v1. Missing checkpoint costs only replay time. | §5.5.5 |
| Directory-entry durability of new files (journal/data segments) | **Mitigated, RUNTIME-TEST.** Creation barrier, large segment sizes, missing referenced segment opens read-only, never a silent drop. | §5.5.5; M4 test 17 |
| GC keeps chunks referenced by retained checkpoint snapshots | **Resolved (pending review).** Reachability includes every root inside C_new and C_old snapshots until that checkpoint is deleted; chunk compaction runs after. | §5.5.6; M4 test 19 |
| Torn-tail recovery | **Changed.** In-place truncate and flush, read-only if truncation fails. Replaces the successor-segment recovery. | §5.5.4; M4 tests 13–14 |
| noise-c random hook | **Resolved to a known work item.** Needs an ESP32 branch in `rand_os.c`. | §3.3 item 3 |
| Entropy/DRBG integration | **Resolved to a design.** No DRBG in the first implementation; entropy source enabled for firmware lifetime; PSA/`esp_fill_random`; low consumption. Defense-in-depth DRBG is a decision for review. | §3.3 |
| CH340 support on Android for 1A86:7523 | **Resolved (documentation).** Listed in the library source. | §3 below |
| CH340 driver on Windows 10 and 11 | **Open, RUNTIME-TEST.** | §3 below |
| WinFsp install, admin and driver-signing details | **Open, DOC-NOT-YET-VERIFIED.** | §3 below |
| noise-c vs `snow` interoperability (spec revision 30 vs 34), noise-c ESP32 footprint | **Open, RUNTIME-TEST.** | §3 below |
| Android foreground service started after a USB-attach launch | **Open, RUNTIME-TEST.** | §3 below |
| NTFS directory-handle flush; SAF directory flush | **Open, DOC-NOT-YET-VERIFIED then RUNTIME-TEST.** Not relied on. | §5.5.5 |
| Exact module variant, flash size, chip revision, bridge variant | **Open, hardware.** Needs the section 8 commands or a photo. | M0 report |
| Windows machine, Android phone | **Open, owner.** | M0 report |

## 3. Findings with primary-source links

### 3.1 noise-c
| Finding | Label | Source |
|---|---|---|
| MIT license (README statement). The full `LICENSE` text was not read. | DOC-VERIFIED (README) / DOC-NOT-YET-VERIFIED (license text) | [README](https://raw.githubusercontent.com/rweather/noise-c/master/README.md) |
| Described by its author as a reference implementation; initial target GNU/Linux, embedded "later"; autotools build; optional libsodium and OpenSSL backends | DOC-VERIFIED | [docs](https://rweather.github.io/noise-c/index.html) |
| Algorithms: 25519 and 448 DH; ChaChaPoly and AESGCM; BLAKE2s, BLAKE2b, SHA256, SHA512. Patterns include NK and NX (the pattern table lists both). Implements Noise spec **revision 30**. | DOC-VERIFIED | docs above; [patterns.c](https://raw.githubusercontent.com/rweather/noise-c/master/src/protocol/patterns.c) |
| `noise_rand_bytes` (`rand_os.c`): `/dev/urandom` on Linux/macOS, `CryptGenRandom` on Windows, otherwise prints a message and calls `exit(1)`. No override hook. The file says it needs modification when porting. | DOC-VERIFIED | [rand_os.c](https://raw.githubusercontent.com/rweather/noise-c/master/src/protocol/rand_os.c) |
| A PRNG (`randstate.c`) sits on top of `noise_rand_bytes` and reseeds from it | DOC-VERIFIED | [randstate.c](https://raw.githubusercontent.com/rweather/noise-c/master/src/protocol/randstate.c) |
| `snow` tracks Noise revision 34 | DOC-VERIFIED | [snow](https://github.com/mcginty/snow) |
| Build under ESP-IDF needs a CMake wrapper component and the ESP32 `rand_os.c` branch; heap/stack footprint unknown; revision 30 vs 34 behavior differences unknown | RUNTIME-TEST (and read the Noise revision changelog: DOC-NOT-YET-VERIFIED) | — |

Plan: vendor noise-c into `firmware/components/noise-c` with a documented patch. If it fails the interop vectors or footprint test, the fallbacks are a Rust Noise implementation on the board, or another vetted C implementation, to be chosen at review.

### 3.2 ESP-IDF mbedTLS, entropy and DRBG (read from the installed v6.1 source)
| Finding | Label | Source |
|---|---|---|
| ESP-IDF installed on the Mac is tag v6.1 (`IDF_VERSION 6.1.0`, commit `fff9895c82d744c7237be8847347bdd1b07c6643`, committed 2026-08-25); bundles mbedTLS **4.1.0** | DOC-VERIFIED (local files) | `~/.espressif/v6.1/esp-idf/tools/cmake/version.cmake`, `components/mbedtls/mbedtls/include/mbedtls/build_info.h` |
| CTR_DRBG and entropy headers are under `mbedtls/private/` (not public API) | DOC-VERIFIED (local files) | `components/mbedtls/mbedtls/tf-psa-crypto/drivers/builtin/include/mbedtls/private/` |
| Port config sets `MBEDTLS_PSA_CRYPTO_EXTERNAL_RNG` and `MBEDTLS_PSA_DRIVER_GET_ENTROPY`; `mbedtls_psa_external_get_random()` and `mbedtls_hardware_poll()` call `esp_fill_random()` directly. So `psa_generate_random()` = hardware RNG, no DRBG in the path. | DOC-VERIFIED (local files) | `components/mbedtls/port/include/mbedtls/esp_config.h` lines 37–39; `components/mbedtls/port/esp_hardware.c` |
| `esp_random()` reads the hardware RNG data register and waits at least 16 APB cycles between words, noting extra entropy is added "provided WiFi or BT are enabled" | DOC-VERIFIED (local file) | `components/esp_hw_support/hw_random.c` |
| True-random only with Wi-Fi/BT on, `bootloader_random_enable()` active, or in the bootloader; the internal state is too small for a continuous true-random stream; conflicts with ADC, I2S and Wi-Fi/BT | DOC-VERIFIED | [ESP-IDF random](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/system/random.html) |
| `bootloader_random_enable()` can be called from app code and is "not safe" while ADC or RF is accessed; `bootloader_random_disable()` must precede RF, ADC, I2S | DOC-VERIFIED | [bootloader_random.h](https://raw.githubusercontent.com/espressif/esp-idf/master/components/bootloader_support/include/bootloader_random.h) |
| The published mbedTLS programming-guide page has nothing on entropy or DRBG | DOC-VERIFIED (negative) | [mbedTLS page](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/protocols/mbedtls.html) |
| Whether our firmware's `psa_generate_random()` returns true-random bytes with the entropy source enabled on this board | RUNTIME-TEST (sanity only, not proof) | — |

### 3.3 CH340 and VID:PID 1A86:7523
| Finding | Label | Source |
|---|---|---|
| `usb-serial-for-android` defines `VENDOR_QINHENG = 0x1a86` and `QINHENG_CH340 = 0x7523`, and its CH34x driver registers that vendor with CH340 and CH341A products. So 1A86:7523 is in the library's supported list. | DOC-VERIFIED | [UsbId.java](https://raw.githubusercontent.com/mik3y/usb-serial-for-android/master/usbSerialForAndroid/src/main/java/com/hoho/android/usbserial/driver/UsbId.java), [Ch34xSerialDriver.java](https://raw.githubusercontent.com/mik3y/usb-serial-for-android/master/usbSerialForAndroid/src/main/java/com/hoho/android/usbserial/driver/Ch34xSerialDriver.java) |
| The driver sets 921600 and 307200 baud via fixed settings and others by computed divisor (it throws if out of range); DTR/RTS go out through vendor request 0xA4 with inverted bits; DTR/RTS getters return cached values | DOC-VERIFIED | Ch34xSerialDriver.java |
| Whether the phone's USB stack and power sustain this bridge, and the real baud ceiling | RUNTIME-TEST | — |
| Windows: third-party pages say Windows Update can supply a CH340 driver and mention WCH's CH341SER package; one Microsoft Q&A user thread reports a Windows 10 update after which a CH340 adapter showed a COM port but stopped communicating. These are anecdotal and not from Microsoft or WCH. | Anecdotal; DOC-NOT-YET-VERIFIED against WCH's page and Microsoft's catalog | [Microsoft Q&A thread](https://learn.microsoft.com/en-us/answers/a/7905162), [Keyestudio](https://docs.keyestudio.com/projects/Arduino/en/latest/windowsCH340.html) |
| The exact CH340 variant (CH340C/G/K…) is not identified by 1A86:7523 alone | Unknown | M0 report |

### 3.4 Windows 10 and 11 dependency requirements
| Finding | Label | Source |
|---|---|---|
| Windows 10 Home/Pro end of support was 2025-10-14 (version 22H2 was the last); LTSC releases follow their own lifecycles | DOC-VERIFIED | [Lifecycle](https://learn.microsoft.com/en-us/lifecycle/products/windows-10-home-and-pro) |
| WebView2 supports Windows 10 SAC 1709 and later, Windows 10 LTSC editions, Windows 11, and several Server versions | DOC-VERIFIED | [WebView2 intro](https://learn.microsoft.com/en-us/microsoft-edge/webview2/) |
| The Evergreen WebView2 Runtime is included with Windows 11; "the vast majority" of Windows 10 devices already have it; a ~2 MB bootstrapper installs it; detect it through the `pv` registry value or `GetAvailableCoreWebView2BrowserVersionString` | DOC-VERIFIED | [Distribution](https://learn.microsoft.com/en-us/microsoft-edge/webview2/concepts/distribution) |
| Tauri 2 on Windows needs the Microsoft C++ Build Tools and the Rust MSVC toolchain; its page says WebView2 is already installed on Windows 10 1803 and later; it also says "Windows 7 and later", which conflicts with the WebView2 list above. Use WebView2's list. | DOC-VERIFIED (page) | [Tauri prerequisites](https://v2.tauri.app/start/prerequisites/) |
| WinFsp supports Windows 7 to Windows 11 on x86, x64, ARM64; GPLv3 with a FLOSS exception; commercial license available. Installer format, driver signing, reboot and admin requirements are not on the README. | DOC-VERIFIED / DOC-NOT-YET-VERIFIED (install details) | [WinFsp](https://github.com/winfsp/winfsp) |
| `System.IO.Ports.SerialPort` exists in .NET Framework 4.x (so in Windows PowerShell 5.1) and modern .NET; `DtrEnable` defaults to `false` | DOC-VERIFIED | [DtrEnable](https://learn.microsoft.com/en-us/dotnet/api/system.io.ports.serialport.dtrenable) |
| Whether Windows sets DTR/RTS on open regardless of that property, resetting the board | RUNTIME-TEST | — |
| Practical Windows 10 claim: usable on supported LTSC/ESU installs and on updated 22H2 machines where our dependencies run, but Microsoft no longer supports Home/Pro 22H2; we will state "target, not supported by Microsoft" and test before claiming anything | PROPOSED | — |

### 3.5 Android foreground service and USB lifecycle
| Finding | Label | Source |
|---|---|---|
| A `connectedDevice` foreground service needs `FOREGROUND_SERVICE_CONNECTED_DEVICE` and at least one precondition, one of which is calling `UsbManager.requestPermission()`. From Android 14 every foreground service must declare a type. | DOC-VERIFIED | [FGS types](https://developer.android.com/develop/background-work/services/fgs/service-types) |
| Apps targeting Android 12+ cannot start a foreground service from the background unless exempt; exemptions include a transition from a user-visible state such as an activity, user interaction with a notification, and user-disabled battery optimization. The page does not mention USB. | DOC-VERIFIED | [Background-start restrictions](https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start) |
| `USB_DEVICE_ATTACHED` with a device filter launches the activity after a user dialog and grants USB permission; detach must be handled by an in-app receiver | DOC-VERIFIED | [USB host](https://developer.android.com/develop/connectivity/usb/host) |
| Whether an activity launched by USB attach counts as the user-visible state that lets us start the foreground service, per Android version and OEM | RUNTIME-TEST |  |
| Full-screen-intent and notification permission behavior for the "second press" prompt | DOC-NOT-YET-VERIFIED |  |

### 3.6 Project and tooling facts
| Finding | Label | Source |
|---|---|---|
| Rust stable is 1.99.1 (manifest dated 2026-10-15) | DOC-VERIFIED | [channel manifest](https://static.rust-lang.org/dist/channel-rust-stable.toml) |
| Android Gradle Plugin 9.4.0 (September 2026) requires Gradle 9.6.0 and **JDK 17**, Build Tools 36.0.0; the page does not use the word "stable" for it | DOC-VERIFIED (version inferred stable) | [AGP releases](https://developer.android.com/build/releases/gradle-plugin) |
| Platform-tools 37.0.1 (July 2026) | DOC-VERIFIED | [Platform-tools](https://developer.android.com/tools/releases/platform-tools) |
| Command-line tools build 15859902 (Mac ARM zip, 156.1 MB); Android Studio "2026.2.1" macOS ARM dmg is 1.5 GB | DOC-VERIFIED | [Android Studio](https://developer.android.com/studio) |
| esptool v5.3.1 command and option set (`--before`, `--after`, `--no-stub`, `chip-id`, `flash-id`, `read-mac`, `read-flash`, `write-flash`) | DOC-VERIFIED (ran `--help` only, no port) | local `esptool --help` |

## 4. Development-environment inventory (nothing installed)

| Item | Found |
|---|---|
| Machine | macOS 27.0.1 (build 26A434), arm64; Xcode 26.1.1; Apple clang 17.0.0; git 2.50.1; cmake 4.4.3 (Homebrew); Homebrew 7.0.7 |
| Disk | Data volume 228 GiB, **25 GiB free, 88% used**. `df` for the project folder reports the same volume. |
| Python | python3 3.14.6 (Homebrew); pip3 |
| Node | v22.9.0 (default via nvm) and v24.21.0 |
| Java | `/usr/bin/java` and `javac`: OpenJDK **11.0.31**. Too old for AGP 9.4 (needs 17). |
| **ESP-IDF** | **v6.1 installed**: source `~/.espressif/v6.1/esp-idf` (731 MB), tools `~/.espressif/tools` (6.9 GB: xtensa-esp-elf GCC 15.2.0, riscv32-esp-elf 2.7 GB, esp-clang 2.4 GB, ninja 1.12.1, openocd-esp32, Python venv with Python 3.14.6, esptool v5.3.1, pyserial 3.5). Activation script `~/.espressif/tools/activate_idf_v6.1.sh`. Installed through the Espressif Installation Manager (`/opt/homebrew/bin/eim`). Source tree has one untracked file (`tools/requirements/requirements.merged.txt`). |
| Arduino | Arduino IDE app plus `~/Library/Arduino15` (5.9 GB) with the esp32 core 3.3.11 and a standalone esptool 5.3.1. Not needed. |
| Missing | `cargo`, `rustc`, `rustup`, `go`, `gradle`, `adb`, `sdkmanager`, Android Studio, Android SDK, `pio`, `uv`, `pipx`. A standalone `ninja` is absent from PATH but IDF bundles ninja 1.12.1. |
| Other | Docker and VS Code (with C/C++ extensions) installed. Not needed. |

## 5. Recommended toolchains, locations, sizes, and commands

All sizes marked "est." are estimates, DOC-NOT-YET-VERIFIED. Nothing below is installed or authorized yet. Prefer project-local installs under `<project>/.toolchains/` (listed in a `.gitignore` when a repo exists), activated by a script that sets environment variables for that shell only.

| Component | Recommended version | Location | Disk | Needed for | Install command (not run) |
|---|---|---|---|---|---|
| ESP-IDF | **Keep v6.1** (tag `v6.1`, commit `fff9895…`). Record the hash in the project; do not upgrade mid-project. Newer ESP-IDF releases were not checked (DOC-NOT-YET-VERIFIED). | Existing `~/.espressif` (shared, outside the project; pinned by commit hash) | 0 extra | Firmware, esptool | none |
| Host Python for M1 clients | IDF venv Python 3.14.6 + pyserial 3.5, already present | `~/.espressif/tools/python/v6.1/venv/bin/python` | 0 | Mac echo client and COBS/CRC tests | none |
| Rust | stable **1.99.1**; `--profile minimal`; add target `x86_64-pc-windows-gnu` (or `-msvc` via `cargo-xwin`, not needed for M1) | `.toolchains/rustup`, `.toolchains/cargo` via `RUSTUP_HOME` and `CARGO_HOME` | est. 0.7–1.2 GB | vault-core and Windows host from M3 on; **not needed for M1** | `curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | RUSTUP_HOME=$PWD/.toolchains/rustup CARGO_HOME=$PWD/.toolchains/cargo sh -s -- -y --profile minimal --default-toolchain 1.99.1 --no-modify-path` |
| JDK | **17** (Temurin or similar tar.gz) | `.toolchains/jdk-17` | est. 0.3 GB | Android Gradle builds (system JDK 11 is too old) | download tarball; extract; set `JAVA_HOME` |
| Android command-line tools | build **15859902** (Mac ARM zip, 156.1 MB, SHA-256 `835b62a2…02c4e` as published on the download page) | `.toolchains/android-sdk/cmdline-tools/latest` | zip 0.16 GB; unpacked est. 0.2 GB | `sdkmanager` | download; verify SHA-256; unzip |
| Android SDK packages | `platform-tools` 37.0.1, `build-tools;36.0.0`, one `platforms;android-NN` (the target SDK chosen at M1), no emulator, no NDK until Rust-on-Android | `.toolchains/android-sdk` | est. 1.0–1.8 GB | build and install the M1 APK, `adb` | `sdkmanager --sdk_root=$PWD/.toolchains/android-sdk "platform-tools" "build-tools;36.0.0" "platforms;android-NN"` |
| Gradle | 9.6.0 through the project's wrapper | `~/.gradle` redirected with `GRADLE_USER_HOME=$PWD/.toolchains/gradle` | est. 0.5–1.5 GB with caches | Android builds | wrapper downloads it |
| Android Studio | **Not recommended** (1.5 GB dmg, plus caches) | — | — | — | — |

Estimated additional disk: **about 3–5 GB if the Android tools are installed, about 1–1.5 GB more for Rust later**, leaving roughly 18–20 GB free. Disk is tight (88% used), so install Android tools only when a phone exists.
Activation script (to be created at M1 start, not now): `source tools/env.sh` sets `IDF`, `RUSTUP_HOME`, `CARGO_HOME`, `ANDROID_HOME`, `JAVA_HOME`, `GRADLE_USER_HOME`, and `PATH` for that shell only.

## 6. Concrete build-and-test sequence for the minimal USB echo (M1)

Echo protocol (PROPOSED): frame = COBS-encoded `[version u8][seq u32 LE][len u16 LE][payload ≤ 256][CRC-32 LE]` followed by `0x00`. The CRC detects line errors only (no authentication). The firmware echoes each valid frame with `seq` unchanged and a flag byte set. The host drops bytes until the first `0x00` after open and discards any frame whose CRC fails.

**Boot-noise caveat (DOC-NOT-YET-VERIFIED for exact text, expected):** the ESP32 ROM prints its boot banner on UART0 at reset, the same UART the bridge carries. We cannot silence it without an eFuse change, which is forbidden. The firmware sets console, bootloader and application logging to none (`CONFIG_ESP_CONSOLE_NONE`, `CONFIG_BOOTLOADER_LOG_LEVEL_NONE`, `CONFIG_LOG_DEFAULT_LEVEL_NONE`) and uses UART0 for frames. The host resynchronizes on `0x00` and CRC, so ROM text is discarded.

| Step | Where | What | Needs board? | Needs approval? |
|---|---|---|---|---|
| S0 | Mac | Write `docs/echo-protocol.md`, a COBS+CRC reference implementation in Python with golden vectors (run by the IDF venv Python), unit tests including garbage-prefix and corrupted-frame cases | no | no |
| S1 | Mac | Create `firmware/m1-echo` (ESP-IDF project, UART0 driver, echo loop, `sdkconfig.defaults` with logging off and Wi-Fi, Bluetooth, ADC, I2S off), build with `idf.py` | no | no (uses the existing install) |
| S2 | Mac | Static checks: grep the generated `sdkconfig` for forbidden options; record binary size | no | no |
| S3 | Mac + board | Identification (section 8, commands A–C), then backup (D) | yes | **yes** |
| S4 | Mac + board | Flash (section 8, command E) | yes | **yes** |
| S5 | Mac + board | Echo test client: 10,000 frames at 115200; record CRC failures; open/close the port 20 times and record whether it resets the board (watch for ROM banner bytes); try with DTR/RTS cleared before open | yes | yes (after S4) |
| S6 | Windows | PowerShell client (`System.IO.Ports.SerialPort`, no install): same tests, driver source and name, COM number stability, DTR/RTS reset behavior, baud steps (115200 then higher), 20 cable pulls | yes + Windows | owner |
| S7 | Phone | Kotlin app with `usb-serial-for-android`: device-filter launch, permission dialog, same echo tests, power observations, foreground service check | yes + phone | owner; needs the Android toolchain |
| S8 | Mac | Record results in `reports/m1-usb-connectivity.md` | — | — |

M1 gates and tests are in [milestones.md](../docs/milestones.md) (M1 and M1c).

## 7. What can be done where

**Can be prepared on the Mac now (no installs, no board):**
- Echo protocol document, COBS+CRC reference and golden vectors, Python tests.
- `firmware/m1-echo` source and a build with the existing ESP-IDF v6.1.
- Static checks of `sdkconfig`; binary size.
- PowerShell client source for Windows (written, not run).
- Kotlin app and Gradle project source for the phone (written, not built until the Android toolchain is installed).
- Environment script and install notes for Rust/Android/JDK (written, not executed).
- Reading remaining documentation: WCH driver page, NTFS directory flush, Android full-screen intent, noise-c license text, WinFsp installer details, Noise revision 30 to 34 changes.

**Can be done on the Mac only after your approval of the section 8 commands (board attached):** identification, backup, flashing, echo tests against the real board.

**Requires Windows:** driver installation state and name for 1A86:7523, COM port enumeration, PowerShell echo test, DTR/RTS reset behavior on open, baud ceiling, cable-pull tests, WebView2 and WinFsp presence checks, Windows 10 build checks.

**Requires a physical Android phone:** USB host and OTG power behavior, device-filter launch dialog, USB permission flow, library support for the bridge at each baud, foreground-service behavior after a USB-attach launch, background and lock-screen behavior.

## 8. Proposed board identification and flashing commands (for review; none executed)

Setup for a shell (no install):

```bash
export PORT=/dev/cu.usbserial-10
export ESPTOOL=$HOME/.espressif/tools/python/v6.1/venv/bin/esptool
```

Every esptool command that opens `$PORT` with the default `--before default-reset` toggles the bridge's DTR and RTS lines. On a standard dev board RTS drives EN and DTR drives GPIO0, so the board **resets into the ROM serial bootloader** (DOC-VERIFIED, [esptool boot-mode page](https://docs.espressif.com/projects/esptool/en/latest/esp32/advanced-topics/boot-mode-selection.html)). The running application stops and RAM contents are lost. `--after hard-reset` resets the chip again so that it boots its existing program. None of the read-only commands below writes flash or eFuses.

| # | Command | Effect on the board | Writes flash? | eFuse? |
|---|---|---|---|---|
| A | `$ESPTOOL --port $PORT --baud 115200 --before default-reset --after hard-reset --no-stub chip-id` | Reset into download mode, read chip ID/revision/features (RAM and eFuse **read**), then reset back to the app. `--no-stub` avoids loading the flasher stub into RAM. | No | Read only |
| B | `$ESPTOOL --port $PORT --baud 115200 --before default-reset --after hard-reset --no-stub flash-id` | Same reset behavior; reads the SPI flash manufacturer and device ID and the detected flash size | No | No |
| C | `$ESPTOOL --port $PORT --baud 115200 --before default-reset --after hard-reset --no-stub read-mac` | Same reset behavior; prints the factory MAC | No | Read only |
| D | `$ESPTOOL --port $PORT --baud 115200 --before default-reset --after hard-reset read-flash 0x0 0x400000 hardware/backup/board-flash-4MB.bin` | Same reset behavior; **reads** the whole 4 MB flash to a local file (size from command B; change if different). Loads the stub by default (RAM only). About 6 minutes at 115200. The file may contain Wi-Fi credentials or other secrets from whatever firmware is on the board: keep it local, never commit or share it. | No (reads) | No |
| E | Build first: `source ~/.espressif/tools/activate_idf_v6.1.sh && cd firmware/m1-echo && idf.py set-target esp32 && idf.py build`. Then: `$ESPTOOL --chip esp32 --port $PORT --baud 115200 --before default-reset --after hard-reset write-flash --flash-mode dio --flash-freq 40m --flash-size detect 0x1000 build/bootloader/bootloader.bin 0x8000 build/partition_table/partition-table.bin 0x10000 build/m1_echo.bin` | Resets into download mode, **erases and writes** the bootloader (0x1000), the partition table (0x8000) and the application (0x10000), then boots the new program. **The previous bootloader, partition table and application are destroyed** (restorable only from the backup D). Regions not covered, such as a different NVS area, are not touched, but a new partition table can change how they are interpreted. `--erase-all` is **not** used. No eFuse writes, no flash encryption, no secure boot. | **Yes** | No |

Addresses and flags in E are the standard classic-ESP32 layout and must be re-derived from `build/flasher_args.json` after the build rather than trusted from this table; `idf.py -p $PORT flash` performs the same operation using that file. `write-flash` flags were confirmed from `esptool write-flash --help` (no port opened).
Not proposed: `erase-flash`, `erase-region`, `--erase-all`, any `espefuse` or `espsecure` command, any flash-encryption or secure-boot option, serial monitors that toggle DTR/RTS.

Before running anything in A–E, please confirm:
1. The board holds nothing you need, or you accept running D first.
2. Resets during A–D are acceptable (they interrupt the existing program).
3. E is approved, with the exact `flasher_args.json` values that the build produces, shown to you first.

## 9. Risks found while reading

1. **Entropy path:** `psa_generate_random()` is a direct hardware-RNG call on ESP-IDF v6.1. Safe only with the entropy source enabled and low consumption; confirm during M2.
2. **noise-c:** no embedded random source, reference-quality code, older spec revision than `snow`. Interop vectors and footprint are the first M2 gate.
3. **Disk:** 25 GB free on the only volume. Install Android tools only when a phone exists.
4. **Java:** the Mac's JDK 11 cannot build the Android app. JDK 17 is required for AGP 9.4.
5. **ROM boot banner** on UART0 will mix with our frames after every reset; the host must resynchronize.
6. **Windows 10:** Microsoft ended support for Home/Pro 22H2 on 2025-10-14, and one anecdotal report mentions CH340 trouble after Windows 10 updates. Treat Windows 10 as a tested target, not a supported one.
7. **Android:** starting a foreground service after a USB-attach launch is undocumented in the pages read; test on the phone.

## 10. For Codex to review

- [ ] Pairing: `pending_pairing` written before `PROV_CONFIRM`, restart verification through `NK` + `AUTH`, the PAIR ceremony (unauthenticated `PAIR_REQUEST`, BOOT press, public-key-only `NX`), refusal in `ACTIVE`, and that no case regenerates the identity or trusts a header key.
- [ ] Checkpoints: no rename; journal never auto-deleted; checkpoint loss costs replay time only; creation barrier and read-only failure for missing referenced files; snapshot-referenced chunks kept; compaction ordering.
- [ ] Journal recovery now truncates in place (§5.5.4); confirm this is safe against the NTFS and Android backends and against the earlier tests.
- [ ] Entropy: dropping the DRBG in favor of the always-enabled entropy source and low consumption; whether to add a private-API DRBG anyway.
- [ ] noise-c as responder library versus alternatives, given the port and revision-30 concerns.
- [ ] Toolchain plan: reuse ESP-IDF v6.1, project-local Rust/JDK/Android SDK, disk budget, no Android Studio.
- [ ] The section 8 commands and their stated effects, before any are executed.
- [ ] Windows 10 and CH340 statements are anecdotal and stay RUNTIME-TEST.
