# M1 result: working USB hardware link (Mac)

Date: 2026-10-19. Owner approved the consolidated checkpoint (identification resets, backup, replacement of existing firmware).

## What works (evidence)
- **Identification (PASS):** ESP32-D0WD-V3 rev v3.1, 4 MB flash (manufacturer c8, device 4016), MAC d4:8c:49:e4:9f:6c, bridge CH340-family (1A86:7523). eFuse summary: no secure boot (ABS_DONE_0/1 false), FLASH_CRYPT_CNT 0, no download restriction, JTAG enabled, RD_DIS 0, WR_DIS 0. All gates passed; nothing irreversible is set.
- **Backup:** full 4,194,304-byte flash read, SHA-256 `3ec48566…50434a`, verified against the board (`verify-flash`: digest matched). Stored in `hardware/backup/` (mode 700, git-ignored, never shared). The first attempt at 460800 baud failed with serial noise on this CH340 and the gate stopped as designed; 115200 was used.
- **Flash:** echo build written at 0x1000/0x8000/0x10000 and verified (digest matched). No eFuse or security change.
- **Echo test on the Mac, 115200 baud:** 1000/1000 frames, 0 timeouts, 0 mismatches (payloads 0-256 bytes incl. zeros); negative cases (garbage, bad CRC, oversize, wrong version, unknown type) handled; INFO counters correct; median round trip 13.8 ms (about 4 KiB/s with one outstanding frame).
- **Reset behavior on macOS, measured with the uptime-based probe (6 cycles each):** default line state: **no reset on open or close** (uptime continuous). With DTR/RTS pre-cleared (`--line-state low`): **reset on open** in 5/5 classified cycles. Windows and Android behavior are pending.

## Fixed during bring-up
- Silence after boot: with the console disabled nothing routed UART0 TX, so the app now sets GPIO1/GPIO3 explicitly. (Found with a temporary diagnostic build, since removed.) The fail-stop path now prints `GPECHO-FATAL <code>` through the ROM output (which is silent when the console is disabled; kept as a best-effort diagnostic).

## Blockers / pending
- Windows machine and Android phone tests (driver, DTR/RTS behavior, echo, cable pulls): pending devices.
- Faster baud rates: later substep M1d (firmware is 115200 only).

## Next
M2: authenticated sessions, PIN/attempt delays, privacy button, recovery, encrypted-vault core with interrupted-save proof on disposable data. Toolchains installed project-locally: Rust 1.99.1, JDK 17.0.20.1, Android command-line tools (SDK packages and license acceptance still pending owner consent).
