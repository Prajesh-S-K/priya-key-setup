# M3 (Windows app) and M4 (Android app): implementation result

Status date 2026-10-19. Everything below was built and tested **on the Mac only**. No Windows PC and no Android phone were used, so every Windows and phone acceptance test is **PENDING**.

## What exists
| Item | Location | Evidence |
|---|---|---|
| Windows controller (mount reconciliation, board arrival/removal, lock on removal, shutdown) | host/windows-app/src/controller.rs | `tests/controller.rs` runs the real device core in the host simulator with a recording mounter: unlock mounts, lock unmounts, board removal / replacement locks the vault and unmounts. PASS |
| WinFsp adapter over the VFS (open/create/read/write/flush/rename/delete/dir listing/volume info) | host/windows-app/src/fs.rs | Type-checks and links for x86_64-pc-windows-msvc. **Never executed.** The VFS underneath has 12 crash/commit tests. |
| WebView2 dashboard shell, native pickers, bridge | host/windows-app/src/{ui,app}.rs | Builds. **Never executed.** |
| `gift-key.exe` (2.2 MB) and `GiftKey-Setup.exe` (NSIS) | dist/windows/ (git-ignored), tools/build_installer.sh | Built; SHA-256 in build output. **Untested on Windows.** WinFsp is installed only if you place its MSI at dist/windows/redist/winfsp.msi before building, otherwise the installer tells the user to install it. |
| Rust Android core: file API, import hash verify, lock behaviour | host/android-core | `tests/core.rs` against the real device core: locked until unlocked, mkdir/create/write/flush/read/rename/delete, hash verify (match and mismatch), `lock_all` closes everything. PASS |
| JNI layer (19 functions) | host/android-core/src/jni_glue.rs | All 19 symbols exported in the arm64 library and match Native.kt. **Never loaded on Android.** |
| Android app: USB (CH340 via usb-serial-for-android), foreground service, DocumentsProvider, WebView dashboard, SAF import/restore | android/ | Compiles; APK is 7.7 MB, signed (apksigner verify OK), contains arm64-v8a, armeabi-v7a, x86_64 cores. **Never installed.** |
| Same dashboard on both platforms (bridge contract identical) | dashboard/index.html | Visually verified in a browser with the mock bridge in the previous milestone. |

Other suites unchanged and passing: vault-core 18, gpkey-host 9, gp-app 5 + 12, Python 94. Total Rust tests now 49.

## Changes to shared code
- `Service::replace_link` (board plugged/unplugged drops the session and everything open), `NullLink`, `FramedLink<ByteIo>`.
- Heartbeats inside import/restore loops (found by reasoning about the 3 s board timeout; covered indirectly by the service tests, not by a dedicated long-import test yet).
- API command `mark_restored` for platforms that restore through their own file API (Android).

## Known limitations (honest list)
- **Windows:** case-sensitive volume; file names invalid on Windows (for example ending in a dot, or containing `:`) imported from another system are listed but may not open. Names over 255 UTF-16 units are not listed. Timestamps cannot be changed by applications. No tray/background mode: closing the window locks everything. Directory mount points are not implemented (drive letters only).
- **Android:** vaults live in the app's private storage, so they are removed when the app is uninstalled; recovery of a vault after reinstall needs a copy of the `.gpv` folder placed back by other means (not designed yet). The "recover folder" picker lists the `.gpv` folders found in app storage. `truncate` while a file is open through the provider is not supported by Android's proxy file descriptors (only truncate-on-open, mode `wt`). Android's DocumentsProvider cannot guarantee that another app's save is durable until that app closes the descriptor; commit points follow the VFS rules (flush/fsync and last close).
- **Both:** the disk backend's durability stays "Unverified" (no directory-fsync evidence on real devices yet). Board-stored dashboard assets are not implemented (the dashboard is bundled in both apps, as the architecture allows when measurements do not force the board); that needs new firmware and your approval to flash.
- Privacy toggle, unplug lock and PIN delays are verified on the board through the simulator and on hardware in M2; the Windows/Android glue that reacts to them (unmount, roots removed, descriptors failing) is only tested through the simulator on the Mac.

## Pending acceptance tests (need your devices)
Windows 11 (and 10 if available): install WinFsp, run installer, board detected within ~2 s of plugging in, PIN, add a disposable folder, unlock shows a drive, Notepad / Word / image editor open-edit-save, save-by-rename editors, large file copy, lock closes the drive while an app holds a file open, unplug while saving, BOOT press, reboot with the drive unlocked, uninstall keeps encrypted data.
Android 11+ phone: install APK, USB permission prompt, USB attach launch, PIN, disposable folder import through the picker, unlocked folder visible as a root in Files and in another app, edit and save from that app, privacy button / unplug removes the root and fails open files, notification behaviour on Android 13+, battery-optimization effects on the foreground service.
Also: DTR/RTS reset behaviour on open on Windows and Android (macOS did not reset the board; unknown elsewhere), which affects how long the board takes to be ready after plugging in.

## Build commands (all on the Mac)
`tools/build_installer.sh` (Windows exe + installer), `tools/build_apk.sh` (Rust cores + signed APK). Toolchains are in `.toolchains/` (Rust, JDK 17, Android SDK + NDK 27, Gradle 9.6, xwin Windows SDK 629 MB).

## M5 progress (dashboard polish)
The dashboard now shows "PLUG IN THE KEY" when no board is on a port, shows host notices (for example WinFsp missing) as toasts, offers "Drive Z:" (Windows) or "Open in Files" (Android) on unlocked cards, and on Android skips the "where to keep the encrypted copy" choice (app-private storage). Exe, installer and APK were rebuilt with these changes; all Rust tests still pass. Not done: board-stored assets, tray mode, app icon and branding, an in-app first-run guide for USB permission/battery settings.
