# M0 — Hardware identification

Date: 2026-10-19. Scope: visual inspection and ordinary OS USB enumeration only. No flashing, no esptool or any reset-causing tool, no serial port opened, no tools installed.
Status: **USB bridge enumerated; hardware identification partial.** Android and Windows behavior is untested and unverified.

## Sources of the observations
- **Codex, read-only Mac enumeration** (reported by the owner; I did not re-run it): USB product string, VID:PID, serial device node. The port was not opened and nothing was flashed or reset.
- **Owner's photo:** board appearance.
- My own earlier read-only checks (twice, before the board was attached) found no device. They are superseded by the Codex observation and have not been repeated since.

## Observed facts

| Item | Observed | Source / status |
|---|---|---|
| USB product string | `USB Serial` | Codex, Mac enumeration. Observed. |
| USB VID:PID | **1A86:7523** | Codex, Mac enumeration. Observed. |
| Serial device node on the Mac | `/dev/cu.usbserial-10` | Codex. Observed. Port not opened. |
| Bridge family | Matches the CH340 family (WCH). The VID:PID is commonly associated with CH340-family chips (DOC-NOT-YET-VERIFIED against WCH documents). | Inference from the ID. **Exact variant (CH340C/G/K/…) UNCONFIRMED** until the chip marking is read. |
| Board form factor | 30-pin board | Owner's photo. Observed. |
| Shield marking | `ESP-32` | Owner's photo. Observed. |
| USB connector | USB-C | Owner's photo. Observed. |
| Buttons | EN and BOOT | Owner's photo. Observed. |

## Unknown items (not inferred from appearance)

| Item | Status |
|---|---|
| Exact ESP32 module variant (e.g. WROOM-32 / -32D / -32E) | UNKNOWN. "ESP-32" on the shield does not identify the variant. |
| Flash size | UNKNOWN. Reading it needs esptool, which resets the board; not authorized. |
| Chip revision | UNKNOWN, same reason. |
| USB bridge chip marking (variant) | UNKNOWN. Needs a close photo of the chip near the connector. |
| BOOT wired to GPIO0 | UNKNOWN (expected on most boards, not verified). |
| Board enumerates over a C-to-C cable | UNKNOWN. |
| Windows driver for 1A86:7523 on Windows 10 and Windows 11 (inbox, Windows Update, or vendor installer) | UNKNOWN, RUNTIME-TEST. Documentation not yet read. |
| Android phone support for this bridge | UNKNOWN. `usb-serial-for-android` lists CH340/CH341 support (DOC-VERIFIED), but nothing is tested on a phone. |
| Windows test machine (version and build) | UNKNOWN, none confirmed. |
| Android test phone (model, version, USB host/OTG, power) | UNKNOWN, none confirmed. |

## Remaining observations needed from the owner

1. Close-up photo of the chip next to the USB-C connector; write down every printed character, or say "unreadable".
2. Close-up photo of the ESP32 metal can top (the full printed text, including any `ESP32-WROOM-32…` line).
3. Windows machine details if available: edition/version (Win+R, `winver`), and with the board plugged in, Device Manager → Ports → Properties → Details → Hardware Ids and the driver name. Say if the driver had to be installed manually.
4. Android phone model and Android version, whether it supports USB OTG as far as known, and which adapter or cable would be used.
5. Do not press BOOT while plugging in, run esptool, or install drivers or tools until told.

## Remaining blockers for M1
- Board variant and flash size unknown.
- No Windows 11 or Windows 10 test machine confirmed.
- No Android phone confirmed, so no USB host or OTG evidence.
- No authorization yet to flash firmware or install toolchains (ESP-IDF, Android SDK, Rust).
