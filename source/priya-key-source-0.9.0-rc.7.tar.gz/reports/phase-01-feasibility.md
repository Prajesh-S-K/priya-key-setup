# Phase 01 report — architecture and feasibility (revision 2)

Date: 2026-10-19. Scope: documentation only. No code, no flashing, no real folders, no runtime tests.
Labels: DOC-VERIFIED / PROPOSED / DOC-NOT-YET-VERIFIED / RUNTIME-TEST ([README](../README.md)).

## 1. Environment inspection

| Finding | Label |
|---|---|
| Project folder was empty at the start of Phase 01. No prior instructions or reference documents. | DOC-VERIFIED (listing) |
| Dev Mac: python3, node 22, java present. PlatformIO, esptool, adb, cargo, go not on PATH. Android Studio presence not checked. | DOC-VERIFIED (command lookup) |
| No ESP32 board visible to the Mac (`system_profiler SPUSBDataType` showed no matching device; `/dev/cu.*` had only Bluetooth/console entries). Read-only check, once. | DOC-VERIFIED |
| Missing tools are installable and do not block building firmware, the Android app or Rust code. | PROPOSED |
| WinFsp, WebView2, Windows USB and Android USB behavior need a Windows 11 PC and a physical phone. | RUNTIME-TEST |

## 2. Findings with evidence

| # | Conclusion | Label | Evidence |
|---|---|---|---|
| F1 | Android has no built-in serial support; library needed. `usb-serial-for-android` (MIT) lists CP210x, CH340/CH341, FTDI, CDC/ACM, CH9102 under CDC. | DOC-VERIFIED | [USB host](https://developer.android.com/develop/connectivity/usb/host), [README](https://github.com/mik3y/usb-serial-for-android) |
| F2 | USB_DEVICE_ATTACHED + device_filter launches after a user dialog. Android 11+ background-launch and foreground-service limits not read. | DOC-VERIFIED / DOC-NOT-YET-VERIFIED | USB host guide |
| F3 | Windows has no documented launch-on-serial-plug. Route: per-user gatekeeper agent using `CM_Register_Notification`. Store/device-metadata apps not assessed. | DOC-VERIFIED (API) / PROPOSED / DOC-NOT-YET-VERIFIED | [CM_Register_Notification](https://learn.microsoft.com/en-us/windows/win32/api/cfgmgr32/nf-cfgmgr32-cm_register_notification) |
| F4 | Opening a port can reset an ESP32 via DTR/RTS; BOOT low at reset enters download mode; GPIO0 internal pull-up ~45 kΩ. | DOC-VERIFIED | [esptool boot-mode](https://docs.espressif.com/projects/esptool/en/latest/esp32/advanced-topics/boot-mode-selection.html) |
| F5 | BOOT as a runtime privacy button depends on the board's wiring. | PROPOSED / RUNTIME-TEST | F4 |
| F6 | Identification via esptool can reset the board even without flashing. Not used. | DOC-VERIFIED | F4 |
| F7 | `ReplaceFile` has no write-through; `MoveFileEx` offers `MOVEFILE_WRITE_THROUGH`; `FlushFileBuffers` flushes with hardware-cache caveats. | DOC-VERIFIED | [ReplaceFile](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-replacefilew), [MoveFileEx](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-movefileexw), [FlushFileBuffers](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-flushfilebuffers) |
| F8 | Commits are journal append + flush, not rename. | PROPOSED | architecture §5.5, §10.2 |
| F9 | WinFsp callbacks and cache flags exist; which dirty cached writes arrive before Cleanup is untested. | DOC-VERIFIED (API) / RUNTIME-TEST | [tutorial](https://github.com/winfsp/winfsp/blob/master/doc/WinFsp-Tutorial.asciidoc), [fsctl.h](https://github.com/winfsp/winfsp/blob/master/inc/winfsp/fsctl.h) |
| F10 | WinFsp: GPLv3 + FLOSS exception with conditions; commercial license available. | DOC-VERIFIED | [License.txt](https://raw.githubusercontent.com/winfsp/winfsp/master/License.txt) |
| F11 | DocumentsProvider operations and `openDocument` mode rules; no truncation statement in the source read. | DOC-VERIFIED (AOSP source) | [DocumentsProvider.java](https://raw.githubusercontent.com/aosp-mirror/platform_frameworks_base/master/core/java/android/provider/DocumentsProvider.java) |
| F12 | Proxy file descriptors: `onGetSize/onRead/onWrite/onFsync/onRelease`, no truncate callback; mmap not stated. | DOC-VERIFIED (AOSP) / RUNTIME-TEST (mmap, ftruncate, open modes) | [ProxyFileDescriptorCallback.java](https://raw.githubusercontent.com/aosp-mirror/platform_frameworks_base/master/core/java/android/os/ProxyFileDescriptorCallback.java), [StorageManager.java](https://raw.githubusercontent.com/aosp-mirror/platform_frameworks_base/master/core/java/android/os/storage/StorageManager.java) |
| F13 | SAF needs no system permission; persisted grants need `takePersistableUriPermission`, are lost on move/delete; cannot pick internal root, `Download`, `Android/data`, `Android/obb`. `MANAGE_EXTERNAL_STORAGE` is for direct paths and excludes `Android/data` and most of `Android`. | DOC-VERIFIED | [SAF](https://developer.android.com/training/data-storage/shared/documents-files), [manage-all-files](https://developer.android.com/training/data-storage/manage-all-files) |
| F14 | Noise defines NK/NX with the needed properties; exact suite strings must be checked in both libraries. | DOC-VERIFIED (spec) / DOC-NOT-YET-VERIFIED / RUNTIME-TEST | [Noise](https://noiseprotocol.org/noise.html) |
| F15 | `snow` Apache-2.0/MIT, unaudited by its own statement. noise-c MIT, reference implementation; pattern list and random hook unread. | DOC-VERIFIED / DOC-NOT-YET-VERIFIED | [snow](https://github.com/mcginty/snow), [noise-c](https://github.com/rweather/noise-c) |
| F16 | libsodium lists XChaCha20-Poly1305-IETF with random nonces safe; no AES-GCM-SIV. | DOC-VERIFIED | [libsodium AEAD](https://doc.libsodium.org/secret-key_cryptography/aead) |
| F17 | NVS: only the in-flight pair is at risk on power loss; without NVS encryption physical access can read/alter/erase/add; limited wear leveling. Flash encryption release mode irreversible; dev mode three plaintext reflashes. | DOC-VERIFIED | [NVS](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/storage/nvs_flash.html), [flash encryption](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/security/flash-encryption.html) |
| **F18** | **Entropy resolved by documentation.** `esp_random()` is true random only with Wi-Fi/BT enabled, `bootloader_random_enable()` active, or in the second-stage bootloader; otherwise pseudo-random. The default bootloader disables the source before the app runs. The entropy source conflicts with ADC, I2S, Wi-Fi/BT. Recommended pattern for USB-only: keep the entropy source enabled for the firmware's lifetime (no ADC/I2S/RF used) and use a seeded CTR_DRBG reseeded per long-term key and per handshake. | DOC-VERIFIED (facts) / PROPOSED (design) | [ESP-IDF RNG](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/system/random.html) |
| F19 | Board-stored dashboard assets: estimates only; signed manifest; app-bundled alternative not adopted. | PROPOSED / RUNTIME-TEST | architecture §8 |
| F20 | Auth design: Noise NK/NX, pinned board key, PIN inside the channel, per-vault KEKs from K_board. | PROPOSED | architecture §3 |
| F21 | PIN enforcement fails closed; provisioning is a single-blob atomic write; no automatic erase; `INCONSISTENT` state is manual-recovery only. | PROPOSED | architecture §3.4–3.5 |
| F22 | Journal framing, authenticated sequence/chain, checkpoint binding, successor-segment torn-tail recovery, interior corruption never skipped; whole-history rollback accepted. | PROPOSED | architecture §5.5 |
| F23 | Delete-then-recreate is not atomic; version store and tombstones make the previous version recoverable, not visible. | PROPOSED | architecture §10.1–10.2 |
| F24 | Android handle policy for `onWrite`, `onFsync`, `onRelease`, provider death, client death, lock; open-mode truncation supported, later `ftruncate` unsupported. | PROPOSED / RUNTIME-TEST | architecture §10.3 |
| F25 | Lifecycle ordering, heartbeat numbers, gatekeeper control path, pin non-replacement by peer keys. | PROPOSED / RUNTIME-TEST (timings) | architecture §4, §7.4 |

Source-quality notes: pages were summarized by a fetch tool; Android reference pages were read through AOSP source. Re-read rendered pages at review time.

## 3. Change report (revision 2)

| Review item | Documents and sections changed |
|---|---|
| 1 Journal recovery | architecture §5.5 (new: frames, 1 MiB limit, chain hash, sequence continuity, checkpoint binding, torn-tail vs interior rules, successor segment with authenticated `prev_valid_len`, idempotent recovery, accepted rollback); §5.7; milestones M4 (tests 1–12) and M3 |
| 2 External-save guarantees | architecture §10.1 (version store, tombstones), §10.2 rule 4 and 6 (no universal atomicity); milestones M5 test 4; requirements C.10 |
| 3 Android commit policy | architecture §10.3 (one policy for every event; open-mode vs `ftruncate`); milestones M7 test 3; requirements C.11 |
| 4 PIN fail closed | architecture §3.4 (provisioning atomicity), §3.5 (algorithm, NVS failures, no auto-erase, interrupted reset); milestones M2 tests 5–6; requirements C.12 |
| 5 Entropy | architecture §3.3 (documentation read; lifecycle, DRBG, conflicts); milestones M2 test 2; this report F18; removed from deferred items |
| 6 Lifecycle ordering | architecture §4 (LOCK before zeroize, heartbeat and timing targets, gatekeeper, unauthenticated second-press status), §6, §7.4; milestones M6 |
| 7 Storage and memory | architecture §7.1–7.3 (placement, backends and permissions, dirty limits, staging); milestones M7 test 4 |
| 8 Wording | README labels (four labels); milestone M4g freeze gate; M2 test 3 and requirements D (no "indistinguishable from random"); architecture §5.6 and requirements C.6 (rotation cannot revoke historical copies); all documents relabelled |

## 3b. Change report (revision 3)

| Item | Changed |
|---|---|
| Provisioning recovery | architecture §3.4 rewritten: states `EMPTY → COMPLETE_UNCONFIRMED → COMPLETE_CONFIRMED` + `INCONSISTENT`; `att` created and committed before the `id` blob (the `id` blob is the commit point), bound by `id_nonce`; BOOT-press pairing ceremony re-reveals the existing key, uses the normal PIN counter, never accepts a header or peer key; §3.5 `att` record fields; milestones M2 tests 6, 6b |
| Incomplete transactions | architecture §5.5.4: recovery boundary = end of last committed record; successor segment fields (`prev_valid_len`, `prev_chain_hash`, `first_seq`, `tx_state=0`, fresh `txid`s); prefix never carried forward; idempotence under power loss; milestones M4 tests 13–15 |
| Checkpoint retention and GC | architecture §5.5.5 (publication stages P1–P4, retention set R, sufficiency, no promise of deleted-segment fallback, cleanup stages G1–G4) and §5.5.6 (reachability includes version store, tombstones, and `C_old` state); milestones M4 tests 16–19 |
| Binary layout | architecture §5.5.1–5.5.2: explicit offset tables, little-endian, reserved bytes, 128-byte segment header (112 authenticated bytes + 16-byte tag), HMAC-SHA256 truncated to the left 16 bytes, 40-byte frame header, AAD list; milestones M4 test 20 (static assertions, golden bytes). Note: my recount of the old field list was 122 bytes, not 130; the new table is authoritative and explicit |

## 3c. Revision 4 update (owner observations and preferences)

- M0 status: USB bridge enumerated (1A86:7523, `USB Serial`, `/dev/cu.usbserial-10`, CH340 family, variant unconfirmed; Codex read-only, port not opened); owner photo shows a 30-pin board, `ESP-32` shield, USB-C, EN and BOOT. Module variant, flash size, chip revision and bridge marking remain unknown ([reports/m0-hardware-identification.md](m0-hardware-identification.md)).
- Compatibility scope: Windows 11 primary; Windows 10 a target pending verification of builds and dependencies; Android 11+ baseline with a broad-compatibility aim across newer phones and phones 3–5 years old. No test machine or phone confirmed; nothing claimed.
- Added: architecture §12 guided setup (USB-host check, bridge detection, just-in-time permissions, folder grants, background-operation explanation, unsupported-condition table); requirements R-PL1b, R-PL2, R-PL2b, R-UX9 and limitation 8; milestone M1c; hardware checklist §5c.
- **Open review items carried forward (not closed by this update):**
  1. *Interrupted pairing confirmation* (architecture §3.4 items 3–6; milestones M2 tests 6, 6b): the board-side `COMPLETE_UNCONFIRMED` state, the BOOT-press ceremony that re-reveals the same key and requires the PIN through the attempt counter, and refusal of header or peer keys await Codex review.
  2. *Checkpoint durability and garbage-collection safety* (architecture §5.5.5–5.5.6; milestones M4 tests 16–19): publication stages, retention set, cleanup order, and reachability await Codex review. The format remains a draft until gate M4g.
- No flashing and no toolchain installation is authorized.

## 3d. Revision 5 (pre-M1 readiness)

See [pre-m1-readiness.md](pre-m1-readiness.md). Changed: architecture §3.3 (entropy: no private-API DRBG, PSA path is direct hardware RNG on ESP-IDF v6.1; noise-c needs an ESP32 random branch), §3.4 item 6 (pairing disconnect points, host `pending_pairing`, PAIR ceremony), §5.5.3–5.5.6 (torn-tail recovery by in-place truncation; checkpoints are accelerators, no rename, journal never auto-deleted in v1, creation barrier, snapshot-referenced chunks kept); milestones M2 test 6b and M4 tests 13, 14, 16–19.

## 4. Remaining hardware-dependent unknowns (RUNTIME-TEST)

Exact bridge chip, module, flash size and revision; whether BOOT is wired to GPIO0 and readable at runtime; DTR/RTS reset behavior per OS; maximum stable baud on Windows and the phone; whether the hardware-RNG path behaves as documented on this board; phone OTG power and bridge support; foreground-service behavior on the phone; WinFsp cleanup/flush delivery and directory-mount behavior; per-editor save patterns; Android `onFsync`/`onRelease` call behavior, `"wt"` handling, `ftruncate`, mmap; SAF fsync behavior; measured heartbeat/lock timings; NVS fault-injection behavior.

## 5. Documentation still to read (DOC-NOT-YET-VERIFIED)

noise-c pattern list and random hook; ESP-IDF mbedTLS entropy glue and NVS error codes; vendor VID:PID and Windows driver availability for the bridge found; WinFsp installation and driver-signing requirements; WebView2 and `WebViewAssetLoader` resource-handler APIs; Android 11+ foreground-service, background-launch and backup (`allowBackup`, data-extraction rules) documents; license texts for every dependency; Windows device-metadata launch options.

## 6. Open decisions

1. WinFsp licensing path (GPL-compatible app, commercial license, or alternative).
2. Board-stored assets: confirm after M1b measurements. App-bundled assets stay an unadopted alternative.
3. HTML versus native PIN entry.
4. Rollback detection: none, host epoch, or board epoch.
5. Draft sealing at lock (default off).
6. Android default vault location (app-private versus SAF tree) and whether to offer `MANAGE_EXTERNAL_STORAGE` at all.
7. Windows default vault location (next to source, versus central store) and directory-mount outcome.
8. Whether noise-c (or another responder) is acceptable; whether snow's unaudited status is acceptable.
9. Whether to later enable flash encryption and secure boot (irreversible).
10. Version-store retention defaults (last 3 roots) and the 4 GiB file-size limit.
11. Tauri versus .NET for the Windows shell.
12. Availability of a Windows 11 PC and an OTG-capable phone.

## 7. What Codex should review

- [ ] Journal: framing, 1 MiB limit, per-record AAD and chain hash, sequence continuity across segments, checkpoint binding, torn-tail classification (tail vs interior), successor-segment recovery and that the next append stays readable, idempotent recovery, and that accepted rollback is separate from the failing cases.
- [ ] PIN board: write-ahead counter with durable verification before comparison, no key release on any storage failure, interrupted reset-to-zero behavior, no automatic erase, provisioning atomicity and `INCONSISTENT`.
- [ ] Entropy: interpretation of the ESP-IDF RNG page, bootloader_random lifecycle for USB-only, DRBG seeding and reseeding, every Noise ephemeral key sourced from the DRBG, conflict statements.
- [ ] Lifecycle: LOCK sent before transport destruction, heartbeat numbers, gatekeeper control path, unauthenticated status event harmlessness, peer-supplied key cannot replace a pin.
- [ ] Save semantics: no universal atomicity claim, delete-then-recreate narrowed, version store and tombstones, Windows commit points conditioned on tests.
- [ ] Android policy: consistent treatment of `onWrite`, `onFsync`, `onRelease`, client death, provider death, lock; open-mode truncation separated from `ftruncate`.
- [ ] Storage placement, backends and permission table; dirty-memory limits and encrypted staging.
- [ ] Labels: documentation-not-yet-verified is separate from runtime-test; no planned feature is described as implemented or tested; no "indistinguishable from random" claim; rotation wording about historical copies.
- [ ] Milestones: risk-first order; M4g format-freeze gate after crash-recovery review.
