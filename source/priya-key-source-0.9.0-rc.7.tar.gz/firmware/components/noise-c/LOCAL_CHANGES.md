# Local changes to noise-c (upstream commit cfe25410979a87391bb9ac8d4d4bef64e9f268c6, MIT license, see COPYING)
- `NOISE_MINIMAL`: dhstate/cipherstate/hashstate no longer reference Curve448, NewHope, AES-GCM, BLAKE2b, SHA-512 (unused).
- `src/protocol/rand_os.c`: ESP32 branch calling `esp_fill_random()` (upstream aborts on unknown platforms).
- `src/backend/ref/dh-curve25519.c`: public key derivation uses curve25519-donna instead of the Ed25519 tables.
- Only the sources listed in CMakeLists.txt are built; everything else is unused upstream material (docs, tests, examples).
