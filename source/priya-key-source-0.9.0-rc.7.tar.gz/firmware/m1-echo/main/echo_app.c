#include "echo_app.h"
#include <string.h>

static void put_u16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put_u32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24);
}

/* Returns 1 only if the whole frame was accepted by the transmit path. */
static int send_frame(echo_app_t *app, uint8_t type, uint32_t seq, const uint8_t *payload, size_t len)
{
    size_t n = ge_build_wire(type, seq, payload, len, app->wire);
    if (n == 0) {
        app->tx_errors++;
        return 0;
    }
    int r = app->ops->tx(app->ops->ctx, app->wire, n);
    if (r < 0 || (size_t)r != n) {
        app->tx_errors++;
        return 0;
    }
    app->tx_frames++;
    return 1;
}

static size_t build_info(const echo_app_t *app, uint8_t out[GE_INFO_LEN])
{
    out[0] = GE_PROTO_VERSION;
    put_u16(out + 1, GE_MAX_PAYLOAD);
    put_u32(out + 3,  app->ops->uptime_ms(app->ops->ctx));
    put_u32(out + 7,  app->rx.c.ok);
    put_u32(out + 11, app->rx.c.cobs);
    put_u32(out + 15, app->rx.c.crc);
    put_u32(out + 19, app->rx.c.length);
    put_u32(out + 23, app->rx.c.oversize);
    put_u32(out + 27, app->uart_err);
    put_u32(out + 31, app->tx_frames);      /* successful transmissions before this reply */
    return GE_INFO_LEN;
}

echo_status_t echo_app_start(echo_app_t *app, const echo_ops_t *ops)
{
    if (app == NULL || ops == NULL || ops->uart_install == NULL || ops->uart_configure == NULL ||
        ops->uart_set_pins == NULL || ops->uart_remove == NULL || ops->tx == NULL || ops->uptime_ms == NULL) {
        return ECHO_E_ARG;
    }
    memset(app, 0, sizeof(*app));
    app->ops = ops;
    ge_rx_init(&app->rx);

    if (ops->uart_install(ops->ctx) != 0) {
        return ECHO_E_INSTALL;
    }
    app->driver_installed = 1;
    echo_status_t st = ECHO_OK;
    if (ops->uart_configure(ops->ctx) != 0) {
        st = ECHO_E_CONFIG;
    } else if (ops->uart_set_pins(ops->ctx) != 0) {
        st = ECHO_E_PINS;
    } else {
        /* Leading delimiter ends any ROM boot text still in the host's receive buffer, then HELLO. */
        const uint8_t zero = 0x00;
        int r = ops->tx(ops->ctx, &zero, 1);
        if (r != 1) {
            st = ECHO_E_TX_DELIM;
        } else {
            uint8_t info[GE_INFO_LEN];
            size_t n = build_info(app, info);
            if (!send_frame(app, GE_T_HELLO, 0, info, n)) {
                st = ECHO_E_TX_HELLO;
            }
        }
    }
    if (st != ECHO_OK) {
        ops->uart_remove(ops->ctx);
        app->driver_installed = 0;
        app->running = 0;
        return st;
    }
    app->running = 1;
    return ECHO_OK;
}

void echo_app_on_byte(echo_app_t *app, uint8_t byte)
{
    if (app == NULL || !app->running) {
        return;
    }
    ge_frame_t f;
    ge_status_t err = GE_OK;
    ge_rx_result_t r = ge_rx_feed(&app->rx, byte, app->raw, &f, &err);
    if (r == GE_RX_FRAME) {
        if (f.type == GE_T_ECHO_REQ) {
            send_frame(app, GE_T_ECHO_RSP, f.seq, f.payload, f.len);
        } else if (f.type == GE_T_INFO_REQ) {
            uint8_t info[GE_INFO_LEN];
            size_t n = build_info(app, info);
            send_frame(app, GE_T_INFO_RSP, f.seq, info, n);
        } else {
            uint8_t code = GE_ERR_TYPE;
            send_frame(app, GE_T_ERR_RSP, f.seq, &code, 1);
        }
    } else if (r == GE_RX_ERROR && (err == GE_E_VERSION || err == GE_E_FLAGS)) {
        /* The CRC passed, so the sequence number can be trusted: answer with an error frame. */
        uint32_t seq = (uint32_t)app->raw[3] | ((uint32_t)app->raw[4] << 8) | ((uint32_t)app->raw[5] << 16) |
                       ((uint32_t)app->raw[6] << 24);
        uint8_t code = (err == GE_E_VERSION) ? GE_ERR_VERSION : GE_ERR_FLAGS;
        send_frame(app, GE_T_ERR_RSP, seq, &code, 1);
    }
    /* All other errors: silent drop, already counted. The next 0x00 resynchronizes. */
}

void echo_app_on_uart_error(echo_app_t *app, int overflow)
{
    if (app == NULL || !app->running) {
        return;
    }
    app->uart_err++;
    if (overflow) {
        ge_counters_t keep = app->rx.c;
        ge_rx_init(&app->rx);
        app->rx.c = keep;
        app->rx.overflow = 1;     /* discard until the next delimiter: the partial frame is unusable */
    }
}
