/* M1 USB echo firmware (docs/echo-protocol.md). Platform glue only: the logic is in echo_app.c.
 *
 * Does exactly this: reads COBS+CRC32 frames from UART0 (the bridge's serial line), answers ECHO and
 * INFO requests, and sends one unsolicited HELLO after boot. Fixed at 115200 baud (see the protocol
 * document: faster rates need a coordinated firmware/client mechanism and are a later substep).
 * It does NOT use: encryption, provisioning, NVS, Wi-Fi, Bluetooth, the ADC, I2S, the BOOT button,
 * or any vault operation. It never writes flash.
 *
 * If any initialization step fails the firmware stops: it removes the UART driver and parks forever
 * without entering the receive loop and without sending HELLO. */
#include <stdint.h>
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "driver/uart.h"
#include "esp_timer.h"
#include "esp_rom_sys.h"
#include "echo_app.h"

#define ECHO_UART       UART_NUM_0
#define ECHO_BAUD       115200
#define UART_RX_BUF     2048
#define UART_TX_BUF     2048
#define UART_QUEUE_LEN  20
#define READ_CHUNK      64

static QueueHandle_t s_queue;
static echo_app_t s_app;

static int hw_install(void *ctx)
{
    (void)ctx;
    s_queue = NULL;
    if (uart_driver_install(ECHO_UART, UART_RX_BUF, UART_TX_BUF, UART_QUEUE_LEN, &s_queue, 0) != ESP_OK) {
        return -1;
    }
    if (s_queue == NULL) {              /* installed but no event queue: unusable, undo and fail */
        uart_driver_delete(ECHO_UART);
        return -1;
    }
    return 0;
}

static int hw_configure(void *ctx)
{
    (void)ctx;
    const uart_config_t cfg = {
        .baud_rate = ECHO_BAUD,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    return uart_param_config(ECHO_UART, &cfg) == ESP_OK ? 0 : -1;
}

static int hw_set_pins(void *ctx)
{
    (void)ctx;
    /* Explicit UART0 pins of the classic ESP32 (TX GPIO1, RX GPIO3, the bridge's lines). With the console disabled
     * nothing else routes them, so UART_PIN_NO_CHANGE would leave TX unconnected. */
    return uart_set_pin(ECHO_UART, 1, 3, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE) == ESP_OK ? 0 : -1;
}

static void hw_remove(void *ctx)
{
    (void)ctx;
    (void)uart_driver_delete(ECHO_UART);
    s_queue = NULL;
}

static int hw_tx(void *ctx, const uint8_t *data, size_t n)
{
    (void)ctx;
    return uart_write_bytes(ECHO_UART, (const char *)data, n);   /* bytes accepted, or -1 */
}

static uint32_t hw_uptime_ms(void *ctx)
{
    (void)ctx;
    return (uint32_t)(esp_timer_get_time() / 1000);
}

static const echo_ops_t OPS = {
    .ctx = NULL,
    .uart_install = hw_install,
    .uart_configure = hw_configure,
    .uart_set_pins = hw_set_pins,
    .uart_remove = hw_remove,
    .tx = hw_tx,
    .uptime_ms = hw_uptime_ms,
};

/* Fail-stop. The UART driver is already removed, so a plain-text diagnostic goes out through the ROM output path
 * (never a protocol frame). The host sees "GPECHO-FATAL <code>" instead of a HELLO. */
static void park_forever(int code)
{
    for (;;) {
        esp_rom_printf("\r\nGPECHO-FATAL %d\r\n", code);
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
}

void app_main(void)
{
    echo_status_t st = echo_app_start(&s_app, &OPS);
    if (st != ECHO_OK) {
        park_forever((int)st);           /* never enter the receive loop with an unusable driver */
    }

    uart_event_t ev;
    uint8_t chunk[READ_CHUNK];
    for (;;) {
        if (xQueueReceive(s_queue, &ev, portMAX_DELAY) != pdTRUE) {
            continue;
        }
        switch (ev.type) {
        case UART_DATA: {
            size_t left = ev.size;
            while (left > 0) {
                int got = uart_read_bytes(ECHO_UART, chunk, left < READ_CHUNK ? left : READ_CHUNK, pdMS_TO_TICKS(20));
                if (got < 0) {
                    echo_app_on_uart_error(&s_app, 0);
                    break;
                }
                if (got == 0) {
                    break;
                }
                for (int i = 0; i < got; i++) {
                    echo_app_on_byte(&s_app, chunk[i]);
                }
                left -= (size_t)got;
            }
            break;
        }
        case UART_FIFO_OVF:
        case UART_BUFFER_FULL:
            uart_flush_input(ECHO_UART);
            xQueueReset(s_queue);
            echo_app_on_uart_error(&s_app, 1);
            break;
        case UART_FRAME_ERR:
        case UART_PARITY_ERR:
        case UART_BREAK:
            echo_app_on_uart_error(&s_app, 0);
            break;
        default:
            break;
        }
    }
}
