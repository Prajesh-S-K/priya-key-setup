/* M1 echo application logic, separated from ESP-IDF so the SAME code is unit-tested on the host
 * (tests/c/test_app.c) and linked into the firmware. All hardware access goes through echo_ops_t.
 * No cryptography, no storage. */
#ifndef ECHO_APP_H
#define ECHO_APP_H

#include <stddef.h>
#include <stdint.h>
#include "echo_frame.h"

typedef struct echo_ops {
    void *ctx;
    int (*uart_install)(void *ctx);      /* 0 = success. Must not leave a driver behind on failure. */
    int (*uart_configure)(void *ctx);    /* 0 = success */
    int (*uart_set_pins)(void *ctx);     /* 0 = success */
    void (*uart_remove)(void *ctx);      /* undo uart_install */
    int (*tx)(void *ctx, const uint8_t *data, size_t n);  /* bytes accepted (== n on success), < 0 on error */
    uint32_t (*uptime_ms)(void *ctx);
} echo_ops_t;

typedef enum {
    ECHO_OK = 0,
    ECHO_E_ARG = 1,
    ECHO_E_INSTALL = 2,
    ECHO_E_CONFIG = 3,
    ECHO_E_PINS = 4,
    ECHO_E_TX_DELIM = 5,
    ECHO_E_TX_HELLO = 6
} echo_status_t;

typedef struct {
    const echo_ops_t *ops;
    ge_rx_t rx;
    uint8_t raw[GE_MAX_RAW];
    uint8_t wire[GE_MAX_ENCODED + 1];
    uint32_t tx_frames;      /* frames fully accepted by the transmit path; failed or short writes are not counted */
    uint32_t tx_errors;      /* frames whose transmission failed or was short */
    uint32_t uart_err;
    int running;             /* 1 only after echo_app_start returned ECHO_OK */
    int driver_installed;
} echo_app_t;

/* Sequence: install, configure, set pins, send the leading 0x00, send HELLO. Any failure undoes what was
 * done (uart_remove if installed), leaves running == 0, and returns the matching error. The caller must
 * not enter the receive loop unless this returns ECHO_OK. */
echo_status_t echo_app_start(echo_app_t *app, const echo_ops_t *ops);

/* Feed one received byte. Does nothing unless running. */
void echo_app_on_byte(echo_app_t *app, uint8_t byte);

/* UART hardware error event. overflow != 0: FIFO overflow or driver buffer full, so the partial frame in
 * progress is unusable and input is discarded until the next delimiter. */
void echo_app_on_uart_error(echo_app_t *app, int overflow);

#endif
