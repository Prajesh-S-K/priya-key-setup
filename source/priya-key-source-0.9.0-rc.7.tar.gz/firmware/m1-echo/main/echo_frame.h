/* M1 USB echo framing. Portable C: no ESP-IDF dependencies, so the host test in
 * tests/c/test_frame.c compiles this same file. Spec: docs/echo-protocol.md.
 * No cryptography. CRC-32 only detects line errors. */
#ifndef ECHO_FRAME_H
#define ECHO_FRAME_H

#include <stddef.h>
#include <stdint.h>

#define GE_PROTO_VERSION   1
#define GE_HEADER_LEN      9u      /* ver u8, type u8, flags u8, seq u32, len u16 */
#define GE_CRC_LEN         4u
#define GE_MAX_PAYLOAD     256u
#define GE_MIN_RAW         (GE_HEADER_LEN + GE_CRC_LEN)                    /* 13  */
#define GE_MAX_RAW         (GE_HEADER_LEN + GE_MAX_PAYLOAD + GE_CRC_LEN)   /* 269 */
#define GE_MAX_ENCODED     (GE_MAX_RAW + GE_MAX_RAW / 254u + 1u)           /* 271, excludes delimiter */

#define GE_T_ECHO_REQ 0x01
#define GE_T_INFO_REQ 0x02
#define GE_T_ECHO_RSP 0x81
#define GE_T_INFO_RSP 0x82
#define GE_T_HELLO    0x83
#define GE_T_ERR_RSP  0xFF

#define GE_ERR_VERSION 1
#define GE_ERR_FLAGS   2
#define GE_ERR_TYPE    3

#define GE_INFO_LEN 35u   /* u8 + u16 + 8 x u32 */

typedef enum {
    GE_OK = 0,
    GE_E_COBS = 1,
    GE_E_LENGTH = 2,
    GE_E_CRC = 3,
    GE_E_VERSION = 4,
    GE_E_FLAGS = 5,
    GE_E_OVERSIZE = 6,
    GE_E_ARG = 7
} ge_status_t;

typedef struct {
    uint8_t  ver, type, flags;
    uint32_t seq;
    uint16_t len;
    const uint8_t *payload;   /* points into the raw buffer passed to ge_parse_raw */
} ge_frame_t;

typedef struct {
    uint32_t ok, cobs, length, crc, version, flags, oversize;
} ge_counters_t;

uint32_t ge_crc32(const uint8_t *data, size_t n);

/* Returns encoded length (no delimiter). out must hold n + n/254 + 1 bytes. */
size_t ge_cobs_encode(const uint8_t *in, size_t n, uint8_t *out);
/* Returns GE_OK or GE_E_COBS / GE_E_LENGTH (output exceeds cap). */
ge_status_t ge_cobs_decode(const uint8_t *in, size_t n, uint8_t *out, size_t cap, size_t *out_len);

/* Builds the raw (pre-COBS) frame. Returns raw length, or 0 on bad argument. out holds GE_MAX_RAW. */
size_t ge_build_raw(uint8_t ver, uint8_t type, uint8_t flags, uint32_t seq,
                    const uint8_t *payload, size_t len, uint8_t *out);
/* Builds COBS(raw) followed by 0x00. out holds GE_MAX_ENCODED + 1. Returns bytes to write, or 0. */
size_t ge_build_wire(uint8_t type, uint32_t seq, const uint8_t *payload, size_t len, uint8_t *out);

/* Validation order: length bounds, len field, CRC, version, flags. */
ge_status_t ge_parse_raw(const uint8_t *raw, size_t n, ge_frame_t *f);

/* Streaming receiver: bytes accumulate until 0x00. See spec section 7. */
typedef struct {
    uint8_t  buf[GE_MAX_ENCODED];
    size_t   n;
    int      overflow;
    ge_counters_t c;
} ge_rx_t;

typedef enum { GE_RX_NONE = 0, GE_RX_FRAME = 1, GE_RX_ERROR = 2 } ge_rx_result_t;

void ge_rx_init(ge_rx_t *rx);
/* Feed one byte. GE_RX_FRAME: *f is valid until the next call (payload points into rx scratch).
 * GE_RX_ERROR: *err is the status; the chunk was dropped and counted. */
ge_rx_result_t ge_rx_feed(ge_rx_t *rx, uint8_t byte, uint8_t raw_scratch[GE_MAX_RAW],
                          ge_frame_t *f, ge_status_t *err);

#endif
