#include "echo_frame.h"
#include <string.h>

uint32_t ge_crc32(const uint8_t *data, size_t n)
{
    /* CRC-32/ISO-HDLC, reflected poly 0xEDB88320, init and xorout 0xFFFFFFFF. Bitwise: no table. */
    uint32_t c = 0xFFFFFFFFu;
    for (size_t i = 0; i < n; i++) {
        c ^= data[i];
        for (int k = 0; k < 8; k++) {
            c = (c & 1u) ? (c >> 1) ^ 0xEDB88320u : (c >> 1);
        }
    }
    return c ^ 0xFFFFFFFFu;
}

size_t ge_cobs_encode(const uint8_t *in, size_t n, uint8_t *out)
{
    size_t code_idx = 0, w = 1;
    uint8_t code = 1;
    out[0] = 0;
    for (size_t i = 0; i < n; i++) {
        if (in[i] == 0) {
            out[code_idx] = code;
            code_idx = w++;
            out[code_idx] = 0;
            code = 1;
        } else {
            out[w++] = in[i];
            code++;
            if (code == 0xFF) {
                out[code_idx] = code;
                code_idx = w++;
                out[code_idx] = 0;
                code = 1;
            }
        }
    }
    out[code_idx] = code;
    return w;
}

ge_status_t ge_cobs_decode(const uint8_t *in, size_t n, uint8_t *out, size_t cap, size_t *out_len)
{
    /* Structural errors (GE_E_COBS) take precedence over "output too long" (GE_E_LENGTH), so the
     * result matches the Python reference, which decodes fully before checking sizes. */
    size_t i = 0, w = 0;
    int too_long = 0;
    while (i < n) {
        uint8_t code = in[i++];
        if (code == 0) {
            return GE_E_COBS;
        }
        size_t blk = (size_t)code - 1;
        if (i + blk > n) {
            return GE_E_COBS;
        }
        for (size_t k = 0; k < blk; k++) {
            if (in[i + k] == 0) {
                return GE_E_COBS;
            }
        }
        if (!too_long) {
            if (w + blk > cap) {
                too_long = 1;
            } else {
                memcpy(out + w, in + i, blk);
                w += blk;
            }
        }
        i += blk;
        if (code < 0xFF && i < n && !too_long) {
            if (w + 1 > cap) {
                too_long = 1;
            } else {
                out[w++] = 0;
            }
        }
    }
    if (too_long) {
        return GE_E_LENGTH;
    }
    *out_len = w;
    return GE_OK;
}

static void put_u16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put_u32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24);
}
static uint16_t get_u16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t get_u32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

size_t ge_build_raw(uint8_t ver, uint8_t type, uint8_t flags, uint32_t seq,
                    const uint8_t *payload, size_t len, uint8_t *out)
{
    if (len > GE_MAX_PAYLOAD || (len > 0 && payload == NULL)) {
        return 0;
    }
    out[0] = ver;
    out[1] = type;
    out[2] = flags;
    put_u32(out + 3, seq);
    put_u16(out + 7, (uint16_t)len);
    if (len) {
        memcpy(out + GE_HEADER_LEN, payload, len);
    }
    put_u32(out + GE_HEADER_LEN + len, ge_crc32(out, GE_HEADER_LEN + len));
    return GE_HEADER_LEN + len + GE_CRC_LEN;
}

size_t ge_build_wire(uint8_t type, uint32_t seq, const uint8_t *payload, size_t len, uint8_t *out)
{
    uint8_t raw[GE_MAX_RAW];
    size_t rn = ge_build_raw(GE_PROTO_VERSION, type, 0, seq, payload, len, raw);
    if (rn == 0) {
        return 0;
    }
    size_t en = ge_cobs_encode(raw, rn, out);
    out[en] = 0x00;
    return en + 1;
}

ge_status_t ge_parse_raw(const uint8_t *raw, size_t n, ge_frame_t *f)
{
    if (n < GE_MIN_RAW || n > GE_MAX_RAW) {
        return GE_E_LENGTH;
    }
    uint16_t len = get_u16(raw + 7);
    if (len > GE_MAX_PAYLOAD || GE_HEADER_LEN + (size_t)len + GE_CRC_LEN != n) {
        return GE_E_LENGTH;
    }
    if (ge_crc32(raw, n - GE_CRC_LEN) != get_u32(raw + n - GE_CRC_LEN)) {
        return GE_E_CRC;
    }
    if (raw[0] != GE_PROTO_VERSION) {
        return GE_E_VERSION;
    }
    if (raw[2] != 0) {
        return GE_E_FLAGS;
    }
    f->ver = raw[0];
    f->type = raw[1];
    f->flags = raw[2];
    f->seq = get_u32(raw + 3);
    f->len = len;
    f->payload = raw + GE_HEADER_LEN;
    return GE_OK;
}

void ge_rx_init(ge_rx_t *rx)
{
    memset(rx, 0, sizeof(*rx));
}

ge_rx_result_t ge_rx_feed(ge_rx_t *rx, uint8_t byte, uint8_t raw_scratch[GE_MAX_RAW],
                          ge_frame_t *f, ge_status_t *err)
{
    if (byte != 0x00) {
        if (!rx->overflow) {
            if (rx->n >= GE_MAX_ENCODED) {
                rx->overflow = 1;
                rx->n = 0;
            } else {
                rx->buf[rx->n++] = byte;
            }
        }
        return GE_RX_NONE;
    }
    if (rx->overflow) {
        rx->overflow = 0;
        rx->n = 0;
        rx->c.oversize++;
        *err = GE_E_OVERSIZE;
        return GE_RX_ERROR;
    }
    if (rx->n == 0) {
        return GE_RX_NONE;   /* empty chunk: idle delimiter */
    }
    size_t raw_len = 0;
    ge_status_t st = ge_cobs_decode(rx->buf, rx->n, raw_scratch, GE_MAX_RAW, &raw_len);
    rx->n = 0;
    if (st == GE_OK) {
        st = ge_parse_raw(raw_scratch, raw_len, f);
    }
    switch (st) {
    case GE_OK:         rx->c.ok++; return GE_RX_FRAME;
    case GE_E_COBS:     rx->c.cobs++; break;
    case GE_E_LENGTH:   rx->c.length++; break;
    case GE_E_CRC:      rx->c.crc++; break;
    case GE_E_VERSION:  rx->c.version++; break;
    case GE_E_FLAGS:    rx->c.flags++; break;
    default: break;
    }
    *err = st;
    return GE_RX_ERROR;
}
