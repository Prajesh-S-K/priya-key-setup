/* GPKEY device firmware: platform glue for gk_core.c (docs/architecture.md sections 3-4).
 * One task owns all state: UART events, the BOOT button (GPIO0, plain GPIO read) and the periodic tick.
 * Not used: Wi-Fi, Bluetooth, ADC, I2S, eFuse writes, flash encryption, secure boot. NVS is never erased automatically. */
#include <stdint.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_timer.h"
#include "esp_random.h"
#include "esp_rom_sys.h"
#include "bootloader_random.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "esp_partition.h"
#include "gk_core.h"

#define KEY_UART     UART_NUM_0
#define KEY_BAUD     115200
#define BOOT_GPIO    GPIO_NUM_0
#define DEBOUNCE_MS  40

static QueueHandle_t s_queue;
static nvs_handle_t s_nvs;
static gk_t s_gk;

static int op_store_init(void *ctx)
{
    (void)ctx;
    esp_err_t e = nvs_flash_init();
    if (e != ESP_OK) {
        return -1;               /* includes NO_FREE_PAGES / NEW_VERSION_FOUND: never erase automatically */
    }
    return nvs_open("gpkey", NVS_READWRITE, &s_nvs) == ESP_OK ? 0 : -1;
}

static int op_store_get(void *ctx, const char *key, uint8_t *buf, size_t cap, size_t *len)
{
    (void)ctx;
    size_t n = 0;
    esp_err_t e = nvs_get_blob(s_nvs, key, NULL, &n);
    if (e == ESP_ERR_NVS_NOT_FOUND) {
        return 1;
    }
    if (e != ESP_OK || n > cap) {
        return -1;
    }
    if (nvs_get_blob(s_nvs, key, buf, &n) != ESP_OK) {
        return -1;
    }
    *len = n;
    return 0;
}

static int op_store_set(void *ctx, const char *key, const uint8_t *buf, size_t len)
{
    (void)ctx;
    if (nvs_set_blob(s_nvs, key, buf, len) != ESP_OK || nvs_commit(s_nvs) != ESP_OK) {
        return -1;
    }
    uint8_t chk[256];
    size_t n = sizeof(chk);
    if (len > sizeof(chk) || nvs_get_blob(s_nvs, key, chk, &n) != ESP_OK || n != len || memcmp(chk, buf, len) != 0) {
        return -1;               /* read-back verification failed */
    }
    return 0;
}

/* Dashboard assets: raw image in the data partition "assets" (subtype 0x40). Header: "GKAS", then the host verifies a signature. */
static const esp_partition_t *s_assets;

static uint32_t op_asset_size(void *ctx)
{
    (void)ctx;
    if (!s_assets) {
        s_assets = esp_partition_find_first(ESP_PARTITION_TYPE_DATA, (esp_partition_subtype_t)0x40, "assets");
    }
    uint8_t h[12];
    if (!s_assets || esp_partition_read(s_assets, 0, h, sizeof(h)) != ESP_OK || memcmp(h, "GKAS", 4) != 0) {
        return 0;
    }
    uint32_t total = (uint32_t)h[8] | ((uint32_t)h[9] << 8) | ((uint32_t)h[10] << 16) | ((uint32_t)h[11] << 24);   /* total image bytes */
    return total <= s_assets->size ? total : 0;
}

static int op_asset_read(void *ctx, uint32_t off, uint8_t *buf, size_t n)
{
    (void)ctx;
    return s_assets && esp_partition_read(s_assets, off, buf, n) == ESP_OK ? 0 : -1;
}

static void op_random(void *ctx, uint8_t *buf, size_t n)
{
    (void)ctx;
    esp_fill_random(buf, n);     /* true-random: the entropy source is enabled for the lifetime of the firmware */
}

static int op_tx(void *ctx, const uint8_t *d, size_t n)
{
    (void)ctx;
    return uart_write_bytes(KEY_UART, (const char *)d, n);
}

static uint32_t op_now(void *ctx)
{
    (void)ctx;
    return (uint32_t)(esp_timer_get_time() / 1000);
}

static const gk_ops_t OPS = {NULL, op_store_init, op_store_get, op_store_set, op_random, op_tx, op_now, op_asset_size, op_asset_read};

static void park(int code)
{
    for (;;) {
        esp_rom_printf("\r\nGPKEY-FATAL %d\r\n", code);
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
}

void app_main(void)
{
    /* Entropy source on for the whole run (architecture 3.3). Wi-Fi, Bluetooth, ADC and I2S are never used. */
    bootloader_random_enable();

    const uart_config_t cfg = {
        .baud_rate = KEY_BAUD, .data_bits = UART_DATA_8_BITS, .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1, .flow_ctrl = UART_HW_FLOWCTRL_DISABLE, .source_clk = UART_SCLK_DEFAULT,
    };
    if (uart_driver_install(KEY_UART, 2048, 2048, 20, &s_queue, 0) != ESP_OK || s_queue == NULL) park(1);
    if (uart_param_config(KEY_UART, &cfg) != ESP_OK) park(2);
    if (uart_set_pin(KEY_UART, 1, 3, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE) != ESP_OK) park(3);

    gpio_config_t io = {.pin_bit_mask = 1ULL << BOOT_GPIO, .mode = GPIO_MODE_INPUT, .pull_up_en = GPIO_PULLUP_ENABLE};
    if (gpio_config(&io) != ESP_OK) park(4);

    gk_init(&s_gk, &OPS);
    uint8_t zero = 0;
    uart_write_bytes(KEY_UART, (const char *)&zero, 1);       /* ends any ROM boot text; then one STATUS frame */
    {
        uint8_t w[GE_MAX_ENCODED + 1];
        uint8_t st[7] = {(uint8_t)s_gk.state, (uint8_t)((s_gk.provisioned ? 8 : 0) | (s_gk.confirmed ? 4 : 0)), 0, 0, 0, 0, 1};
        size_t n = ge_build_wire(GK_T_STATUS, 0, st, sizeof(st), w);
        uart_write_bytes(KEY_UART, (const char *)w, n);
    }

    uart_event_t ev;
    uint8_t chunk[64];
    int pressed = 0;
    uint32_t down_at = 0;
    for (;;) {
        if (xQueueReceive(s_queue, &ev, pdMS_TO_TICKS(10)) == pdTRUE) {
            switch (ev.type) {
            case UART_DATA: {
                size_t left = ev.size;
                while (left > 0) {
                    int got = uart_read_bytes(KEY_UART, chunk, left < sizeof(chunk) ? left : sizeof(chunk), pdMS_TO_TICKS(20));
                    if (got <= 0) break;
                    for (int i = 0; i < got; i++) gk_on_byte(&s_gk, chunk[i]);
                    left -= (size_t)got;
                }
                break;
            }
            case UART_FIFO_OVF:
            case UART_BUFFER_FULL:
                uart_flush_input(KEY_UART);
                xQueueReset(s_queue);
                ge_rx_init(&s_gk.rx);
                s_gk.rx.overflow = 1;
                break;
            default:
                break;
            }
        }
        /* BOOT button: plain GPIO read of GPIO0 (pressed = low), debounced; the press is acted on once. */
        uint32_t t = op_now(NULL);
        int low = gpio_get_level(BOOT_GPIO) == 0;
        if (low && !pressed) {
            if (down_at == 0) down_at = t;
            if (t - down_at >= DEBOUNCE_MS) {
                pressed = 1;
                gk_button_pressed(&s_gk);
            }
        } else if (!low) {
            pressed = 0;
            down_at = 0;
        }
        gk_tick(&s_gk);
    }
}
