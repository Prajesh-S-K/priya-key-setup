#!/bin/sh
# Build the host simulator of the device core (real gk_core.c + noise-c). Output: gpkey/sim/gk_sim
set -e
cd "$(dirname "$0")/../.."
NC=components/noise-c
OUT=${1:-gpkey/sim/gk_sim}
SRC="$NC/src/protocol/cipherstate.c $NC/src/protocol/dhstate.c $NC/src/protocol/errors.c $NC/src/protocol/handshakestate.c \
$NC/src/protocol/hashstate.c $NC/src/protocol/internal.c $NC/src/protocol/names.c $NC/src/protocol/patterns.c \
$NC/src/protocol/rand_os.c $NC/src/protocol/randstate.c $NC/src/protocol/signstate.c $NC/src/protocol/symmetricstate.c \
$NC/src/protocol/util.c $NC/src/backend/ref/cipher-chachapoly.c $NC/src/backend/ref/dh-curve25519.c \
$NC/src/backend/ref/hash-blake2s.c $NC/src/backend/ref/hash-sha256.c $NC/src/crypto/chacha/chacha.c \
$NC/src/crypto/blake2/blake2s.c $NC/src/crypto/donna/poly1305-donna.c $NC/src/crypto/sha2/sha256.c \
gpkey/components/gkcore/gk_core.c gpkey/components/gkcore/gk_hash.c m1-echo/main/echo_frame.c gpkey/sim/gk_sim.c"
clang -std=gnu11 -O1 -g -w -DNOISE_MINIMAL=1 -DUSE_LIBSODIUM=0 -DUSE_OPENSSL=0 -DHAVE_PTHREAD=0 \
  -I $NC/include -I $NC/src -I $NC/src/protocol -I gpkey/components/gkcore/include -I m1-echo/main $SRC -o "$OUT"
