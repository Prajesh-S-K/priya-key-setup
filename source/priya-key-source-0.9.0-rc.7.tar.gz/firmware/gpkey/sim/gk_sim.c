/* Host simulator of the GPKEY device: the REAL gk_core.c with a file-backed store, a virtual clock and fault
 * injection. Driven over stdin by the Rust integration tests (host/vault-core/tests/device_sim.rs).
 *
 * usage: gk_sim <store-dir> [--fail-init] [--fail-get id|att]
 * stdin:  F <hex>        feed received bytes
 *         T <ms>         advance the clock, run the periodic tick
 *         B              BOOT button pressed
 *         R              reboot (drop RAM state, re-initialize from the store, clock restarts at 0)
 *         FAILSET <n>    the n-th store_set from now fails without writing (1 = the next one)
 *         CRASHSET <n>   the n-th store_set from now "loses power" before writing: process exits with code 42
 *         ?              print "STATE <state> <flags> <attempts> <delay_until>"
 * stdout: O <hex>        bytes transmitted by the device
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include "gk_core.h"

static char dir[512];
static uint32_t clock_ms;
static int fail_init, fail_set_in, crash_set_in;
static char fail_get_key[16];

static int s_init(void *c) { (void)c; return fail_init ? -1 : 0; }
static int s_get(void *c, const char *key, uint8_t *buf, size_t cap, size_t *len)
{
    (void)c;
    if (fail_get_key[0] && strcmp(fail_get_key, key) == 0) return -1;
    char p[600]; snprintf(p, sizeof(p), "%s/%s.bin", dir, key);
    FILE *f = fopen(p, "rb");
    if (!f) return 1;
    size_t n = fread(buf, 1, cap, f);
    fclose(f);
    *len = n;
    return 0;
}
static int s_set(void *c, const char *key, const uint8_t *buf, size_t len)
{
    (void)c;
    if (crash_set_in && --crash_set_in == 0) { fflush(stdout); _exit(42); }
    if (fail_set_in && --fail_set_in == 0) return -1;
    char p[600], t[620]; snprintf(p, sizeof(p), "%s/%s.bin", dir, key); snprintf(t, sizeof(t), "%s.tmp", p);
    FILE *f = fopen(t, "wb");
    if (!f) return -1;
    if (fwrite(buf, 1, len, f) != len) { fclose(f); return -1; }
    fflush(f); fsync(fileno(f)); fclose(f);
    if (rename(t, p) != 0) return -1;
    /* read back */
    uint8_t chk[512]; size_t n = 0;
    if (s_get(NULL, key, chk, sizeof(chk), &n) != 0 || n != len || memcmp(chk, buf, len) != 0) return -1;
    return 0;
}
static void s_random(void *c, uint8_t *b, size_t n)
{
    (void)c;
    int fd = open("/dev/urandom", O_RDONLY);
    if (fd < 0 || read(fd, b, n) != (ssize_t)n) { fprintf(stderr, "random failed\n"); exit(3); }
    close(fd);
}
static int s_tx(void *c, const uint8_t *d, size_t n)
{
    (void)c;
    printf("O ");
    for (size_t i = 0; i < n; i++) printf("%02x", d[i]);
    printf("\n");
    fflush(stdout);
    return (int)n;
}
static uint32_t s_now(void *c) { (void)c; return clock_ms; }

static uint8_t asset[1 << 16];
static uint32_t asset_len;
static uint32_t s_asset_size(void *c) { (void)c; return asset_len; }
static int s_asset_read(void *c, uint32_t off, uint8_t *b, size_t n)
{
    (void)c;
    if (off > asset_len || n > asset_len - off) return -1;
    memcpy(b, asset + off, n);
    return 0;
}
static gk_ops_t ops = {NULL, s_init, s_get, s_set, s_random, s_tx, s_now, s_asset_size, s_asset_read};
static gk_t g;

int main(int argc, char **argv)
{
    if (argc < 2) { fprintf(stderr, "usage: gk_sim <dir>\n"); return 2; }
    snprintf(dir, sizeof(dir), "%s", argv[1]);
    for (int i = 2; i < argc; i++) {
        if (!strcmp(argv[i], "--fail-init")) fail_init = 1;
        else if (!strcmp(argv[i], "--assets") && i + 1 < argc) {
            FILE *f = fopen(argv[++i], "rb");
            if (f) { asset_len = (uint32_t)fread(asset, 1, sizeof(asset), f); fclose(f); }
        }
        else if (!strcmp(argv[i], "--fail-get") && i + 1 < argc) snprintf(fail_get_key, sizeof(fail_get_key), "%s", argv[++i]);
    }
    gk_init(&g, &ops);
    static char line[1 << 16];
    while (fgets(line, sizeof(line), stdin)) {
        if (line[0] == 'F' && line[1] == ' ') {
            for (char *p = line + 2; p[0] && p[1] && p[0] != '\n'; p += 2) {
                char h[3] = {p[0], p[1], 0};
                gk_on_byte(&g, (uint8_t)strtoul(h, NULL, 16));
            }
        } else if (line[0] == 'T') {
            clock_ms += (uint32_t)strtoul(line + 2, NULL, 10);
            gk_tick(&g);
        } else if (line[0] == 'B') {
            gk_button_pressed(&g);
        } else if (line[0] == 'R') {
            clock_ms = 0;
            gk_init(&g, &ops);
        } else if (!strncmp(line, "FAILSET", 7)) {
            fail_set_in = atoi(line + 8);
        } else if (!strncmp(line, "CRASHSET", 8)) {
            crash_set_in = atoi(line + 9);
        } else if (line[0] == '?') {
            printf("STATE %d %d %u %u\n", g.state, (g.confirmed ? 4 : 0) | (g.provisioned ? 8 : 0), g.attempts, g.delay_until);
            fflush(stdout);
        }
    }
    return 0;
}
