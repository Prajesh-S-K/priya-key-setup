/* GPKEY device core: Noise sessions, PIN policy, provisioning, privacy button. Portable C (no ESP-IDF includes):
 * the same code runs on the ESP32 and in the host simulator used by the integration tests.
 * Spec: docs/architecture.md sections 3-4. No irreversible security settings are used or required. */
#ifndef GK_CORE_H
#define GK_CORE_H

#include <stddef.h>
#include <stdint.h>
#include <noise/protocol.h>
#include "echo_frame.h"

/* Frame types of the key protocol (same COBS+CRC framing as docs/echo-protocol.md). */
#define GK_T_PAIR_REQ   0x10
#define GK_T_STATUS_REQ 0x11
#define GK_T_HS_NK_1    0x20
#define GK_T_TRANSPORT  0x21
#define GK_T_HS_NX_1    0x22
#define GK_T_ASSET_INFO_REQ 0x12   /* public dashboard assets stored on the board (not secret; the host verifies a signature) */
#define GK_T_ASSET_READ_REQ 0x13   /* payload: offset u32 LE, length u16 LE (<= GK_ASSET_CHUNK) */
#define GK_T_ASSET_INFO 0x92       /* payload: total size u32 LE (0 = no assets) */
#define GK_T_ASSET_DATA 0x93       /* payload: offset u32 LE, then the bytes */
#define GK_ASSET_CHUNK  192
#define GK_T_STATUS     0x90
#define GK_T_HS_2       0xA0
#define GK_T_TRANSPORT_R 0xA1
/* error frames (type 0xFF) payload byte */
#define GK_E_STATE      10
#define GK_E_HANDSHAKE  11
#define GK_E_NO_SESSION 12
#define GK_E_DECRYPT    13
#define GK_E_BAD_FRAME  14

/* transport commands (plaintext inside Noise) */
#define GK_C_AUTH        1
#define GK_C_GET_KEK     2
#define GK_C_HEARTBEAT   3
#define GK_C_CHANGE_PIN  4
#define GK_C_PROV_PIN    5
#define GK_C_PROV_CONFIRM 6
#define GK_C_LOCK        7
#define GK_C_INFO        8
#define GK_C_LOCK_NOTICE 0x84   /* device-initiated, no request */
/* response status byte */
#define GK_S_OK          0
#define GK_S_WRONG_PIN   1
#define GK_S_DELAYED     2
#define GK_S_STORAGE     3
#define GK_S_NOT_READY   4
#define GK_S_BAD_ARG     5
#define GK_S_FORBIDDEN   6

typedef enum {
    GK_EMPTY = 0,
    GK_LOCKED = 1,
    GK_ACTIVE = 2,
    GK_PRIVACY = 3,
    GK_FAIL_CLOSED = 4,
    GK_INCONSISTENT = 5
} gk_state_t;

#define GK_PAIR_WINDOW_MS   30000u
#define GK_HEARTBEAT_TIMEOUT_MS 3000u
#define GK_FREE_ATTEMPTS    3u

typedef struct gk_ops {
    void *ctx;
    int (*store_init)(void *ctx);                                                   /* 0 ok, <0 storage unusable */
    int (*store_get)(void *ctx, const char *key, uint8_t *buf, size_t cap, size_t *len); /* 0 found, 1 absent, <0 error */
    int (*store_set)(void *ctx, const char *key, const uint8_t *buf, size_t len);   /* 0 ONLY if committed and read back */
    void (*random)(void *ctx, uint8_t *buf, size_t n);
    int (*tx)(void *ctx, const uint8_t *data, size_t n);                            /* bytes accepted, <0 error */
    uint32_t (*now_ms)(void *ctx);
    /* optional (NULL = no assets): size of the asset image, and a bounds-checked read from it (0 ok) */
    uint32_t (*asset_size)(void *ctx);
    int (*asset_read)(void *ctx, uint32_t off, uint8_t *buf, size_t n);
} gk_ops_t;

typedef struct {
    uint8_t id_nonce[16];
    uint8_t static_priv[32];
    uint8_t static_pub[32];
    uint8_t k_board[32];
    uint8_t k_pin[32];
    uint8_t pin_salt[16];
    uint8_t pin_verifier[32];
} gk_identity_t;

typedef struct gk {
    const gk_ops_t *ops;
    gk_state_t state;
    int provisioned;            /* identity present */
    int confirmed;
    uint32_t attempts;          /* attempts_since_success, persisted */
    uint32_t generation;
    gk_identity_t id;

    /* pairing window */
    uint32_t pair_wait_until;   /* 0 = not waiting */
    uint32_t pair_auth_until;   /* 0 = not authorized */
    uint8_t pending_priv[32];   /* EMPTY state: keypair generated at authorization, persisted only at PROV_PIN */
    uint8_t pending_pub[32];
    int pending_valid;

    /* session */
    NoiseHandshakeState *hs;
    NoiseCipherState *send, *recv;
    int session_kind;           /* 0 none, 1 NK, 2 NX */
    int authed;
    int privileged_disabled;
    uint32_t last_rx;
    uint32_t delay_until;       /* boot-relative ms; 0 = none */

    /* framing */
    ge_rx_t rx;
    uint8_t raw[GE_MAX_RAW];
    uint8_t wire[GE_MAX_ENCODED + 1];
    uint32_t tx_errors;
} gk_t;

void gk_init(gk_t *g, const gk_ops_t *ops);
void gk_on_byte(gk_t *g, uint8_t b);
void gk_tick(gk_t *g);
void gk_button_pressed(gk_t *g);

/* crypto helpers (HMAC-SHA256 and HKDF-SHA256, RFC 2104 / RFC 5869) exposed for tests */
void gk_hmac_sha256(const uint8_t *key, size_t keylen, const uint8_t *msg, size_t len, uint8_t out[32]);
void gk_hkdf_sha256(const uint8_t *salt, size_t saltlen, const uint8_t *ikm, size_t ikmlen,
                    const uint8_t *info, size_t infolen, uint8_t out[32]);
uint32_t gk_delay_for_attempts(uint32_t attempts_since_success);

#endif
