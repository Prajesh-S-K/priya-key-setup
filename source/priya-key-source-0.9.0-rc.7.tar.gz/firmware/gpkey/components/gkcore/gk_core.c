#include "gk_core.h"
#include <string.h>
#include "crypto/sha2/sha256.h"

#define NK_NAME "Noise_NK_25519_ChaChaPoly_BLAKE2s"
#define NX_NAME "Noise_NX_25519_ChaChaPoly_BLAKE2s"
#define PROLOGUE_NK "GPKEY1|NK"
#define PROLOGUE_NX "GPKEY1|NX"

#define ID_BLOB_LEN 225u   /* 1 + 16 + 32*4 + 16 + 32 + 32 (digest) */
#define ATT_BLOB_LEN 30u

static const uint32_t DELAY_TIERS_MS[] = {5000u, 30000u, 300000u, 1800000u, 1800000u};

uint32_t gk_delay_for_attempts(uint32_t a)
{
    if (a <= GK_FREE_ATTEMPTS) {
        return 0;
    }
    uint32_t i = a - GK_FREE_ATTEMPTS - 1;
    uint32_t last = (uint32_t)(sizeof(DELAY_TIERS_MS) / sizeof(DELAY_TIERS_MS[0])) - 1;
    return DELAY_TIERS_MS[i > last ? last : i];
}

/* ------------------------------------------------------------------------------------------ small helpers */
static void wipe(void *p, size_t n)
{
    volatile uint8_t *v = (volatile uint8_t *)p;
    while (n--) {
        *v++ = 0;
    }
}

static int ct_equal(const uint8_t *a, const uint8_t *b, size_t n)
{
    uint8_t d = 0;
    for (size_t i = 0; i < n; i++) {
        d |= (uint8_t)(a[i] ^ b[i]);
    }
    return d == 0;
}

static void put32(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24); }
static uint32_t get32(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }

static uint32_t now(const gk_t *g) { return g->ops->now_ms(g->ops->ctx); }

static int send_frame(gk_t *g, uint8_t type, uint32_t seq, const uint8_t *payload, size_t len)
{
    size_t n = ge_build_wire(type, seq, payload, len, g->wire);
    if (n == 0) {
        g->tx_errors++;
        return -1;
    }
    int r = g->ops->tx(g->ops->ctx, g->wire, n);
    if (r < 0 || (size_t)r != n) {
        g->tx_errors++;
        return -1;
    }
    return 0;
}

static void send_err(gk_t *g, uint32_t seq, uint8_t code) { send_frame(g, GE_T_ERR_RSP, seq, &code, 1); }

static uint8_t status_flags(const gk_t *g)
{
    uint32_t t = now(g);
    uint8_t f = 0;
    if (g->pair_wait_until && t < g->pair_wait_until) f |= 1;
    if (g->pair_auth_until && t < g->pair_auth_until) f |= 2;
    if (g->confirmed) f |= 4;
    if (g->provisioned) f |= 8;
    return f;
}

static void send_status(gk_t *g, uint32_t seq)
{
    uint8_t p[7];
    p[0] = (uint8_t)g->state;
    p[1] = status_flags(g);
    uint32_t rem = 0;
    if (g->delay_until && now(g) < g->delay_until) rem = g->delay_until - now(g);
    put32(p + 2, rem);
    p[6] = 1; /* protocol version */
    send_frame(g, GK_T_STATUS, seq, p, sizeof(p));
}

/* ------------------------------------------------------------------------------------------ persistence */
static void digest32(const uint8_t *d, size_t n, uint8_t out[32])
{
    sha256_context_t c;
    sha256_reset(&c);
    sha256_update(&c, d, n);
    sha256_finish(&c, out);
}

static void id_serialize(const gk_identity_t *id, uint8_t out[ID_BLOB_LEN])
{
    size_t o = 0;
    out[o++] = 1;
    memcpy(out + o, id->id_nonce, 16); o += 16;
    memcpy(out + o, id->static_priv, 32); o += 32;
    memcpy(out + o, id->static_pub, 32); o += 32;
    memcpy(out + o, id->k_board, 32); o += 32;
    memcpy(out + o, id->k_pin, 32); o += 32;
    memcpy(out + o, id->pin_salt, 16); o += 16;
    memcpy(out + o, id->pin_verifier, 32); o += 32;
    digest32(out, o - 0, out + o);
}

static int id_parse(const uint8_t *in, size_t len, gk_identity_t *id)
{
    if (len != ID_BLOB_LEN || in[0] != 1) return -1;
    uint8_t d[32];
    digest32(in, ID_BLOB_LEN - 32, d);
    if (!ct_equal(d, in + ID_BLOB_LEN - 32, 32)) return -1;
    size_t o = 1;
    memcpy(id->id_nonce, in + o, 16); o += 16;
    memcpy(id->static_priv, in + o, 32); o += 32;
    memcpy(id->static_pub, in + o, 32); o += 32;
    memcpy(id->k_board, in + o, 32); o += 32;
    memcpy(id->k_pin, in + o, 32); o += 32;
    memcpy(id->pin_salt, in + o, 16); o += 16;
    memcpy(id->pin_verifier, in + o, 32);
    return 0;
}

static void att_serialize(const gk_t *g, uint8_t out[ATT_BLOB_LEN])
{
    out[0] = 1;
    memcpy(out + 1, g->id.id_nonce, 16);
    put32(out + 17, g->attempts);
    put32(out + 21, g->generation);
    out[25] = (uint8_t)(g->confirmed ? 1 : 0);
    put32(out + 26, ge_crc32(out, 26));
}

static int att_persist(gk_t *g)
{
    uint8_t b[ATT_BLOB_LEN];
    att_serialize(g, b);
    return g->ops->store_set(g->ops->ctx, "att", b, sizeof(b));
}

static int id_persist(gk_t *g)
{
    uint8_t b[ID_BLOB_LEN];
    id_serialize(&g->id, b);
    int r = g->ops->store_set(g->ops->ctx, "id", b, sizeof(b));
    wipe(b, sizeof(b));
    return r;
}

/* ------------------------------------------------------------------------------------------ sessions */
static void session_clear(gk_t *g)
{
    if (g->hs) { noise_handshakestate_free(g->hs); g->hs = NULL; }
    if (g->send) { noise_cipherstate_free(g->send); g->send = NULL; }
    if (g->recv) { noise_cipherstate_free(g->recv); g->recv = NULL; }
    g->session_kind = 0;
    g->authed = 0;
}

static void lock_to_locked(gk_t *g)
{
    session_clear(g);
    if (g->state == GK_ACTIVE) g->state = GK_LOCKED;
}

static int send_transport(gk_t *g, uint32_t seq, const uint8_t *plain, size_t len)
{
    if (g->send == NULL || len > GE_MAX_PAYLOAD - 16) return -1;
    uint8_t buf[GE_MAX_PAYLOAD];
    memcpy(buf, plain, len);
    NoiseBuffer nb;
    noise_buffer_set_inout(nb, buf, len, sizeof(buf));
    if (noise_cipherstate_encrypt_with_ad(g->send, NULL, 0, &nb) != NOISE_ERROR_NONE) return -1;
    return send_frame(g, GK_T_TRANSPORT_R, seq, nb.data, nb.size);
}

static void reply(gk_t *g, uint32_t seq, uint8_t cmd, uint8_t status, const uint8_t *data, size_t dlen)
{
    uint8_t p[GE_MAX_PAYLOAD - 16];
    if (dlen > sizeof(p) - 2) dlen = sizeof(p) - 2;
    p[0] = (uint8_t)(cmd | 0x80);
    p[1] = status;
    if (dlen) memcpy(p + 2, data, dlen);
    send_transport(g, seq, p, 2 + dlen);
}

static void fail_closed(gk_t *g)
{
    g->state = GK_FAIL_CLOSED;
    g->privileged_disabled = 1;
    g->authed = 0;
}

/* ------------------------------------------------------------------------------------------ init */
void gk_init(gk_t *g, const gk_ops_t *ops)
{
    memset(g, 0, sizeof(*g));
    g->ops = ops;
    ge_rx_init(&g->rx);
    if (ops->store_init(ops->ctx) != 0) {
        g->state = GK_INCONSISTENT;
        return;
    }
    uint8_t buf[ID_BLOB_LEN + 8];
    size_t len = 0;
    int r = ops->store_get(ops->ctx, "id", buf, sizeof(buf), &len);
    if (r < 0) { g->state = GK_INCONSISTENT; return; }
    if (r == 1) { g->state = GK_EMPTY; return; }              /* no identity: stale 'att' is ignored */
    if (id_parse(buf, len, &g->id) != 0) { g->state = GK_INCONSISTENT; return; }
    wipe(buf, sizeof(buf));
    uint8_t ab[ATT_BLOB_LEN + 8];
    size_t alen = 0;
    r = ops->store_get(ops->ctx, "att", ab, sizeof(ab), &alen);
    if (r != 0 || alen != ATT_BLOB_LEN || ab[0] != 1 || ge_crc32(ab, 26) != get32(ab + 26) ||
        !ct_equal(ab + 1, g->id.id_nonce, 16)) {
        g->state = GK_INCONSISTENT;                           /* missing or mismatched counter: never default to zero */
        wipe(&g->id, sizeof(g->id));
        return;
    }
    g->attempts = get32(ab + 17);
    g->generation = get32(ab + 21);
    g->confirmed = ab[25] ? 1 : 0;
    g->provisioned = 1;
    g->state = GK_LOCKED;
    uint32_t d = gk_delay_for_attempts(g->attempts);          /* delay restarts from boot */
    if (d) g->delay_until = now(g) + d;
}

/* ------------------------------------------------------------------------------------------ PIN logic */
/* Write-ahead attempt counter, compare, reset on success. Keys are never released by this function. */
static uint8_t check_pin(gk_t *g, const uint8_t pin[4], uint32_t *delay_out)
{
    *delay_out = 0;
    if (g->state == GK_FAIL_CLOSED || g->state == GK_INCONSISTENT) return GK_S_STORAGE;
    uint32_t t = now(g);
    if (g->delay_until && t < g->delay_until) {
        *delay_out = g->delay_until - t;
        return GK_S_DELAYED;
    }
    for (int i = 0; i < 4; i++) if (pin[i] < '0' || pin[i] > '9') return GK_S_BAD_ARG;
    g->attempts++;
    g->generation++;
    if (att_persist(g) != 0) {                                /* cannot count the guess durably: refuse and fail closed */
        fail_closed(g);
        return GK_S_STORAGE;
    }
    uint8_t m[20], v[32];
    memcpy(m, g->id.pin_salt, 16);
    memcpy(m + 16, pin, 4);
    gk_hmac_sha256(g->id.k_pin, 32, m, 20, v);
    int ok = ct_equal(v, g->id.pin_verifier, 32);
    wipe(m, sizeof(m)); wipe(v, sizeof(v));
    if (!ok) {
        uint32_t d = gk_delay_for_attempts(g->attempts);
        g->delay_until = d ? now(g) + d : 0;
        *delay_out = d;
        return GK_S_WRONG_PIN;
    }
    g->attempts = 0;
    g->generation++;
    if (att_persist(g) != 0) {                                /* success could not be recorded: no keys, fail closed */
        fail_closed(g);
        return GK_S_STORAGE;
    }
    g->delay_until = 0;
    return GK_S_OK;
}

/* ------------------------------------------------------------------------------------------ commands */
static void cmd_auth(gk_t *g, uint32_t seq, const uint8_t *a, size_t n)
{
    if (g->session_kind != 1 || !g->provisioned) { reply(g, seq, GK_C_AUTH, GK_S_NOT_READY, NULL, 0); return; }
    if (g->privileged_disabled || g->state == GK_PRIVACY) { reply(g, seq, GK_C_AUTH, GK_S_FORBIDDEN, NULL, 0); return; }
    if (n != 4) { reply(g, seq, GK_C_AUTH, GK_S_BAD_ARG, NULL, 0); return; }
    uint32_t d;
    uint8_t st = check_pin(g, a, &d);
    if (st == GK_S_OK) { g->authed = 1; g->state = GK_ACTIVE; }
    uint8_t dd[4]; put32(dd, d);
    reply(g, seq, GK_C_AUTH, st, dd, 4);
}

static void cmd_get_kek(gk_t *g, uint32_t seq, const uint8_t *a, size_t n)
{
    if (!g->authed || g->state != GK_ACTIVE || g->privileged_disabled) { reply(g, seq, GK_C_GET_KEK, GK_S_FORBIDDEN, NULL, 0); return; }
    if (n != 16) { reply(g, seq, GK_C_GET_KEK, GK_S_BAD_ARG, NULL, 0); return; }
    uint8_t kek[32];
    static const char info[] = "gp-vault-kek-v1";
    gk_hkdf_sha256(a, 16, g->id.k_board, 32, (const uint8_t *)info, sizeof(info) - 1, kek);
    reply(g, seq, GK_C_GET_KEK, GK_S_OK, kek, 32);
    wipe(kek, sizeof(kek));
}

static void cmd_change_pin(gk_t *g, uint32_t seq, const uint8_t *a, size_t n)
{
    if (!g->authed || g->state != GK_ACTIVE || g->privileged_disabled) { reply(g, seq, GK_C_CHANGE_PIN, GK_S_FORBIDDEN, NULL, 0); return; }
    if (n != 8) { reply(g, seq, GK_C_CHANGE_PIN, GK_S_BAD_ARG, NULL, 0); return; }
    for (int i = 4; i < 8; i++) if (a[i] < '0' || a[i] > '9') { reply(g, seq, GK_C_CHANGE_PIN, GK_S_BAD_ARG, NULL, 0); return; }
    uint32_t d;
    uint8_t st = check_pin(g, a, &d);                          /* the old PIN goes through the same attempt counter */
    if (st == GK_S_OK) {
        uint8_t salt[16], m[20], v[32];
        g->ops->random(g->ops->ctx, salt, 16);
        memcpy(m, salt, 16);
        memcpy(m + 16, a + 4, 4);
        gk_hmac_sha256(g->id.k_pin, 32, m, 20, v);
        gk_identity_t keep = g->id;
        memcpy(g->id.pin_salt, salt, 16);
        memcpy(g->id.pin_verifier, v, 32);
        if (id_persist(g) != 0) {
            g->id = keep;
            wipe(&keep, sizeof(keep));
            fail_closed(g);
            st = GK_S_STORAGE;
        }
        wipe(&keep, sizeof(keep)); wipe(m, sizeof(m)); wipe(v, sizeof(v));
    }
    uint8_t dd[4]; put32(dd, d);
    reply(g, seq, GK_C_CHANGE_PIN, st, dd, 4);
}

static void cmd_prov_pin(gk_t *g, uint32_t seq, const uint8_t *a, size_t n)
{
    if (g->session_kind != 2 || g->state != GK_EMPTY || !g->pending_valid) { reply(g, seq, GK_C_PROV_PIN, GK_S_NOT_READY, NULL, 0); return; }
    if (n != 4) { reply(g, seq, GK_C_PROV_PIN, GK_S_BAD_ARG, NULL, 0); return; }
    for (int i = 0; i < 4; i++) if (a[i] < '0' || a[i] > '9') { reply(g, seq, GK_C_PROV_PIN, GK_S_BAD_ARG, NULL, 0); return; }
    gk_identity_t id;
    memset(&id, 0, sizeof(id));
    g->ops->random(g->ops->ctx, id.id_nonce, 16);
    g->ops->random(g->ops->ctx, id.k_board, 32);
    g->ops->random(g->ops->ctx, id.k_pin, 32);
    g->ops->random(g->ops->ctx, id.pin_salt, 16);
    memcpy(id.static_priv, g->pending_priv, 32);
    memcpy(id.static_pub, g->pending_pub, 32);
    uint8_t m[20];
    memcpy(m, id.pin_salt, 16);
    memcpy(m + 16, a, 4);
    gk_hmac_sha256(id.k_pin, 32, m, 20, id.pin_verifier);
    wipe(m, sizeof(m));
    gk_t shadow = *g;                                           /* persist att FIRST, identity LAST (commit point) */
    shadow.id = id; shadow.attempts = 0; shadow.generation = 0; shadow.confirmed = 0;
    int r = att_persist(&shadow);
    if (r == 0) r = id_persist(&shadow);
    if (r != 0) {
        wipe(&id, sizeof(id)); wipe(&shadow, sizeof(shadow));
        reply(g, seq, GK_C_PROV_PIN, GK_S_STORAGE, NULL, 0);    /* stays EMPTY: nothing durable can be half-provisioned */
        return;
    }
    g->id = id;
    g->attempts = 0; g->generation = 0; g->confirmed = 0; g->provisioned = 1; g->state = GK_LOCKED;
    wipe(&id, sizeof(id)); wipe(&shadow, sizeof(shadow));
    wipe(g->pending_priv, 32); g->pending_valid = 0;
    reply(g, seq, GK_C_PROV_PIN, GK_S_OK, NULL, 0);
}

static void cmd_prov_confirm(gk_t *g, uint32_t seq)
{
    if (!g->authed || g->state != GK_ACTIVE || g->session_kind != 1) { reply(g, seq, GK_C_PROV_CONFIRM, GK_S_FORBIDDEN, NULL, 0); return; }
    if (g->confirmed) { reply(g, seq, GK_C_PROV_CONFIRM, GK_S_OK, NULL, 0); return; }   /* idempotent */
    g->confirmed = 1;
    g->generation++;
    if (att_persist(g) != 0) {
        fail_closed(g);
        reply(g, seq, GK_C_PROV_CONFIRM, GK_S_STORAGE, NULL, 0);
        return;
    }
    reply(g, seq, GK_C_PROV_CONFIRM, GK_S_OK, NULL, 0);
}

static void handle_command(gk_t *g, uint32_t seq, const uint8_t *p, size_t n)
{
    if (n < 1) { reply(g, seq, 0, GK_S_BAD_ARG, NULL, 0); return; }
    const uint8_t *a = p + 1;
    size_t an = n - 1;
    switch (p[0]) {
    case GK_C_AUTH: cmd_auth(g, seq, a, an); break;
    case GK_C_GET_KEK: cmd_get_kek(g, seq, a, an); break;
    case GK_C_HEARTBEAT:
        reply(g, seq, GK_C_HEARTBEAT, (g->authed && g->state == GK_ACTIVE) ? GK_S_OK : GK_S_NOT_READY, NULL, 0);
        break;
    case GK_C_CHANGE_PIN: cmd_change_pin(g, seq, a, an); break;
    case GK_C_PROV_PIN: cmd_prov_pin(g, seq, a, an); break;
    case GK_C_PROV_CONFIRM: cmd_prov_confirm(g, seq); break;
    case GK_C_LOCK:
        reply(g, seq, GK_C_LOCK, GK_S_OK, NULL, 0);
        lock_to_locked(g);
        break;
    case GK_C_INFO: {
        uint8_t d[3] = {(uint8_t)g->state, status_flags(g), 1};
        reply(g, seq, GK_C_INFO, GK_S_OK, d, 3);
        break;
    }
    default: reply(g, seq, p[0], GK_S_BAD_ARG, NULL, 0); break;
    }
}

/* ------------------------------------------------------------------------------------------ handshake */
static void handle_handshake(gk_t *g, uint32_t seq, int kind, const uint8_t *msg, size_t len)
{
    uint32_t t = now(g);
    const uint8_t *priv = NULL;
    if (kind == 1) {                                            /* NK: provisioned, not in privacy, not failed */
        if (!g->provisioned || (g->state != GK_LOCKED && g->state != GK_ACTIVE)) { send_err(g, seq, GK_E_STATE); return; }
        priv = g->id.static_priv;
        if (g->state == GK_ACTIVE) lock_to_locked(g);           /* a new session requires a fresh PIN */
    } else {                                                    /* NX: only inside a physical-presence window */
        if (!(g->pair_auth_until && t < g->pair_auth_until) || (g->state != GK_EMPTY && g->state != GK_LOCKED)) {
            send_err(g, seq, GK_E_STATE);
            return;
        }
        priv = g->state == GK_EMPTY ? g->pending_priv : g->id.static_priv;
        if (g->state == GK_EMPTY && !g->pending_valid) { send_err(g, seq, GK_E_STATE); return; }
        g->pair_auth_until = 0;                                 /* one use */
    }
    session_clear(g);
    NoiseHandshakeState *hs = NULL;
    int rc = noise_handshakestate_new_by_name(&hs, kind == 1 ? NK_NAME : NX_NAME, NOISE_ROLE_RESPONDER);
    if (rc != NOISE_ERROR_NONE) { send_err(g, seq, GK_E_HANDSHAKE); return; }
    const char *pro = kind == 1 ? PROLOGUE_NK : PROLOGUE_NX;
    NoiseDHState *dh = noise_handshakestate_get_local_keypair_dh(hs);
    if (dh == NULL || noise_handshakestate_set_prologue(hs, pro, strlen(pro)) != NOISE_ERROR_NONE ||
        noise_dhstate_set_keypair_private(dh, priv, 32) != NOISE_ERROR_NONE ||
        noise_handshakestate_start(hs) != NOISE_ERROR_NONE) {
        noise_handshakestate_free(hs);
        send_err(g, seq, GK_E_HANDSHAKE);
        return;
    }
    uint8_t in[GE_MAX_PAYLOAD], out[GE_MAX_PAYLOAD], pay[8];
    NoiseBuffer mb, pb;
    int ok = 0;
    for (int guard = 0; guard < 4; guard++) {
        int act = noise_handshakestate_get_action(hs);
        if (act == NOISE_ACTION_READ_MESSAGE) {
            memcpy(in, msg, len);
            noise_buffer_set_input(mb, in, len);
            noise_buffer_set_output(pb, pay, sizeof(pay));
            if (noise_handshakestate_read_message(hs, &mb, &pb) != NOISE_ERROR_NONE) break;
        } else if (act == NOISE_ACTION_WRITE_MESSAGE) {
            noise_buffer_set_output(mb, out, sizeof(out));
            noise_buffer_init(pb);
            if (noise_handshakestate_write_message(hs, &mb, NULL) != NOISE_ERROR_NONE) break;
            if (send_frame(g, GK_T_HS_2, seq, mb.data, mb.size) != 0) break;
        } else if (act == NOISE_ACTION_SPLIT) {
            if (noise_handshakestate_split(hs, &g->send, &g->recv) != NOISE_ERROR_NONE) break;
            ok = 1;
            break;
        } else {
            break;
        }
    }
    noise_handshakestate_free(hs);
    if (!ok) {
        session_clear(g);
        send_err(g, seq, GK_E_HANDSHAKE);
        return;
    }
    g->session_kind = kind;
    g->authed = 0;
    g->last_rx = t;
}

static void handle_transport(gk_t *g, uint32_t seq, const uint8_t *ct, size_t len)
{
    if (g->session_kind == 0 || g->recv == NULL) { send_err(g, seq, GK_E_NO_SESSION); return; }
    if (len < 16 || len > GE_MAX_PAYLOAD) { send_err(g, seq, GK_E_BAD_FRAME); return; }
    uint8_t buf[GE_MAX_PAYLOAD];
    memcpy(buf, ct, len);
    NoiseBuffer nb;
    noise_buffer_set_input(nb, buf, len);
    if (noise_cipherstate_decrypt_with_ad(g->recv, NULL, 0, &nb) != NOISE_ERROR_NONE) {
        lock_to_locked(g);                                      /* any decrypt failure ends the session */
        send_err(g, seq, GK_E_DECRYPT);
        return;
    }
    g->last_rx = now(g);
    handle_command(g, seq, nb.data, nb.size);
    wipe(buf, sizeof(buf));
}

/* ------------------------------------------------------------------------------------------ assets */
static void handle_asset(gk_t *g, uint8_t type, uint32_t seq, const uint8_t *p, size_t len)
{
    if (g->state == GK_PRIVACY || g->state == GK_FAIL_CLOSED || !g->ops->asset_size || !g->ops->asset_read) {
        send_err(g, seq, GK_E_STATE);
        return;
    }
    uint32_t total = g->ops->asset_size(g->ops->ctx);
    if (type == GK_T_ASSET_INFO_REQ) {
        uint8_t o[4] = {(uint8_t)total, (uint8_t)(total >> 8), (uint8_t)(total >> 16), (uint8_t)(total >> 24)};
        send_frame(g, GK_T_ASSET_INFO, seq, o, 4);
        return;
    }
    if (len != 6) { send_err(g, seq, GK_E_BAD_FRAME); return; }
    uint32_t off = (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
    uint32_t n = (uint32_t)p[4] | ((uint32_t)p[5] << 8);
    if (n == 0 || n > GK_ASSET_CHUNK || off > total || n > total - off) { send_err(g, seq, GK_E_BAD_FRAME); return; }
    uint8_t out[4 + GK_ASSET_CHUNK];
    memcpy(out, p, 4);
    if (g->ops->asset_read(g->ops->ctx, off, out + 4, n) != 0) { send_err(g, seq, GK_E_STATE); return; }
    send_frame(g, GK_T_ASSET_DATA, seq, out, 4 + n);
}

/* ------------------------------------------------------------------------------------------ frames */
void gk_on_byte(gk_t *g, uint8_t b)
{
    ge_frame_t f;
    ge_status_t err = GE_OK;
    ge_rx_result_t r = ge_rx_feed(&g->rx, b, g->raw, &f, &err);
    if (r != GE_RX_FRAME) {
        return; /* malformed input is dropped silently (counted inside ge_rx) */
    }
    switch (f.type) {
    case GK_T_STATUS_REQ:
        send_status(g, f.seq);
        break;
    case GK_T_ASSET_INFO_REQ:
    case GK_T_ASSET_READ_REQ:
        handle_asset(g, f.type, f.seq, f.payload, f.len);
        break;
    case GK_T_PAIR_REQ:
        if (g->state == GK_EMPTY || g->state == GK_LOCKED) {
            g->pair_wait_until = now(g) + GK_PAIR_WINDOW_MS;
            send_status(g, f.seq);
        } else {
            send_err(g, f.seq, GK_E_STATE);
        }
        break;
    case GK_T_HS_NK_1:
        handle_handshake(g, f.seq, 1, f.payload, f.len);
        break;
    case GK_T_HS_NX_1:
        handle_handshake(g, f.seq, 2, f.payload, f.len);
        break;
    case GK_T_TRANSPORT:
        handle_transport(g, f.seq, f.payload, f.len);
        break;
    default:
        send_err(g, f.seq, GK_E_BAD_FRAME);
        break;
    }
}

void gk_tick(gk_t *g)
{
    uint32_t t = now(g);
    if (g->pair_wait_until && t >= g->pair_wait_until) g->pair_wait_until = 0;
    if (g->pair_auth_until && t >= g->pair_auth_until) {
        g->pair_auth_until = 0;
        wipe(g->pending_priv, 32);
        g->pending_valid = 0;
    }
    if (g->state == GK_ACTIVE && (uint32_t)(t - g->last_rx) > GK_HEARTBEAT_TIMEOUT_MS) {
        g->privileged_disabled = 1;
        lock_to_locked(g);
        g->privileged_disabled = 0;
    }
}

void gk_button_pressed(gk_t *g)
{
    uint32_t t = now(g);
    switch (g->state) {
    case GK_ACTIVE:
        /* 1. disable privileged commands at once; 2. send LOCK while the transport is live; 3. zeroize; 4. PRIVACY */
        g->privileged_disabled = 1;
        {
            uint8_t n = GK_C_LOCK_NOTICE;
            send_transport(g, 0, &n, 1);
        }
        session_clear(g);
        g->pair_wait_until = 0; g->pair_auth_until = 0;
        g->state = GK_PRIVACY;
        send_status(g, 0);
        break;
    case GK_PRIVACY:
        g->privileged_disabled = 0;
        g->state = GK_LOCKED;
        send_status(g, 0);
        break;
    case GK_EMPTY:
    case GK_LOCKED:
        if (g->pair_wait_until && t < g->pair_wait_until) {
            g->pair_wait_until = 0;
            if (g->state == GK_EMPTY) {
                g->ops->random(g->ops->ctx, g->pending_priv, 32);
                NoiseDHState *dh = NULL;
                if (noise_dhstate_new_by_id(&dh, NOISE_DH_CURVE25519) == NOISE_ERROR_NONE) {
                    if (noise_dhstate_set_keypair_private(dh, g->pending_priv, 32) == NOISE_ERROR_NONE &&
                        noise_dhstate_get_public_key(dh, g->pending_pub, 32) == NOISE_ERROR_NONE) {
                        g->pending_valid = 1;
                    }
                    noise_dhstate_free(dh);
                }
                if (!g->pending_valid) break;
            }
            g->pair_auth_until = t + GK_PAIR_WINDOW_MS;
            send_status(g, 0);
        }
        break;
    default:
        break;
    }
}
