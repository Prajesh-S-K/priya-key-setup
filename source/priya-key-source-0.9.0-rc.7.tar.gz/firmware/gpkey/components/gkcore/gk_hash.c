#include "gk_core.h"
#include <string.h>
#include "crypto/sha2/sha256.h"

void gk_hmac_sha256(const uint8_t *key, size_t keylen, const uint8_t *msg, size_t len, uint8_t out[32])
{
    uint8_t k[64], ipad[64], opad[64], inner[32];
    sha256_context_t c;
    memset(k, 0, sizeof(k));
    if (keylen > 64) {
        sha256_reset(&c); sha256_update(&c, key, keylen); sha256_finish(&c, k);
    } else {
        memcpy(k, key, keylen);
    }
    for (int i = 0; i < 64; i++) { ipad[i] = k[i] ^ 0x36; opad[i] = k[i] ^ 0x5c; }
    sha256_reset(&c); sha256_update(&c, ipad, 64); sha256_update(&c, msg, len); sha256_finish(&c, inner);
    sha256_reset(&c); sha256_update(&c, opad, 64); sha256_update(&c, inner, 32); sha256_finish(&c, out);
}

/* HKDF-SHA256 with a 32-byte output: one expand block (RFC 5869). */
void gk_hkdf_sha256(const uint8_t *salt, size_t saltlen, const uint8_t *ikm, size_t ikmlen,
                    const uint8_t *info, size_t infolen, uint8_t out[32])
{
    uint8_t prk[32];
    uint8_t zero_salt[32] = {0};
    if (salt == NULL || saltlen == 0) { salt = zero_salt; saltlen = 32; }
    gk_hmac_sha256(salt, saltlen, ikm, ikmlen, prk);
    uint8_t buf[256 + 1];
    if (infolen > 256) infolen = 256;
    memcpy(buf, info, infolen);
    buf[infolen] = 0x01;
    gk_hmac_sha256(prk, 32, buf, infolen + 1, out);
}
