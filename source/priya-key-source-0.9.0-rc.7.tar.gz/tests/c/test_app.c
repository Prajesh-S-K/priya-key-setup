/* Host tests for the REAL firmware logic in firmware/m1-echo/main/echo_app.c, driven through a mock of the
 * hardware operations. Covers initialization failure and request dispatch. */
#include <stdio.h>
#include <string.h>
#include "echo_app.h"

static int failures;
#define CHECK(cond, ...) do { if (!(cond)) { failures++; printf("FAIL %s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

typedef struct {
    int fail_install, fail_configure, fail_pins;
    int calls_install, calls_configure, calls_pins, calls_remove, calls_tx;
    char log[64]; size_t log_n;
    int tx_fail_at;          /* 1-based tx call index that fails (returns -1), 0 = never */
    int tx_short_at;         /* 1-based tx call index that is accepted short, 0 = never */
    uint8_t out[8192]; size_t out_n;
    uint32_t uptime;
} mock_t;

static void logc(mock_t *m, char c) { if (m->log_n < sizeof(m->log) - 1) { m->log[m->log_n++] = c; m->log[m->log_n] = 0; } }
static int m_install(void *c) { mock_t *m = c; m->calls_install++; logc(m, 'I'); return m->fail_install ? -1 : 0; }
static int m_config(void *c) { mock_t *m = c; m->calls_configure++; logc(m, 'C'); return m->fail_configure ? -1 : 0; }
static int m_pins(void *c) { mock_t *m = c; m->calls_pins++; logc(m, 'P'); return m->fail_pins ? -1 : 0; }
static void m_remove(void *c) { mock_t *m = c; m->calls_remove++; logc(m, 'R'); }
static int m_tx(void *c, const uint8_t *d, size_t n)
{
    mock_t *m = c;
    m->calls_tx++;
    logc(m, 'T');
    if (m->tx_fail_at == m->calls_tx) { return -1; }
    if (m->tx_short_at == m->calls_tx) {
        size_t k = n > 1 ? n - 1 : 0;
        memcpy(m->out + m->out_n, d, k); m->out_n += k;
        return (int)k;
    }
    memcpy(m->out + m->out_n, d, n); m->out_n += n;
    return (int)n;
}
static uint32_t m_uptime(void *c) { return ((mock_t *)c)->uptime; }

static echo_ops_t ops_for(mock_t *m)
{
    echo_ops_t o = {m, m_install, m_config, m_pins, m_remove, m_tx, m_uptime};
    return o;
}

static void feed_wire(echo_app_t *a, const uint8_t *w, size_t n) { for (size_t i = 0; i < n; i++) echo_app_on_byte(a, w[i]); }

static void feed_frame(echo_app_t *a, uint8_t type, uint32_t seq, const uint8_t *p, size_t n)
{
    uint8_t w[GE_MAX_ENCODED + 1];
    size_t wn = ge_build_wire(type, seq, p, n, w);
    feed_wire(a, w, wn);
}

/* Decode the n-th frame (0-based) written to the mock transmit buffer. Skips a leading 0x00. */
static int frame_at(const mock_t *m, int index, ge_frame_t *f, uint8_t *raw)
{
    size_t i = 0; int k = 0;
    while (i < m->out_n) {
        size_t j = i;
        while (j < m->out_n && m->out[j] != 0) j++;
        if (j == i) { i++; continue; }
        size_t rn = 0;
        /* Chunks that do not decode (for example the remains of a deliberately short write) are skipped. */
        if (ge_cobs_decode(m->out + i, j - i, raw, GE_MAX_RAW, &rn) == GE_OK && ge_parse_raw(raw, rn, f) == GE_OK) {
            if (k == index) return 1;
            k++;
        }
        i = j + 1;
    }
    return 0;
}

static uint32_t rd32(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }

static void test_init_failures(void)
{
    struct { int fi, fc, fp; echo_status_t want; const char *log; int removes; } t[] = {
        {1, 0, 0, ECHO_E_INSTALL, "I",   0},   /* install fails: nothing else runs, nothing to remove */
        {0, 1, 0, ECHO_E_CONFIG,  "ICR", 1},
        {0, 0, 1, ECHO_E_PINS,    "ICPR", 1},
    };
    for (size_t i = 0; i < sizeof(t) / sizeof(t[0]); i++) {
        mock_t m = {0}; echo_app_t a; echo_ops_t o = ops_for(&m);
        m.fail_install = t[i].fi; m.fail_configure = t[i].fc; m.fail_pins = t[i].fp;
        echo_status_t st = echo_app_start(&a, &o);
        CHECK(st == t[i].want, "case %zu status %d want %d", i, st, t[i].want);
        CHECK(strcmp(m.log, t[i].log) == 0, "case %zu call order '%s' want '%s'", i, m.log, t[i].log);
        CHECK(m.calls_remove == t[i].removes, "case %zu remove calls %d", i, m.calls_remove);
        CHECK(m.calls_tx == 0 && m.out_n == 0, "case %zu nothing transmitted", i);
        CHECK(a.running == 0 && a.driver_installed == 0, "case %zu not running", i);
        /* The receive path must be inert after a failed start. */
        uint8_t w[GE_MAX_ENCODED + 1];
        size_t wn = ge_build_wire(GE_T_ECHO_REQ, 1, (const uint8_t *)"x", 1, w);
        feed_wire(&a, w, wn);
        CHECK(m.calls_tx == 0, "case %zu no reply while not running", i);
    }
}

static void test_tx_failures_at_start(void)
{
    /* Leading delimiter rejected. */
    { mock_t m = {0}; echo_app_t a; echo_ops_t o = ops_for(&m); m.tx_fail_at = 1;
      CHECK(echo_app_start(&a, &o) == ECHO_E_TX_DELIM, "delimiter failure status");
      CHECK(m.calls_remove == 1 && a.running == 0 && a.tx_frames == 0, "delimiter failure cleanup"); }
    /* Delimiter accepted short (0 of 1 byte). */
    { mock_t m = {0}; echo_app_t a; echo_ops_t o = ops_for(&m); m.tx_short_at = 1;
      CHECK(echo_app_start(&a, &o) == ECHO_E_TX_DELIM, "short delimiter status");
      CHECK(m.calls_remove == 1 && a.running == 0, "short delimiter cleanup"); }
    /* HELLO fails. */
    { mock_t m = {0}; echo_app_t a; echo_ops_t o = ops_for(&m); m.tx_fail_at = 2;
      CHECK(echo_app_start(&a, &o) == ECHO_E_TX_HELLO, "hello failure status");
      CHECK(m.calls_remove == 1 && a.running == 0 && a.tx_frames == 0 && a.tx_errors == 1, "hello failure: not counted as sent"); }
    /* HELLO short. */
    { mock_t m = {0}; echo_app_t a; echo_ops_t o = ops_for(&m); m.tx_short_at = 2;
      CHECK(echo_app_start(&a, &o) == ECHO_E_TX_HELLO, "short hello status");
      CHECK(a.tx_frames == 0 && a.tx_errors == 1, "short hello not counted"); }
    /* Bad arguments. */
    { echo_app_t a; mock_t m = {0}; echo_ops_t o = ops_for(&m); o.tx = NULL;
      CHECK(echo_app_start(&a, &o) == ECHO_E_ARG, "null op rejected");
      CHECK(echo_app_start(&a, NULL) == ECHO_E_ARG, "null ops rejected"); }
}

static void test_dispatch(void)
{
    mock_t m = {0}; echo_app_t a; echo_ops_t o = ops_for(&m);
    m.uptime = 1234;
    CHECK(echo_app_start(&a, &o) == ECHO_OK && a.running == 1, "start ok");
    CHECK(strcmp(m.log, "ICPTT") == 0, "start order '%s'", m.log);
    CHECK(a.tx_frames == 1, "HELLO counted once");

    ge_frame_t f; uint8_t raw[GE_MAX_RAW];
    CHECK(frame_at(&m, 0, &f, raw) && f.type == GE_T_HELLO && f.seq == 0 && f.len == GE_INFO_LEN, "HELLO frame");
    CHECK(rd32(f.payload + 3) == 1234 && rd32(f.payload + 31) == 0, "HELLO uptime and tx_frames");

    /* ECHO */
    uint8_t p[256]; for (int i = 0; i < 256; i++) p[i] = (uint8_t)(i * 7);
    p[10] = 0; p[11] = 0;
    feed_frame(&a, GE_T_ECHO_REQ, 0xA0B0C0D0u, p, 256);
    CHECK(frame_at(&m, 1, &f, raw) && f.type == GE_T_ECHO_RSP && f.seq == 0xA0B0C0D0u && f.len == 256 &&
          memcmp(f.payload, p, 256) == 0, "echo of maximum payload with zeros");
    feed_frame(&a, GE_T_ECHO_REQ, 5, NULL, 0);
    CHECK(frame_at(&m, 2, &f, raw) && f.type == GE_T_ECHO_RSP && f.seq == 5 && f.len == 0, "echo of empty payload");

    /* INFO reflects counters and counts only prior successful transmissions */
    feed_frame(&a, GE_T_INFO_REQ, 9, NULL, 0);
    CHECK(frame_at(&m, 3, &f, raw) && f.type == GE_T_INFO_RSP && f.seq == 9 && f.len == GE_INFO_LEN, "INFO response");
    CHECK(f.payload[0] == 1 && f.payload[1] == 0 && f.payload[2] == 1, "INFO proto_ver and max_payload 256");
    CHECK(rd32(f.payload + 7) == 3, "rx_ok counts the 3 valid requests, got %u", rd32(f.payload + 7));
    CHECK(rd32(f.payload + 31) == 3, "tx_frames before INFO = HELLO + 2 echoes, got %u", rd32(f.payload + 31));

    /* Unknown type, version, flags -> ERR_RSP with the trusted seq */
    feed_frame(&a, 0x7E, 0x11, NULL, 0);
    CHECK(frame_at(&m, 4, &f, raw) && f.type == GE_T_ERR_RSP && f.seq == 0x11 && f.len == 1 && f.payload[0] == GE_ERR_TYPE, "ERR type");
    uint8_t rawf[GE_MAX_RAW], enc[GE_MAX_ENCODED + 1];
    size_t rn = ge_build_raw(2, GE_T_ECHO_REQ, 0, 0x22, (const uint8_t *)"v", 1, rawf);
    size_t en = ge_cobs_encode(rawf, rn, enc); enc[en] = 0; feed_wire(&a, enc, en + 1);
    CHECK(frame_at(&m, 5, &f, raw) && f.type == GE_T_ERR_RSP && f.seq == 0x22 && f.payload[0] == GE_ERR_VERSION, "ERR version");
    rn = ge_build_raw(1, GE_T_ECHO_REQ, 1, 0x33, (const uint8_t *)"f", 1, rawf);
    en = ge_cobs_encode(rawf, rn, enc); enc[en] = 0; feed_wire(&a, enc, en + 1);
    CHECK(frame_at(&m, 6, &f, raw) && f.type == GE_T_ERR_RSP && f.seq == 0x33 && f.payload[0] == GE_ERR_FLAGS, "ERR flags");

    /* Malformed input never produces a reply */
    size_t before = m.out_n;
    const uint8_t garbage[] = {'g', 'a', 'r', 'b', 'a', 'g', 'e', 0};
    feed_wire(&a, garbage, sizeof(garbage));
    rn = ge_build_raw(1, GE_T_ECHO_REQ, 0, 0x44, (const uint8_t *)"corrupt", 7, rawf);
    rawf[10] ^= 1;
    en = ge_cobs_encode(rawf, rn, enc); enc[en] = 0; feed_wire(&a, enc, en + 1);
    uint8_t big[600]; memset(big, 0x55, sizeof(big)); big[599] = 0; feed_wire(&a, big, sizeof(big));
    CHECK(m.out_n == before, "garbage, bad CRC and oversize produce no reply");
    feed_frame(&a, GE_T_ECHO_REQ, 0x55, (const uint8_t *)"after", 5);
    CHECK(frame_at(&m, 7, &f, raw) && f.type == GE_T_ECHO_RSP && f.seq == 0x55, "clean echo after garbage");
    feed_frame(&a, GE_T_INFO_REQ, 0x56, NULL, 0);
    CHECK(frame_at(&m, 8, &f, raw), "INFO after negatives");
    CHECK(rd32(f.payload + 11) == 1 && rd32(f.payload + 15) == 1 && rd32(f.payload + 23) == 1,
          "counters cobs=%u crc=%u oversize=%u", rd32(f.payload + 11), rd32(f.payload + 15), rd32(f.payload + 23));
}

static void test_tx_accounting(void)
{
    mock_t m = {0}; echo_app_t a; echo_ops_t o = ops_for(&m);
    CHECK(echo_app_start(&a, &o) == ECHO_OK, "start");
    uint32_t base = a.tx_frames;
    CHECK(base == 1, "HELLO counted");

    m.tx_fail_at = m.calls_tx + 1;                         /* next transmission fails */
    feed_frame(&a, GE_T_ECHO_REQ, 1, (const uint8_t *)"a", 1);
    CHECK(a.tx_frames == base && a.tx_errors == 1, "failed send not counted: tx=%u err=%u", a.tx_frames, a.tx_errors);

    m.tx_short_at = m.calls_tx + 1;                        /* next one is accepted short */
    feed_frame(&a, GE_T_ECHO_REQ, 2, (const uint8_t *)"b", 1);
    CHECK(a.tx_frames == base && a.tx_errors == 2, "short send not counted: tx=%u err=%u", a.tx_frames, a.tx_errors);

    for (int i = 0; i < 10; i++) feed_frame(&a, GE_T_ECHO_REQ, 100 + i, (const uint8_t *)"ok", 2);
    CHECK(a.tx_frames == base + 10 && a.tx_errors == 2, "successful sends counted exactly: tx=%u", a.tx_frames);

    /* INFO reports only successful transmissions. */
    feed_frame(&a, GE_T_INFO_REQ, 200, NULL, 0);
    ge_frame_t f; uint8_t raw[GE_MAX_RAW];
    int found = 0;
    for (int k = 0; k < 40 && !found; k++) {
        if (frame_at(&m, k, &f, raw) && f.type == GE_T_INFO_RSP && f.seq == 200) found = 1;
    }
    CHECK(found && rd32(f.payload + 31) == base + 10, "INFO tx_frames = %u", found ? rd32(f.payload + 31) : 0);
}

static void test_uart_events(void)
{
    mock_t m = {0}; echo_app_t a; echo_ops_t o = ops_for(&m);
    CHECK(echo_app_start(&a, &o) == ECHO_OK, "start");
    /* Half a frame, then a FIFO overflow: the partial frame is discarded until the next delimiter. */
    uint8_t w[GE_MAX_ENCODED + 1];
    size_t wn = ge_build_wire(GE_T_ECHO_REQ, 7, (const uint8_t *)"abcdef", 6, w);
    feed_wire(&a, w, wn / 2);
    echo_app_on_uart_error(&a, 1);
    feed_wire(&a, w + wn / 2, wn - wn / 2);               /* rest of the old frame including its delimiter */
    size_t before = m.out_n;
    CHECK(a.uart_err == 1 && a.rx.c.oversize == 1, "overflow recorded: uart_err=%u oversize=%u", a.uart_err, a.rx.c.oversize);
    feed_frame(&a, GE_T_ECHO_REQ, 8, (const uint8_t *)"next", 4);
    ge_frame_t f; uint8_t raw[GE_MAX_RAW];
    CHECK(m.out_n > before, "next frame answered after overflow");
    int ok = 0;
    for (int k = 0; k < 10; k++) { if (frame_at(&m, k, &f, raw) && f.type == GE_T_ECHO_RSP && f.seq == 8) ok = 1; }
    CHECK(ok, "echo for seq 8 after overflow");
    /* A frame error event is counted but does not disturb the stream. */
    echo_app_on_uart_error(&a, 0);
    CHECK(a.uart_err == 2, "non-overflow error counted");
}

int main(void)
{
    test_init_failures();
    test_tx_failures_at_start();
    test_dispatch();
    test_tx_accounting();
    test_uart_events();
    if (failures) { printf("%d failure(s)\n", failures); return 1; }
    printf("C app tests passed\n");
    return 0;
}
