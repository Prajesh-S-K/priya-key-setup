/* Host test for firmware/m1-echo/main/echo_frame.c. Compiled and run on the Mac (no board).
 * Checks the C implementation against the Python reference through generated vectors. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "echo_frame.h"
#include "vectors.h"

static int failures;
#define CHECK(cond, ...) do { if (!(cond)) { failures++; printf("FAIL %s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

static void test_crc(void)
{
    CHECK(ge_crc32((const uint8_t *)"", 0) == 0x00000000u, "crc empty");
    CHECK(ge_crc32((const uint8_t *)"a", 1) == 0xE8B7BE43u, "crc a");
    CHECK(ge_crc32((const uint8_t *)"123456789", 9) == 0xCBF43926u, "crc check value");
    const char *fox = "The quick brown fox jumps over the lazy dog";
    CHECK(ge_crc32((const uint8_t *)fox, strlen(fox)) == 0x414FA339u, "crc fox");
    const uint8_t z[4] = {0, 0, 0, 0};
    CHECK(ge_crc32(z, 4) == 0x2144DF1Cu, "crc zeros");
}

static void test_cobs_vectors(void)
{
    struct { const uint8_t raw[4]; size_t rn; const uint8_t enc[6]; size_t en; } v[] = {
        {{0x00}, 1, {0x01, 0x01}, 2},
        {{0x00, 0x00}, 2, {0x01, 0x01, 0x01}, 3},
        {{0x00, 0x11, 0x00}, 3, {0x01, 0x02, 0x11, 0x01}, 4},
        {{0x11, 0x22, 0x00, 0x33}, 4, {0x03, 0x11, 0x22, 0x02, 0x33}, 5},
        {{0x11, 0x22, 0x33, 0x44}, 4, {0x05, 0x11, 0x22, 0x33, 0x44}, 5},
        {{0x11, 0x00, 0x00, 0x00}, 4, {0x02, 0x11, 0x01, 0x01, 0x01}, 5},
    };
    for (size_t i = 0; i < sizeof(v) / sizeof(v[0]); i++) {
        uint8_t enc[16], dec[16];
        size_t en = ge_cobs_encode(v[i].raw, v[i].rn, enc), dn = 0;
        CHECK(en == v[i].en && memcmp(enc, v[i].enc, en) == 0, "cobs encode vector %zu", i);
        CHECK(ge_cobs_decode(enc, en, dec, sizeof(dec), &dn) == GE_OK && dn == v[i].rn && memcmp(dec, v[i].raw, dn) == 0,
              "cobs decode vector %zu", i);
    }
    uint8_t one;
    size_t n = ge_cobs_encode(&one, 0, &one);
    CHECK(n == 1 && one == 0x01, "cobs empty");
}

static void test_cobs_roundtrip(void)
{
    uint32_t s = 12345;
    for (size_t n = 0; n <= 520; n++) {
        for (int pat = 0; pat < 3; pat++) {
            uint8_t raw[520], enc[520 + 4], dec[520];
            for (size_t i = 0; i < n; i++) {
                s = s * 1664525u + 1013904223u;
                raw[i] = pat == 0 ? (uint8_t)(s >> 24) : pat == 1 ? 0 : (uint8_t)(1 + (s >> 24) % 255);
            }
            size_t en = ge_cobs_encode(raw, n, enc), dn = 0;
            CHECK(en <= n + n / 254 + 1, "bound n=%zu", n);
            for (size_t i = 0; i < en; i++) {
                CHECK(enc[i] != 0, "zero in encoding n=%zu", n);
            }
            CHECK(ge_cobs_decode(enc, en, dec, sizeof(dec), &dn) == GE_OK && dn == n && memcmp(dec, raw, n) == 0,
                  "roundtrip n=%zu pat=%d", n, pat);
        }
    }
}

static void test_valid_vectors(void)
{
    for (size_t i = 0; i < N_VALID; i++) {
        uint8_t wire[GE_MAX_ENCODED + 1];
        size_t wn = ge_build_wire(VALID[i].type, VALID[i].seq, VALID[i].payload, VALID[i].plen, wire);
        CHECK(wn == VALID[i].wlen && memcmp(wire, VALID[i].wire, wn) == 0, "wire parity vector %zu", i);
        ge_rx_t rx;
        ge_rx_init(&rx);
        uint8_t scratch[GE_MAX_RAW];
        ge_frame_t f;
        ge_status_t err;
        ge_rx_result_t r = GE_RX_NONE;
        for (size_t k = 0; k < VALID[i].wlen; k++) {
            r = ge_rx_feed(&rx, VALID[i].wire[k], scratch, &f, &err);
        }
        CHECK(r == GE_RX_FRAME && f.type == VALID[i].type && f.seq == VALID[i].seq && f.len == VALID[i].plen &&
              (f.len == 0 || memcmp(f.payload, VALID[i].payload, f.len) == 0), "parse parity vector %zu", i);
    }
}

static int status_to_code(ge_status_t s)
{
    switch (s) {
    case GE_E_COBS: return 1;
    case GE_E_LENGTH: return 2;
    case GE_E_CRC: return 3;
    case GE_E_VERSION: return 4;
    case GE_E_FLAGS: return 5;
    default: return -1;
    }
}

static void test_chunk_vectors(void)
{
    for (size_t i = 0; i < N_CHUNKS; i++) {
        ge_rx_t rx;
        ge_rx_init(&rx);
        uint8_t scratch[GE_MAX_RAW];
        ge_frame_t f;
        ge_status_t err = GE_OK;
        ge_rx_result_t r = GE_RX_NONE;
        for (size_t k = 0; k < CHUNKS[i].len; k++) {
            r = ge_rx_feed(&rx, CHUNKS[i].data[k], scratch, &f, &err);
            CHECK(r == GE_RX_NONE, "chunk %zu emitted before delimiter", i);
        }
        r = ge_rx_feed(&rx, 0x00, scratch, &f, &err);
        int got = (r == GE_RX_FRAME) ? 0 : (r == GE_RX_ERROR ? status_to_code(err) : -9);
        CHECK(got == CHUNKS[i].expect, "chunk %zu: C=%d Python=%d", i, got, CHUNKS[i].expect);
    }
}

static void test_stream_behaviour(void)
{
    uint8_t scratch[GE_MAX_RAW];
    ge_frame_t f;
    ge_status_t err;
    ge_rx_t rx;

    /* Oversize input, then a good frame: one oversize error, then the frame. */
    ge_rx_init(&rx);
    for (size_t i = 0; i < 5000; i++) {
        CHECK(ge_rx_feed(&rx, 0x55, scratch, &f, &err) == GE_RX_NONE, "oversize accumulation");
    }
    CHECK(rx.n <= GE_MAX_ENCODED, "buffer never exceeds the limit");
    CHECK(ge_rx_feed(&rx, 0x00, scratch, &f, &err) == GE_RX_ERROR && err == GE_E_OVERSIZE, "oversize reported");
    uint8_t wire[GE_MAX_ENCODED + 1];
    size_t wn = ge_build_wire(GE_T_ECHO_REQ, 42, (const uint8_t *)"ok", 2, wire);
    ge_rx_result_t r = GE_RX_NONE;
    for (size_t i = 0; i < wn; i++) {
        r = ge_rx_feed(&rx, wire[i], scratch, &f, &err);
    }
    CHECK(r == GE_RX_FRAME && f.seq == 42, "frame after oversize");
    CHECK(rx.c.oversize == 1 && rx.c.ok == 1, "counters");

    /* Exactly the maximum encoded size is not oversize. */
    ge_rx_init(&rx);
    for (size_t i = 0; i < GE_MAX_ENCODED; i++) {
        ge_rx_feed(&rx, 0x55, scratch, &f, &err);
    }
    r = ge_rx_feed(&rx, 0x00, scratch, &f, &err);
    CHECK(r == GE_RX_ERROR && err != GE_E_OVERSIZE, "max-size chunk is decoded, not oversize");

    /* Empty delimiters are ignored. */
    ge_rx_init(&rx);
    CHECK(ge_rx_feed(&rx, 0x00, scratch, &f, &err) == GE_RX_NONE, "idle delimiter");

    /* Boot text, delimiter, frame. */
    ge_rx_init(&rx);
    const char *boot = "ets Jun  8 2016 00:22:57\r\nrst:0x1 (POWERON_RESET),boot:0x13\r\n";
    int errors = 0, frames = 0;
    for (size_t i = 0; boot[i]; i++) {
        ge_rx_feed(&rx, (uint8_t)boot[i], scratch, &f, &err);
    }
    r = ge_rx_feed(&rx, 0x00, scratch, &f, &err);
    errors += (r == GE_RX_ERROR);
    wn = ge_build_wire(GE_T_HELLO, 0, (const uint8_t *)"x", 1, wire);
    for (size_t i = 0; i < wn; i++) {
        r = ge_rx_feed(&rx, wire[i], scratch, &f, &err);
        frames += (r == GE_RX_FRAME);
    }
    CHECK(errors == 1 && frames == 1, "boot text then frame: errors=%d frames=%d", errors, frames);
}

int main(void)
{
    test_crc();
    test_cobs_vectors();
    test_cobs_roundtrip();
    test_valid_vectors();
    test_chunk_vectors();
    test_stream_behaviour();
    if (failures) {
        printf("%d failure(s)\n", failures);
        return 1;
    }
    printf("C framing tests passed (%zu valid vectors, %zu chunk vectors)\n", (size_t)N_VALID, (size_t)N_CHUNKS);
    return 0;
}
