/* Drives the real firmware logic (echo_app.c) from a script on stdin and prints everything it transmits as hex.
 * Used by tests/test_firmware_parity.py to compare against the Python FakeDevice model.
 * Input lines: "D <hex>" feed bytes, "E" UART error, "O" UART overflow. Uptime is fixed at 1234 ms. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "echo_app.h"

static uint8_t out[1 << 20];
static size_t out_n;

static int m_ok(void *c) { (void)c; return 0; }
static void m_remove(void *c) { (void)c; }
static int m_tx(void *c, const uint8_t *d, size_t n) { (void)c; memcpy(out + out_n, d, n); out_n += n; return (int)n; }
static uint32_t m_up(void *c) { (void)c; return 1234; }

int main(void)
{
    echo_ops_t ops = {NULL, m_ok, m_ok, m_ok, m_remove, m_tx, m_up};
    static echo_app_t app;
    if (echo_app_start(&app, &ops) != ECHO_OK) return 2;
    char line[1 << 16];
    while (fgets(line, sizeof(line), stdin)) {
        if (line[0] == 'E') { echo_app_on_uart_error(&app, 0); continue; }
        if (line[0] == 'O') { echo_app_on_uart_error(&app, 1); continue; }
        if (line[0] == 'D') {
            for (char *p = line + 2; p[0] && p[1] && p[0] != '\n'; p += 2) {
                char h[3] = {p[0], p[1], 0};
                echo_app_on_byte(&app, (uint8_t)strtoul(h, NULL, 16));
            }
        }
    }
    for (size_t i = 0; i < out_n; i++) printf("%02x", out[i]);
    printf("\n");
    return 0;
}
