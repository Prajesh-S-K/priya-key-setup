"""Reference MODEL of the journal-replay / garbage-collection policy (architecture section 5.5.6).

This is NOT vault storage and shares no code with a future implementation. It is a small executable
specification used to test the carried-forward policy before any storage code exists:

  P1. A journal record may reference only chunks that are live or written by the same transaction.
  P2. Replay rebuilds state from records alone and never checks that historical chunk references still
      exist. Only references that are live in the final state (current roots, version store, tombstones)
      are validated, and a missing live chunk is corruption.
  P3. GC keeps every chunk reachable from the final state AND from every retained checkpoint snapshot.
  P4. Version retention is deterministic: the last VERSION_KEEP roots per file, in commit order.
"""
import random
import unittest

VERSION_KEEP = 3


class Corruption(Exception):
    pass


class State:
    def __init__(self):
        self.versions = {}      # file -> list of roots (tuple of chunk ids), newest last, max VERSION_KEEP
        self.tombstones = {}    # file -> list of roots retained after delete

    def copy(self):
        s = State()
        s.versions = {k: list(v) for k, v in self.versions.items()}
        s.tombstones = {k: list(v) for k, v in self.tombstones.items()}
        return s

    def live_chunks(self):
        out = set()
        for roots in list(self.versions.values()) + list(self.tombstones.values()):
            for root in roots:
                out.update(root)
        return out

    def apply(self, rec):
        op, f = rec["op"], rec["file"]
        if op == "put":
            vs = self.versions.setdefault(f, [])
            vs.append(rec["root"])
            del vs[:-VERSION_KEEP]
        elif op == "delete":
            vs = self.versions.pop(f, [])
            if vs:
                self.tombstones.setdefault(f, []).extend(vs)
        elif op == "restore":
            vs = self.versions.setdefault(f, [])
            vs.append(rec["root"])
            del vs[:-VERSION_KEEP]
        elif op == "purge":
            self.tombstones.pop(f, None)


class Model:
    def __init__(self):
        self.journal = []
        self.store = set()          # chunk ids that physically exist
        self.state = State()
        self.next_chunk = 0
        self.checkpoints = []       # list of State snapshots (retained: newest two)

    # ---- writes (P1 enforced here)
    def put(self, f, n_chunks, reuse=()):
        live = self.state.live_chunks()
        for cid in reuse:
            if cid not in live or cid not in self.store:
                raise ValueError(f"P1 violated: record references non-live chunk {cid}")
        new = [self.next_chunk + i for i in range(n_chunks)]
        self.next_chunk += n_chunks
        self.store.update(new)                       # data first
        self._commit({"op": "put", "file": f, "root": tuple(list(reuse) + new)})

    def delete(self, f):
        if f in self.state.versions:
            self._commit({"op": "delete", "file": f})

    def restore(self, f):
        # Restore the oldest retained tombstoned or versioned root as the new current root.
        roots = self.state.versions.get(f) or self.state.tombstones.get(f)
        if roots:
            self._commit({"op": "restore", "file": f, "root": roots[0]})

    def purge(self, f):
        if f in self.state.tombstones:
            self._commit({"op": "purge", "file": f})

    def _commit(self, rec):
        self.journal.append(rec)
        self.state.apply(rec)

    def checkpoint(self):
        self.checkpoints.append(self.state.copy())
        del self.checkpoints[:-2]                    # C_new and C_old

    # ---- GC (P3)
    def reachable(self, include_snapshots=True):
        keep = set(self.state.live_chunks())
        if include_snapshots:
            for ck in self.checkpoints:
                keep |= ck.live_chunks()
        return keep

    def gc(self, include_snapshots=True):
        self.store &= self.reachable(include_snapshots)


def replay(journal):
    """P2: rebuild state from records only; no chunk-existence checks here."""
    s = State()
    for rec in journal:
        s.apply(rec)
    return s


def validate_live(state, store):
    for f, roots in state.versions.items():
        for root in roots:
            for cid in root:
                if cid not in store:
                    raise Corruption(f"live chunk {cid} of {f} missing")
    for f, roots in state.tombstones.items():
        for root in roots:
            for cid in root:
                if cid not in store:
                    raise Corruption(f"tombstoned chunk {cid} of {f} missing")


def run_random(seed, steps=400):
    rng = random.Random(seed)
    m = Model()
    files = ["a", "b", "c", "d"]
    for _ in range(steps):
        r = rng.random()
        f = rng.choice(files)
        if r < 0.45:
            live = sorted(m.state.live_chunks())
            reuse = tuple(rng.sample(live, k=min(len(live), rng.randrange(0, 3)))) if live else ()
            m.put(f, rng.randrange(1, 4), reuse)
        elif r < 0.60:
            m.delete(f)
        elif r < 0.70:
            m.restore(f)
        elif r < 0.78:
            m.purge(f)
        elif r < 0.88:
            m.checkpoint()
        else:
            m.gc()
    return m


class ReplayPolicyModelTests(unittest.TestCase):
    def test_journal_only_replay_matches_live_state_after_gc(self):
        for seed in range(60):
            m = run_random(seed)
            m.gc()
            rebuilt = replay(m.journal)
            self.assertEqual(rebuilt.versions, m.state.versions, seed)
            self.assertEqual(rebuilt.tombstones, m.state.tombstones, seed)
            validate_live(rebuilt, m.store)          # P2: only live references are checked

    def test_historical_references_are_dangling_yet_replay_succeeds(self):
        dangling_seen = 0
        for seed in range(60):
            m = run_random(seed)
            m.gc(include_snapshots=False)
            all_refs = {cid for rec in m.journal if "root" in rec for cid in rec["root"]}
            dangling = all_refs - m.store
            dangling_seen += bool(dangling)
            validate_live(replay(m.journal), m.store)     # still fine
        self.assertGreater(dangling_seen, 10, "scenario must actually exercise dangling historical references")

    def test_missing_live_chunk_is_corruption(self):
        m = run_random(7)
        m.gc()
        live = sorted(m.state.live_chunks())
        self.assertTrue(live)
        m.store.discard(live[0])
        with self.assertRaises(Corruption):
            validate_live(replay(m.journal), m.store)

    def test_missing_garbage_chunk_is_not_corruption(self):
        m = run_random(11)
        garbage = m.store - m.reachable()
        if not garbage:
            m.put("zz", 2)
            m.put("zz", 2)
            m.put("zz", 2)
            m.put("zz", 2)         # pushes the first version out of retention
            m.checkpoint()
            m.checkpoint()
            m.checkpoint()
            m.put("zz", 1)
            m.put("zz", 1)
            m.put("zz", 1)
            garbage = {c for c in range(m.next_chunk) if c in m.store and c not in m.reachable()}
        self.assertTrue(garbage)
        m.store -= garbage
        validate_live(replay(m.journal), m.store)

    def test_p1_rejects_references_to_dead_chunks(self):
        m = Model()
        m.put("a", 1)
        for _ in range(4):
            m.put("a", 1)                          # first version leaves retention
        m.checkpoint(); m.checkpoint(); m.checkpoint()
        for _ in range(3):
            m.put("a", 1)
        m.gc()
        self.assertNotIn(0, m.store)
        with self.assertRaises(ValueError):
            m.put("b", 1, reuse=(0,))              # chunk 0 is dead

    def test_snapshot_referenced_chunks_survive_gc(self):
        survived = 0
        for seed in range(60):
            m = run_random(seed)
            m.gc(include_snapshots=True)
            for ck in m.checkpoints:
                self.assertTrue(ck.live_chunks() <= m.store, seed)
                survived += bool(ck.live_chunks() - m.state.live_chunks())
        self.assertGreater(survived, 5, "scenario must include snapshot-only chunks")

    def test_ignoring_snapshots_in_gc_breaks_snapshot_readability(self):
        broken = 0
        for seed in range(60):
            m = run_random(seed)
            m.gc(include_snapshots=False)
            for ck in m.checkpoints:
                broken += not (ck.live_chunks() <= m.store)
        self.assertGreater(broken, 0, "demonstrates why P3 includes retained snapshots")

    def test_replay_is_deterministic(self):
        m = run_random(3)
        a, b = replay(m.journal), replay(list(m.journal))
        self.assertEqual((a.versions, a.tombstones), (b.versions, b.tombstones))


if __name__ == "__main__":
    unittest.main()
