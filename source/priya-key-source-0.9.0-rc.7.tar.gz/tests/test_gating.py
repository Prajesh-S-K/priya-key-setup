"""Tests for the board-command gates. All inputs are SYNTHETIC fixtures built from the output formats found in the
esptool 5.3.1 and espefuse 5.3.1 sources; none was captured from a board. No serial port is opened."""
import copy
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOOLS = os.path.join(ROOT, "tools")
sys.path.insert(0, TOOLS)
import check_identification as CI  # noqa: E402
import plan_flash as PF  # noqa: E402

MAC = "24:6f:28:aa:bb:cc"

CHIP_OK = ("esptool v5.3.1\nConnected to ESP32 on /dev/cu.usbserial-10:\n"
           "Chip type:          ESP32-D0WD-V3 (revision v3.1)\nFeatures:           Wi-Fi, BT, Dual Core\n")
FLASH_OK = "esptool v5.3.1\nConnected to ESP32 on /dev/cu.usbserial-10:\nManufacturer: 20\nDevice: 4016\nDetected flash size: 4MB\n"
MAC_OK = f"esptool v5.3.1\nConnected to ESP32 on /dev/cu.usbserial-10:\nMAC:                {MAC}\n"
EFUSE_CONSOLE = "espefuse v5.3.1\nSaving eFuse values to step-efuse_summary.json\n"


def rd(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def jl(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def fuse(value, readable=True):
    return {"name": "x", "value": value, "readable": readable, "writeable": True}


FUSES_OK = {
    "FLASH_CRYPT_CNT": fuse(0), "ABS_DONE_0": fuse(False), "ABS_DONE_1": fuse(False),
    "UART_DOWNLOAD_DIS": fuse(False), "DISABLE_DL_ENCRYPT": fuse(False), "DISABLE_DL_DECRYPT": fuse(False),
    "DISABLE_DL_CACHE": fuse(False), "JTAG_DISABLE": fuse(False), "RD_DIS": fuse(0), "WR_DIS": fuse(0),
    "MAC": fuse(f"{MAC} (OK)"), "CONSOLE_DEBUG_DISABLE": fuse(True),
}


def write(d, name, text, mode=0o600):
    with open(os.path.join(d, name), "w") as fh:
        fh.write(text)


def make_dir(chip=CHIP_OK, flash=FLASH_OK, mac=MAC_OK, fuses=None, rcs=None, outputs=None, skip=()):
    d = tempfile.mkdtemp()
    fuses = FUSES_OK if fuses is None else fuses
    texts = {"chip_id": chip, "flash_id": flash, "read_mac": mac, "efuse_summary": EFUSE_CONSOLE}
    texts.update(outputs or {})
    for name, text in texts.items():
        if name in skip:
            continue
        write(d, f"step-{name}.txt", text)
        write(d, f"step-{name}.rc", str((rcs or {}).get(name, 0)))
    if fuses is not False and "efuse_json" not in skip:
        write(d, "step-efuse_summary.json", fuses if isinstance(fuses, str) else json.dumps(fuses))
    return d


def codes(d):
    return {c for c, _ in CI.evaluate(d).stops}


class IdentificationChecks(unittest.TestCase):
    def test_pass_case_and_derived_values(self):
        res = CI.evaluate(make_dir())
        self.assertTrue(res.passed, res.stops)
        self.assertEqual(res.data["flash_bytes"], 4 * 1024 * 1024)
        self.assertEqual(res.data["mac"], MAC)
        self.assertEqual(res.data["revision"], "v3.1")

    def stop_case(self, expected, **kw):
        d = make_dir(**kw)
        self.assertIn(expected, codes(d), CI.evaluate(d).stops)
        self.assertFalse(CI.evaluate(d).passed)

    def with_fuse(self, **changes):
        f = copy.deepcopy(FUSES_OK)
        for k, v in changes.items():
            f[k] = v
        return f

    def test_failed_or_missing_steps_stop(self):
        self.stop_case("STEP_FAILED", rcs={"chip_id": 2})
        self.stop_case("STEP_FAILED", rcs={"efuse_summary": 1})
        self.stop_case("STEP_MISSING", skip=("flash_id",))
        self.stop_case("EMPTY_OUTPUT", outputs={"read_mac": "  \n"})
        self.stop_case("ERROR_OUTPUT", outputs={"chip_id": CHIP_OK + "A fatal error occurred: Failed to connect to ESP32\n"})

    def test_unexpected_chip_stops(self):
        for chip in ("ESP32-S3 (revision v0.1)", "ESP32-C3 (revision v0.4)", "ESP32-S2", "ESP8266", "ESP32-P4"):
            text = f"Connected to {chip.split(' ')[0]} on /dev/x:\nChip type:          {chip}\n"
            self.stop_case("UNEXPECTED_CHIP", chip=text)
        self.assertTrue(CI.evaluate(make_dir(chip=CHIP_OK.replace("ESP32-D0WD-V3", "ESP32-S0WD"))).passed)

    def test_secure_download_mode_stops(self):
        self.stop_case("SECURE_DOWNLOAD_MODE", chip=CHIP_OK.replace("ESP32-D0WD-V3 (revision v3.1)", "ESP32 in Secure Download Mode"))

    def test_flash_size_problems_stop(self):
        self.stop_case("FLASH_SIZE", flash="Manufacturer: 20\nDevice: 4016\nDetected flash size: Unknown\n")
        self.stop_case("FLASH_SIZE", flash="Manufacturer: 20\nDetected flash size: 128MB\n")
        self.stop_case("FLASH_SIZE", flash="nothing useful\n")

    def test_secure_boot_stops(self):
        self.stop_case("SECURE_BOOT", fuses=self.with_fuse(ABS_DONE_0=fuse(True)))
        self.stop_case("SECURE_BOOT", fuses=self.with_fuse(ABS_DONE_1=fuse(True)))

    def test_flash_encryption_stops(self):
        self.stop_case("FLASH_ENCRYPTION", fuses=self.with_fuse(FLASH_CRYPT_CNT=fuse(1)))
        self.stop_case("FLASH_ENCRYPTION", fuses=self.with_fuse(FLASH_CRYPT_CNT=fuse(7)))
        self.stop_case("FLASH_ENCRYPTION", fuses=self.with_fuse(FLASH_CRYPT_CNT=fuse(3)))   # even, non-zero

    def test_restricted_download_stops(self):
        for name in ("UART_DOWNLOAD_DIS", "DISABLE_DL_ENCRYPT", "DISABLE_DL_DECRYPT", "DISABLE_DL_CACHE"):
            self.stop_case("DOWNLOAD_RESTRICTED", fuses=self.with_fuse(**{name: fuse(True)}))

    def test_irreversible_or_protected_settings_stop(self):
        self.stop_case("IRREVERSIBLE_SETTING", fuses=self.with_fuse(JTAG_DISABLE=fuse(True)))
        self.stop_case("SECURITY_UNKNOWN", fuses=self.with_fuse(RD_DIS=fuse(2)))

    def test_unknown_security_status_stops(self):
        self.stop_case("SECURITY_UNKNOWN", fuses=False)                              # JSON missing
        self.stop_case("SECURITY_UNKNOWN", fuses="{ not json")
        self.stop_case("SECURITY_UNKNOWN", fuses="[1, 2]")
        for name in CI.REQUIRED_FUSES:
            if name == "MAC":
                continue
            f = copy.deepcopy(FUSES_OK)
            del f[name]
            self.stop_case("SECURITY_UNKNOWN", fuses=f)
        self.stop_case("SECURITY_UNKNOWN", fuses=self.with_fuse(FLASH_CRYPT_CNT=fuse("??", readable=False)))
        self.stop_case("SECURITY_UNKNOWN", fuses=self.with_fuse(ABS_DONE_0=fuse("maybe")))

    def test_mac_problems_stop(self):
        self.stop_case("MAC_MISSING", mac="Connected to ESP32 on /dev/x:\n")
        self.stop_case("MAC_MISMATCH", mac=MAC_OK.replace("aa:bb:cc", "11:22:33"))

    def test_informational_warning_does_not_stop(self):
        res = CI.evaluate(make_dir(fuses=self.with_fuse(WR_DIS=fuse(4))))
        self.assertTrue(res.passed, res.stops)
        self.assertTrue(res.warnings)

    def test_command_line_exit_codes_and_evidence_permissions(self):
        d = make_dir()
        r = subprocess.run([sys.executable, "-I", os.path.join(TOOLS, "check_identification.py"), "--dir", d],
                           capture_output=True, text=True, timeout=60)
        self.assertEqual(r.returncode, 0, r.stdout)
        self.assertEqual(oct(os.stat(os.path.join(d, "identification.json")).st_mode & 0o777), "0o600")
        d = make_dir(fuses=copy.deepcopy(FUSES_OK) | {"ABS_DONE_1": fuse(True)})
        r = subprocess.run([sys.executable, "-I", os.path.join(TOOLS, "check_identification.py"), "--dir", d],
                           capture_output=True, text=True, timeout=60)
        self.assertEqual(r.returncode, 1)
        self.assertIn("RESULT: STOP", r.stdout)
        self.assertEqual(jl(os.path.join(d, "identification.json"))["verdict"], "STOP")

    def test_same_board_check(self):
        d = make_dir()
        CI.write_evidence(d, CI.evaluate(d))
        write(d, "other.txt", MAC_OK)
        self.assertTrue(CI.same_board(d, os.path.join(d, "other.txt"))[0])
        write(d, "other.txt", MAC_OK.replace("aa:bb:cc", "00:00:00"))
        self.assertFalse(CI.same_board(d, os.path.join(d, "other.txt"))[0])
        d2 = make_dir(fuses=copy.deepcopy(FUSES_OK) | {"ABS_DONE_0": fuse(True)})
        CI.write_evidence(d2, CI.evaluate(d2))
        self.assertFalse(CI.same_board(d2, os.path.join(d, "other.txt"))[0])


class RunStepShellTests(unittest.TestCase):
    """The generated shell wrapper must stop on failure, including when the failing command's output is also shown."""

    def run_script(self, body):
        d = tempfile.mkdtemp()
        os.makedirs(os.path.join(d, "hardware", "backup"))
        script = PF.PREAMBLE.format(port="/dev/null") + "\n" + body
        r = subprocess.run(["bash", "-c", script], cwd=d, capture_output=True, text=True, timeout=60)
        return d, r

    def test_failure_stops_and_later_steps_do_not_run(self):
        d, r = self.run_script('run_step a echo first\nrun_step b sh -c "echo oops; exit 3"\nrun_step c echo SHOULD_NOT_RUN\n')
        self.assertEqual(r.returncode, 3, r.stdout + r.stderr)
        self.assertNotIn("SHOULD_NOT_RUN", r.stdout)
        self.assertIn("STOP: step 'b' failed with exit code 3", r.stderr)
        self.assertEqual(rd(os.path.join(d, "hardware", "backup", "step-b.rc")).strip(), "3")
        self.assertEqual(rd(os.path.join(d, "hardware", "backup", "step-a.rc")).strip(), "0")
        self.assertFalse(os.path.exists(os.path.join(d, "hardware", "backup", "step-c.rc")))

    def test_success_records_output_and_continues(self):
        d, r = self.run_script('run_step a echo hello\nrun_step b echo world\necho DONE\n')
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("DONE", r.stdout)
        self.assertEqual(rd(os.path.join(d, "hardware", "backup", "step-a.txt")).strip(), "hello")

    def test_failure_stops_even_when_stderr_has_output(self):
        d, r = self.run_script('run_step a sh -c "echo err >&2; exit 1"\necho SHOULD_NOT_RUN\n')
        self.assertEqual(r.returncode, 1)
        self.assertNotIn("SHOULD_NOT_RUN", r.stdout)

    def test_a_failed_check_after_steps_stops(self):
        d, r = self.run_script('run_step a echo ok\nfalse\necho SHOULD_NOT_RUN\n')
        self.assertNotEqual(r.returncode, 0)
        self.assertNotIn("SHOULD_NOT_RUN", r.stdout)

    def test_generated_scripts_use_no_pipes_to_tee_and_set_pipefail(self):
        for stage in ("identify",):
            out = subprocess.run([sys.executable, "-I", os.path.join(TOOLS, "plan_flash.py"), "--stage", stage],
                                 capture_output=True, text=True, timeout=60).stdout
            self.assertIn("set -euo pipefail", out)
            self.assertNotIn("| tee", out)
            self.assertNotIn("|tee", out)


class PlanStageGates(unittest.TestCase):
    BANNED_IN_IDENTIFY = ("write-flash", "erase-flash", "erase-region", "read-flash", "verify-flash", "burn-", "write-protect",
                          "read-protect", "set-flash-voltage", "--do-not-confirm", "--erase-all", "espsecure", "--encrypt")

    def stage(self, name, d):
        return subprocess.run([sys.executable, "-I", os.path.join(TOOLS, "plan_flash.py"), "--stage", name, "--dir", d],
                              capture_output=True, text=True, timeout=60)

    def evidence_dir(self, flash_bytes=4 * 1024 * 1024, backup_bytes=None, problems=None, rc_read=0, rc_verify=0,
                     tamper=False, with_backup=True):
        d = make_dir()
        CI.write_evidence(d, CI.evaluate(d))
        if with_backup:
            n = flash_bytes if backup_bytes is None else backup_bytes
            path = os.path.join(d, PF.BACKUP_NAME)
            data = os.urandom(n)
            with open(path, "wb") as fh:
                fh.write(data)
            man = {"file": PF.BACKUP_NAME, "bytes": n, "sha256": hashlib.sha256(data).hexdigest(), "mac": "246f28aabbcc",
                   "problems": problems or []}
            write(d, PF.MANIFEST_NAME, json.dumps(man))
            if tamper:
                with open(path, "ab") as fh:
                    fh.write(b"x")
            write(d, "step-backup_read.rc", str(rc_read))
            write(d, "step-backup_verify.rc", str(rc_verify))
        return d

    def test_identify_stage_contains_only_read_commands(self):
        out = subprocess.run([sys.executable, "-I", os.path.join(TOOLS, "plan_flash.py"), "--stage", "identify"],
                             capture_output=True, text=True, timeout=60).stdout
        code = "\n".join(l for l in out.splitlines() if not l.lstrip().startswith("#"))
        for banned in self.BANNED_IN_IDENTIFY:
            self.assertNotIn(banned, code, banned)
        self.assertEqual(code.count("run_step "), 4)           # exactly the four identification steps
        self.assertIn("summary --format json", code)

    def test_backup_and_flash_withheld_without_identification(self):
        d = tempfile.mkdtemp()
        for stage in ("backup", "flash"):
            r = self.stage(stage, d)
            self.assertEqual(r.returncode, 3)
            self.assertIn("WITHHELD", r.stdout)
            self.assertNotIn("write-flash", r.stdout)

    def test_backup_and_flash_withheld_after_failed_identification(self):
        d = make_dir(fuses=copy.deepcopy(FUSES_OK) | {"ABS_DONE_0": fuse(True)})
        CI.write_evidence(d, CI.evaluate(d))
        for stage in ("backup", "flash"):
            r = self.stage(stage, d)
            self.assertEqual(r.returncode, 3, stage)
            self.assertNotIn("write-flash", r.stdout)

    def test_backup_stage_derives_size_and_checks_same_board(self):
        d = self.evidence_dir(with_backup=False)
        r = self.stage("backup", d)
        self.assertEqual(r.returncode, 0, r.stdout)
        self.assertIn("0x400000", r.stdout)
        self.assertIn("--same-board", r.stdout)
        self.assertIn("verify-flash 0x0", r.stdout)
        self.assertNotIn("write-flash", r.stdout)
        self.assertIn("test ! -e", r.stdout)                      # never overwrite an existing backup

    def test_flash_withheld_without_a_backup(self):
        r = self.stage("flash", self.evidence_dir(with_backup=False))
        self.assertEqual(r.returncode, 3)
        self.assertNotIn("write-flash", r.stdout)

    def test_flash_withheld_for_each_evidence_failure(self):
        cases = {
            "not full size": dict(backup_bytes=2 * 1024 * 1024),
            "manifest problems": dict(problems=["file is entirely 0xFF"]),
            "read failed": dict(rc_read=1),
            "not compared with board": dict(rc_verify=1),
            "file changed after manifest": dict(tamper=True),
        }
        for name, kw in cases.items():
            r = self.stage("flash", self.evidence_dir(**kw))
            self.assertEqual(r.returncode, 3, name + r.stdout)
            self.assertNotIn("write-flash", r.stdout, name)

    def test_flash_withheld_when_comparison_record_is_missing(self):
        d = self.evidence_dir()
        os.unlink(os.path.join(d, "step-backup_verify.rc"))
        r = self.stage("flash", d)
        self.assertEqual(r.returncode, 3)
        self.assertNotIn("write-flash", r.stdout)

    def test_flash_presented_only_with_complete_evidence_and_derived_from_metadata(self):
        meta_path = os.path.join(ROOT, "firmware", "m1-echo", "build", "flasher_args.json")
        if not os.path.exists(meta_path):
            self.skipTest("firmware not built")
        meta = jl(meta_path)
        r = self.stage("flash", self.evidence_dir())
        self.assertEqual(r.returncode, 0, r.stdout)
        for addr, f in meta["flash_files"].items():
            self.assertIn(f"{addr} firmware/m1-echo/build/{f}", r.stdout)
        self.assertIn("preflash_mac", r.stdout)
        self.assertIn("--same-board", r.stdout)
        self.assertNotIn("--erase-all", r.stdout.replace("No --erase-all", ""))
        self.assertIn("--stage flash >/dev/null", r.stdout)       # evidence re-checked at execution time

    def test_planner_never_executes_anything(self):
        import ast
        tree = ast.parse(rd(os.path.join(TOOLS, "plan_flash.py")))
        imported = {n.names[0].name.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.Import)}
        self.assertFalse(imported & {"serial", "subprocess", "socket", "esptool"}, imported)


if __name__ == "__main__":
    unittest.main()
