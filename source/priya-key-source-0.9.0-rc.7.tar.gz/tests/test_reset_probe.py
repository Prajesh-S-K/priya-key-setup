"""Reset-probe classification tests against a simulated device with a fake clock. No serial port."""
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
from gpecho import framing as F  # noqa: E402
from gpecho import probe as P  # noqa: E402


class SimWorld:
    """A board that may reset when the port is opened and/or closed. Boot takes `boot_delay` seconds until the
    application runs (uptime counts from then), as on the real chip. ROM text and HELLO are only visible to a port
    that is open when they are emitted."""

    def __init__(self, reset_on_open=False, reset_on_close=False, emit_text=True, boot_delay=0.6, hang=False, silent=False):
        self.t = 0.0
        self.boot_t = -1000.0
        self.boot_delay = boot_delay
        self.reset_on_open, self.reset_on_close, self.emit_text, self.hang = reset_on_open, reset_on_close, emit_text, hang
        self.silent = silent      # the host never sees ROM text or HELLO (missed, flushed, or opened too late)
        self.open = False
        self.t_open = 0.0
        self.events = []      # (time, bytes)
        self.mid_session_reset_at = None

    def reset(self, at=None):
        at = self.t if at is None else at
        self.boot_t = at
        if self.silent:
            return
        if self.emit_text:
            self.events.append((at + 0.1, b"ets Jun  8 2016 00:22:57\r\nrst:0x1 (POWERON_RESET),boot:0x13\r\n"))
        self.events.append((at + self.boot_delay, b"\x00" + F.encode_frame(F.T_HELLO, 0, F.pack_info(1, 256, 0, 0, 0, 0, 0, 0, 0, 1))))

    def uptime(self):
        if self.hang or self.t < self.boot_t + self.boot_delay:
            return None
        return int((self.t - self.boot_t - self.boot_delay) * 1000)

    def sleep(self, s):
        self.t += s

    def clock(self):
        return self.t

    def opener(self):
        self.open = True
        self.t_open = self.t
        if self.reset_on_open:
            self.reset(self.t + 0.05)
        return SimPort(self)


class SimPort:
    def __init__(self, w):
        self.w = w
        self.dec = F.StreamDecoder()

    def write(self, data):
        for ev in self.dec.feed(data):
            if ev.kind == "frame" and ev.frame.type == F.T_INFO_REQ:
                u = self.w.uptime()
                if u is not None:
                    self.w.events.append((self.w.t + 0.004, F.encode_frame(
                        F.T_INFO_RSP, ev.frame.seq, F.pack_info(1, 256, u, 1, 0, 0, 0, 0, 0, 1))))

    def read(self, timeout):
        w = self.w
        ready = [e for e in w.events if e[0] <= w.t and e[0] >= w.t_open]
        if ready:
            w.events = [e for e in w.events if e not in ready]
            return b"".join(b for _, b in ready)
        w.t += min(timeout, 0.01)
        return b""

    def close(self):
        w = self.w
        w.open = False
        if w.reset_on_close:
            w.reset()


def probe(world, repeats=5, wait_s=3.0):
    lines = []
    verdicts, conclusion = P.run_probe(world.opener, repeats, world.clock, world.sleep, out=lines.append, wait_s=wait_s)
    return [v.kind for v in verdicts], conclusion, "\n".join(lines)


class ResetProbeTests(unittest.TestCase):
    def test_no_reset_board(self):
        w = SimWorld()
        w.reset(-30.0)                                   # booted long ago
        kinds, conclusion, text = probe(w)
        self.assertEqual(kinds, ["baseline"] + ["no-reset"] * 4)
        self.assertIn("NO RESET", conclusion)

    def test_reset_on_open_is_detected_and_not_called_close(self):
        w = SimWorld(reset_on_open=True)
        w.reset(-30.0)
        kinds, conclusion, _ = probe(w)
        self.assertEqual(set(kinds[1:]), {"reset-on-open"})
        self.assertIn("RESET ON OPEN", conclusion)

    def test_reset_on_close_is_detected_separately(self):
        w = SimWorld(reset_on_close=True)
        w.reset(-30.0)
        kinds, conclusion, _ = probe(w)
        self.assertEqual(set(kinds[1:]), {"reset-on-close"})
        self.assertIn("RESET ON CLOSE", conclusion)

    def test_reset_on_both_is_attributed_to_open_with_a_masking_note(self):
        w = SimWorld(reset_on_open=True, reset_on_close=True)
        w.reset(-30.0)
        kinds, conclusion, text = probe(w)
        self.assertEqual(set(kinds[1:]), {"reset-on-open"})
        self.assertIn("masked", text)

    def test_absent_boot_text_does_not_hide_a_reset(self):
        w = SimWorld(reset_on_open=True, silent=True)       # reset happens, but no boot output is ever captured
        w.reset(-30.0)
        kinds, conclusion, text = probe(w)
        self.assertEqual(set(kinds[1:]), {"reset-on-open"})
        self.assertIn("inconclusive, not proof", text)
        self.assertIn("RESET ON OPEN", conclusion)

    def test_absent_boot_text_is_not_proof_of_no_reset_after_close_either(self):
        w = SimWorld(reset_on_close=True, silent=True)
        w.reset(-30.0)
        kinds, _, text = probe(w)
        self.assertEqual(set(kinds[1:]), {"reset-on-close"})
        self.assertIn("inconclusive, not proof", text)

    def test_silent_board_without_reset_is_still_classified_by_uptime(self):
        w = SimWorld(silent=True)
        w.reset(-30.0)
        kinds, conclusion, text = probe(w)
        self.assertEqual(set(kinds[1:]), {"no-reset"})
        self.assertIn("inconclusive, not proof", text)

    def test_unresponsive_board_is_inconclusive_not_clean(self):
        w = SimWorld(hang=True)
        w.reset(-30.0)
        kinds, conclusion, _ = probe(w, repeats=3)
        self.assertNotIn("no-reset", kinds)
        self.assertTrue(all(k == "inconclusive" for k in kinds))

    def test_boot_text_with_continuous_uptime_is_an_anomaly(self):
        prev = P.Observation(t_open=0, hello_seen=False, boot_text_seen=False, t_a=1, u_a=10_000, t_b=2, u_b=11_000, t_close=2.1)
        cur = P.Observation(t_open=5.1, hello_seen=True, boot_text_seen=True, t_a=6.0, u_a=15_000, t_b=6.3, u_b=15_300)
        self.assertEqual(P.classify(prev, cur).kind, "anomaly")

    def test_reset_before_the_close_is_not_attributed(self):
        prev = P.Observation(0, False, False, 1.0, 10_000, 1.3, 10_300, t_close=3.0)
        # the board restarted at 1.5 s (application up at 2.1 s), before the port was closed at 3.0 s
        cur = P.Observation(t_open=7.0, hello_seen=False, boot_text_seen=False, t_a=8.0, u_a=5_900, t_b=8.3, u_b=6_200)
        self.assertEqual(P.classify(prev, cur).kind, "inconclusive")

    def test_reset_during_a_session_is_reported(self):
        o = P.Observation(0, False, False, 1.0, 20_000, 1.3, 400, 1.4)
        self.assertTrue(P.within_session_reset(o))
        ok = P.Observation(0, False, False, 1.0, 20_000, 1.3, 20_300, 1.4)
        self.assertFalse(P.within_session_reset(ok))

    def test_first_cycle_is_baseline_only(self):
        w = SimWorld(reset_on_open=True)
        kinds, _, _ = probe(w, repeats=1)
        self.assertEqual(kinds, ["baseline"])


if __name__ == "__main__":
    unittest.main()
