"""Regression tests for tools/flash_firmware.py (the flasher shipped with the release). The REAL gating code runs
(check_identification, backup_manifest, plan_flash evidence); only the esptool/espefuse executables are replaced by
tests/fake_esptool.py, which keeps a fake flash image in a file. No serial port is opened and no board is touched."""
import hashlib
import json
import os
import shutil
import struct
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import flash_firmware as FF  # noqa: E402

FAKE = os.path.join(ROOT, "tests", "fake_esptool.py")


def rd(path, mode="rb"):
    with open(path, mode) as fh:
        return fh.read()


def wr(path, data, mode="wb"):
    with open(path, mode) as fh:
        fh.write(data)


def jl(path):
    with open(path) as fh:
        return json.load(fh)


def jd(obj, path):
    with open(path, "w") as fh:
        json.dump(obj, fh)
MAC = "d4:8c:49:e4:9f:6c"
CHIP = "ESP32-D0WD-V3 (revision v3.1)"


def fuse(v):
    return {"name": "x", "value": v, "readable": True, "writeable": True}


FUSES_OK = {"FLASH_CRYPT_CNT": fuse(0), "ABS_DONE_0": fuse(False), "ABS_DONE_1": fuse(False), "UART_DOWNLOAD_DIS": fuse(False),
            "DISABLE_DL_ENCRYPT": fuse(False), "DISABLE_DL_DECRYPT": fuse(False), "DISABLE_DL_CACHE": fuse(False),
            "JTAG_DISABLE": fuse(False), "RD_DIS": fuse(0), "WR_DIS": fuse(0), "MAC": fuse(f"{MAC} (OK)"), "CONSOLE_DEBUG_DISABLE": fuse(True)}


def ptable(entries):
    body = b"".join(struct.pack("<HBBLL16sL", 0x50AA, t, s, o, z, n.encode().ljust(16, b"\0"), 0) for n, t, s, o, z in entries)
    body += b"\xeb\xeb" + b"\xff" * 14 + hashlib.md5(body).digest()
    return body.ljust(3072, b"\xff")


GOOD_TABLE = [("nvs", 1, 2, 0x9000, 0x6000), ("phy_init", 1, 1, 0xF000, 0x1000), ("factory", 0, 0, 0x10000, 0x100000), ("assets", 1, 0x40, 0x110000, 0x10000)]


def esp_image(n, seed):
    h = bytearray(os.urandom(0) or bytes((seed * 7 + i) & 0xFF for i in range(n)))
    h[0] = 0xE9
    h[12:14] = b"\0\0"
    return bytes(h)


def assets_image(n=9000):
    b = bytearray(bytes((i * 13) & 0xFF for i in range(n)))
    b[0:4] = b"GKAS"
    b[8:12] = struct.pack("<I", n)
    return bytes(b)


class Env:
    """A release-like package folder plus a fake board."""

    def __init__(self, test, table=GOOD_TABLE, flash_mb=4, chip=CHIP, fuses=None, macs=(MAC,), fail_write=False):
        self.t = tempfile.mkdtemp()
        test.addCleanup(shutil.rmtree, self.t, True)
        self.fw = os.path.join(self.t, "firmware")
        os.makedirs(self.fw)
        files = {"bootloader.bin": esp_image(18000, 1), "partition-table.bin": ptable(table), "gpkey.bin": esp_image(170000, 2), "assets.bin": assets_image()}
        for n, b in files.items():
            wr(os.path.join(self.fw, n), b)
        jd({"flash_settings": {"flash_mode": "dio", "flash_freq": "40m", "flash_size": "2MB"},
            "flash_files": {"0x1000": "bootloader/bootloader.bin", "0x8000": "partition_table/partition-table.bin", "0x10000": "gpkey.bin"},
            "extra_esptool_args": {"chip": "esp32", "stub": True}}, os.path.join(self.fw, "flasher_args.json"))
        self.sums = os.path.join(self.t, "SHA256SUMS.txt")
        self.rewrite_sums()
        # the fake board: 4 MiB flash with distinctive content, NVS holds the "pairing record"
        self.image = os.path.join(self.t, "board.img")
        img = bytearray(os.urandom(flash_mb * 1024 * 1024))
        img[0x9000:0x9000 + 16] = b"PAIRING-RECORD!!"
        wr(self.image, img)
        self.orig = bytes(img)
        self.state = os.path.join(self.t, "state")
        os.makedirs(self.state)
        jd({"image": self.image, "chip": chip, "flash_mb": flash_mb, "macs": list(macs), "fuses": FUSES_OK if fuses is None else fuses,
            "fail_write": fail_write}, os.path.join(self.state, "scenario.json"))
        os.environ["FAKE_STATE"] = self.state
        self.work = os.path.join(self.t, "work")

    def rewrite_sums(self):
        with open(self.sums, "w") as fh:
            for n in FF.FILES:
                fh.write(f"{FF.sha256_file(os.path.join(self.fw, n))}  ./firmware/{n}\n")

    def calls(self):
        p = os.path.join(self.state, "calls.log")
        return rd(p, "r").split("\n")[:-1] if os.path.exists(p) else []

    def flash(self):
        return rd(self.image)

    def run(self, *extra):
        out = []
        fake = f"{sys.executable} {FAKE}"
        rc = FF.run(["--port", "FAKEPORT", "--package", self.fw, "--sums", self.sums, "--workdir", self.work, "--esptool", fake, "--espefuse", fake, *extra], say=out.append)
        return rc, "\n".join(out)


class PackageGate(unittest.TestCase):
    def test_dry_run_validates_without_touching_a_board(self):
        e = Env(self)
        rc, out = e.run("--dry-run")
        self.assertEqual(rc, 0, out)
        self.assertEqual(e.calls(), [])
        self.assertIn("0x110000", out)

    def stop(self, e, why, *extra):
        rc, out = e.run(*extra)
        self.assertEqual(rc, 1, out)
        self.assertIn(why, out)
        self.assertEqual(e.calls(), [], "no board command may run when the package is invalid")
        self.assertEqual(e.flash(), e.orig)

    def test_tampered_or_missing_files_stop_before_any_board_command(self):
        e = Env(self)
        with open(os.path.join(e.fw, "gpkey.bin"), "r+b") as fh:
            fh.seek(100); fh.write(b"\x00\x01")
        self.stop(e, "does not match its SHA-256")

    def test_missing_checksum_file_or_entry_fails_closed(self):
        e = Env(self); os.remove(e.sums)
        self.stop(e, "cannot be verified")
        e2 = Env(self)
        wr(e2.sums, "".join(l for l in rd(e2.sums, "r").splitlines(True) if "assets.bin" not in l), "w")
        self.stop(e2, "not listed")

    def test_metadata_disagreements_are_stops(self):
        e = Env(self)
        m = jl(os.path.join(e.fw, "flasher_args.json"))
        m["flash_files"]["0x20000"] = "evil.bin"
        jd(m, os.path.join(e.fw, "flasher_args.json")); e.rewrite_sums()
        self.stop(e, "differ from the expected layout")

    def test_bad_partition_tables(self):
        moved_nvs = [("nvs", 1, 2, 0xA000, 0x6000)] + GOOD_TABLE[1:]
        self.stop(Env(self, table=moved_nvs), "moves the NVS")
        no_assets = GOOD_TABLE[:3]
        self.stop(Env(self, table=no_assets), "no 'assets'")
        small = GOOD_TABLE[:3] + [("assets", 1, 0x40, 0x110000, 0x1000)]
        self.stop(Env(self, table=small), "dashboard image does not fit")
        e = Env(self)
        b = bytearray(rd(os.path.join(e.fw, "partition-table.bin"))); b[40] ^= 1   # corrupt an entry: MD5 must fail
        wr(os.path.join(e.fw, "partition-table.bin"), b); e.rewrite_sums()
        self.stop(e, "MD5")

    def test_bad_images(self):
        e = Env(self)
        b = bytearray(rd(os.path.join(e.fw, "assets.bin"))); b[8] ^= 1
        wr(os.path.join(e.fw, "assets.bin"), b); e.rewrite_sums()
        self.stop(e, "dashboard image")
        e2 = Env(self)
        b = bytearray(rd(os.path.join(e2.fw, "gpkey.bin"))); b[0] = 0
        wr(os.path.join(e2.fw, "gpkey.bin"), b); e2.rewrite_sums()
        self.stop(e2, "not an ESP32 image")

    def test_write_regions_never_touch_nvs_even_if_a_bootloader_grows(self):
        e = Env(self)
        wr(os.path.join(e.fw, "bootloader.bin"), esp_image(0x7100, 1)); e.rewrite_sums()
        self.stop(e, "too large")


class BoardGates(unittest.TestCase):
    def test_default_run_backs_up_verifies_and_does_not_write(self):
        e = Env(self)
        rc, out = e.run()
        self.assertEqual(rc, 3, out)
        self.assertIn("NOTHING was written", out)
        self.assertEqual(e.flash(), e.orig)
        bk = os.path.join(e.work, "flash-backup-full.bin")
        self.assertEqual(rd(bk), e.orig)
        self.assertEqual(os.stat(bk).st_mode & 0o077, 0, "backup must be owner-only")
        self.assertEqual(os.stat(e.work).st_mode & 0o077, 0)
        self.assertNotIn("write-flash", e.calls())
        self.assertIn("verify-flash", e.calls())

    def test_confirmed_write_writes_only_validated_regions_and_verifies(self):
        e = Env(self)
        rc, out = e.run("--confirm-write", MAC.upper())
        self.assertEqual(rc, 0, out)
        img = e.flash()
        self.assertEqual(img[0x9000:0x10000], e.orig[0x9000:0x10000], "NVS / pairing record must be untouched")
        self.assertEqual(img[:0x1000], e.orig[:0x1000])
        for off, name in ((0x1000, "bootloader.bin"), (0x8000, "partition-table.bin"), (0x10000, "gpkey.bin"), (0x110000, "assets.bin")):
            d = rd(os.path.join(e.fw, name))
            self.assertEqual(img[off:off + len(d)], d, name)
        self.assertEqual(img[0x120000:], e.orig[0x120000:], "nothing beyond the dashboard region is written")
        self.assertEqual(e.calls().count("write-flash"), 1)

    def test_wrong_confirmation_mac_blocks_the_write(self):
        e = Env(self)
        rc, out = e.run("--confirm-write", "00:11:22:33:44:55")
        self.assertEqual(rc, 1, out)
        self.assertEqual(e.flash(), e.orig)
        self.assertNotIn("write-flash", e.calls())

    def test_unrelated_large_backup_is_rejected(self):
        e = Env(self)
        other = os.path.join(e.t, "other.bin")
        wr(other, os.urandom(4 * 1024 * 1024))          # right size, wrong contents
        rc, out = e.run("--backup", other, "--confirm-write", MAC)
        self.assertEqual(rc, 1, out)
        self.assertIn("backup_verify", out)
        self.assertEqual(e.flash(), e.orig)
        self.assertNotIn("write-flash", e.calls())

    def test_short_oversized_blank_and_missing_backups_are_rejected(self):
        for label, data in (("short", e0 := os.urandom(1024 * 1024)), ("blank", b"\xff" * 4 * 1024 * 1024), ("zero", b"\x00" * 4 * 1024 * 1024), ("big", os.urandom(8 * 1024 * 1024))):
            e = Env(self)
            p = os.path.join(e.t, f"{label}.bin"); wr(p, data)
            rc, out = e.run("--backup", p, "--confirm-write", MAC)
            self.assertEqual(rc, 1, f"{label}: {out}")
            self.assertEqual(e.flash(), e.orig, label)
            self.assertNotIn("write-flash", e.calls(), label)
        e = Env(self)
        rc, out = e.run("--backup", os.path.join(e.t, "nope.bin"))
        self.assertEqual(rc, 1)

    def test_a_correct_existing_backup_is_accepted_after_verification(self):
        e = Env(self)
        good = os.path.join(e.t, "mine.bin"); wr(good, e.orig)
        rc, out = e.run("--backup", good, "--confirm-write", MAC)
        self.assertEqual(rc, 0, out)
        self.assertIn("verify-flash", e.calls())

    def test_old_evidence_in_the_work_folder_is_never_reused(self):
        e = Env(self)
        self.assertEqual(e.run()[0], 3)
        # same work folder, different board contents: the old backup must not be overwritten or reused
        img = os.urandom(4 * 1024 * 1024); wr(e.image, img)
        before = rd(os.path.join(e.work, "flash-backup-full.bin"))
        rc, out = e.run("--confirm-write", MAC)
        self.assertEqual(rc, 1, out)
        self.assertIn("already exists", out)
        self.assertEqual(rd(os.path.join(e.work, "flash-backup-full.bin")), before)
        self.assertEqual(e.flash(), img)

    def test_security_state_problems_fail_closed_before_any_backup_or_write(self):
        cases = {
            "secure boot": dict(fuses={**FUSES_OK, "ABS_DONE_0": fuse(True)}),
            "flash encryption": dict(fuses={**FUSES_OK, "FLASH_CRYPT_CNT": fuse(1)}),
            "download restricted": dict(fuses={**FUSES_OK, "UART_DOWNLOAD_DIS": fuse(True)}),
            "unparseable fuses": dict(fuses="{not json"),
            "missing fuses": dict(fuses=None),
            "other chip": dict(chip="ESP32-S3 (revision v0.1)"),
        }
        for label, kw in cases.items():
            e = Env(self, **kw)
            if label == "missing fuses":
                jd({**jl(os.path.join(e.state, "scenario.json")), "fuses": None}, os.path.join(e.state, "scenario.json"))
            rc, out = e.run("--confirm-write", MAC)
            self.assertEqual(rc, 1, f"{label}: {out}")
            self.assertEqual(e.flash(), e.orig, label)
            c = e.calls()
            self.assertNotIn("read-flash", c, label)
            self.assertNotIn("write-flash", c, label)

    def test_flash_too_small_for_the_package_is_a_stop(self):
        e = Env(self, flash_mb=1)
        rc, out = e.run("--confirm-write", MAC)
        self.assertEqual(rc, 1, out)
        self.assertIn("needs", out)
        self.assertNotIn("write-flash", e.calls())

    def test_board_swapped_between_steps_is_a_stop(self):
        e = Env(self, macs=(MAC, "aa:bb:cc:dd:ee:ff"))             # identify, then a different board at the backup check
        rc, out = e.run("--confirm-write", MAC)
        self.assertEqual(rc, 1, out)
        self.assertEqual(e.flash(), e.orig)
        self.assertNotIn("write-flash", e.calls())
        e2 = Env(self, macs=(MAC, MAC, "aa:bb:cc:dd:ee:ff"))        # differs only at the pre-write check
        rc, out = e2.run("--confirm-write", MAC)
        self.assertEqual(rc, 1, out)
        self.assertNotIn("write-flash", e2.calls())

    def test_failed_write_is_reported_and_not_called_success(self):
        e = Env(self, fail_write=True)
        rc, out = e.run("--confirm-write", MAC)
        self.assertEqual(rc, 1, out)
        self.assertIn("flash_write", out)

    def test_the_real_release_firmware_folder_passes_package_validation_when_present(self):
        rel = [d for d in sorted(os.listdir(os.path.join(ROOT, "release"))) if d.startswith("PriyaKey-") and "rc" in d] if os.path.isdir(os.path.join(ROOT, "release")) else []
        if not rel:
            self.skipTest("no release folder built")
        base = os.path.join(ROOT, "release", rel[-1])
        if not os.path.exists(os.path.join(base, "firmware", "flash_firmware.py")):
            self.skipTest("release folder predates the Python flasher")
        plan = FF.validate_package(os.path.join(base, "firmware"), os.path.join(base, "SHA256SUMS.txt"))
        self.assertEqual([hex(o) for o, _ in plan["writes"]], ["0x1000", "0x8000", "0x10000", "0x110000"])


if __name__ == "__main__":
    unittest.main()
