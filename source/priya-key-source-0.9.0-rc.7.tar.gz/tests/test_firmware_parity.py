"""Runs the REAL firmware logic (firmware/m1-echo/main/echo_app.c, compiled for the host with mocked hardware)
and compares everything it transmits with the Python FakeDevice model, byte for byte, for scripted and
random input streams. Also runs the C unit tests for initialization failure, request dispatch and
transmission accounting. No serial port, no board."""
import os
import random
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import echo_client  # noqa: E402
from gpecho import framing as F  # noqa: E402

CC = shutil.which("clang") or shutil.which("cc")
MAIN = os.path.join(ROOT, "firmware", "m1-echo", "main")


def build(tmp, name, source, sanitize=False):
    exe = os.path.join(tmp, name)
    cmd = [CC, "-std=c11", "-Wall", "-Wextra", "-Werror", "-O1", "-g"]
    if sanitize:
        cmd.append("-fsanitize=undefined")   # AddressSanitizer hangs on the dev Mac, see reports/m1-preparation.md
    cmd += ["-I", MAIN, os.path.join(ROOT, "tests", "c", source), os.path.join(MAIN, "echo_app.c"),
            os.path.join(MAIN, "echo_frame.c"), "-o", exe]
    subprocess.run(cmd, check=True, timeout=120)
    return exe


@unittest.skipUnless(CC, "no C compiler")
class FirmwareLogicTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.stream = build(cls.tmp, "app_stream", "app_stream.c")
        cls.unit = build(cls.tmp, "test_app", "test_app.c", sanitize=True)

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def test_c_unit_tests_pass(self):
        p = subprocess.run([self.unit], capture_output=True, text=True, timeout=60)
        self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
        self.assertIn("C app tests passed", p.stdout)

    def run_both(self, events):
        script = []
        dev = echo_client.FakeDevice(uptime_fn=lambda: 1234)
        for ev in events:
            if ev[0] == "D":
                script.append("D " + ev[1].hex())
                dev.feed(ev[1])
            elif ev[0] == "E":
                script.append("E")
                dev.uart_error(False)
            else:
                script.append("O")
                dev.uart_error(True)
        p = subprocess.run([self.stream], input="\n".join(script) + "\n", capture_output=True, text=True, timeout=60)
        self.assertEqual(p.returncode, 0, p.stderr)
        return p.stdout.strip(), bytes(dev.out).hex()

    def test_scripted_scenario_matches_model(self):
        ev = [
            ("D", F.encode_frame(F.T_ECHO_REQ, 1, b"hello")),
            ("D", F.encode_frame(F.T_ECHO_REQ, 2, bytes(256))),
            ("D", F.encode_frame(F.T_INFO_REQ, 3)),
            ("D", F.encode_frame(0x7E, 4)),
            ("D", F.encode_frame(F.T_ECHO_REQ, 5, b"v", ver=2)),
            ("D", F.encode_frame(F.T_ECHO_REQ, 6, b"f", flags=1)),
            ("D", b"garbage\x00"),
            ("D", b"\x55" * 700 + b"\x00"),
            ("D", F.encode_frame(F.T_ECHO_REQ, 7, b"after")),
            ("E",),
            ("D", F.encode_frame(F.T_INFO_REQ, 8)),
        ]
        c_out, py_out = self.run_both(ev)
        self.assertEqual(c_out, py_out)

    def test_random_streams_match_model(self):
        rng = random.Random(77)
        for _ in range(150):
            events = []
            for _ in range(rng.randrange(1, 25)):
                k = rng.randrange(8)
                if k == 0:
                    events.append(("D", F.encode_frame(F.T_ECHO_REQ, rng.getrandbits(32),
                                                       bytes(rng.randrange(256) for _ in range(rng.randrange(0, 257))))))
                elif k == 1:
                    events.append(("D", F.encode_frame(F.T_INFO_REQ, rng.getrandbits(32))))
                elif k == 2:
                    events.append(("D", F.encode_frame(rng.choice([0x03, 0x41, 0x81, 0xFE]), rng.getrandbits(32),
                                                       bytes(rng.randrange(256) for _ in range(rng.randrange(0, 20))))))
                elif k == 3:
                    events.append(("D", F.encode_frame(F.T_ECHO_REQ, rng.getrandbits(32), b"x",
                                                       ver=rng.choice([0, 2, 255]), flags=rng.choice([0, 1, 128]))))
                elif k == 4:
                    m = bytearray(F.encode_frame(F.T_ECHO_REQ, rng.getrandbits(32), b"mutate me"))
                    for _ in range(rng.randrange(1, 3)):
                        m[rng.randrange(len(m) - 1)] = rng.randrange(1, 256)
                    events.append(("D", bytes(m)))
                elif k == 5:
                    events.append(("D", bytes(rng.randrange(256) for _ in range(rng.randrange(1, 400)))))
                elif k == 6:
                    events.append(("D", b"\x00" * rng.randrange(1, 4)))
                else:
                    events.append((rng.choice("EO"),))
            c_out, py_out = self.run_both(events)
            self.assertEqual(c_out, py_out)


if __name__ == "__main__":
    unittest.main()
