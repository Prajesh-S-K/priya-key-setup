"""Tests for the local helper tools. None of them touches a serial port or the board."""
import json
import os
import stat
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOOLS = os.path.join(ROOT, "tools")


def rd(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def jl(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def run(args):
    return subprocess.run([sys.executable, "-I"] + args, capture_output=True, text=True, timeout=60)


class BackupManifestTests(unittest.TestCase):
    def make(self, data, mode=0o600):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "b.bin")
        with open(p, "wb") as fh:
            fh.write(data)
        os.chmod(p, mode)
        return d, p

    def test_good_file(self):
        d, p = self.make(os.urandom(4096))
        r = run([os.path.join(TOOLS, "backup_manifest.py"), "--file", p, "--expected-bytes", "4096",
                 "--out", os.path.join(d, "m.json")])
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        m = jl(os.path.join(d, "m.json"))
        self.assertEqual(m["bytes"], 4096)
        self.assertEqual(stat.S_IMODE(os.stat(os.path.join(d, "m.json")).st_mode), 0o600)

    def test_wrong_size_blank_and_loose_permissions_fail(self):
        d, p = self.make(os.urandom(4096))
        self.assertEqual(run([os.path.join(TOOLS, "backup_manifest.py"), "--file", p, "--expected-bytes", "8192",
                              "--out", os.path.join(d, "m.json")]).returncode, 1)
        d, p = self.make(b"\xff" * 4096)
        self.assertEqual(run([os.path.join(TOOLS, "backup_manifest.py"), "--file", p, "--expected-bytes", "4096",
                              "--out", os.path.join(d, "m.json")]).returncode, 1)
        d, p = self.make(os.urandom(4096), mode=0o644)
        self.assertEqual(run([os.path.join(TOOLS, "backup_manifest.py"), "--file", p, "--expected-bytes", "4096",
                              "--out", os.path.join(d, "m.json")]).returncode, 1)


class PlanFlashTests(unittest.TestCase):
    def test_default_stage_is_identification_only(self):
        r = run([os.path.join(TOOLS, "plan_flash.py")])
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("IDENTIFICATION ONLY", r.stdout)
        self.assertNotIn("write-flash", r.stdout)
        self.assertNotIn("read-flash", r.stdout)

    def test_planner_never_imports_serial_or_runs_commands(self):
        import ast
        tree = ast.parse(rd(os.path.join(TOOLS, "plan_flash.py")))
        imported = set()
        calls = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported.update(n.name.split(".")[0] for n in node.names)
            elif isinstance(node, ast.ImportFrom):
                imported.add((node.module or "").split(".")[0])
            elif isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name):
                calls.add(f"{node.value.id}.{node.attr}")
        self.assertFalse(imported & {"serial", "subprocess", "esptool", "socket"}, imported)
        self.assertFalse(calls & {"os.system", "os.popen", "os.exec", "os.spawn"}, calls)


class GuardTests(unittest.TestCase):
    def test_python_client_has_no_default_port_access(self):
        src = rd(os.path.join(TOOLS, "echo_client.py"))
        self.assertIn("--confirm-board-access", src)
        self.assertIn("Refusing to open a serial port", src)

    def test_powershell_client_has_the_same_guard(self):
        src = rd(os.path.join(TOOLS, "echo_client.ps1"))
        self.assertIn("-not $ConfirmBoardAccess", src)

    def test_backup_paths_are_git_ignored(self):
        gi = rd(os.path.join(ROOT, ".gitignore"))
        self.assertIn("hardware/backup/", gi)
        self.assertIn("*.manifest.json", gi)
        self.assertEqual(stat.S_IMODE(os.stat(os.path.join(ROOT, "hardware", "backup")).st_mode), 0o700)


class FirmwareSourceScanTests(unittest.TestCase):
    """The echo firmware must not use forbidden features. Scan the sources (the ELF symbol check is in the report)."""

    def test_no_forbidden_apis_in_firmware_sources(self):
        d = os.path.join(ROOT, "firmware", "m1-echo", "main")
        text = "".join(rd(os.path.join(d, f)) for f in os.listdir(d) if f.endswith((".c", ".h")))
        for banned in ("nvs_", "esp_wifi", "esp_bt", "esp_ble", "mbedtls", "psa_", "esp_efuse", "esp_partition",
                       "esp_flash_write", "adc_", "i2s_", "esp_random", "esp_fill_random", "gpio_"):
            self.assertNotIn(banned, text, banned)


if __name__ == "__main__":
    unittest.main()
