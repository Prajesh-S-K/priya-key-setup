"""Runs the Mac client's in-memory self-test. No serial port is opened."""
import io
import os
import subprocess
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import echo_client  # noqa: E402


class ClientSelfTest(unittest.TestCase):
    def test_selftest_passes(self):
        lines = []
        dev = echo_client.FakeDevice(boot_text=b"rst:0x1 (POWERON_RESET)\r\n")
        rc = echo_client.run_tests(echo_client.Client(echo_client.LoopbackTransport(dev)), 300,
                                   echo_client.DEFAULT_SIZES, 1, 0.0, out=lines.append)
        self.assertEqual(rc, 0, "\n".join(lines))
        self.assertTrue(any("PASS" in l for l in lines))

    def test_refuses_serial_without_confirmation(self):
        p = subprocess.run([sys.executable, os.path.join(ROOT, "tools", "echo_client.py"), "--port", "/dev/null"],
                           capture_output=True, text=True, timeout=30)
        self.assertEqual(p.returncode, 2)
        self.assertIn("Refusing", p.stderr)

    def test_other_baud_rates_are_refused_before_any_port_access(self):
        for baud in ("230400", "921600", "9600"):
            p = subprocess.run([sys.executable, os.path.join(ROOT, "tools", "echo_client.py"), "--selftest", "--baud", baud],
                               capture_output=True, text=True, timeout=30)
            self.assertEqual(p.returncode, 2, baud)
            self.assertIn("115200 baud only", p.stderr)

    def test_reset_probe_needs_confirmation_and_two_cycles(self):
        p = subprocess.run([sys.executable, os.path.join(ROOT, "tools", "echo_client.py"), "--port", "/dev/null", "--reset-probe", "5"],
                           capture_output=True, text=True, timeout=30)
        self.assertEqual(p.returncode, 2)
        self.assertIn("Refusing", p.stderr)
        p = subprocess.run([sys.executable, os.path.join(ROOT, "tools", "echo_client.py"), "--port", "/dev/null",
                            "--confirm-board-access", "--reset-probe", "1"], capture_output=True, text=True, timeout=30)
        self.assertNotEqual(p.returncode, 0)

    def test_no_arguments_is_an_error(self):
        p = subprocess.run([sys.executable, os.path.join(ROOT, "tools", "echo_client.py")],
                           capture_output=True, text=True, timeout=30)
        self.assertNotEqual(p.returncode, 0)


if __name__ == "__main__":
    unittest.main()
