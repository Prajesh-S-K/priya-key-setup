"""Host-side framing tests for the M1 echo protocol. Pure standard library, no serial port, no board.

Run with the existing ESP-IDF Python (no install needed):
  ~/.espressif/tools/python/v6.1/venv/bin/python -I -m unittest discover -s tests -v
"""
import os
import random
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest
import zlib

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))

from gpecho import framing as F  # noqa: E402


def stream(*frames):
    return b"".join(frames)


class CrcTests(unittest.TestCase):
    # Published CRC-32/ISO-HDLC check values.
    VECTORS = [
        (b"", 0x00000000),
        (b"a", 0xE8B7BE43),
        (b"123456789", 0xCBF43926),
        (b"The quick brown fox jumps over the lazy dog", 0x414FA339),
        (b"\x00\x00\x00\x00", 0x2144DF1C),
    ]

    def test_known_vectors(self):
        for data, want in self.VECTORS:
            self.assertEqual(F.crc32(data), want, data)

    def test_matches_zlib(self):
        rng = random.Random(1)
        for n in (0, 1, 2, 3, 13, 64, 255, 256, 269, 1000):
            data = bytes(rng.randrange(256) for _ in range(n))
            self.assertEqual(F.crc32(data), zlib.crc32(data) & 0xFFFFFFFF)


class CobsTests(unittest.TestCase):
    VECTORS = [
        (b"\x00", b"\x01\x01"),
        (b"\x00\x00", b"\x01\x01\x01"),
        (b"\x00\x11\x00", b"\x01\x02\x11\x01"),
        (b"\x11\x22\x00\x33", b"\x03\x11\x22\x02\x33"),
        (b"\x11\x22\x33\x44", b"\x05\x11\x22\x33\x44"),
        (b"\x11\x00\x00\x00", b"\x02\x11\x01\x01\x01"),
    ]

    def test_known_vectors(self):
        for raw, enc in self.VECTORS:
            self.assertEqual(F.cobs_encode(raw), enc)
            self.assertEqual(F.cobs_decode(enc), raw)

    def test_empty(self):
        self.assertEqual(F.cobs_encode(b""), b"\x01")
        self.assertEqual(F.cobs_decode(b"\x01"), b"")

    def test_no_zero_in_output_and_roundtrip(self):
        rng = random.Random(2)
        for n in list(range(0, 520)) + [1000]:
            for pattern in ("rand", "zeros", "ones", "nonzero"):
                if pattern == "rand":
                    raw = bytes(rng.randrange(256) for _ in range(n))
                elif pattern == "zeros":
                    raw = b"\x00" * n
                elif pattern == "ones":
                    raw = b"\xff" * n
                else:
                    raw = bytes(rng.randrange(1, 256) for _ in range(n))
                enc = F.cobs_encode(raw)
                self.assertNotIn(0, enc)
                self.assertLessEqual(len(enc), n + n // 254 + 1)
                self.assertEqual(F.cobs_decode(enc), raw)

    def test_254_boundary_and_lenient_trailing_block(self):
        raw = bytes(range(1, 255))                    # 254 non-zero bytes
        enc = F.cobs_encode(raw)
        self.assertEqual(enc, b"\xff" + raw + b"\x01")
        self.assertEqual(len(enc), 254 + 254 // 254 + 1)   # the bound is tight here
        self.assertEqual(F.cobs_decode(b"\xff" + raw), raw)   # without the trailing empty block
        self.assertEqual(F.cobs_decode(enc), raw)

    def test_decode_rejects_structure_errors(self):
        for bad in (b"\x00", b"\x02", b"\x05\x11\x22", b"\x03\x11\x00", b"\x01\x00\x01"):
            with self.assertRaises(F.FrameError) as cm:
                F.cobs_decode(bad)
            self.assertEqual(cm.exception.kind, "cobs", bad)


class FrameTests(unittest.TestCase):
    def test_layout_and_crc_coverage(self):
        raw = F.build_raw(F.T_ECHO_REQ, 0x01020304, b"\xaa\xbb")
        self.assertEqual(raw[:9], bytes([1, 0x01, 0, 0x04, 0x03, 0x02, 0x01, 2, 0]))
        self.assertEqual(raw[9:11], b"\xaa\xbb")
        self.assertEqual(struct.unpack("<I", raw[11:])[0], F.crc32(raw[:11]))
        self.assertEqual(len(raw), 13 + 2)

    def test_golden_wire_bytes(self):
        # Pinned so the C and PowerShell implementations can be compared against the same bytes.
        wire = F.encode_frame(F.T_ECHO_REQ, 1, b"hi")
        self.assertEqual(F.parse_encoded(wire[:-1]), F.Frame(F.T_ECHO_REQ, 1, b"hi"))
        self.assertEqual(wire[-1], 0)
        self.assertNotIn(0, wire[:-1])
        # Hand-derived: raw = 01 01 00 01 00 00 00 02 00 'h' 'i' CRC32=0xBA22F554 (LE 54 f5 22 ba),
        # then COBS and the 0x00 delimiter.
        self.assertEqual(wire.hex(), "03010102010101020207686954f522ba00")

    def test_zero_bytes_everywhere(self):
        for payload in (b"", b"\x00", b"\x00" * 7, b"\x00" * 256, b"\x00\x01" * 128):
            for seq in (0, 1, 0xFFFFFFFF, 0x00000100):
                wire = F.encode_frame(F.T_ECHO_RSP, seq, payload)
                dec = F.StreamDecoder()
                ev = dec.feed(wire)
                self.assertEqual([e.kind for e in ev], ["frame"])
                self.assertEqual(ev[0].frame, F.Frame(F.T_ECHO_RSP, seq, payload))

    def test_all_payload_sizes_up_to_max(self):
        rng = random.Random(3)
        for n in range(0, F.MAX_PAYLOAD + 1):
            payload = bytes(rng.randrange(256) for _ in range(n))
            wire = F.encode_frame(F.T_ECHO_REQ, n, payload)
            self.assertLessEqual(len(wire) - 1, F.MAX_ENCODED)
            self.assertEqual(F.parse_encoded(wire[:-1]).payload, payload)

    def test_maximum_payload_and_encoded_size(self):
        self.assertEqual(F.MAX_RAW, 269)
        self.assertEqual(F.MAX_ENCODED, 271)
        self.assertEqual(F.MAX_ENCODED_WITH_DELIM, 272)
        worst = F.encode_frame(F.T_ECHO_REQ, 0xFFFFFFFF, b"\xff" * 256)
        self.assertLessEqual(len(worst), 272)
        with self.assertRaises(ValueError):
            F.build_raw(F.T_ECHO_REQ, 0, b"x" * 257)

    def test_real_frames_fit_within_the_buffer_limit(self):
        # MAX_ENCODED is the COBS worst case for any 269-byte input. Real frames always contain a zero
        # (the flags byte), so they are at most this long; check a spread of the largest ones.
        rng = random.Random(6)
        longest = 0
        for _ in range(300):
            payload = bytes(rng.randrange(1, 256) for _ in range(256))
            wire = F.encode_frame(F.T_ECHO_REQ, rng.getrandbits(32) | 0x01010101, payload)
            longest = max(longest, len(wire) - 1)
            self.assertLessEqual(len(wire) - 1, F.MAX_ENCODED)
        self.assertGreaterEqual(longest, 269)   # at least raw length

    def test_length_validation(self):
        good = F.build_raw(F.T_ECHO_REQ, 1, b"abc")
        # too short
        for n in range(0, F.MIN_RAW):
            with self.assertRaises(F.FrameError) as cm:
                F.parse_raw(good[:n])
            self.assertEqual(cm.exception.kind, "length")
        # len field disagrees with decoded size (fix CRC so only length is wrong)
        body = bytearray(good[:-4])
        body[7] = 4
        bad = bytes(body) + struct.pack("<I", F.crc32(bytes(body)))
        with self.assertRaises(F.FrameError) as cm:
            F.parse_raw(bad)
        self.assertEqual(cm.exception.kind, "length")
        # len field says more than the maximum
        body = bytearray(struct.pack("<BBBIH", 1, 1, 0, 1, 257) + b"x" * 257)
        bad = bytes(body) + struct.pack("<I", F.crc32(bytes(body)))
        with self.assertRaises(F.FrameError) as cm:
            F.parse_raw(bad)
        self.assertEqual(cm.exception.kind, "length")

    def test_version_and_flags_rejected_after_crc(self):
        for kind, kwargs in (("version", {"ver": 2}), ("flags", {"flags": 1})):
            raw = F.build_raw(F.T_ECHO_REQ, 5, b"x", **kwargs)
            with self.assertRaises(F.FrameError) as cm:
                F.parse_raw(raw)
            self.assertEqual(cm.exception.kind, kind)

    def test_every_single_byte_corruption_is_rejected(self):
        for payload in (b"", b"hello", bytes(range(256))):
            wire = F.encode_frame(F.T_ECHO_REQ, 0x12345678, payload)
            enc = wire[:-1]
            for i in range(len(enc)):
                for delta in (1, 0x80, 0xFF):
                    mutated = bytearray(enc)
                    mutated[i] = (mutated[i] + delta) & 0xFF
                    try:
                        frame = F.parse_encoded(bytes(mutated))
                    except F.FrameError:
                        continue
                    # A mutated chunk that still parses must not equal a different valid frame silently
                    # unless the mutation changed nothing meaningful; CRC-32 detects all single-byte errors.
                    self.fail(f"corruption accepted at {i} delta {delta}: {frame}")

    def test_single_bit_flips_in_raw_always_fail_crc_or_length(self):
        raw = F.build_raw(F.T_ECHO_REQ, 9, b"payload-bytes")
        for i in range(len(raw)):
            for bit in range(8):
                m = bytearray(raw)
                m[i] ^= 1 << bit
                with self.assertRaises(F.FrameError):
                    F.parse_raw(bytes(m))


class StreamTests(unittest.TestCase):
    def kinds(self, events):
        return [(e.kind, e.error) for e in events]

    def test_back_to_back_frames_and_empty_delimiters(self):
        w1 = F.encode_frame(F.T_ECHO_REQ, 1, b"one")
        w2 = F.encode_frame(F.T_ECHO_REQ, 2, b"two")
        dec = F.StreamDecoder()
        ev = dec.feed(b"\x00\x00" + w1 + b"\x00" + w2)
        self.assertEqual([e.frame.seq for e in ev], [1, 2])
        self.assertEqual(dec.counters["empty"], 3)

    def test_byte_at_a_time_equals_whole(self):
        data = stream(F.encode_frame(F.T_ECHO_REQ, 1, b"a" * 200), b"junk\x00", F.encode_frame(F.T_INFO_REQ, 2))
        a = F.StreamDecoder()
        whole = a.feed(data)
        b = F.StreamDecoder()
        parts = []
        for byte in data:
            parts += b.feed(bytes([byte]))
        self.assertEqual(self.kinds(whole), self.kinds(parts))
        self.assertEqual([e.frame for e in whole if e.frame], [e.frame for e in parts if e.frame])

    def test_recovery_after_esp32_boot_text(self):
        boot = (b"ets Jun  8 2016 00:22:57\r\n\r\nrst:0x1 (POWERON_RESET),boot:0x13 (SPI_FAST_FLASH_BOOT)\r\n"
                b"configsip: 0, SPIWP:0xee\r\n")
        hello = F.encode_frame(F.T_HELLO, 0, b"\x01" * 35)
        # ROM text, then our leading delimiter, then HELLO.
        dec = F.StreamDecoder()
        ev = dec.feed(boot + b"\x00" + hello)
        self.assertEqual(sum(1 for e in ev if e.kind == "error"), 1)   # the ROM text chunk, whatever its kind
        self.assertEqual([e.frame.type for e in ev if e.frame], [F.T_HELLO])

    def test_boot_text_glued_to_frame_loses_only_that_frame(self):
        boot = b"rst:0x1 (POWERON_RESET)\r\n"
        f1 = F.encode_frame(F.T_ECHO_RSP, 1, b"x")
        f2 = F.encode_frame(F.T_ECHO_RSP, 2, b"y")
        dec = F.StreamDecoder()
        ev = dec.feed(boot + f1 + f2)          # no delimiter between the text and the first frame
        self.assertEqual([e.frame.seq for e in ev if e.frame], [2])
        self.assertEqual(sum(1 for e in ev if e.kind == "error"), 1)

    def test_recovery_after_random_garbage(self):
        rng = random.Random(4)
        good = [F.encode_frame(F.T_ECHO_REQ, i, bytes([i]) * (i % 40)) for i in range(50)]
        data = bytearray()
        for g in good:
            data += b"\x00" + bytes(rng.randrange(256) for _ in range(rng.randrange(0, 60))) + b"\x00" + g
        dec = F.StreamDecoder()
        ev = dec.feed(bytes(data))
        seqs = [e.frame.seq for e in ev if e.frame]
        self.assertEqual(seqs, list(range(50)))

    def test_truncated_frame_then_good_frame(self):
        full = F.encode_frame(F.T_ECHO_REQ, 7, b"0123456789")
        good = F.encode_frame(F.T_ECHO_REQ, 8, b"ok")
        for cut in range(1, len(full) - 1):
            dec = F.StreamDecoder()
            ev = dec.feed(full[:cut] + b"\x00" + good)
            self.assertEqual([e.frame.seq for e in ev if e.frame], [8], cut)

    def test_truncated_frame_without_delimiter_waits(self):
        full = F.encode_frame(F.T_ECHO_REQ, 7, b"0123456789")
        dec = F.StreamDecoder()
        self.assertEqual(dec.feed(full[:-1]), [])       # no delimiter, nothing emitted yet
        self.assertEqual([e.frame.seq for e in dec.feed(full[-1:])], [7])

    def test_oversize_input_is_discarded_and_resynchronizes(self):
        good = F.encode_frame(F.T_ECHO_REQ, 1, b"ok")
        for n in (F.MAX_ENCODED + 1, F.MAX_ENCODED + 2, 1000, 100000):
            dec = F.StreamDecoder()
            ev = dec.feed(b"\x55" * n + b"\x00" + good)
            self.assertEqual(self.kinds(ev), [("error", "oversize"), ("frame", None)], n)
            self.assertEqual(dec.counters["oversize"], 1)
            self.assertLessEqual(len(dec.buf), F.MAX_ENCODED)

    def test_exactly_max_encoded_chunk_is_not_oversize(self):
        dec = F.StreamDecoder()
        ev = dec.feed(b"\x55" * F.MAX_ENCODED + b"\x00")
        self.assertEqual([e.kind for e in ev], ["error"])
        self.assertNotEqual(ev[0].error, "oversize")
        self.assertEqual(dec.counters["oversize"], 0)

    def test_largest_valid_frame_passes_through_the_stream_decoder(self):
        wire = F.encode_frame(F.T_ECHO_REQ, 0x7F7F7F7F, bytes(range(1, 255)) + b"\xff\xfe")
        self.assertEqual(len(F.parse_raw(F.cobs_decode(wire[:-1])).payload), 256)
        dec = F.StreamDecoder()
        ev = dec.feed(wire)
        self.assertEqual([e.kind for e in ev], ["frame"])

    def test_fuzz_never_raises_and_only_accepts_real_frames(self):
        rng = random.Random(5)
        real = [F.encode_frame(F.T_ECHO_REQ, i, bytes(rng.randrange(256) for _ in range(rng.randrange(0, 257))))
                for i in range(40)]
        valid_wire = {r[:-1] for r in real}
        for _ in range(3000):
            blob = bytearray()
            for _ in range(rng.randrange(1, 6)):
                kind = rng.randrange(4)
                if kind == 0:
                    blob += rng.choice(real)
                elif kind == 1:
                    m = bytearray(rng.choice(real))
                    for _ in range(rng.randrange(1, 4)):
                        m[rng.randrange(len(m))] = rng.randrange(256)
                    blob += m
                elif kind == 2:
                    blob += bytes(rng.randrange(256) for _ in range(rng.randrange(0, 400)))
                else:
                    blob += b"\x00" * rng.randrange(1, 4)
            dec = F.StreamDecoder()
            events = dec.feed(bytes(blob))
            for e in events:
                if e.kind == "frame":
                    # Anything accepted must re-encode to a byte-identical valid frame.
                    re = F.cobs_encode(F.build_raw(e.frame.type, e.frame.seq, e.frame.payload))
                    self.assertEqual(F.parse_encoded(re), e.frame)


class InfoTests(unittest.TestCase):
    def test_info_roundtrip_and_size(self):
        payload = F.pack_info(1, 256, 12345, 1, 2, 3, 4, 5, 6, 7)
        self.assertEqual(len(payload), 35)
        info = F.unpack_info(payload)
        self.assertEqual(info["rx_crc_err"], 3)
        self.assertEqual(info["tx_frames"], 7)
        with self.assertRaises(F.FrameError):
            F.unpack_info(payload[:-1])


@unittest.skipUnless(shutil.which("clang") or shutil.which("cc"), "no C compiler")
class CParityTests(unittest.TestCase):
    """Compile the firmware's framing code on the host and compare it with this module."""

    def test_c_matches_python(self):
        cc = shutil.which("clang") or shutil.which("cc")
        with tempfile.TemporaryDirectory() as tmp:
            exe = os.path.join(tmp, "test_frame")
            subprocess.run([cc, "-std=c11", "-Wall", "-Wextra", "-Werror", "-O1", "-g", "-fsanitize=undefined",
                            "-I", os.path.join(ROOT, "firmware", "m1-echo", "main"),
                            os.path.join(ROOT, "tests", "c", "test_frame.c"),
                            os.path.join(ROOT, "firmware", "m1-echo", "main", "echo_frame.c"),
                            "-o", exe], check=True, timeout=120)
            # AddressSanitizer hangs at startup on the dev Mac (see reports/m1-preparation.md), so only UBSan is used.
            p = subprocess.run([exe], capture_output=True, text=True, timeout=60)
            self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
            self.assertIn("C framing tests passed", p.stdout)


if __name__ == "__main__":
    unittest.main()
