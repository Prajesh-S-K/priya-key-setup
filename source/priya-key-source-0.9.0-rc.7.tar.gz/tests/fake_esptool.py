#!/usr/bin/env python3
"""A fake esptool/espefuse for the flasher tests. It keeps a 'flash' in a file and answers the commands the flasher uses
with the output formats of esptool 5.3.1 / espefuse 5.3.1 (same formats as the gating tests). It never opens a serial port.
State: $FAKE_STATE/scenario.json (inputs) and $FAKE_STATE/calls.log (every subcommand seen, in order)."""
import json
import os
import sys

S = os.environ["FAKE_STATE"]
sc = json.load(open(os.path.join(S, "scenario.json")))
args = sys.argv[1:]


def log(x):
    with open(os.path.join(S, "calls.log"), "a") as fh:
        fh.write(x + "\n")


def counter(name):
    p = os.path.join(S, name)
    n = int(open(p).read()) if os.path.exists(p) else 0
    open(p, "w").write(str(n + 1))
    return n


def image():
    return bytearray(open(sc["image"], "rb").read())


def pairs(rest):
    out, i = [], 0
    while i < len(rest):
        if rest[i].startswith("--"):
            i += 2
            continue
        out.append((int(rest[i], 0), rest[i + 1]))
        i += 2
    return out


if "summary" in args:
    log("efuse summary")
    path = args[args.index("--file") + 1]
    if sc.get("fuses") is not None:
        open(path, "w").write(sc["fuses"] if isinstance(sc["fuses"], str) else json.dumps(sc["fuses"]))
    print("espefuse v5.3.1")
    sys.exit(0)

sub = next(a for a in args if a in ("chip-id", "flash-id", "read-mac", "read-flash", "verify-flash", "write-flash"))
rest = args[args.index(sub) + 1:]
log(sub)
head = f"esptool v5.3.1\nConnected to ESP32 on {sc.get('port', 'X')}:\n"
if sub == "chip-id":
    print(head + f"Chip type:          {sc['chip']}\nFeatures:           Wi-Fi, BT, Dual Core")
elif sub == "flash-id":
    print(head + f"Manufacturer: 20\nDevice: 4016\nDetected flash size: {sc['flash_mb']}MB")
elif sub == "read-mac":
    macs = sc["macs"]
    n = counter("macs")
    print(head + f"MAC:                {macs[min(n, len(macs) - 1)]}")
elif sub == "read-flash":
    addr, size, path = int(rest[0], 0), int(rest[1], 0), rest[2]
    open(path, "wb").write(bytes(image()[addr:addr + size]))
elif sub == "verify-flash":
    img = image()
    bad = False
    for off, f in pairs(rest):
        d = open(f, "rb").read()
        if bytes(img[off:off + len(d)]) != d:
            bad = True
    print("Verification failed" if bad else "Hash of data verified.")
    sys.exit(2 if bad else 0)
elif sub == "write-flash":
    if sc.get("fail_write"):
        print("A fatal error occurred: write failed"); sys.exit(2)
    img = image()
    for off, f in pairs(rest):
        d = open(f, "rb").read()
        img[off:off + len(d)] = d
        log(f"wrote 0x{off:x} {len(d)}")
    open(sc["image"], "wb").write(bytes(img))
