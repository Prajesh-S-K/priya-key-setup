"""Source-level regression guards for Windows start-up failures found on a real PC (the app cannot be run on the build Mac)."""
import os
import re
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def rd(p):
    with open(os.path.join(ROOT, p), encoding="utf-8") as fh:
        return fh.read()


class WindowsStartup(unittest.TestCase):
    def test_webview2_data_folder_is_in_the_user_profile_not_program_files(self):
        s = rd("host/windows-app/src/app.rs")
        self.assertIn("WebContext::new(Some(", s)
        self.assertIn("new_with_web_context(", s)
        self.assertNotRegex(s, r"WebViewBuilder::new\(\)")
        self.assertIn('"LOCALAPPDATA"', s)
        self.assertNotRegex(s, r"current_exe\(\)[^;]*parent", "never derive a data folder from the exe's folder")

    def test_every_startup_failure_is_shown_not_silent(self):
        s = rd("host/windows-app/src/app.rs")
        self.assertIn("set_hook", s)
        self.assertIn("fn fatal", s)
        self.assertNotRegex(s, r"\.expect\(", "no silent panics on the start-up path")
        self.assertEqual(len(re.findall(r"\.unwrap\(\)", re.sub(r"lock\(\)\.unwrap\(\)|serde_json::to_string\([^)]*\)\.unwrap\(\)", "", s))), 0)

    def test_winfsp_is_delay_loaded_and_loaded_by_installed_path(self):
        b = rd("host/windows-app/build.rs")
        self.assertIn("/DELAYLOAD:winfsp-x64.dll", b)
        f = rd("host/windows-app/src/fs.rs")
        self.assertIn("preload_winfsp", f)
        self.assertIn("WOW6432Node", f)
        self.assertIn("InstallDir", f)
        self.assertIn("delay-loaded", rd("tools/build_windows.sh"))

    def test_nothing_is_written_next_to_the_exe(self):
        for f in ("host/windows-app/src/app.rs", "host/windows-app/src/ui.rs", "host/windows-app/src/fs.rs", "host/windows-app/src/controller.rs"):
            s = rd(f)
            self.assertNotRegex(s, r"current_exe\(\)\s*\.[^;]*(write|create|File::)", f)


if __name__ == "__main__":
    unittest.main()
