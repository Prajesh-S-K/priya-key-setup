#!/bin/sh
# Rebuilds and (re)starts the dashboard preview on http://127.0.0.1:8766/  (localhost only). Preview PIN: 2026.
set -eu
D="$(cd "$(dirname "$0")" && pwd)"
python3 "$D/build.py"
OLD=$(lsof -tiTCP:8766 -sTCP:LISTEN 2>/dev/null || true); [ -z "$OLD" ] || kill $OLD 2>/dev/null || true
sleep 0.3
cd "$D/site" && nohup python3 -m http.server 8766 --bind 127.0.0.1 >"$D/server.log" 2>&1 </dev/null &
sleep 0.8
curl -fsS -o /dev/null http://127.0.0.1:8766/ && echo "preview running: http://127.0.0.1:8766/"
[ "${1:-}" = "--no-open" ] || open "http://127.0.0.1:8766/"
