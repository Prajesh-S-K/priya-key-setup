// PREVIEW ONLY. A simulated device and host so the dashboard can be explored in a browser. Nothing here talks to a board.
// The preview PIN lives only in this file (never in firmware, apps or the real board).
(function(){
  const PREVIEW_PIN='2026';
  const Q=new URLSearchParams(location.search), P=Q.get('p')||'windows';
  const saved=(()=>{try{return JSON.parse(sessionStorage.getItem('pv_state')||'{}')}catch(e){return{}}})();
  let discreet=!!saved.discreet; let pin=saved.pin||PREVIEW_PIN, wrong=0, until=0, authed=false, device='Locked', events=[], recovery=true, restored={}, pendingOrig={};
  const cards=[
    {id:'a1',name:'Taxes 2025',hidden:false,state:'Locked',dir:'C:/Users/Priya/Vaults/3f9a21c4.gpv'},
    {id:'c3',name:'Passport scans',hidden:false,state:'Locked',dir:'E:/Docs/55aa01d9.gpv'},
    {id:'b2',name:'Family photos',hidden:true,state:'Locked · Hidden',dir:'D:/Backup/9b02ee17.gpv'},
    {id:'d4',name:'Love letters',hidden:true,state:'Locked · Hidden',dir:'C:/Users/Priya/Desktop/0c7d4b3a.gpv'}];
  const tree={'':[{name:'docs',dir:true,size:0},{name:'readme.txt',dir:false,size:1600},{name:'pic.png',dir:false,size:70},{name:'report.pdf',dir:false,size:482113}],
    docs:[{name:'notes.md',dir:false,size:19},{name:'deep',dir:true,size:0}],'docs/deep':[{name:'todo.txt',dir:false,size:42}]};
  const png='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==';
  const CODE='7K2M-9QXA-D4TR-1VHB-N6WE-PZ03-8YCG-F5JS-KT2D-WA71-9MXH-4EQ6-B';
  const save=()=>{try{sessionStorage.setItem('pv_state',JSON.stringify({pin,discreet}))}catch(e){}};
  const find=id=>cards.find(c=>c.id===id);
  const lockAll=why=>{authed=false;cards.forEach(c=>{c.state=c.hidden?'Locked · Hidden':'Locked'});if(why)events.push({type:'locked',reason:why})};
  const open=()=>cards.filter(c=>c.state==='Unlocked');

  window.__gpNative=async(n,a)=>{const x=JSON.parse(a||'{}');
    if(n==='capabilities')return P==='android'?{platform:'android',backup:true,open_path:true,battery:true,discreet:true}:{platform:'windows',backup:true,open_path:true,autostart:true,discreet:true};
    if(n==='setup_status'&&P==='android')return [{id:'host',label:'This phone supports USB devices',ok:true,detail:'USB host mode is available.'},{id:'board',label:'Key plugged in',ok:true,detail:'The key was found.'},{id:'usb',label:'Permission to use the key',ok:true,detail:'Granted'},{id:'notif',label:'Notification while the key is connected',ok:false,detail:'Android requires a visible notice while the key stays connected.',action:'notifications',action_label:'Allow'},{id:'battery',label:'Unrestricted background use',ok:false,detail:'Recommended so Android does not stop the connection.',action:'battery',action_label:'Open'}];
    if(n==='autostart_get')return !!window.__auto;
    if(n==='autostart_set'){window.__auto=x.on;return true}
    if(n==='pick_folder'){const t=x.title||'';return t.includes('backup')||t.includes('Backup')?'D:/Backups/PriyaKey':t.includes('Where to keep')?'D:/Vaults':t.includes('Restore')?'C:/Users/Priya/Restored':t.includes('protect')?'C:/Users/Priya/Documents/Example folder':t.includes('recover')?'D:/Backup/9b02ee17.gpv':'C:/Users/Priya/Documents/Example'}
    if(n==='confirm'){return window.confirm((x.title||'')+'\n\n'+(x.text||''))}
    if(n==='prompt'){return window.prompt(x.title||'',x.value||'')}
    if(n==='open_path'){window.__toast&&0;alert('Preview: this would open the drive / file picker.');return null}
    if(n==='open_battery_settings'){alert('Preview: this would open Android battery settings.');return null}
    if(n==='setup_action'){return null}
    return null};

  window.__gpBridge=async(s)=>{const r=JSON.parse(s),ok=d=>JSON.stringify({ok:true,data:d}),err=m=>JSON.stringify({ok:false,error:m});
    await new Promise(z=>setTimeout(z,r.cmd==='status'||r.cmd==='events'?0:150));
    switch(r.cmd){
      case 'status':return ok({device,paired:true,authenticated:authed,recovery,cards:authed?cards:[],settings:{discreet},board_connected:device!=='Unplugged',mount_problem:null,
        mounts:Object.fromEntries(open().map(c=>[c.id,'Z:'])),unlocked:open().map(c=>({id:c.id,name:c.name})),notices:[],
        app:{version:'preview',platform:'Preview (simulated device)',dashboard_source:'bundled with the app',dashboard_version:1}});
      case 'events':{const e=events;events=[];return ok({events:e})}
      case 'auth':{
        if(device==='Privacy')return ok({result:'not_ready'});
        if(Date.now()<until)return ok({result:'delayed',remaining_ms:until-Date.now()});
        if(r.pin===pin){wrong=0;authed=true;device='Active';return ok({result:'ok'})}
        wrong++;let d=0;if(wrong>=4){d=[5000,30000,300000][Math.min(wrong-4,2)];until=Date.now()+d}
        return ok({result:'wrong_pin',delay_ms:d})}
      case 'pair':await new Promise(z=>setTimeout(z,1500));pin=r.pin;save();authed=true;device='Active';return ok({paired:true});
      case 'change_pin':if(r.old!==pin)return ok({result:'wrong_pin',delay_ms:0});if(!/^\d{4}$/.test(r.new))return ok({result:'bad_pin'});pin=r.new;save();return ok({result:'ok'});
      case 'set_discreet':discreet=!!r.on;save();return ok({discreet});
      case 'lock_all':lockAll('locked by you');return ok({});
      case 'unlock':if(!authed)return err('locked: authenticate first');find(r.id).state='Unlocked';return ok({});
      case 'lock':{const c=find(r.id);c.state=c.hidden?'Locked · Hidden':'Locked';return ok({})}
      case 'set_hidden':{const c=find(r.id);c.hidden=r.hidden;if(c.state!=='Unlocked')c.state=r.hidden?'Locked · Hidden':'Locked';return ok({})}
      case 'rename':find(r.id).name=r.name;return ok({});
      case 'browse':return ok({entries:tree[r.path]||[]});
      case 'preview':return /\.png$/.test(r.path)?ok({kind:'image',mime:'image/png',size:70,base64:png}):/\.pdf$/.test(r.path)?ok({kind:'other',mime:'application/pdf',size:482113}):ok({kind:'text',mime:'text/plain',size:19,text:'# disposable sample\nhello from the simulated vault\n'});
      case 'add_folder':{const id='n'+Date.now();cards.push({id,name:r.name,hidden:!!r.hidden,state:r.hidden?'Locked · Hidden':'Locked',dir:(r.parent||'D:/Vaults')+'/'+id.slice(-8)+'.gpv'});pendingOrig[id]=true;
        return ok({id,import:{files:[{path:'a.txt',size:120,sha256:''},{path:'b/c.png',size:70,sha256:''}],bytes:190,errors:[],skipped:[],verified:true}})}
      case 'delete_originals':delete pendingOrig[r.id];return ok({deleted:2,kept:[],note:'Ordinary delete; this is not secure erasure on SSD or flash storage.'});
      case 'restore':restored[r.id]=true;return ok({files:[{path:'readme.txt',size:1600,sha256:''},{path:'pic.png',size:70,sha256:''}],bytes:1670,errors:[],skipped:[],verified:true});
      case 'delete_vault':{if(!restored[r.id])return err('the restored copy has not been verified: the encrypted folder is kept');cards.splice(cards.indexOf(find(r.id)),1);return ok({note:'Ordinary delete; this is not secure erasure on SSD or flash storage.'})}
      case 'setup_recovery':case 'rotate_recovery':recovery=true;return ok({code:CODE});
      case 'export_vault':{const c=find(r.id);if(c.state==='Unlocked')return err('lock the folder first, then make the backup');return ok({report:{dest:r.dest+'/'+c.dir.split('/').pop(),files:4,bytes:3145728,verified:true,errors:[]},note:'This is a copy of the ENCRYPTED folder. Keep it somewhere safe; the recovery code cannot recreate a folder file that was deleted.'})}
      case 'restore_backup':return ok({id:'z9',report:{verified:true,files:4,bytes:3145728,errors:[]}});
      case 'recover_vault':if(!/^[A-Z0-9-]{20,}$/.test((r.code||'').trim().toUpperCase()))return err('that recovery code does not open this folder');return ok({id:'a1'});
      default:return ok({});
    }};

  // ---- preview-only controls (simulate the physical key)
  window.addEventListener('DOMContentLoaded',()=>{
    const bar=document.createElement('div');bar.id='pv-bar';
    bar.innerHTML='<b>Preview — simulated device</b><span>PIN 2026</span><i></i><button data-a="boot">Press BOOT</button><button data-a="unplug">Unplug key</button><button data-a="plug">Plug in key</button>';
    document.body.appendChild(bar);
    bar.onclick=e=>{const a=e.target.dataset&&e.target.dataset.a;if(!a)return;
      if(a==='boot'){if(device==='Privacy'){device='Locked'}else{lockAll('the key\'s BOOT button was pressed (privacy mode)');device='Privacy'}}
      if(a==='unplug'){lockAll('the key was unplugged');device='Unplugged';
        if(discreet){ // what discreet mode does on the real apps: the dashboard (and previews) are closed, tray icon removed
          const o=document.createElement('div');o.id='pv-conceal';o.style.cssText='position:fixed;inset:30px 0 0 0;z-index:99998;background:#000;color:#5b6b7a;display:flex;align-items:center;justify-content:center;text-align:center;font:14px system-ui;padding:20px';
          o.innerHTML='<div>Discreet mode: the dashboard was closed and the tray icon removed.<br>Everything is locked. Press “Plug in key” to simulate the key returning — the dashboard comes back at the PIN screen.</div>';document.body.appendChild(o)}}
      if(a==='plug'){if(device==='Unplugged'){device='Locked';if(discreet){save();location.reload()}}}};
  });
})();
