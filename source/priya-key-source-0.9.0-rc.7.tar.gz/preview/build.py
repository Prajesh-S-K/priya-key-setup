#!/usr/bin/env python3
"""Builds preview/site/index.html = the CURRENT dashboard (dashboard/index.html, unmodified) + the preview mock bridge + a
'Preview - simulated device' label. The production dashboard, firmware and apps are not touched."""
import os
R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
html = open(f"{R}/dashboard/index.html", encoding="utf-8").read()
mock = open(f"{R}/preview/mock-preview.js", encoding="utf-8").read()
css = """<style>#pv-bar{position:fixed;left:0;right:0;top:0;z-index:99999;display:flex;gap:10px;align-items:center;justify-content:center;flex-wrap:wrap;padding:5px 10px;background:#ff4fa3;color:#12010a;font:12px/1.2 system-ui,sans-serif}
#pv-bar b{letter-spacing:.04em}#pv-bar span{background:#12010a;color:#ff9fd0;border-radius:99px;padding:2px 8px}#pv-bar i{flex:1;max-width:30px}
#pv-bar button{background:#12010a;color:#fff;border:0;border-radius:6px;padding:3px 9px;font:inherit;cursor:pointer}body{padding-top:30px}
#boot,#gate,#app,#lock,.panel{top:30px !important}</style>"""
assert '<script>\n"use strict";' in html
out = html.replace("</head>", css + "</head>", 1).replace('<script>\n"use strict";', "<script>" + mock + "</script>\n<script>\n\"use strict\";", 1)
os.makedirs(f"{R}/preview/site", exist_ok=True)
open(f"{R}/preview/site/index.html", "w", encoding="utf-8").write(out)
print("built preview/site/index.html", len(out), "bytes")
