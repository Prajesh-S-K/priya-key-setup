# Priya Key {{VERSION}} — installation guide

**Release candidate — physical-device acceptance pending.** Nothing in this package has been run on a Windows PC, an Android phone, or after flashing the new firmware. Use disposable test files first (see TEST_CHECKLIST.md). Do not put anything you cannot afford to lose into a protected folder until the checklist passes.

## What is in this folder
| Path | What it is |
|---|---|
| `windows/PriyaKey-Setup-{{VERSION}}.exe` | Windows installer (Windows 10 / 11, 64-bit). It installs WinFsp (included) and checks for WebView2. |
| `windows/redist/` | Offline copies of WinFsp and the Microsoft WebView2 runtime installer. Keep the `redist` folder **next to** the setup file. |
| `android/PriyaKey-{{VERSION}}.apk` | Android 11+ app, signed with the project's private release key. |
| `firmware/` | ESP32 firmware bundle (bootloader, partition table, app, signed dashboard image) and `flash_firmware.sh`. |
| `setup-site/` | The first-use setup page with everything it links to: complete Windows ZIP, installer-only, APK, SHA256SUMS, licences and GPL source (relative links; host the folder as-is). **Not published yet.** |
| `qr-card/` | Printable gift-card kit. QR code status: **pending** (needs the real published address). |
| `tools/` | `make-test-files.sh` / `.ps1` create disposable test folders. |
| `SHA256SUMS.txt`, `VERSION.txt` | Checksums and exact versions. Verify before installing. |
| `source/` | Source code (GPL-3.0-or-later) without secrets. |

## 0. Verify the files
macOS/Linux: `shasum -a 256 -c SHA256SUMS.txt`  ·  Windows PowerShell: `Get-FileHash <file> -Algorithm SHA256` and compare with SHA256SUMS.txt.

## First use: open the setup link first
**Connecting the key alone cannot install anything.** On first use, open the setup page (the link/QR on the gift card, or the files in `setup-site/` if you host them yourself) on the PC or phone you will use, install the app from it, and only then plug the key in. Each install is approved by you (Windows asks for administrator permission; Android asks to allow installing from your browser/Files app). The page explains permissions and shows the SHA-256 fingerprints to compare. The page is in the `setup-site` folder and is not yet published anywhere: see `qr-card/README.md`.

## 1. Board firmware (a separate, deliberate step)
The board already running the previous firmware keeps working with these apps; flashing is needed only for the board-stored dashboard (apps fall back to the bundled dashboard without it). Flashing **writes the board**, so it is two deliberate runs of one gated tool, `firmware/flash_firmware.py` (Python 3.9+, `pip install "esptool>=5"`; it uses the project's identification, security-state and backup-verification gates).
1. **Safe run (writes nothing):** `python3 flash_firmware.py --port <PORT> --workdir ~/priya-key-flash`.
   It verifies every package file against `SHA256SUMS.txt`, checks `flasher_args.json` and the partition table agree (write addresses are derived from them and may never touch the NVS/pairing region), identifies the board (classic ESP32, flash size, MAC), reads the security state (secure boot, flash encryption, restricted download mode — any uncertainty is a STOP), takes a **full-flash backup** at 115200 baud, and proves with `verify-flash` that the backup equals the connected board. It then stops and prints the board's MAC. The backup is in the work folder (owner-only; keep it private and offline — it can contain your pairing secrets).
2. **Authorize and write:** run again with a **new** work folder, the verified backup, and the MAC you saw: `python3 flash_firmware.py --port <PORT> --workdir ~/priya-key-flash2 --backup ~/priya-key-flash/flash-backup-full.bin --confirm-write <MAC>`. The tool re-identifies the board, re-verifies the backup against it, checks it is the same board again right before writing, writes only bootloader (0x1000), partition table (0x8000), app (0x10000) and dashboard image (0x110000) with no erase, and verifies what it wrote. An unrelated, short, blank or merely large backup file is rejected.
3. Unplug and replug. The dashboard shows `KEY · LOCKED` (paired) or `NEW KEY`.
Offline check without a board: `python3 flash_firmware.py --dry-run`. Never use `erase-flash`; secure boot / flash encryption are not supported with these files.

## 2. Windows
1. Copy the whole `windows` folder to the PC. Run `PriyaKey-Setup-{{VERSION}}.exe` as administrator. Windows SmartScreen may say "unknown publisher" because the app is not Authenticode-signed: choose *More info → Run anyway* only if the SHA-256 matched. **Windows 11 Smart App Control**, if on, can block the unsigned installer with no override: use a PC where it is off (see the setup page); turning it off is a deliberate choice that Microsoft has historically not let you undo without resetting Windows.
2. Leave "Start with Windows" unticked unless you want the tray icon at login. "Desktop shortcut" is also optional (unticked by default); the Start-menu entry *Priya Key* is always created.
3. Plug in the key. If Windows does not create a COM port within ~30 s, see Troubleshooting.
4. Start *Priya Key* from the Start menu, follow the first-time check, choose a four-digit PIN, press the key's BOOT button when asked, and **write down the recovery code**.
5. Upgrade: run a newer setup over the old one; your folders and settings stay in `%APPDATA%\PriyaKey` and the folders you created.

## 3. Android
1. Copy the APK to the phone, open it, and allow "install unknown apps" for the app you opened it from.
2. Open *Priya Key*; do the first-time check (notifications, background use). Plug the key in with a USB data cable or adapter (USB-C OTG if needed); choose **Allow** at the USB prompt.
3. **Storage warning:** encrypted folders live in the app's private storage. Uninstalling the app, clearing its data, or "storage cleanup" tools **permanently delete them**. The recovery code cannot bring back a deleted vault file. Use *card ▸ More ▸ Back up encrypted folder…* regularly and keep the backups elsewhere.
4. Update: install a newer APK signed with the same key over the old one (data is kept). Never uninstall first.

## Discreet mode (optional setting, off by default)
Settings ▸ *Discreet mode*. When on and the key is **unplugged**: everything locks (always the case), previews are dismissed, the dashboard window closes and, on Windows, the tray icon is removed; on Android the dashboard task is closed, provider roots disappear and the connection notification/foreground service stop. Only minimal detection remains: Windows keeps a small background process that checks for the key every 2 s (no window, no tray); Android keeps nothing running; the app is designed to be started by Android's USB-attach prompt, but that relaunch is **pending verification on a real phone — do not rely on it**: open the app by hand if it does not appear. **Reconnecting never restores access: the PIN is required again.**
It is **not invisibility**: the app stays in installed-app lists, the key stays visible to the OS as a USB device, and while the key is connected Android shows its required notification and Windows shows the tray icon.
- **Manual launch / recovery route:** Windows — Start menu ▸ *Priya Key*, or run `"C:\Program Files\PriyaKey\priya-key.exe"` (launching it always shows the window, even when discreet mode has hidden it; if it is already running it brings itself forward). Android — app drawer ▸ *Priya Key*. If a launcher icon was hidden by your phone maker's own feature, restore it there or open Settings ▸ Apps ▸ Priya Key ▸ Open.
- **Android launcher icon:** this app deliberately keeps its launcher entry. Hiding it dynamically could stop the USB-attach launch from working, which has not been verified on a phone. If you want the icon hidden, use your launcher's own *hide app* option (launcher-specific, optional, at your own risk; keep the manual route above in mind).

**Where the app keeps its files (Windows):** settings and pairing record in `%APPDATA%\PriyaKey`; the window's browser profile in `%LOCALAPPDATA%\PriyaKey\WebView2`; start-up problems, if any, in `%LOCALAPPDATA%\PriyaKey\startup-error.txt`. Nothing is written under `C:\Program Files`. Uninstalling leaves these folders (the WebView2 folder is only a cache and can be deleted).

## 4. Uninstall and data retention
- **Windows:** uninstalling removes the program only. `%APPDATA%\PriyaKey` and every encrypted folder you created stay on disk (deliberately). WinFsp stays installed. Delete encrypted folders yourself only if you will never need them.
- **Android:** uninstalling deletes everything the app stored, including encrypted folders (see above).
- **Board:** nothing is erased by uninstalling software. The key keeps its PIN and secrets. There is no secure-erase feature; deleting files is an ordinary delete.
- Plain copies you imported or restored are yours to manage: the app **never** deletes originals automatically; it offers deletion only after verification and only on your confirmation.

## Troubleshooting
| Symptom | Try |
|---|---|
| Dashboard says `PLUG IN THE KEY` | Use a data cable (many only charge). Another USB port. Windows: Device Manager → Ports should show a "USB-SERIAL CH340 (COMx)" device; if it shows an unknown device, run Windows Update or install the WCH CH340 driver from the chip vendor (not bundled here). Android: the phone must support USB host; try an OTG adapter. |
| `KEY NOT DETECTED` / no status | Unplug, wait 5 s, replug. Close other programs that use the COM port (serial terminals, Arduino IDE, esptool). |
| Windows: "Could not open … as a drive" | WinFsp is missing: run `windows\redist\winfsp.msi`, restart Priya Key. |
| Windows: window is blank/white | WebView2 runtime missing: run `windows\redist\MicrosoftEdgeWebView2RuntimeInstallerX64.exe`. |
| Second launch does nothing | It brings the first window forward (single instance). Look for the tray icon. |
| Android: folders lock when the screen is off | Settings ▸ First-time check ▸ Battery: allow unrestricted background use; also check your phone maker's own battery/“protected apps” list. |
| Android: no USB prompt | Unplug/replug the key; open the app; Settings ▸ First-time check ▸ "Ask now". |
| Window disappeared and the tray icon is gone | Discreet mode closed it when the key was unplugged. Plug the key in again, or launch Priya Key by hand (Start menu / app drawer). |
| Pairing fails with `Access is denied (os error 5)` | The key's USB link dropped or another program uses the COM port. Close serial monitors/Arduino IDE, unplug and replug, try another cable or a rear/powered USB port, and retry (the app now reconnects automatically). If the key vanishes from Device Manager ▸ Ports when BOOT is pressed, it is a power/cable problem. |
| `PRIVACY MODE` | The key's BOOT button was pressed once: press it once more, then enter the PIN. |
| `PLEASE WAIT` after wrong PINs | The key enforces delays (3 free tries, then 5 s, 30 s, 5 min, 30 min). The failed-attempt count survives unplugging; the waiting time itself starts again after a reconnect. |
| "needs attention" | The key's storage looked inconsistent and it stays locked for safety. Unplug/replug; if it persists use the recovery code with a replacement key. |
