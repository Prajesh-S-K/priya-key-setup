# Printable gift card — QR code status: PENDING

**No final QR code exists yet, on purpose.** It must point at the real, public HTTPS address of the setup page, and that address has not been chosen. `card-template.html` shows the layout with a clearly marked empty QR area ("TEMPLATE — NOT FOR PRINTING"); it contains no address.

## When the setup page is published
1. Publish **only** the contents of the `setup-site` folder, as-is (page, icon, `downloads/` with the complete Windows ZIP, installer, APK and `SHA256SUMS.txt`, `notices/` licences, `source/` GPL archive). Do not publish anything else (no project folder, keys, backups or host state).
2. One command verifies the live address and, only if everything passes, makes the final card:
   `python3 qr-card/tools/finish_publish.py https://YOUR-REAL-ADDRESS/ --out qr-card/out`
   It requires a public `https://` hostname (never localhost, IPs, private/`.local`/`.test`/example names), then checks over the network: valid HTTPS, every link on the page resolves, each download matches both the fingerprint on the page and `SHA256SUMS.txt`, the complete ZIP is intact and contains the published installer plus the WebView2 and WinFsp installers with the stated fingerprints. Any failure stops with no card.
3. Open `qr-card/out/card.html`, scan the QR with a phone camera to confirm it opens the page, then print at 100% scale on A6 (105 × 148 mm; two pages: front and back).
