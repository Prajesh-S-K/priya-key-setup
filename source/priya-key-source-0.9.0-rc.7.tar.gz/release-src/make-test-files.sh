#!/bin/sh
# Creates DISPOSABLE test folders (random content, nothing personal). Usage: ./make-test-files.sh [target-dir]
set -eu
T="${1:-./PriyaKey-TestData}"
mkdir -p "$T/Docs/sub" "$T/Pics" "$T/Nested/a/b/c" "$T/Big"
for i in 1 2 3; do printf 'Disposable note %s\nline two\nline three\n' "$i" > "$T/Docs/note$i.txt"; done
printf '# Disposable\nTesting Priya Key.\n' > "$T/Docs/sub/readme.md"
# 1x1 PNG pictures (valid images, different colours)
for n in red green blue; do
  case $n in red) b64='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==';; *) b64='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==';; esac
  printf '%s' "$b64" | base64 -d > "$T/Pics/$n.png" 2>/dev/null || printf '%s' "$b64" | base64 -D > "$T/Pics/$n.png"
done
echo "deep file" > "$T/Nested/a/b/c/deep.txt"
: > "$T/Nested/empty.bin"
# 40 MB of random data for large-file tests
dd if=/dev/urandom of="$T/Big/random-40MB.bin" bs=1048576 count=40 2>/dev/null
( cd "$T" && find . -type f | sort | while read f; do shasum -a 256 "$f"; done ) > "$T/SHA256-originals.txt"
echo "Created $T (4 folders: Docs, Pics, Nested, Big). Hashes of the originals: $T/SHA256-originals.txt"
