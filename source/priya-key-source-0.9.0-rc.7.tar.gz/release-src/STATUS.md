# Priya Key {{VERSION}} — final status

**Release candidate — physical-device acceptance pending.** Legend: **Implemented** = code exists and builds. **Locally verified** = automated tests/checks on the development Mac (simulated device core, no real Windows/Android/USB). **Awaiting physical-device testing** = needs the checklist on real hardware. Nothing here is "fully tested".

| Area | Implemented | Locally verified | Awaiting physical-device testing | Evidence / note |
|---|---|---|---|---|
| ESP32 firmware: PIN, delays, pairing, privacy button, key release | yes | yes (device core runs in a host simulator with crash/fault injection) | **yes** for this exact build | The earlier build of the same core passed on the real board (M2). This build adds assets + a partition table and has **not been flashed**. |
| Board-stored dashboard assets (signed image, `assets` partition, ASSET_INFO/READ commands, host fetch + cache) | yes | yes (byte-exact transfer, signature, tamper, cache choice, board-without-assets) | **yes** | Firmware built; flashing is the separate checkpoint in INSTALL.md §1. Apps fall back to the bundled dashboard. |
| Vault crypto, journal, crash safety, recovery slot | yes | yes (fault sweeps, torn tails, splicing, HPKE recovery) | partly (real-disk durability) | Format is draft v0. Disk durability level: Unverified. |
| Import / verify / restore / remove-encryption flows | yes | yes | **yes** (large real folders) | Originals are never deleted automatically. |
| Encrypted-vault backup export + verified restore/link | yes (Rust core; Windows via paths; Android via folder picker) | yes for the Rust core (copy, hash compare, refuse unlocked, refuse duplicate, wrong-board refusal) | **yes** (Android picker code is compile-checked only) | |
| Android plaintext restore / folder import / encrypted-backup import (rc.2 fixes: exact byte counts, premature-EOF rejection, full destination verification, listing failures are errors, name validation and containment) | yes | yes (JVM unit tests on the real transfer engines with fakes, including mutation-checked regression) | **yes** (Android content-provider adapters are compile-checked only) | See CHANGES.md. |
| Release firmware flasher (package checksums, metadata-derived regions, identification/security gates, backup verified against the board, same-board checks, owner MAC confirmation) | yes | yes (real gate code against a fake esptool/espefuse with a simulated flash; no board touched) | **yes** (real esptool/board) | Flashing remains a separate owner-authorized step. |
| First-use setup page (Windows/Android choice, permission guidance, verification fingerprints) | yes | yes (built from the real artifacts; placeholders, relative links, content checks; previewed locally in a browser) | **yes** (real hosting, real phone/PC walkthrough) | Not published: no hosting destination exists yet. |
| Printable QR gift card | tool + template yes | yes (URL gate refuses localhost/placeholders; a test QR decodes to the exact URL with macOS CoreImage) | – | **Final QR code pending**: needs the real published address. Template card is marked not for printing. |
| Discreet mode (explicit setting; conceal on unplug, reveal at PIN screen on return; Windows tray removal; Android task/notification/roots) | yes | partly (setting persistence and the Windows controller conceal/reveal/fresh-auth logic against the simulator) | **yes** (window/tray/Android behaviour and USB-attach relaunch) | Not invisibility; Android launcher entry deliberately kept. |
| Windows app (WinFsp drive, WebView2 dashboard) | yes | partly (controller/mount logic vs the simulator; builds and links for x64 Windows) | **yes** | WinFsp adapter, WebView2 shell never executed. |
| Windows tray, single instance, hide-on-close, autostart | yes | no (compile-checked) | **yes** | |
| Windows installer (WinFsp bundled, WebView2 offline installer beside it, upgrade, data-retention message) | yes | built only | **yes** | Not Authenticode-signed. |
| Android app (USB, foreground service, DocumentsProvider, WebView, import/restore) | yes | partly (Rust core + JNI symbol check; APK builds and verifies) | **yes** | Kotlin/JNI never executed on a phone. |
| Android icon, first-run checklist, battery/notification guidance, storage warning | yes | UI checked in a browser with a mock bridge | **yes** | |
| Dashboard (animation, PIN setup/change, folder cards, hide, recovery, privacy-mode screens) | yes | yes in a browser with a mock bridge (Windows and Android variants) | **yes** | Unavailable features are disabled, not simulated. |
| Branding and icon (key on dark square; "Priya Key") | yes | visual check | – | |
| Versioning (one `VERSION` file: {{VERSION}}) | yes | yes (see CHECKS) | – | |
| Android release signing | yes (private project key, not shipped) | yes (apksigner verify) | – | Keep `android/release.jks` and `keystore.properties` safe: they are needed for updates and are not in this package. |
| Windows code signing | **no** | – | – | SmartScreen warning; **Smart App Control blocks the unsigned installer with no override** (seen on a real laptop). |
| Secure boot / flash encryption on the board | **no (by design)** | – | – | Irreversible; not enabled. |

## Automated checks run for this build
{{CHECKS}}

## Blockers / not done
- Physical acceptance on Windows 11, Windows 10, an Android phone, and the flashed board (TEST_CHECKLIST.md).
- Windows Authenticode signing (needs a certificate).
- Real-disk durability evidence for the vault storage layer.
