# Creates DISPOSABLE test folders (random content, nothing personal). Usage: .\make-test-files.ps1 [-Target .\PriyaKey-TestData]
param([string]$Target = ".\PriyaKey-TestData")
$ErrorActionPreference = "Stop"
foreach ($d in "Docs\sub","Pics","Nested\a\b\c","Big") { New-Item -ItemType Directory -Force -Path (Join-Path $Target $d) | Out-Null }
1..3 | ForEach-Object { "Disposable note $_`r`nline two`r`nline three" | Set-Content (Join-Path $Target "Docs\note$_.txt") }
"# Disposable`r`nTesting Priya Key." | Set-Content (Join-Path $Target "Docs\sub\readme.md")
$png = [Convert]::FromBase64String("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==")
foreach ($n in "red","green","blue") { [IO.File]::WriteAllBytes((Join-Path $Target "Pics\$n.png"), $png) }
"deep file" | Set-Content (Join-Path $Target "Nested\a\b\c\deep.txt")
New-Item -ItemType File -Force -Path (Join-Path $Target "Nested\empty.bin") | Out-Null
$buf = New-Object byte[] (40MB); (New-Object Random).NextBytes($buf)
[IO.File]::WriteAllBytes((Join-Path $Target "Big\random-40MB.bin"), $buf)
Get-ChildItem -Recurse -File $Target | Where-Object { $_.Name -ne "SHA256-originals.txt" } | Sort-Object FullName |
  ForEach-Object { "{0}  {1}" -f (Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLower(), $_.FullName.Substring((Resolve-Path $Target).Path.Length) } |
  Set-Content (Join-Path $Target "SHA256-originals.txt")
Write-Host "Created $Target (4 folders: Docs, Pics, Nested, Big). Hashes: $Target\SHA256-originals.txt"
