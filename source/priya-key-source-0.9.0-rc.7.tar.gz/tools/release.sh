#!/bin/sh
# Builds everything from the current source and assembles the release-candidate folder. Stops on the first failed check.
# Secrets (signing keys, board backups, host state) are never copied: see the scan at the end.
set -eu
P="$(cd "$(dirname "$0")/.." && pwd)"
VER="$(cat "$P/VERSION")"
NAME="PriyaKey-$VER-RC-physical-device-acceptance-pending"
OUT="$P/release/$NAME"
LOG="$P/release/checks.txt"
mkdir -p "$P/release"; : > "$LOG"
export RUSTUP_HOME="$P/.toolchains/rustup" CARGO_HOME="$P/.toolchains/cargo"
export PATH="$P/.toolchains/cargo/bin:$PATH"
ok() { echo "- PASS: $1" | tee -a "$LOG"; }
PY="$HOME/.espressif/tools/python/v6.1/venv/bin/python"

# --- version consistency
CV=$(sed -n 's/^version = "\(.*\)"/\1/p' "$P/host/Cargo.toml" | head -1)
[ "$CV" = "$VER" ] || { echo "version mismatch: Cargo $CV vs VERSION $VER"; exit 1; }
ok "version $VER identical in VERSION and the Rust workspace (Android/firmware/installer read the same file)"

# --- tests
sh "$P/firmware/gpkey/sim/build.sh" >/dev/null 2>&1
( cd "$P/host" && cargo test --workspace 2>&1 ) > "$P/release/rust-tests.txt"
N=$(grep -E "^test result: ok" "$P/release/rust-tests.txt" | awk '{s+=$4} END{print s}')
! grep -E "FAILED|panicked" "$P/release/rust-tests.txt" >/dev/null || { echo "Rust tests failed"; exit 1; }
ok "Rust workspace tests: $N passed, 0 failed"
"$PY" -u -I -W error::ResourceWarning -m unittest discover -s "$P/tests" > "$P/release/python-tests.txt" 2>&1 || { tail -20 "$P/release/python-tests.txt"; exit 1; }
ok "Python tests (framing, C firmware parity, replay model, tools): $(grep -E '^Ran ' "$P/release/python-tests.txt"), OK"

# --- Android unit tests (transfer engines: exact reads, name validation, containment, verification)
( cd "$P/android" && JAVA_HOME="$P/.toolchains/jdk-17/Contents/Home" ANDROID_HOME="$P/.toolchains/android-sdk" ./gradlew --no-daemon -q cleanTestDebugUnitTest testDebugUnitTest ) > "$P/release/android-unit-tests.txt" 2>&1 || { tail -30 "$P/release/android-unit-tests.txt"; exit 1; }
AT=$(cat "$P"/android/app/build/test-results/testDebugUnitTest/*.xml | grep -o 'tests="[0-9]*" skipped="[0-9]*" failures="[0-9]*" errors="[0-9]*"' | head -1)
echo "$AT" | grep -q 'failures="0" errors="0"' || { echo "Android unit tests failed: $AT"; exit 1; }
ok "Android JVM unit tests (EnginesTest): $AT"

# --- firmware + signed dashboard image
bash -c ". \"$HOME/.espressif/tools/activate_idf_v6.1.sh\" >/dev/null 2>&1; cd \"$P/firmware/gpkey\" && idf.py build" >"$P/release/firmware-build.txt" 2>&1 || { tail -20 "$P/release/firmware-build.txt"; exit 1; }
FW="$P/firmware/gpkey/build"
( cd "$P/host" && cargo run -q -p gp-app --bin gp-assets -- pack "$P/dashboard/index.html" "$P/signing/assets_ed25519.key" "$FW/assets.bin" >/dev/null && cargo run -q -p gp-app --bin gp-assets -- verify "$FW/assets.bin" >/dev/null )
[ "$(strings -a "$FW/gpkey.bin" | grep -c "$VER")" -ge 1 ] || { echo "firmware does not carry version $VER"; exit 1; }
ok "firmware built ($(stat -f%z "$FW/gpkey.bin" 2>/dev/null || stat -c%s "$FW/gpkey.bin") bytes, version string present: $(strings -a "$FW/gpkey.bin" | grep -c "$VER")); dashboard image signed and verified against the compiled-in public key"
"$PY" - "$FW" <<'PYEOF'
import json,sys,os
a=json.load(open(sys.argv[1]+"/flasher_args.json"))
assert list(a["flash_files"].keys())==["0x1000","0x8000","0x10000"]
assert os.path.getsize(sys.argv[1]+"/assets.bin")<=0x10000
PYEOF
ok "firmware flash layout: bootloader 0x1000, partition table 0x8000, app 0x10000, dashboard image 0x110000 (64 KiB partition)"

# --- applications
"$P/tools/build_installer.sh" > "$P/release/windows-build.txt" 2>&1 || { tail -20 "$P/release/windows-build.txt"; exit 1; }
ok "Windows exe + NSIS installer built (x64, release profile)"
"$P/tools/build_apk.sh" > "$P/release/android-build.txt" 2>&1 || { tail -20 "$P/release/android-build.txt"; exit 1; }
APK="$P/dist/android/PriyaKey-$VER.apk"
AAPT="$P/.toolchains/android-sdk/build-tools/36.0.0/aapt2"
"$AAPT" dump badging "$APK" | grep -q "versionName='$VER'" || { echo "APK version mismatch"; exit 1; }
! "$AAPT" dump xmltree --file AndroidManifest.xml "$APK" | grep -qi "debuggable.*true" || { echo "APK is debuggable"; exit 1; }
ok "Android APK built, signature verified, versionName=$VER, not debuggable"

# --- assemble
rm -rf "$OUT"; mkdir -p "$OUT/windows/redist" "$OUT/android" "$OUT/firmware" "$OUT/tools" "$OUT/source"
cp "$P/dist/windows/PriyaKey-Setup-$VER.exe" "$OUT/windows/"
cp "$P/dist/windows/redist/winfsp.msi" "$OUT/windows/redist/"
cp "$P/.toolchains/dl/redist/webview2.exe" "$OUT/windows/redist/MicrosoftEdgeWebView2RuntimeInstallerX64.exe"
cp "$APK" "$OUT/android/"
mkdir -p "$OUT/qr-card/tools" "$OUT/qr-card/brand"
cp "$P/tools/make_qr_card.py" "$P/tools/verify_published.py" "$P/tools/finish_publish.py" "$P/tools/qr_decode.swift" "$OUT/qr-card/tools/"; cp -R "$P/tools/vendor" "$OUT/qr-card/tools/vendor"; cp "$P/brand/icon-256.png" "$OUT/qr-card/brand/"
"$PY" "$OUT/qr-card/tools/make_qr_card.py" --template --out "$OUT/qr-card" >/dev/null
find "$OUT/qr-card" -name '__pycache__' -prune -exec rm -rf {} +
cp "$P/release-src/QR-CARD.md" "$OUT/qr-card/README.md"
cp "$FW/bootloader/bootloader.bin" "$FW/partition_table/partition-table.bin" "$FW/gpkey.bin" "$FW/assets.bin" "$FW/flasher_args.json" "$OUT/firmware/"
cp "$P/tools/flash_firmware.py" "$P/tools/check_identification.py" "$P/tools/backup_manifest.py" "$P/tools/plan_flash.py" "$OUT/firmware/"
cp "$P/release-src/make-test-files.sh" "$P/release-src/make-test-files.ps1" "$OUT/tools/"
cp "$P/LICENSE" "$OUT/LICENSE.txt"; cp "$P/release-src/COPYING.txt" "$OUT/COPYING-GPL-3.0.txt"
for f in INSTALL KNOWN_LIMITATIONS TEST_CHECKLIST CHANGES; do sed "s/{{VERSION}}/$VER/g" "$P/release-src/$f.md" > "$OUT/$f.md"; done
"$PY" "$OUT/firmware/flash_firmware.py" --package "$OUT/firmware" --sums "$P/release/.nosums" --dry-run >/dev/null 2>&1 && { echo "flasher accepted a package without a checksum file"; exit 1; } || true
# the shipped QR kit must refuse a localhost/placeholder destination and write nothing for it
if "$PY" "$OUT/qr-card/tools/make_qr_card.py" --url https://localhost:8765/ --out "$OUT/qr-card/refused-test" >/dev/null 2>&1; then echo "QR tool accepted localhost"; exit 1; fi
[ ! -e "$OUT/qr-card/refused-test" ] || { echo "QR tool wrote files after refusing"; exit 1; }
find "$OUT/qr-card" -name '__pycache__' -prune -exec rm -rf {} +
ok "QR-card kit: template card included (no QR, marked not for printing); tool refuses localhost/placeholder addresses and writes nothing"
# tests of the shipped test-data script
T=$(mktemp -d); sh "$OUT/tools/make-test-files.sh" "$T/td" >/dev/null && [ "$(wc -l < "$T/td/SHA256-originals.txt" | tr -d ' ')" -ge 10 ] && [ "$(wc -c < "$T/td/Big/random-40MB.bin" | tr -d ' ')" -eq 41943040 ] && ok "test-data script creates 4 disposable folders and a hash list"; rm -rf "$T"

# source archive without secrets, toolchains, backups and build output
tar -C "$P" -czf "$OUT/source/priya-key-source-$VER.tar.gz" \
  --exclude='./.toolchains' --exclude='./hardware' --exclude='./signing' --exclude='./release' --exclude='./dist' \
  --exclude='./publish-staging' --exclude='./publish-build' --exclude='./setup-site/dist' --exclude='./qr-card/out' --exclude='./preview/site' \
  --exclude='target' --exclude='build' --exclude='.gradle' --exclude='*.jks' --exclude='keystore.properties' --exclude='local.properties' \
  --exclude='jniLibs' --exclude='*.dSYM' --exclude='gk_sim' --exclude='__pycache__' --exclude='.git' --exclude='demo-vault' --exclude='*.key' \
  --exclude='src/main/assets' --exclude='sdkconfig.old' .
[ "$(stat -f%z "$OUT/source/priya-key-source-$VER.tar.gz" 2>/dev/null || stat -c%s "$OUT/source/priya-key-source-$VER.tar.gz")" -lt 20000000 ] || { echo "source archive is suspiciously large (build output included?)"; exit 1; }
ok "source archive created (secrets, backups, toolchains, staging and build output excluded; under 20 MB)"

# notices
"$PY" - "$P" > "$OUT/THIRD_PARTY_NOTICES.txt" <<'PYEOF'
import json,subprocess,sys,collections
P=sys.argv[1]
m=json.loads(subprocess.check_output(["cargo","metadata","--format-version","1","--manifest-path",P+"/host/Cargo.toml"]))
lic=collections.defaultdict(list)
mine={"vault-core","gpkey-host","gp-app","gp-windows","gp-android"}
for p in m["packages"]:
    if p["name"] not in mine: lic[p.get("license") or "see crate"].append(f'{p["name"]} {p["version"]}')
print("Priya Key is GPL-3.0-or-later (see COPYING-GPL-3.0.txt). It includes or installs the following third-party components.\n")
print("Bundled/installed separately:\n- WinFsp 2.1 (GPLv3 with FLOSS exception) - windows/redist/winfsp.msi, https://winfsp.dev\n- Microsoft Edge WebView2 Runtime (Microsoft license) - redistributed unmodified from Microsoft's Evergreen Standalone Installer\n- usb-serial-for-android 3.9.0 (MIT) - Android app\n- noise-c (MIT) - board firmware; ESP-IDF 6.1 (Apache-2.0) - board firmware\n")
print("Rust crates (from cargo metadata), grouped by declared license:")
for k in sorted(lic): print(f"\n[{k}]\n  "+", ".join(sorted(set(lic[k]))))
PYEOF
ok "third-party notices generated"

# --- first-use setup page: built from the final artifacts, staged by allowlist, then verified exactly as a visitor would
"$PY" "$P/tools/build_setup_site.py" --release "$OUT" --out "$OUT/setup-site" >/dev/null || { echo "setup page build failed"; exit 1; }
ok "first-use setup page built: complete Windows ZIP (installer + redist), installer, APK; fingerprints, certificate fingerprint, notices and GPL source filled from the real files"
"$PY" "$P/tools/stage_publish.py" --src "$OUT/setup-site" --out "$P/publish-staging" || { echo "publish staging refused"; exit 1; }
ok "publish staging: allowlist only (page, icon, three downloads, checksums, licences, source); no keys, backups or host state"
"$PY" - "$P" <<'PYEOF' || { echo "local verification of the staged site failed"; exit 1; }
import functools, http.server, sys, threading
P = sys.argv[1]
sys.path.insert(0, P + "/tools")
import verify_published as VP
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(Q, directory=P + "/publish-staging"))
threading.Thread(target=srv.serve_forever, daemon=True).start()
ok = VP.verify(f"http://127.0.0.1:{srv.server_address[1]}/", insecure_local=True, say=lambda m: None)
srv.shutdown(); srv.server_close()
sys.exit(0 if ok else 1)
PYEOF
ok "staged site served locally and verified: every link resolves, three downloads match SHA256SUMS.txt and the page, ZIP contents and inner installer verified"

# --- version file, status, checksums
{
  echo "Priya Key $VER (release candidate - physical-device acceptance pending)"
  echo "built: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "rust: $(rustc --version)"; echo "esp-idf: v6.1; noise-c vendored commit cfe25410"
  echo "android: compileSdk 36, minSdk 30, NDK $(ls "$P/.toolchains/android-sdk/ndk"), gradle $(ls -d "$P"/.toolchains/gradle-* | sed 's/.*gradle-//'), AGP 9.4.0"
  echo "windows: winfsp-rs 0.13.1 / WinFsp 2.1.25156, wry 0.57, tao 0.35; installer NSIS $(makensis -VERSION)"
  echo "vault format: draft v0; protocol: GPKEY1 (Noise NK/NX 25519 ChaChaPoly BLAKE2s); dashboard image version: $(sed -n 's/.*BUNDLED_VERSION: u16 = \([0-9]*\);.*/\1/p' "$P/host/gp-app/src/assets.rs")"
  echo "dashboard signing public key: $(cd "$P/host" && cargo run -q -p gp-app --bin gp-assets -- pubkey "$P/signing/assets_ed25519.key")"
  echo "Android signing certificate SHA-256: $("$P/.toolchains/android-sdk/build-tools/36.0.0/apksigner" verify --print-certs "$APK" | sed -n 's/.*certificate SHA-256 digest: //p' | head -1)"
} > "$OUT/VERSION.txt"
CHECKS=$(cat "$LOG"); "$PY" - "$P/release-src/STATUS.md" "$OUT/STATUS.md" "$VER" "$LOG" <<'PYEOF'
import sys
s=open(sys.argv[1]).read().replace("{{VERSION}}",sys.argv[3]).replace("{{CHECKS}}",open(sys.argv[4]).read())
open(sys.argv[2],"w").write(s)
PYEOF
cp "$P/release/rust-tests.txt" "$P/release/python-tests.txt" "$P/release/android-unit-tests.txt" "$OUT/source/" 2>/dev/null || true
cp "$P"/android/app/build/test-results/testDebugUnitTest/*.xml "$OUT/source/" 2>/dev/null || true
# --- shipped flasher: package validation against the real checksum list, and tamper detection (no board is contacted)
mksums() { ( cd "$OUT" && find . -type f ! -name SHA256SUMS.txt | sort | while read f; do shasum -a 256 "$f"; done > SHA256SUMS.txt ); }
mksums
"$PY" "$OUT/firmware/flash_firmware.py" --dry-run >/dev/null || { echo "shipped flasher rejects its own package"; exit 1; }
ok "shipped flasher validates the package (checksums, flasher_args, partition table MD5, regions avoid NVS) in dry-run mode"
TMPF=$(mktemp -d); cp -R "$OUT/firmware" "$TMPF/firmware"; cp "$OUT/SHA256SUMS.txt" "$TMPF/"
printf 'X' | dd of="$TMPF/firmware/gpkey.bin" bs=1 seek=1000 conv=notrunc 2>/dev/null
if "$PY" "$TMPF/firmware/flash_firmware.py" --dry-run >/dev/null 2>&1; then echo "flasher accepted a tampered package"; exit 1; fi
rm -rf "$TMPF"
ok "shipped flasher refuses a tampered package"
# --- secret scan: names and contents
BAD=$(find "$OUT" \( -name '*.jks' -o -name 'keystore.properties' -o -name '*.key' -o -name 'identification.json' -o -name 'flash-backup*' -o -name 'trusted_board*' -o -name 'test_pin*' \) | head)
[ -z "$BAD" ] || { echo "SECRET FILE IN RELEASE: $BAD"; exit 1; }
PW=$(sed -n 's/^storePassword=//p' "$P/android/keystore.properties")
SEED=$(cat "$P/signing/assets_ed25519.key")
if grep -rIl -F -e "$PW" -e "$SEED" "$OUT" >/dev/null 2>&1; then echo "SECRET VALUE FOUND IN RELEASE"; exit 1; fi
if tar -xzOf "$OUT/source/priya-key-source-$VER.tar.gz" 2>/dev/null | grep -aF -e "$PW" -e "$SEED" >/dev/null; then echo "SECRET VALUE FOUND IN SOURCE ARCHIVE"; exit 1; fi
tar -tzf "$OUT/source/priya-key-source-$VER.tar.gz" | grep -E '^\./(hardware|signing)/|\.jks|keystore\.properties|host-state|flash-backup' && { echo "source archive lists a private path"; exit 1; } || true
echo "- PASS: secret scan: no signing keys, keystore, passwords, board backups or host state in the release folder or the source archive" | tee -a "$LOG"
sed -i.bak "s|^{{CHECKS}}||" "$OUT/STATUS.md" 2>/dev/null; rm -f "$OUT/STATUS.md.bak"
"$PY" - "$P/release-src/STATUS.md" "$OUT/STATUS.md" "$VER" "$LOG" <<'PYEOF'
import sys
s=open(sys.argv[1]).read().replace("{{VERSION}}",sys.argv[3]).replace("{{CHECKS}}",open(sys.argv[4]).read())
open(sys.argv[2],"w").write(s)
PYEOF
mksums
echo "RELEASE READY: $OUT"
du -sh "$OUT"
