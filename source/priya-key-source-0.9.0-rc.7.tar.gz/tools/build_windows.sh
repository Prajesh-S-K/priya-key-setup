#!/bin/sh
# Cross-builds the Windows application (priya-key.exe) on macOS with the project-local Rust toolchain and the Windows SDK
# downloaded by xwin into .toolchains/xwin. Nothing here runs on Windows; the result is untested until a Windows PC is used.
set -eu
P="$(cd "$(dirname "$0")/.." && pwd)"
export RUSTUP_HOME="$P/.toolchains/rustup" CARGO_HOME="$P/.toolchains/cargo" PATH="$P/.toolchains/cargo/bin:$PATH"
X="$P/.toolchains/xwin"
export BINDGEN_EXTRA_CLANG_ARGS="--target=x86_64-pc-windows-msvc -I$X/crt/include -I$X/sdk/include/ucrt -I$X/sdk/include/um -I$X/sdk/include/shared"
export CARGO_TARGET_X86_64_PC_WINDOWS_MSVC_LINKER=rust-lld
export CARGO_TARGET_X86_64_PC_WINDOWS_MSVC_RUSTFLAGS="-Lnative=$X/crt/lib/x86_64 -Lnative=$X/sdk/lib/um/x86_64 -Lnative=$X/sdk/lib/ucrt/x86_64"
cd "$P/host"
cargo build --release -p gp-windows --target x86_64-pc-windows-msvc
# Regression guard: winfsp-x64.dll MUST be delay-loaded, otherwise the exe will not start without WinFsp on PATH.
RO="$(ls "$P"/.toolchains/android-sdk/ndk/*/toolchains/llvm/prebuilt/*/bin/llvm-readobj | head -1)"
IMP="$("$RO" --coff-imports target/x86_64-pc-windows-msvc/release/priya-key.exe)"
echo "$IMP" | awk '/^Import \{/{blk="import"} /^DelayImport \{/{blk="delay"} /winfsp-x64.dll/{print blk}' | grep -qx delay || { echo "STOP: winfsp-x64.dll is not delay-loaded"; exit 1; }
! echo "$IMP" | awk '/^Import \{/{blk="import"} /^DelayImport \{/{blk="delay"} /winfsp-x64.dll/{print blk}' | grep -qx import || { echo "STOP: winfsp-x64.dll is a normal import"; exit 1; }
echo "check: winfsp-x64.dll is delay-loaded (the app starts even when WinFsp is missing)"
mkdir -p "$P/dist/windows"
cp target/x86_64-pc-windows-msvc/release/priya-key.exe "$P/dist/windows/"
shasum -a 256 "$P/dist/windows/priya-key.exe"
