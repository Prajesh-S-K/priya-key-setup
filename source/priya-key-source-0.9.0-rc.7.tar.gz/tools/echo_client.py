#!/usr/bin/env python3
"""M1 USB echo test client (Mac, Linux, Windows). Spec: docs/echo-protocol.md.

SAFETY: this program does not touch a serial port unless you pass --port AND --confirm-board-access.
Until the board-access review is approved, run only --selftest (in-memory loopback, no hardware).

Run with the existing ESP-IDF Python (has pyserial 3.5, nothing to install):
  ~/.espressif/tools/python/v6.1/venv/bin/python tools/echo_client.py --selftest
"""
from __future__ import annotations

import argparse
import os
import random
import struct
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gpecho import framing as F  # noqa: E402
from gpecho import probe  # noqa: E402

DEFAULT_SIZES = [0, 1, 2, 3, 63, 64, 127, 128, 253, 254, 255, 256]
FIRMWARE_BAUD = 115200   # the M1 echo firmware is built for this rate only (docs/echo-protocol.md section 1)


# ------------------------------------------------------------------ transports
class SerialTransport:
    def __init__(self, port: str, baud: int, line_state: str):
        import serial  # pyserial; imported lazily so --selftest needs nothing
        self.serial = serial
        self.ser = serial.Serial()
        self.ser.port = port
        self.ser.baudrate = baud
        self.ser.bytesize = serial.EIGHTBITS
        self.ser.parity = serial.PARITY_NONE
        self.ser.stopbits = serial.STOPBITS_ONE
        self.ser.timeout = 0
        self.ser.write_timeout = 2
        self.ser.xonxoff = self.ser.rtscts = self.ser.dsrdtr = False
        if line_state == "low":
            # Pre-set DTR/RTS low before open. The OS/driver may still pulse them during open; whether
            # that resets the board is exactly what the reset probe measures.
            self.ser.dtr = False
            self.ser.rts = False
        self.ser.open()

    def write(self, data: bytes) -> None:
        self.ser.write(data)
        self.ser.flush()

    def read(self, timeout: float) -> bytes:
        deadline = time.monotonic() + timeout
        while True:
            n = self.ser.in_waiting
            if n:
                return self.ser.read(n)
            if time.monotonic() >= deadline:
                return b""
            time.sleep(0.001)

    def close(self) -> None:
        self.ser.close()


class FakeDevice:
    """Python model of the firmware (main.c) for the in-memory self-test."""

    def __init__(self, boot_text: bytes = b"", uptime_fn=None):
        self.rx = bytearray()
        self.overflow = False
        self.c = dict(ok=0, cobs=0, crc=0, length=0, oversize=0, uart=0, tx=0)
        self.out = bytearray(boot_text)
        self.t0 = time.monotonic()
        self.uptime_fn = uptime_fn or (lambda: int((time.monotonic() - self.t0) * 1000))
        self.out += b"\x00"
        self._send(F.T_HELLO, 0, self._info())

    def _info(self) -> bytes:
        return F.pack_info(1, F.MAX_PAYLOAD, self.uptime_fn(), self.c["ok"],
                           self.c["cobs"], self.c["crc"], self.c["length"], self.c["oversize"], self.c["uart"],
                           self.c["tx"])

    def _send(self, type_, seq, payload=b""):
        self.out += F.encode_frame(type_, seq, payload)
        self.c["tx"] += 1

    def uart_error(self, overflow: bool = False) -> None:
        self.c["uart"] += 1
        if overflow:
            self.rx.clear()
            self.overflow = True

    def feed(self, data: bytes) -> None:
        for b in data:
            if b != 0:
                if not self.overflow:
                    if len(self.rx) >= F.MAX_ENCODED:
                        self.overflow = True
                        self.rx.clear()
                    else:
                        self.rx.append(b)
                continue
            if self.overflow:
                self.overflow = False
                self.rx.clear()
                self.c["oversize"] += 1
                continue
            if not self.rx:
                continue
            chunk = bytes(self.rx)
            self.rx.clear()
            try:
                raw = F.cobs_decode(chunk)
                f = F.parse_raw(raw)
            except F.FrameError as e:
                if e.kind in ("cobs", "length", "crc"):
                    self.c[e.kind] += 1
                elif e.kind in ("version", "flags"):
                    seq = struct.unpack_from("<I", raw, 3)[0]
                    self._send(F.T_ERR_RSP, seq, bytes([F.ERR_VERSION if e.kind == "version" else F.ERR_FLAGS]))
                continue
            self.c["ok"] += 1
            if f.type == F.T_ECHO_REQ:
                self._send(F.T_ECHO_RSP, f.seq, f.payload)
            elif f.type == F.T_INFO_REQ:
                self._send(F.T_INFO_RSP, f.seq, self._info())
            else:
                self._send(F.T_ERR_RSP, f.seq, bytes([F.ERR_TYPE]))


class LoopbackTransport:
    def __init__(self, device: FakeDevice):
        self.dev = device

    def write(self, data: bytes) -> None:
        self.dev.feed(data)

    def read(self, timeout: float) -> bytes:
        out = bytes(self.dev.out)
        self.dev.out.clear()
        return out

    def close(self) -> None:
        pass


# ------------------------------------------------------------------ client logic
class Client:
    def __init__(self, transport, verbose=False):
        self.t = transport
        self.dec = F.StreamDecoder()
        self.verbose = verbose
        self.pending: list[F.Frame] = []
        self.seq = 1

    def _pump(self, timeout: float) -> None:
        data = self.t.read(timeout)
        if data:
            for ev in self.dec.feed(data):
                if ev.kind == "frame":
                    self.pending.append(ev.frame)

    def wait_frame(self, pred, timeout: float):
        deadline = time.monotonic() + timeout
        while True:
            for i, f in enumerate(self.pending):
                if pred(f):
                    return self.pending.pop(i)
            self._pump(min(0.05, max(0.0, deadline - time.monotonic())))
            for i, f in enumerate(self.pending):
                if pred(f):
                    return self.pending.pop(i)
            if time.monotonic() >= deadline:
                return None

    def send(self, type_: int, payload: bytes = b"") -> int:
        seq = self.seq
        self.seq = (self.seq + 1) & 0xFFFFFFFF
        self.t.write(F.encode_frame(type_, seq, payload))
        return seq

    def sync(self) -> None:
        self.t.write(b"\x00")            # ends any boot text; the device ignores empty chunks

    def info(self, timeout=1.0):
        seq = self.send(F.T_INFO_REQ)
        f = self.wait_frame(lambda x: x.type == F.T_INFO_RSP and x.seq == seq, timeout)
        return F.unpack_info(f.payload) if f else None

    def echo_once(self, payload: bytes, timeout=1.0):
        seq = self.send(F.T_ECHO_REQ, payload)
        t0 = time.monotonic()
        f = self.wait_frame(lambda x: x.seq == seq and x.type in (F.T_ECHO_RSP, F.T_ERR_RSP), timeout)
        return f, time.monotonic() - t0


def run_tests(client: Client, count: int, sizes, seed: int, hello_timeout: float, out=print) -> int:
    rng = random.Random(seed)
    failures = 0
    hello = client.wait_frame(lambda f: f.type == F.T_HELLO, hello_timeout)
    out("HELLO: " + (str(F.unpack_info(hello.payload)) if hello else "not seen (continuing)"))
    client.sync()
    info0 = client.info()
    out(f"INFO: {info0}")
    if info0 is None:
        out("FAIL: no INFO response")
        return 1
    if info0["proto_ver"] != F.PROTO_VERSION or info0["max_payload"] != F.MAX_PAYLOAD:
        out("FAIL: protocol/limit mismatch")
        failures += 1

    ok = timeouts = mismatches = 0
    rtts = []
    total_bytes = 0
    t_start = time.monotonic()
    for i in range(count):
        n = sizes[i % len(sizes)] if i % 7 else rng.randrange(0, F.MAX_PAYLOAD + 1)
        payload = bytes(rng.randrange(256) for _ in range(n))
        if i % 5 == 0:
            payload = bytes(n)                      # all zero bytes
        f, rtt = client.echo_once(payload)
        if f is None:
            timeouts += 1
            client.sync()
        elif f.type != F.T_ECHO_RSP or f.payload != payload:
            mismatches += 1
            out(f"MISMATCH at frame {i}: size {n}, got type {f.type:#x}")
        else:
            ok += 1
            rtts.append(rtt)
            total_bytes += n
    elapsed = time.monotonic() - t_start
    out(f"echo: {ok}/{count} ok, {timeouts} timeouts, {mismatches} mismatches, {elapsed:.2f}s total")
    if rtts:
        rtts.sort()
        out(f"rtt ms: min {rtts[0]*1000:.2f} median {rtts[len(rtts)//2]*1000:.2f} max {rtts[-1]*1000:.2f}; "
            f"payload {total_bytes/elapsed/1024:.1f} KiB/s each way")
    if ok != count:
        failures += 1

    # Negative checks the firmware must survive: garbage, corrupt frame, wrong version, unknown type.
    client.t.write(b"garbage that is not a frame\x00")
    raw = bytearray(F.build_raw(F.T_ECHO_REQ, 0x7777, b"corrupt me"))
    raw[10] ^= 0x01                                                    # payload bit flip: valid COBS, bad CRC
    client.t.write(F.cobs_encode(bytes(raw)) + b"\x00")
    client.t.write(b"\x55" * 600 + b"\x00")                            # oversize chunk
    seq = client.send(F.T_ECHO_REQ, b"after-garbage")
    f = client.wait_frame(lambda x: x.seq == seq, 1.0)
    if not f or f.type != F.T_ECHO_RSP or f.payload != b"after-garbage":
        out("FAIL: no clean echo after garbage")
        failures += 1
    client.t.write(F.encode_frame(F.T_ECHO_REQ, 0x8001, b"v", ver=2))
    f = client.wait_frame(lambda x: x.seq == 0x8001, 1.0)
    if not f or f.type != F.T_ERR_RSP or f.payload != bytes([F.ERR_VERSION]):
        out("FAIL: no ERR_VERSION")
        failures += 1
    client.t.write(F.encode_frame(0x7E, 0x8002))
    f = client.wait_frame(lambda x: x.seq == 0x8002, 1.0)
    if not f or f.type != F.T_ERR_RSP or f.payload != bytes([F.ERR_TYPE]):
        out("FAIL: no ERR_TYPE")
        failures += 1

    info1 = client.info()
    out(f"INFO after negatives: {info1}")
    if info1 is None:
        failures += 1
    else:
        for key, minimum in (("rx_cobs_err", 1), ("rx_crc_err", 1), ("rx_oversize", 1)):
            if info1[key] - info0[key] < minimum:
                out(f"FAIL: counter {key} did not increase")
                failures += 1
    out("RESULT: " + ("PASS" if failures == 0 else f"FAIL ({failures})"))
    return 0 if failures == 0 else 1


def reset_probe(port: str, baud: int, line_state: str, repeats: int, wait_s: float, out=print) -> int:
    """Separates reset-on-open from reset-on-close using the firmware's uptime counter (see gpecho/probe.py).
    Absence of captured boot text is treated as inconclusive, never as proof that no reset happened."""
    verdicts, conclusion = probe.run_probe(lambda: SerialTransport(port, baud, line_state), repeats, time.monotonic,
                                           time.sleep, out=out, wait_s=wait_s)
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--selftest", action="store_true", help="in-memory loopback against a Python model of the firmware")
    ap.add_argument("--port", help="serial device (requires --confirm-board-access)")
    ap.add_argument("--confirm-board-access", action="store_true",
                    help="required for any real serial access; add only after the board-access review is approved")
    ap.add_argument("--baud", type=int, default=FIRMWARE_BAUD,
                    help="must be 115200: this firmware supports only that rate. Changing only the host rate would "
                         "make failures look like bridge limits. Faster tests need a coordinated firmware/client "
                         "mechanism or separately built firmware variants (a later M1 substep).")
    ap.add_argument("--count", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--hello-timeout", type=float, default=3.0)
    ap.add_argument("--line-state", choices=["default", "low"], default="default",
                    help="'low' pre-clears DTR/RTS before open (may still pulse during open)")
    ap.add_argument("--reset-probe", type=int, metavar="N",
                    help="open/close the port N times (at least 2) and classify reset-on-open vs reset-on-close from the "
                         "firmware uptime; missing boot text is inconclusive, not proof of no reset")
    ap.add_argument("--probe-wait", type=float, default=probe.WAIT_BETWEEN_S, help="seconds between close and the next open")
    args = ap.parse_args(argv)

    if args.baud != FIRMWARE_BAUD:
        print(f"Refusing --baud {args.baud}: the echo firmware supports {FIRMWARE_BAUD} baud only. Changing just the client rate "
              "would turn framing failures into misleading 'bridge limit' results. A faster-rate test needs a coordinated "
              "firmware/client mechanism or separately built firmware variants (later M1 substep).", file=sys.stderr)
        return 2
    if args.selftest:
        dev = FakeDevice(boot_text=b"ets Jun  8 2016 00:22:57\r\nrst:0x1 (POWERON_RESET),boot:0x13\r\n")
        return run_tests(Client(LoopbackTransport(dev)), args.count, DEFAULT_SIZES, args.seed, 0.0)
    if not args.port:
        ap.error("give --selftest, or --port with --confirm-board-access")
    if not args.confirm_board_access:
        print("Refusing to open a serial port without --confirm-board-access (board access is not yet approved).",
              file=sys.stderr)
        return 2
    if args.reset_probe:
        if args.reset_probe < 2:
            ap.error("--reset-probe needs at least 2 cycles (the first is only a baseline)")
        return reset_probe(args.port, args.baud, args.line_state, args.reset_probe, args.probe_wait)
    t = SerialTransport(args.port, args.baud, args.line_state)
    try:
        return run_tests(Client(t), args.count, DEFAULT_SIZES, args.seed, args.hello_timeout)
    finally:
        t.close()


if __name__ == "__main__":
    sys.exit(main())
