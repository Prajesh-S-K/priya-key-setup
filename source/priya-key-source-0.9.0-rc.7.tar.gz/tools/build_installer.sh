#!/bin/sh
# Windows exe + NSIS installer. Needs dist/windows/redist/winfsp.msi (see tools/fetch_redist.sh).
set -eu
P="$(cd "$(dirname "$0")/.." && pwd)"
VER="$(cat "$P/VERSION")"
NUM="$(echo "$VER" | sed -E 's/-rc\.?([0-9]+)/.\1/; s/^([0-9]+\.[0-9]+\.[0-9]+)$/\1.0/')"
"$P/tools/build_windows.sh"
mkdir -p "$P/dist/windows/redist"
[ -f "$P/dist/windows/redist/winfsp.msi" ] || cp "$P/.toolchains/dl/redist/winfsp.msi" "$P/dist/windows/redist/winfsp.msi"
cd "$P/installer/windows" && LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8 makensis -V2 -DVERSION="$VER" -DNUMVER="$NUM" -DOUT="$P/dist/windows/PriyaKey-Setup-$VER.exe" priya-key.nsi
shasum -a 256 "$P/dist/windows/PriyaKey-Setup-$VER.exe"
