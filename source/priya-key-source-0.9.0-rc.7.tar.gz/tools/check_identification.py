#!/usr/bin/env python3
"""Evaluate the saved output of the board identification steps and decide whether the sequence may continue.

Never touches the board. Reads files that the identification script saved in a private directory:
  step-chip_id.txt / .rc          esptool chip-id
  step-flash_id.txt / .rc         esptool flash-id
  step-read_mac.txt / .rc         esptool read-mac
  step-efuse_summary.txt / .rc    espefuse summary (console output)
  step-efuse_summary.json         espefuse summary --format json (read-only eFuse values)

Any problem is a STOP. There is no override flag. The result is written to identification.json (mode 600).
Exit status: 0 = every check passed, 1 = STOP, 2 = usage error.

Why espefuse and not `esptool get-security-info`: the esptool 5.3.1 source notes that the classic ESP32 does not
support the security-info command, so security status is read from the eFuse summary instead (read-only command).
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from dataclasses import dataclass, field

ERROR_MARKERS = ("A fatal error occurred", "Traceback (most recent call last)", "FatalError", "Failed to connect",
                 "Timed out waiting", "No serial data received", "StopIteration")

# Names read from the ESP32 eFuse definitions shipped with espefuse 5.3.1 (efuse_defs/esp32.yaml).
REQUIRED_FUSES = ("FLASH_CRYPT_CNT", "ABS_DONE_0", "ABS_DONE_1", "UART_DOWNLOAD_DIS", "DISABLE_DL_ENCRYPT",
                  "DISABLE_DL_DECRYPT", "DISABLE_DL_CACHE", "JTAG_DISABLE", "RD_DIS", "MAC")
INFORMATIONAL_FUSES = ("WR_DIS", "CONSOLE_DEBUG_DISABLE", "CHIP_PACKAGE", "CHIP_VER_REV1", "CHIP_VER_REV2", "CODING_SCHEME")
STEPS = ("chip_id", "flash_id", "read_mac", "efuse_summary")
MAC_RE = re.compile(r"\b([0-9a-fA-F]{2}(?::[0-9a-fA-F]{2}){5})\b")
OTHER_FAMILY_RE = re.compile(r"^ESP32-(S[2-9]|C[2-9]|H[2-9]|P[2-9]|E\d)")   # S2, S3, C3, C6, H2, P4, E22 ... (S0WD is a classic variant)


@dataclass
class Result:
    stops: list = field(default_factory=list)       # (code, message)
    warnings: list = field(default_factory=list)
    data: dict = field(default_factory=dict)

    def stop(self, code, msg):
        self.stops.append((code, msg))

    @property
    def passed(self):
        return not self.stops


def read_text(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except FileNotFoundError:
        return None


def check_step_files(d, res):
    for name in STEPS:
        rc_text = read_text(os.path.join(d, f"step-{name}.rc"))
        out = read_text(os.path.join(d, f"step-{name}.txt"))
        if rc_text is None or out is None:
            res.stop("STEP_MISSING", f"step '{name}' has no saved exit code or output (it did not run, or its record is missing)")
            continue
        try:
            rc = int(rc_text.strip())
        except ValueError:
            res.stop("STEP_FAILED", f"step '{name}': unreadable exit code {rc_text!r}")
            continue
        if rc != 0:
            res.stop("STEP_FAILED", f"step '{name}' exited with code {rc}")
        if not out.strip():
            res.stop("EMPTY_OUTPUT", f"step '{name}' produced no output")
        for marker in ERROR_MARKERS:
            if marker in out:
                res.stop("ERROR_OUTPUT", f"step '{name}' output contains '{marker}'")
                break
        if "Secure Download Mode" in out:
            res.stop("SECURE_DOWNLOAD_MODE", f"step '{name}': the chip reports Secure Download Mode (restricted download)")


def check_chip(d, res):
    out = read_text(os.path.join(d, "step-chip_id.txt")) or ""
    if not re.search(r"Connected to ESP32 on ", out):
        res.stop("UNEXPECTED_CHIP", "chip-id output does not say 'Connected to ESP32 on ...'")
    m = re.search(r"^Chip type:\s*(.+)$", out, re.M)
    if not m:
        res.stop("UNEXPECTED_CHIP", "no 'Chip type:' line in chip-id output")
        return
    chip = m.group(1).strip()
    res.data["chip"] = chip
    if not chip.startswith("ESP32") or OTHER_FAMILY_RE.match(chip):
        res.stop("UNEXPECTED_CHIP", f"expected a classic ESP32, got '{chip}'")
    rev = re.search(r"revision (v[\d.]+)", chip)
    res.data["revision"] = rev.group(1) if rev else None


def check_flash(d, res):
    out = read_text(os.path.join(d, "step-flash_id.txt")) or ""
    m = re.search(r"Detected flash size:\s*(\d+)\s*(KB|MB)", out)
    if not m:
        res.stop("FLASH_SIZE", "no 'Detected flash size: <N>MB' in flash-id output (size unknown or unrecognized)")
        return
    size = int(m.group(1)) * (1024 if m.group(2) == "KB" else 1024 * 1024)
    res.data["flash_label"] = f"{m.group(1)}{m.group(2)}"
    res.data["flash_bytes"] = size
    if size < 1024 * 1024 or size > 16 * 1024 * 1024:
        res.stop("FLASH_SIZE", f"flash size {size} bytes is outside the expected 1 to 16 MB range")
    man = re.search(r"Manufacturer:\s*([0-9a-fA-F]+)", out)
    dev = re.search(r"Device:\s*([0-9a-fA-F]+)", out)
    res.data["flash_manufacturer"] = man.group(1) if man else None
    res.data["flash_device"] = dev.group(1) if dev else None


def mac_from_text(text):
    m = re.search(r"^MAC:\s*([0-9a-fA-F:]{17})\s*$", text or "", re.M)
    return m.group(1).lower() if m else None


def check_mac_and_fuses(d, res):
    mac_txt = mac_from_text(read_text(os.path.join(d, "step-read_mac.txt")))
    if not mac_txt:
        res.stop("MAC_MISSING", "no 'MAC:' line in read-mac output")
    res.data["mac"] = mac_txt

    raw = read_text(os.path.join(d, "step-efuse_summary.json"))
    if raw is None:
        res.stop("SECURITY_UNKNOWN", "eFuse summary JSON is missing: security status unknown")
        return
    try:
        fuses = json.loads(raw)
        if not isinstance(fuses, dict):
            raise ValueError("not an object")
    except ValueError as e:
        res.stop("SECURITY_UNKNOWN", f"eFuse summary JSON is unparseable ({e}): security status unknown")
        return

    values = {}
    for name in REQUIRED_FUSES:
        entry = fuses.get(name)
        if not isinstance(entry, dict) or "value" not in entry:
            res.stop("SECURITY_UNKNOWN", f"eFuse '{name}' is missing from the summary: security status unknown")
            continue
        if entry.get("readable") is False or (isinstance(entry["value"], str) and "?" in entry["value"] and name != "MAC"):
            res.stop("SECURITY_UNKNOWN", f"eFuse '{name}' is not readable (read-protected): security status unknown")
            continue
        values[name] = entry["value"]
    for name in INFORMATIONAL_FUSES:
        if name in fuses and isinstance(fuses[name], dict):
            values[name] = fuses[name].get("value")
    res.data["efuses"] = {k: v for k, v in values.items() if k != "MAC"}

    def flag(name):
        v = values.get(name)
        if isinstance(v, bool):
            return v
        if isinstance(v, int):
            return v != 0
        res.stop("SECURITY_UNKNOWN", f"eFuse '{name}' has unexpected value {v!r}: security status unknown")
        return None

    if "ABS_DONE_0" in values and flag("ABS_DONE_0"):
        res.stop("SECURE_BOOT", "secure boot V1 is enabled (ABS_DONE_0)")
    if "ABS_DONE_1" in values and flag("ABS_DONE_1"):
        res.stop("SECURE_BOOT", "secure boot V2 is enabled (ABS_DONE_1)")

    cnt = values.get("FLASH_CRYPT_CNT")
    if "FLASH_CRYPT_CNT" in values:
        if isinstance(cnt, bool) or not isinstance(cnt, int):
            res.stop("SECURITY_UNKNOWN", f"FLASH_CRYPT_CNT has unexpected value {cnt!r}")
        elif bin(cnt).count("1") % 2 == 1:
            res.stop("FLASH_ENCRYPTION", f"flash encryption is enabled (FLASH_CRYPT_CNT={cnt})")
        elif cnt != 0:
            res.stop("FLASH_ENCRYPTION", f"FLASH_CRYPT_CNT={cnt} is non-zero: flash encryption was toggled before; review needed")

    for name, label in (("UART_DOWNLOAD_DIS", "UART download mode is disabled"),
                        ("DISABLE_DL_ENCRYPT", "flash encryption disabled in the UART bootloader"),
                        ("DISABLE_DL_DECRYPT", "flash decryption disabled in the UART bootloader"),
                        ("DISABLE_DL_CACHE", "flash cache disabled in the UART bootloader")):
        if name in values and flag(name):
            res.stop("DOWNLOAD_RESTRICTED", f"restricted download mode: {label} ({name})")

    if "JTAG_DISABLE" in values and flag("JTAG_DISABLE"):
        res.stop("IRREVERSIBLE_SETTING", "JTAG is permanently disabled (JTAG_DISABLE): an irreversible setting is already applied; review needed")
    if "RD_DIS" in values:
        rd = values["RD_DIS"]
        if isinstance(rd, bool) or not isinstance(rd, int):
            res.stop("SECURITY_UNKNOWN", f"RD_DIS has unexpected value {rd!r}")
        elif rd != 0:
            res.stop("SECURITY_UNKNOWN", f"RD_DIS={rd}: some eFuse blocks are read-protected, so security status cannot be fully read")
    wr = values.get("WR_DIS")
    if isinstance(wr, int) and not isinstance(wr, bool) and wr != 0:
        res.warnings.append(f"WR_DIS={wr:#x}: some eFuses are write-protected (informational)")

    # The board that answered the eFuse read must be the board that answered read-mac.
    efuse_mac = None
    if "MAC" in values:
        m = MAC_RE.search(str(values["MAC"]))
        efuse_mac = m.group(1).lower() if m else None
        if efuse_mac is None:
            res.stop("MAC_MISSING", "no MAC found in the eFuse summary")
    if mac_txt and efuse_mac and mac_txt != efuse_mac:
        res.stop("MAC_MISMATCH", f"read-mac ({mac_txt}) differs from the eFuse MAC ({efuse_mac}): the board may have changed during the sequence")


def evaluate(d):
    res = Result()
    check_step_files(d, res)
    check_chip(d, res)
    check_flash(d, res)
    check_mac_and_fuses(d, res)
    return res


def write_evidence(d, res):
    ev = {"verdict": "PASS" if res.passed else "STOP",
          "stops": [{"code": c, "message": m} for c, m in res.stops],
          "warnings": res.warnings, **res.data}
    path = os.path.join(d, "identification.json")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as fh:
        json.dump(ev, fh, indent=2)
    return path


def same_board(d, mac_file):
    """True if the MAC in mac_file equals the MAC recorded in a PASSED identification.json."""
    raw = read_text(os.path.join(d, "identification.json"))
    if raw is None:
        return False, "identification.json is missing"
    ev = json.loads(raw)
    if ev.get("verdict") != "PASS":
        return False, "identification did not pass"
    mac = mac_from_text(read_text(mac_file))
    if mac is None:
        return False, f"no MAC line in {mac_file}"
    if mac != ev.get("mac"):
        return False, f"connected board MAC {mac} differs from the identified board {ev.get('mac')}"
    return True, ""


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dir", required=True)
    ap.add_argument("--same-board", metavar="READ_MAC_OUTPUT",
                    help="instead of evaluating, require that this read-mac output matches the identified board")
    a = ap.parse_args(argv)
    if a.same_board:
        ok, why = same_board(a.dir, a.same_board)
        print("SAME BOARD" if ok else f"STOP: {why}")
        return 0 if ok else 1
    res = evaluate(a.dir)
    path = write_evidence(a.dir, res)
    print("Identification checks")
    for k in ("chip", "revision", "flash_label", "flash_bytes", "mac"):
        print(f"  {k}: {res.data.get(k)}")
    for w in res.warnings:
        print(f"  warning: {w}")
    if res.passed:
        print(f"RESULT: PASS (evidence written to {path})")
        return 0
    for code, msg in res.stops:
        print(f"  STOP [{code}]: {msg}")
    print(f"RESULT: STOP. The sequence ends here. No later stage will be presented. (evidence: {path})")
    return 1


if __name__ == "__main__":
    sys.exit(main())
