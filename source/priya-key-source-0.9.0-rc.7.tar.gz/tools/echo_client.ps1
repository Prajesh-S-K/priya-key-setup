<#
.SYNOPSIS
  M1 USB echo test client for Windows PowerShell 5.1 / PowerShell 7 (spec: docs/echo-protocol.md).

.DESCRIPTION
  Uses System.IO.Ports.SerialPort. Nothing to install on Windows 10/11 (Windows PowerShell 5.1 ships .NET Framework 4.x).

  STATUS: written on a Mac, NOT YET RUN. PowerShell is not installed on the dev Mac, so even the parse/syntax check
  is pending. Run -SelfTest first on the Windows machine: it needs no hardware.

  SAFETY: no serial port is opened unless you pass -Port AND -ConfirmBoardAccess. Do not pass
  -ConfirmBoardAccess until the board-access review is approved.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\echo_client.ps1 -SelfTest
  powershell -ExecutionPolicy Bypass -File .\echo_client.ps1 -Port COM5 -ConfirmBoardAccess -Count 1000
  powershell -ExecutionPolicy Bypass -File .\echo_client.ps1 -Port COM5 -ConfirmBoardAccess -ResetProbe 20   (at least 2; 115200 baud only)
#>
[CmdletBinding()]
param(
    [switch]$SelfTest,
    [string]$Port,
    [switch]$ConfirmBoardAccess,
    [int]$Baud = 115200,
    [int]$Count = 1000,
    [int]$Seed = 1,
    [double]$HelloTimeout = 3.0,
    [ValidateSet('default', 'low')][string]$LineState = 'default',
    [int]$ResetProbe = 0
)

Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'

# The M1 echo firmware is built for 115200 baud only. Changing just the host rate would make framing failures look like
# bridge limits. Faster tests need a coordinated firmware/client mechanism or separately built firmware variants (later M1 substep).
if ($Baud -ne 115200) {
    Write-Host "Refusing -Baud ${Baud}: the echo firmware supports 115200 baud only (a faster-rate test is a later M1 substep)."
    exit 2
}

# ---------------------------------------------------------------- constants (match tools/gpecho/framing.py)
$script:PROTO = 1
$script:HEADER = 9
$script:CRCLEN = 4
$script:MAXPAYLOAD = 256
$script:MINRAW = 13
$script:MAXRAW = 269
$script:MAXENC = 271
$script:T_ECHO_REQ = 0x01
$script:T_INFO_REQ = 0x02
$script:T_ECHO_RSP = 0x81
$script:T_INFO_RSP = 0x82
$script:T_HELLO = 0x83
$script:T_ERR_RSP = 0xFF

# ---------------------------------------------------------------- CRC-32 (reflected 0xEDB88320, init/xorout 0xFFFFFFFF)
# 64-bit math avoids PowerShell's signed 32-bit hex literal behaviour.
$script:CrcTable = New-Object 'uint64[]' 256
for ($i = 0; $i -lt 256; $i++) {
    [uint64]$c = $i
    for ($k = 0; $k -lt 8; $k++) {
        if (($c -band 1) -ne 0) { $c = (($c -shr 1) -bxor [uint64]3988292384) } else { $c = ($c -shr 1) }
    }
    $script:CrcTable[$i] = $c
}

function Get-Crc32([byte[]]$Data, [int]$Length) {
    [uint64]$c = 4294967295
    for ($i = 0; $i -lt $Length; $i++) {
        $idx = [int](($c -bxor $Data[$i]) -band 255)
        $c = ($script:CrcTable[$idx] -bxor ($c -shr 8))
    }
    return [uint64](($c -bxor 4294967295) -band 4294967295)
}

# ---------------------------------------------------------------- COBS
function ConvertTo-Cobs([byte[]]$Data) {
    $out = New-Object 'System.Collections.Generic.List[byte]'
    $out.Add(0)
    $codeIdx = 0
    $code = 1
    foreach ($b in $Data) {
        if ($b -eq 0) {
            $out[$codeIdx] = [byte]$code
            $codeIdx = $out.Count
            $out.Add(0)
            $code = 1
        } else {
            $out.Add($b)
            $code++
            if ($code -eq 255) {
                $out[$codeIdx] = [byte]$code
                $codeIdx = $out.Count
                $out.Add(0)
                $code = 1
            }
        }
    }
    $out[$codeIdx] = [byte]$code
    return , $out.ToArray()
}

# Returns @{ Ok = $true; Data = byte[] } or @{ Ok = $false; Error = 'cobs' }
function ConvertFrom-Cobs([byte[]]$Enc) {
    $out = New-Object 'System.Collections.Generic.List[byte]'
    $n = $Enc.Length
    $i = 0
    while ($i -lt $n) {
        $code = [int]$Enc[$i]
        if ($code -eq 0) { return @{ Ok = $false; Error = 'cobs' } }
        $i++
        $end = $i + $code - 1
        if ($end -gt $n) { return @{ Ok = $false; Error = 'cobs' } }
        for ($k = $i; $k -lt $end; $k++) {
            if ($Enc[$k] -eq 0) { return @{ Ok = $false; Error = 'cobs' } }
            $out.Add($Enc[$k])
        }
        $i = $end
        if ($code -lt 255 -and $i -lt $n) { $out.Add(0) }
    }
    return @{ Ok = $true; Data = $out.ToArray() }
}

# ---------------------------------------------------------------- frames
function New-RawFrame([int]$Type, [uint32]$Seq, [byte[]]$Payload, [int]$Ver = 1, [int]$Flags = 0) {
    if ($null -eq $Payload) { $Payload = [byte[]]@() }
    if ($Payload.Length -gt $script:MAXPAYLOAD) { throw 'payload too long' }
    $len = $Payload.Length
    $raw = New-Object 'byte[]' ($script:HEADER + $len + $script:CRCLEN)
    $raw[0] = [byte]$Ver
    $raw[1] = [byte]$Type
    $raw[2] = [byte]$Flags
    $raw[3] = [byte]($Seq -band 255)
    $raw[4] = [byte](($Seq -shr 8) -band 255)
    $raw[5] = [byte](($Seq -shr 16) -band 255)
    $raw[6] = [byte](($Seq -shr 24) -band 255)
    $raw[7] = [byte]($len -band 255)
    $raw[8] = [byte](($len -shr 8) -band 255)
    if ($len -gt 0) { [Array]::Copy($Payload, 0, $raw, $script:HEADER, $len) }
    $crc = Get-Crc32 $raw ($script:HEADER + $len)
    $p = $script:HEADER + $len
    $raw[$p] = [byte]($crc -band 255)
    $raw[$p + 1] = [byte](($crc -shr 8) -band 255)
    $raw[$p + 2] = [byte](($crc -shr 16) -band 255)
    $raw[$p + 3] = [byte](($crc -shr 24) -band 255)
    return , $raw
}

function New-WireFrame([int]$Type, [uint32]$Seq, [byte[]]$Payload, [int]$Ver = 1, [int]$Flags = 0) {
    $raw = New-RawFrame $Type $Seq $Payload $Ver $Flags
    $enc = ConvertTo-Cobs $raw
    $wire = New-Object 'byte[]' ($enc.Length + 1)
    [Array]::Copy($enc, 0, $wire, 0, $enc.Length)
    $wire[$enc.Length] = 0
    return , $wire
}

# Validation order: length bounds, len field, CRC, version, flags.
function ConvertFrom-RawFrame([byte[]]$Raw) {
    $n = $Raw.Length
    if ($n -lt $script:MINRAW -or $n -gt $script:MAXRAW) { return @{ Ok = $false; Error = 'length' } }
    $len = [int]$Raw[7] + ([int]$Raw[8] -shl 8)
    if ($len -gt $script:MAXPAYLOAD -or ($script:HEADER + $len + $script:CRCLEN) -ne $n) { return @{ Ok = $false; Error = 'length' } }
    $crcRx = [uint64]$Raw[$n - 4] + ([uint64]$Raw[$n - 3] -shl 8) + ([uint64]$Raw[$n - 2] -shl 16) + ([uint64]$Raw[$n - 1] -shl 24)
    $crc = Get-Crc32 $Raw ($n - 4)
    if ($crc -ne $crcRx) { return @{ Ok = $false; Error = 'crc' } }
    if ($Raw[0] -ne $script:PROTO) { return @{ Ok = $false; Error = 'version' } }
    if ($Raw[2] -ne 0) { return @{ Ok = $false; Error = 'flags' } }
    $seq = [uint64]$Raw[3] + ([uint64]$Raw[4] -shl 8) + ([uint64]$Raw[5] -shl 16) + ([uint64]$Raw[6] -shl 24)
    $payload = New-Object 'byte[]' $len
    if ($len -gt 0) { [Array]::Copy($Raw, $script:HEADER, $payload, 0, $len) }
    return @{ Ok = $true; Type = [int]$Raw[1]; Seq = $seq; Payload = $payload }
}

# ---------------------------------------------------------------- streaming receiver (same rules as the firmware)
function New-Decoder { return @{ Buf = (New-Object 'System.Collections.Generic.List[byte]'); Overflow = $false; Oversize = 0; Errors = 0; Ok = 0 } }

# Returns an array of events: @{Kind='frame'; Type; Seq; Payload} or @{Kind='error'; Error}
function Add-DecoderBytes($Dec, [byte[]]$Data) {
    $events = New-Object 'System.Collections.Generic.List[object]'
    foreach ($b in $Data) {
        if ($b -ne 0) {
            if (-not $Dec.Overflow) {
                if ($Dec.Buf.Count -ge $script:MAXENC) { $Dec.Overflow = $true; $Dec.Buf.Clear() } else { $Dec.Buf.Add($b) }
            }
            continue
        }
        if ($Dec.Overflow) {
            $Dec.Overflow = $false; $Dec.Buf.Clear(); $Dec.Oversize++
            $events.Add(@{ Kind = 'error'; Error = 'oversize' }); continue
        }
        if ($Dec.Buf.Count -eq 0) { continue }
        $chunk = $Dec.Buf.ToArray(); $Dec.Buf.Clear()
        $d = ConvertFrom-Cobs $chunk
        if (-not $d.Ok) { $Dec.Errors++; $events.Add(@{ Kind = 'error'; Error = $d.Error }); continue }
        $f = ConvertFrom-RawFrame $d.Data
        if ($f.Ok) { $Dec.Ok++; $events.Add(@{ Kind = 'frame'; Type = $f.Type; Seq = $f.Seq; Payload = $f.Payload }) }
        else { $Dec.Errors++; $events.Add(@{ Kind = 'error'; Error = $f.Error }) }
    }
    return , $events.ToArray()
}

function Test-BytesEqual([byte[]]$A, [byte[]]$B) {
    if ($A.Length -ne $B.Length) { return $false }
    for ($i = 0; $i -lt $A.Length; $i++) { if ($A[$i] -ne $B[$i]) { return $false } }
    return $true
}

function ConvertTo-Hex([byte[]]$B) { return ([BitConverter]::ToString($B) -replace '-', '').ToLower() }

# ---------------------------------------------------------------- self-test (no hardware)
function Invoke-SelfTest {
    $fail = 0
    function Check([bool]$Cond, [string]$Msg) { if (-not $Cond) { Write-Host "FAIL: $Msg"; $script:selfFail++ } }
    $script:selfFail = 0

    # CRC known vectors
    $v = [System.Text.Encoding]::ASCII.GetBytes('123456789')
    Check ((Get-Crc32 $v $v.Length) -eq 3421780262) 'crc check value 0xCBF43926'
    Check ((Get-Crc32 ([byte[]]@()) 0) -eq 0) 'crc empty'
    $a = [System.Text.Encoding]::ASCII.GetBytes('a')
    Check ((Get-Crc32 $a 1) -eq 3904355907) 'crc "a" 0xE8B7BE43'
    $z = [byte[]]@(0, 0, 0, 0)
    Check ((Get-Crc32 $z 4) -eq 558161692) 'crc 4 zeros 0x2144DF1C'

    # COBS vectors
    Check ((ConvertTo-Hex (ConvertTo-Cobs ([byte[]]@(0)))) -eq '0101') 'cobs 00'
    Check ((ConvertTo-Hex (ConvertTo-Cobs ([byte[]]@(0x11, 0x22, 0x00, 0x33)))) -eq '0311220233') 'cobs 11 22 00 33'
    Check ((ConvertTo-Hex (ConvertTo-Cobs ([byte[]]@(0x11, 0, 0, 0)))) -eq '0211010101') 'cobs 11 00 00 00'

    # Golden wire bytes pinned from the Python reference
    $wire = New-WireFrame $script:T_ECHO_REQ 1 ([System.Text.Encoding]::ASCII.GetBytes('hi'))
    Check ((ConvertTo-Hex $wire) -eq '03010102010101020207686954f522ba00') 'golden wire bytes'

    # Round trip for every payload size, through the decoder, including all-zero payloads
    $rng = New-Object System.Random 1
    $dec = New-Decoder
    for ($n = 0; $n -le $script:MAXPAYLOAD; $n++) {
        $p = New-Object 'byte[]' $n
        if ($n % 2 -eq 0) { $rng.NextBytes($p) }
        $w = New-WireFrame $script:T_ECHO_REQ ([uint32]$n) $p
        Check ($w.Length - 1 -le $script:MAXENC) "encoded size at payload $n"
        $ev = Add-DecoderBytes $dec $w
        Check ($ev.Count -eq 1 -and $ev[0].Kind -eq 'frame' -and (Test-BytesEqual $ev[0].Payload $p) -and $ev[0].Seq -eq $n) "roundtrip payload $n"
    }

    # Corruption: flip a payload bit in the raw frame, re-encode: must be a CRC error
    $raw = New-RawFrame $script:T_ECHO_REQ 5 ([System.Text.Encoding]::ASCII.GetBytes('payload'))
    $raw[10] = $raw[10] -bxor 1
    $enc = ConvertTo-Cobs $raw
    $d2 = New-Decoder
    $ev = Add-DecoderBytes $d2 ($enc + [byte[]]@(0))
    Check ($ev.Count -eq 1 -and $ev[0].Kind -eq 'error' -and $ev[0].Error -eq 'crc') 'crc error classification'

    # Oversize then good frame
    $d3 = New-Decoder
    $big = New-Object 'byte[]' 5000
    for ($i = 0; $i -lt $big.Length; $i++) { $big[$i] = 0x55 }
    $good = New-WireFrame $script:T_ECHO_REQ 9 ([System.Text.Encoding]::ASCII.GetBytes('ok'))
    $ev = Add-DecoderBytes $d3 ($big + [byte[]]@(0) + $good)
    Check ($ev.Count -eq 2 -and $ev[0].Error -eq 'oversize' -and $ev[1].Kind -eq 'frame') 'oversize then frame'

    # Boot text then delimiter then frame
    $d4 = New-Decoder
    $boot = [System.Text.Encoding]::ASCII.GetBytes("ets Jun  8 2016 00:22:57`r`nrst:0x1 (POWERON_RESET)`r`n")
    $ev = Add-DecoderBytes $d4 ($boot + [byte[]]@(0) + $good)
    $errs = @($ev | Where-Object { $_.Kind -eq 'error' }).Count
    $frames = @($ev | Where-Object { $_.Kind -eq 'frame' }).Count
    Check ($errs -eq 1 -and $frames -eq 1) 'boot text recovery'

    # Truncated frame followed by a delimiter and a good frame
    $d5 = New-Decoder
    $full = New-WireFrame $script:T_ECHO_REQ 7 ([System.Text.Encoding]::ASCII.GetBytes('0123456789'))
    $cut = New-Object 'byte[]' 6
    [Array]::Copy($full, 0, $cut, 0, 6)
    $ev = Add-DecoderBytes $d5 ($cut + [byte[]]@(0) + $good)
    $frames = @($ev | Where-Object { $_.Kind -eq 'frame' })
    Check ($frames.Count -eq 1 -and $frames[0].Seq -eq 9) 'truncated frame recovery'

    # Reset-probe classification (same numbers as tests/test_reset_probe.py)
    $prev = @{ TOpen = 0.0; HelloSeen = $false; BootText = $false; TA = 1.0; UA = 10000.0; TB = 1.3; UB = 10300.0; TClose = 1.4 }
    $base = @{ TOpen = 4.4; HelloSeen = $false; BootText = $false; TA = 5.4; UA = 14300.0; TB = 5.7; UB = 14600.0; TClose = 5.8 }
    Check ((Get-ResetVerdict $null $base).Kind -eq 'baseline') 'probe baseline'
    Check ((Get-ResetVerdict $prev $base).Kind -eq 'no-reset') 'probe no-reset'
    $c = $base.Clone(); $c.UA = 300.0
    Check ((Get-ResetVerdict $prev $c).Kind -eq 'reset-on-open') 'probe reset-on-open (no boot text needed)'
    $c = $base.Clone(); $c.UA = 2900.0
    Check ((Get-ResetVerdict $prev $c).Kind -eq 'reset-on-close') 'probe reset-on-close'
    $c = $base.Clone(); $c.HelloSeen = $true
    Check ((Get-ResetVerdict $prev $c).Kind -eq 'anomaly') 'probe anomaly'
    $c = $base.Clone(); $c.UA = $null
    Check ((Get-ResetVerdict $prev $c).Kind -eq 'inconclusive') 'probe no INFO is inconclusive'

    if ($script:selfFail -eq 0) { Write-Host 'SELFTEST: PASS' ; return 0 }
    Write-Host "SELFTEST: FAIL ($($script:selfFail))"
    return 1
}

# ---------------------------------------------------------------- serial test run
function Open-Port([string]$PortName, [int]$BaudRate, [string]$State) {
    $sp = New-Object System.IO.Ports.SerialPort $PortName, $BaudRate, ([System.IO.Ports.Parity]::None), 8, ([System.IO.Ports.StopBits]::One)
    $sp.Handshake = [System.IO.Ports.Handshake]::None
    $sp.ReadTimeout = 50
    $sp.WriteTimeout = 2000
    if ($State -eq 'low') { $sp.DtrEnable = $false; $sp.RtsEnable = $false }   # default is already false per the docs; the driver may still pulse at open
    $sp.Open()
    return $sp
}

function Read-Available($Sp, [double]$TimeoutSec) {
    $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSec)
    do {
        $n = $Sp.BytesToRead
        if ($n -gt 0) {
            $buf = New-Object 'byte[]' $n
            [void]$Sp.Read($buf, 0, $n)
            return , $buf
        }
        Start-Sleep -Milliseconds 1
    } while ([DateTime]::UtcNow -lt $deadline)
    return , ([byte[]]@())
}

function Wait-Frame($Sp, $Dec, $Pending, [scriptblock]$Pred, [double]$TimeoutSec) {
    $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSec)
    while ($true) {
        for ($i = 0; $i -lt $Pending.Count; $i++) {
            if (& $Pred $Pending[$i]) { $f = $Pending[$i]; $Pending.RemoveAt($i); return $f }
        }
        $data = Read-Available $Sp 0.05
        if ($data.Length -gt 0) {
            foreach ($e in (Add-DecoderBytes $Dec $data)) { if ($e.Kind -eq 'frame') { [void]$Pending.Add($e) } }
            continue
        }
        if ([DateTime]::UtcNow -ge $deadline) { return $null }
    }
}

function Invoke-EchoRun([string]$PortName, [int]$BaudRate, [string]$State, [int]$N, [int]$SeedValue, [double]$HelloSec) {
    $sp = Open-Port $PortName $BaudRate $State
    $failures = 0
    try {
        $dec = New-Decoder
        $pending = New-Object 'System.Collections.ArrayList'
        $seq = [uint32]1
        $hello = Wait-Frame $sp $dec $pending { param($f) $f.Type -eq $script:T_HELLO } $HelloSec
        Write-Host ('HELLO: ' + $(if ($hello) { 'seen' } else { 'not seen (continuing)' }))
        $sp.Write([byte[]]@(0), 0, 1)
        $rng = New-Object System.Random $SeedValue
        $sizes = @(0, 1, 2, 3, 63, 64, 127, 128, 253, 254, 255, 256)
        $ok = 0; $timeouts = 0; $mismatch = 0
        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        for ($i = 0; $i -lt $N; $i++) {
            $len = if ($i % 7 -eq 0) { $rng.Next(0, 257) } else { $sizes[$i % $sizes.Count] }
            $p = New-Object 'byte[]' $len
            if ($i % 5 -ne 0) { $rng.NextBytes($p) }
            $mySeq = $seq; $seq = [uint32](($seq + 1) -band 4294967295)
            $w = New-WireFrame $script:T_ECHO_REQ $mySeq $p
            $sp.Write($w, 0, $w.Length)
            $s2 = $mySeq
            $f = Wait-Frame $sp $dec $pending { param($x) $x.Seq -eq $s2 } 1.0
            if ($null -eq $f) { $timeouts++; $sp.Write([byte[]]@(0), 0, 1) }
            elseif ($f.Type -ne $script:T_ECHO_RSP -or -not (Test-BytesEqual $f.Payload $p)) { $mismatch++ }
            else { $ok++ }
        }
        Write-Host ("echo: $ok/$N ok, $timeouts timeouts, $mismatch mismatches, {0:N2}s" -f $sw.Elapsed.TotalSeconds)
        if ($ok -ne $N) { $failures++ }
        Write-Host ('RESULT: ' + $(if ($failures -eq 0) { 'PASS' } else { 'FAIL' }))
    } finally { $sp.Close() }
    return $(if ($failures -eq 0) { 0 } else { 1 })
}

# ---------------------------------------------------------------- reset probe (uptime based; mirrors tools/gpecho/probe.py)
# Absence of captured boot text is INCONCLUSIVE, never proof of "no reset". The firmware's INFO uptime_ms is the primary signal.
$script:TolMs = 500

# Observation: hashtable with TOpen, HelloSeen, BootText, TA, UA, TB, UB, TClose (seconds on one stopwatch; UA/UB = uptime ms or $null).
function Get-ResetVerdict($Prev, $Cur) {
    $notes = New-Object 'System.Collections.Generic.List[string]'
    if ($Cur.HelloSeen) { $notes.Add('HELLO frame seen after open') }
    if ($Cur.BootText) { $notes.Add('ROM boot text seen after open') }
    if (-not ($Cur.HelloSeen -or $Cur.BootText)) { $notes.Add('no boot text or HELLO captured (this alone is inconclusive, not proof of no reset)') }
    if ($null -eq $Cur.UA) { $notes.Add('no INFO response after open'); return @{ Kind = 'inconclusive'; Notes = $notes } }
    if ($null -eq $Prev -or $null -eq $Prev.UB) { return @{ Kind = 'baseline'; Notes = $notes } }
    $expected = $Prev.UB + (($Cur.TA - $Prev.TB) * 1000.0)
    $sinceOpen = ($Cur.TA - $Cur.TOpen) * 1000.0
    $sinceClose = ($Cur.TA - $Prev.TClose) * 1000.0
    $u = [double]$Cur.UA
    if ($u -ge ($expected - $script:TolMs)) {
        if ($Cur.HelloSeen -or $Cur.BootText) { $notes.Add('uptime continuous but boot evidence seen: inconsistent, repeat'); return @{ Kind = 'anomaly'; Notes = $notes } }
        $notes.Add("uptime continuous ($u ms, expected about $([math]::Round($expected)))")
        return @{ Kind = 'no-reset'; Notes = $notes }
    }
    $notes.Add("uptime restarted ($u ms, expected about $([math]::Round($expected)) without a reset)")
    if ($u -le ($sinceOpen + $script:TolMs)) { $notes.Add('board booted after the port was opened; a reset on close, if any, is masked'); return @{ Kind = 'reset-on-open'; Notes = $notes } }
    if ($u -le ($sinceClose + $script:TolMs)) { $notes.Add('board booted after the previous close and before this open'); return @{ Kind = 'reset-on-close'; Notes = $notes } }
    $notes.Add('restart predates the previous close: cannot be attributed to open or close')
    return @{ Kind = 'inconclusive'; Notes = $notes }
}

function Get-InfoUptime($Sp, $Dec, $Pending, [uint32]$Seq, $Sw) {
    $w = New-WireFrame $script:T_INFO_REQ $Seq ([byte[]]@())
    $Sp.Write($w, 0, $w.Length)
    $s2 = $Seq
    $f = Wait-Frame $Sp $Dec $Pending { param($x) $x.Seq -eq $s2 -and $x.Type -eq $script:T_INFO_RSP } 1.0
    if ($null -eq $f -or $f.Payload.Length -lt 7) { return @{ T = $null; U = $null } }
    $u = [uint64]$f.Payload[3] + ([uint64]$f.Payload[4] -shl 8) + ([uint64]$f.Payload[5] -shl 16) + ([uint64]$f.Payload[6] -shl 24)
    return @{ T = $Sw.Elapsed.TotalSeconds; U = [double]$u }
}

function Invoke-ResetProbe([string]$PortName, [int]$BaudRate, [string]$State, [int]$Repeats, [double]$WaitSec = 3.0) {
    if ($Repeats -lt 2) { Write-Host 'The reset probe needs at least 2 cycles (the first is only a baseline).'; return 2 }
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $prev = $null
    $kinds = New-Object 'System.Collections.Generic.List[string]'
    for ($i = 1; $i -le $Repeats; $i++) {
        $sp = Open-Port $PortName $BaudRate $State
        $tOpen = $sw.Elapsed.TotalSeconds
        $dec = New-Decoder
        $pending = New-Object 'System.Collections.ArrayList'
        $all = New-Object 'System.Collections.Generic.List[byte]'
        $hello = $false
        while (($sw.Elapsed.TotalSeconds - $tOpen) -lt 1.0) {
            $data = Read-Available $sp 0.02
            if ($data.Length -gt 0) {
                $all.AddRange($data)
                foreach ($e in (Add-DecoderBytes $dec $data)) { if ($e.Kind -eq 'frame' -and $e.Type -eq $script:T_HELLO) { $hello = $true } }
            }
        }
        $text = [System.Text.Encoding]::ASCII.GetString($all.ToArray())
        $boot = $text.Contains('rst:') -or $text.Contains('ets ')
        $sp.Write([byte[]]@(0), 0, 1)
        $pending.Clear()
        $a = Get-InfoUptime $sp $dec $pending ([uint32](2 * $i - 1)) $sw
        Start-Sleep -Milliseconds 300
        $b = Get-InfoUptime $sp $dec $pending ([uint32](2 * $i)) $sw
        $sp.Close()
        $tClose = $sw.Elapsed.TotalSeconds
        $cur = @{ TOpen = $tOpen; HelloSeen = $hello; BootText = $boot; TA = $a.T; UA = $a.U; TB = $b.T; UB = $b.U; TClose = $tClose }
        $v = Get-ResetVerdict $prev $cur
        $kinds.Add($v.Kind)
        Write-Host ("cycle $i/$Repeats : " + $v.Kind)
        foreach ($n in $v.Notes) { Write-Host "    - $n" }
        $prev = $cur
        if ($i -lt $Repeats) { Start-Sleep -Milliseconds ([int]($WaitSec * 1000)) }
    }
    $classified = @($kinds | Where-Object { $_ -ne 'baseline' })
    if ($classified -contains 'reset-on-open') { Write-Host 'conclusion: RESET ON OPEN observed' }
    elseif ($classified -contains 'reset-on-close') { Write-Host 'conclusion: RESET ON CLOSE observed (no reset on open observed)' }
    elseif ($classified.Count -gt 0 -and @($classified | Where-Object { $_ -ne 'no-reset' }).Count -eq 0) { Write-Host 'conclusion: NO RESET observed on open or close (uptime continuous in every classified cycle)' }
    else { Write-Host 'conclusion: INCONCLUSIVE' }
    return 0
}

# ---------------------------------------------------------------- entry
if ($SelfTest) { exit (Invoke-SelfTest) }
if (-not $Port) { Write-Host 'Give -SelfTest, or -Port with -ConfirmBoardAccess.'; exit 2 }
if (-not $ConfirmBoardAccess) {
    Write-Host 'Refusing to open a serial port without -ConfirmBoardAccess (board access is not yet approved).'
    exit 2
}
if ($ResetProbe -gt 0) { exit (Invoke-ResetProbe $Port $Baud $LineState $ResetProbe 3.0) }
exit (Invoke-EchoRun $Port $Baud $LineState $Count $Seed $HelloTimeout)
