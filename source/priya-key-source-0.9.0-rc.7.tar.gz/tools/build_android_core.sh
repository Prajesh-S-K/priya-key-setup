#!/bin/sh
# Builds libgpandroid.so (Rust core + JNI) for the three Android ABIs with the project-local NDK and puts them in jniLibs.
set -eu
P="$(cd "$(dirname "$0")/.." && pwd)"
export RUSTUP_HOME="$P/.toolchains/rustup" CARGO_HOME="$P/.toolchains/cargo" PATH="$P/.toolchains/cargo/bin:$P/.toolchains/android-sdk/platform-tools:$PATH"
NDK="$(ls -d "$P"/.toolchains/android-sdk/ndk/* | head -1)"
BIN="$(ls -d "$NDK"/toolchains/llvm/prebuilt/*/bin)"
API=30
build() { # rust-target abi clang-prefix
  T=$1; ABI=$2; CC=$3
  UP=$(echo "$T" | tr 'a-z-' 'A-Z_')
  eval "export CARGO_TARGET_${UP}_LINKER=$BIN/${CC}${API}-clang"
  eval "export CC_$(echo $T | tr - _)=$BIN/${CC}${API}-clang"
  eval "export AR_$(echo $T | tr - _)=$BIN/llvm-ar"
  (cd "$P/host" && cargo build --release -p gp-android --target "$T")
  mkdir -p "$P/android/app/src/main/jniLibs/$ABI"
  cp "$P/host/target/$T/release/libgpandroid.so" "$P/android/app/src/main/jniLibs/$ABI/"
}
build aarch64-linux-android arm64-v8a aarch64-linux-android
build armv7-linux-androideabi armeabi-v7a armv7a-linux-androideabi
build x86_64-linux-android x86_64 x86_64-linux-android
ls -l "$P"/android/app/src/main/jniLibs/*/libgpandroid.so
