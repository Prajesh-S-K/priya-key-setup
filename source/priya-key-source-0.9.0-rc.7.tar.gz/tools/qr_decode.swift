// Decodes the QR code in a PNG with macOS CoreImage and prints its text. Used only by tests/QA on a Mac.
import CoreImage
import Foundation
guard CommandLine.arguments.count > 1, let img = CIImage(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1])) else { exit(2) }
let det = CIDetector(ofType: CIDetectorTypeQRCode, context: nil, options: [CIDetectorAccuracy: CIDetectorAccuracyHigh])
let feats = det?.features(in: img) as? [CIQRCodeFeature] ?? []
if let m = feats.first?.messageString { print(m) } else { exit(1) }
