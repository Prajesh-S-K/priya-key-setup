"""Reset probe: separates reset-on-open from reset-on-close using the firmware's own uptime counter.

Why uptime and not boot text: the ROM boot banner and HELLO frame are easy to miss (the host may open the port
after they were printed, or the OS may discard bytes at open). ABSENCE of boot text therefore proves nothing and is
recorded only as inconclusive evidence. The firmware's INFO uptime_ms (since application start) is the primary
signal: if the board resets, uptime drops below what continuity predicts.

Per cycle: open, listen ~1 s, send 0x00, INFO (A), wait, INFO (B), close, wait, repeat.
Classification of cycle k compares INFO A of cycle k with INFO B and the close time of cycle k-1:

  uptime continuous                           -> no-reset            (HELLO/boot text seen anyway -> anomaly)
  uptime restarted, boot AFTER the open       -> reset-on-open       (a close-reset that also occurs is masked)
  uptime restarted, boot between close/open   -> reset-on-close
  uptime restarted, boot before the close     -> inconclusive        (reset while the previous session was open)
  no INFO response                            -> inconclusive
Resets are attributed only from timing; the verdict is never stronger than the timing allows.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from . import framing as F

TOL_MS = 500            # allowance for host scheduling and INFO latency
LISTEN_S = 1.0
GAP_S = 0.3
WAIT_BETWEEN_S = 3.0    # close-to-open gap: must exceed the firmware boot time so open and close resets are separable


@dataclass
class Observation:
    t_open: float
    hello_seen: bool
    boot_text_seen: bool
    t_a: float | None
    u_a: int | None
    t_b: float | None
    u_b: int | None
    t_close: float | None = None


@dataclass
class Verdict:
    kind: str
    notes: list = field(default_factory=list)


def classify(prev: Observation | None, cur: Observation) -> Verdict:
    ev = []
    if cur.hello_seen:
        ev.append("HELLO frame seen after open")
    if cur.boot_text_seen:
        ev.append("ROM boot text seen after open")
    if not (cur.hello_seen or cur.boot_text_seen):
        ev.append("no boot text or HELLO captured (this alone is inconclusive, not proof of no reset)")
    if cur.u_a is None or cur.t_a is None:
        return Verdict("inconclusive", ["no INFO response after open: the board may be resetting, wedged, or not running the echo firmware"] + ev)
    if prev is None or prev.u_b is None or prev.t_b is None or prev.t_close is None:
        return Verdict("baseline", ["first observation: no previous uptime to compare"] + ev)
    expected = prev.u_b + (cur.t_a - prev.t_b) * 1000.0
    since_open = (cur.t_a - cur.t_open) * 1000.0
    since_close = (cur.t_a - prev.t_close) * 1000.0
    u = cur.u_a
    if u >= expected - TOL_MS:
        if cur.hello_seen or cur.boot_text_seen:
            return Verdict("anomaly", [f"uptime is continuous ({u} ms, expected about {expected:.0f}) yet boot evidence was seen: "
                                       "inconsistent, repeat the probe"] + ev)
        return Verdict("no-reset", [f"uptime continuous across close and open ({u} ms, expected about {expected:.0f})"] + ev)
    base = f"uptime restarted ({u} ms, expected about {expected:.0f} if there had been no reset)"
    if u <= since_open + TOL_MS:
        return Verdict("reset-on-open", [base + f"; it is below the {since_open:.0f} ms since open, so the board booted after the port was opened. "
                                         "A reset on close, if any, is masked by this later reset"] + ev)
    if u <= since_close + TOL_MS:
        return Verdict("reset-on-close", [base + f"; the board booted after the previous close ({since_close:.0f} ms ago) but before this open"] + ev)
    return Verdict("inconclusive", [base + "; but the restart predates the previous close, so it happened while that session was open and "
                                           "cannot be attributed to open or close"] + ev)


def within_session_reset(cur: Observation) -> bool:
    """True if uptime dropped between INFO A and INFO B of the same open session."""
    if None in (cur.u_a, cur.u_b, cur.t_a, cur.t_b):
        return False
    return cur.u_b < cur.u_a + (cur.t_b - cur.t_a) * 1000.0 - TOL_MS


def run_probe(opener, repeats: int, clock, sleep, out=print, wait_s: float = WAIT_BETWEEN_S):
    """opener() -> port with write(bytes), read(timeout)->bytes, close(). clock() and sleep(s) are injectable."""
    observations: list[Observation] = []
    verdicts: list[Verdict] = []
    prev = None
    for i in range(repeats):
        port = opener()
        t_open = clock()
        dec = F.StreamDecoder()
        raw_seen = bytearray()
        hello = False
        end = t_open + LISTEN_S
        while clock() < end:
            data = port.read(0.02)
            if data:
                raw_seen += data
                for ev in dec.feed(data):
                    if ev.kind == "frame" and ev.frame.type == F.T_HELLO:
                        hello = True
        boot_text = b"rst:" in raw_seen or b"ets " in raw_seen
        port.write(b"\x00")

        def query(seq):
            port.write(F.encode_frame(F.T_INFO_REQ, seq))
            deadline = clock() + 1.0
            d = F.StreamDecoder()
            while clock() < deadline:
                data = port.read(0.02)
                for ev in d.feed(data):
                    if ev.kind == "frame" and ev.frame.type == F.T_INFO_RSP and ev.frame.seq == seq:
                        return clock(), F.unpack_info(ev.frame.payload)["uptime_ms"]
            return None, None

        t_a, u_a = query(2 * i + 1)
        sleep(GAP_S)
        t_b, u_b = query(2 * i + 2)
        port.close()
        t_close = clock()
        obs = Observation(t_open, hello, boot_text, t_a, u_a, t_b, u_b, t_close)
        v = classify(prev, obs)
        if within_session_reset(obs):
            v = Verdict("reset-during-session", ["uptime dropped between two INFO queries while the port stayed open"] + v.notes)
        observations.append(obs)
        verdicts.append(v)
        out(f"cycle {i + 1}/{repeats}: {v.kind}" + "".join(f"\n    - {n}" for n in v.notes))
        prev = obs
        if i + 1 < repeats:
            sleep(wait_s)
    kinds = [v.kind for v in verdicts]
    counts = {k: kinds.count(k) for k in sorted(set(kinds))}
    out(f"summary: {counts}")
    classified = [k for k in kinds if k != "baseline"]
    if not classified:
        conclusion = "no classified cycles (run at least 2)"
    elif any(k == "reset-on-open" for k in classified):
        conclusion = "RESET ON OPEN observed (separately from close; see per-cycle notes)"
    elif any(k == "reset-on-close" for k in classified):
        conclusion = "RESET ON CLOSE observed (no reset on open observed)"
    elif all(k == "no-reset" for k in classified):
        conclusion = "NO RESET observed on open or close (uptime continuous in every classified cycle)"
    else:
        conclusion = "INCONCLUSIVE: " + ", ".join(sorted(set(classified)))
    out("conclusion: " + conclusion)
    return verdicts, conclusion
