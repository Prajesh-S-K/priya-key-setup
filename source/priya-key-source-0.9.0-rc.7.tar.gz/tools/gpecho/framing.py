"""Reference implementation of the M1 USB echo framing (docs/echo-protocol.md).

No cryptography. The CRC detects line errors only and provides no authentication.
Pure standard library. The firmware's C implementation (firmware/m1-echo/main/echo_frame.c)
must match this module byte for byte; tests/c/test_frame.c checks that with shared vectors.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field

PROTO_VERSION = 1
HEADER_LEN = 9            # ver u8, type u8, flags u8, seq u32, len u16
CRC_LEN = 4
MAX_PAYLOAD = 256
MIN_RAW = HEADER_LEN + CRC_LEN                      # 13
MAX_RAW = HEADER_LEN + MAX_PAYLOAD + CRC_LEN        # 269
MAX_ENCODED = MAX_RAW + MAX_RAW // 254 + 1          # 271 (COBS worst case, excluding delimiter)
MAX_ENCODED_WITH_DELIM = MAX_ENCODED + 1            # 272
DELIMITER = 0x00

# Message types. Bit 7 set = sent by the device (response or unsolicited).
T_ECHO_REQ = 0x01
T_INFO_REQ = 0x02
T_ECHO_RSP = 0x81
T_INFO_RSP = 0x82
T_HELLO = 0x83
T_ERR_RSP = 0xFF
HOST_TYPES = (T_ECHO_REQ, T_INFO_REQ)
DEVICE_TYPES = (T_ECHO_RSP, T_INFO_RSP, T_HELLO, T_ERR_RSP)

# ERR_RSP payload[0] codes
ERR_VERSION = 1
ERR_FLAGS = 2
ERR_TYPE = 3

INFO_FORMAT = "<BHIIIIIIII"  # proto_ver u8, max_payload u16, then 8 x u32 (see spec)
INFO_FIELDS = ("proto_ver", "max_payload", "uptime_ms", "rx_ok", "rx_cobs_err",
               "rx_crc_err", "rx_len_err", "rx_oversize", "rx_uart_err", "tx_frames")


class FrameError(Exception):
    """Raised for a malformed frame. .kind is one of: cobs, length, crc, version, flags."""

    def __init__(self, kind: str, msg: str = ""):
        super().__init__(f"{kind}: {msg}" if msg else kind)
        self.kind = kind


# ---------------------------------------------------------------- CRC-32
# CRC-32/ISO-HDLC (zlib, IEEE 802.3): width 32, poly 0x04C11DB7, init 0xFFFFFFFF,
# refin true, refout true, xorout 0xFFFFFFFF. Check value for b"123456789" is 0xCBF43926.
def _make_table():
    tbl = []
    for i in range(256):
        c = i
        for _ in range(8):
            c = (c >> 1) ^ 0xEDB88320 if c & 1 else c >> 1
        tbl.append(c)
    return tbl


_CRC_TABLE = _make_table()


def crc32(data: bytes) -> int:
    c = 0xFFFFFFFF
    for b in data:
        c = _CRC_TABLE[(c ^ b) & 0xFF] ^ (c >> 8)
    return c ^ 0xFFFFFFFF


# ---------------------------------------------------------------- COBS
def cobs_encode(data: bytes) -> bytes:
    """Consistent Overhead Byte Stuffing. Output contains no 0x00. Worst case len(data)+len(data)//254+1."""
    out = bytearray([0])
    code_idx = 0
    code = 1
    for b in data:
        if b == 0:
            out[code_idx] = code
            code_idx = len(out)
            out.append(0)
            code = 1
        else:
            out.append(b)
            code += 1
            if code == 0xFF:
                out[code_idx] = code
                code_idx = len(out)
                out.append(0)
                code = 1
    out[code_idx] = code
    return bytes(out)


def cobs_decode(enc: bytes) -> bytes:
    """Strict about structure (no zero bytes, block lengths must fit) and lenient about a trailing empty block."""
    out = bytearray()
    i = 0
    n = len(enc)
    while i < n:
        code = enc[i]
        if code == 0:
            raise FrameError("cobs", "zero byte inside encoded data")
        i += 1
        end = i + code - 1
        if end > n:
            raise FrameError("cobs", "block runs past end")
        blk = enc[i:end]
        if 0 in blk:
            raise FrameError("cobs", "zero byte inside block")
        out += blk
        i = end
        if code < 0xFF and i < n:
            out.append(0)
    return bytes(out)


# ---------------------------------------------------------------- frames
@dataclass(frozen=True)
class Frame:
    type: int
    seq: int
    payload: bytes = b""
    ver: int = PROTO_VERSION
    flags: int = 0


def build_raw(type_: int, seq: int, payload: bytes = b"", ver: int = PROTO_VERSION, flags: int = 0) -> bytes:
    if not 0 <= len(payload) <= MAX_PAYLOAD:
        raise ValueError("payload length out of range")
    if not (0 <= type_ <= 0xFF and 0 <= seq <= 0xFFFFFFFF and 0 <= ver <= 0xFF and 0 <= flags <= 0xFF):
        raise ValueError("field out of range")
    body = struct.pack("<BBBIH", ver, type_, flags, seq, len(payload)) + payload
    return body + struct.pack("<I", crc32(body))


def encode_frame(type_: int, seq: int, payload: bytes = b"", ver: int = PROTO_VERSION, flags: int = 0) -> bytes:
    """COBS-encoded frame followed by the 0x00 delimiter, ready to write to the serial port."""
    return cobs_encode(build_raw(type_, seq, payload, ver, flags)) + b"\x00"


def parse_raw(raw: bytes) -> Frame:
    """Validate order: length bounds, len field match, CRC, then version, then flags."""
    n = len(raw)
    if n < MIN_RAW or n > MAX_RAW:
        raise FrameError("length", f"decoded size {n}")
    ver, type_, flags, seq, length = struct.unpack_from("<BBBIH", raw, 0)
    if length > MAX_PAYLOAD or HEADER_LEN + length + CRC_LEN != n:
        raise FrameError("length", f"len field {length} vs decoded size {n}")
    (crc_rx,) = struct.unpack_from("<I", raw, n - CRC_LEN)
    if crc32(raw[:n - CRC_LEN]) != crc_rx:
        raise FrameError("crc")
    if ver != PROTO_VERSION:
        raise FrameError("version", f"ver {ver}")
    if flags != 0:
        raise FrameError("flags", f"flags {flags:#x}")
    return Frame(type_, seq, bytes(raw[HEADER_LEN:HEADER_LEN + length]), ver, flags)


def parse_encoded(enc: bytes) -> Frame:
    return parse_raw(cobs_decode(enc))


# ---------------------------------------------------------------- INFO payload
def pack_info(proto_ver, max_payload, uptime_ms, rx_ok, rx_cobs_err, rx_crc_err, rx_len_err,
              rx_oversize, rx_uart_err, tx_frames):
    return struct.pack(INFO_FORMAT, proto_ver, max_payload, uptime_ms, rx_ok, rx_cobs_err,
                       rx_crc_err, rx_len_err, rx_oversize, rx_uart_err, tx_frames)


def unpack_info(payload: bytes) -> dict:
    if len(payload) != struct.calcsize(INFO_FORMAT):
        raise FrameError("length", "INFO payload size")
    return dict(zip(INFO_FIELDS, struct.unpack(INFO_FORMAT, payload)))


# ---------------------------------------------------------------- streaming receiver
@dataclass
class Event:
    kind: str                      # "frame" or "error"
    frame: Frame | None = None
    error: str | None = None       # cobs, length, crc, version, flags, oversize


@dataclass
class StreamDecoder:
    """Byte-stream receiver with delimiter resynchronization.

    Rules (identical in the firmware): bytes accumulate until 0x00. An empty chunk is ignored.
    A chunk longer than MAX_ENCODED sets an overflow flag, discards bytes, and on the next 0x00
    reports one 'oversize' error. Any malformed chunk is dropped whole and counted; the next
    0x00-delimited chunk is parsed independently, which is the resynchronization step.
    """
    buf: bytearray = field(default_factory=bytearray)
    overflow: bool = False
    counters: dict = field(default_factory=lambda: {
        "ok": 0, "cobs": 0, "length": 0, "crc": 0, "version": 0, "flags": 0, "oversize": 0, "empty": 0})

    def feed(self, data: bytes) -> list[Event]:
        events: list[Event] = []
        for b in data:
            if b != DELIMITER:
                if not self.overflow:
                    if len(self.buf) >= MAX_ENCODED:
                        self.overflow = True
                        self.buf.clear()
                    else:
                        self.buf.append(b)
                continue
            # delimiter
            if self.overflow:
                self.overflow = False
                self.buf.clear()
                self.counters["oversize"] += 1
                events.append(Event("error", error="oversize"))
                continue
            if not self.buf:
                self.counters["empty"] += 1
                continue
            chunk = bytes(self.buf)
            self.buf.clear()
            try:
                frame = parse_encoded(chunk)
            except FrameError as e:
                self.counters[e.kind] += 1
                events.append(Event("error", error=e.kind))
            else:
                self.counters["ok"] += 1
                events.append(Event("frame", frame=frame))
        return events
