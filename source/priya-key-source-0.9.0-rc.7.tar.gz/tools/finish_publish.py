#!/usr/bin/env python3
"""After the setup page is published: verify the REAL https address (page, links, both downloads, ZIP contents), and only if
everything passes generate the final printable QR card and check that the QR decodes to exactly that address.
usage: finish_publish.py https://your.address/ [--out qr-card/out]"""
import argparse
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import make_qr_card as QC  # noqa: E402
import verify_published as VP  # noqa: E402


def run(url, out, say=print, verify=VP.verify, extra_bases=()):
    try:
        url = QC.validate_url(url)
    except QC.BadUrl as e:
        say(f"REFUSED: {e}. No QR code was made.")
        return 1
    if not verify(url, say=say, extra_bases=list(extra_bases)):
        say("Verification failed: no QR card was generated.")
        return 1
    if QC.main(["--url", url, "--out", out]) != 0:
        return 1
    png = os.path.join(out, "qr.png")
    if shutil.which("swift") and sys.platform == "darwin":
        d = subprocess.run(["swift", os.path.join(ROOT, "tools", "qr_decode.swift"), png], capture_output=True, text=True)
        if d.stdout.strip() != url:
            say(f"STOP: the generated QR decodes to '{d.stdout.strip()}', not the published address")
            return 1
        say("QR code decodes to the published address")
    else:
        say("note: QR decode check skipped (needs macOS CoreImage); scan the printed preview with a phone before printing")
    say(f"final card: {os.path.join(out, 'card.html')}")
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("url")
    ap.add_argument("--out", default=os.path.join(ROOT, "qr-card", "out"))
    ap.add_argument("--downloads-base", action="append", default=[], help="where the downloads are hosted if not on the page's own site")
    a = ap.parse_args()
    sys.exit(run(a.url, a.out, extra_bases=a.downloads_base))
