#!/usr/bin/env python3
"""Verify a flash backup file locally and write an owner-only manifest. Never touches the board.

Checks: file exists, size equals --expected-bytes, not entirely 0xFF or 0x00, SHA-256 recorded.
"""
import argparse
import datetime
import hashlib
import json
import os
import stat
import sys


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--file", required=True)
    ap.add_argument("--expected-bytes", type=lambda s: int(s, 0), required=True)
    ap.add_argument("--mac", default="")
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)

    size = os.path.getsize(a.file)
    problems = []
    if size != a.expected_bytes:
        problems.append(f"size {size} != expected {a.expected_bytes}")
    h = hashlib.sha256()
    all_ff = all_00 = True
    with open(a.file, "rb") as fh:
        while True:
            chunk = fh.read(1 << 20)
            if not chunk:
                break
            h.update(chunk)
            if all_ff and chunk.count(b"\xff") != len(chunk):
                all_ff = False
            if all_00 and chunk.count(b"\x00") != len(chunk):
                all_00 = False
    if all_ff or all_00:
        problems.append("file is entirely 0xFF or entirely 0x00 (blank read)")
    mode = stat.S_IMODE(os.stat(a.file).st_mode)
    if mode & 0o077:
        problems.append(f"permissions {oct(mode)} allow group/other access; run chmod 600")
    manifest = {
        "file": os.path.basename(a.file), "bytes": size, "sha256": h.hexdigest(), "mac": a.mac,
        "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
        "problems": problems,
    }
    fd = os.open(a.out, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as fh:
        json.dump(manifest, fh, indent=2)
    print(json.dumps(manifest, indent=2))
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
