#!/usr/bin/env python3
"""Checks a PUBLISHED setup page over the network: HTTPS (valid certificate), every link on the page resolves, every download
matches both the fingerprint printed on the page and SHA256SUMS.txt, and the complete Windows ZIP contains the installer
(identical to the published one) and the two redistributables with the fingerprints the page states.
usage: verify_published.py https://your.address/   Exit status 0 only if every check passes."""
import argparse
import hashlib
import os
import re
import sys
import tempfile
import urllib.error
import urllib.request
import zipfile
import zlib
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.urls = []

    def handle_starttag(self, tag, attrs):
        for k, v in attrs:
            if k in ("href", "src") and v:
                self.urls.append(v)


def fetch(url, to_file=None, timeout=60):
    """Returns (status, content_type, length, sha256_hex, body_or_None)."""
    req = urllib.request.Request(url, headers={"User-Agent": "priya-key-verify/1"})
    h = hashlib.sha256()
    n = 0
    body = [] if to_file is None else None
    try:
        r = urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        e.close()                      # release the connection of an error response
        raise
    with r:
        status, ctype, clen = r.status, r.headers.get("Content-Type", ""), r.headers.get("Content-Length")
        out = open(to_file, "wb") if to_file else None
        try:
            while True:
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                h.update(chunk)
                n += len(chunk)
                if out:
                    out.write(chunk)
                else:
                    body.append(chunk)
        finally:
            if out:
                out.close()
    if clen is not None and int(clen) != n:
        raise ValueError(f"incomplete download: {n} of {clen} bytes")
    return status, ctype, n, h.hexdigest(), (b"".join(body) if body is not None else None)


def sha_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def verify(base, insecure_local=False, say=print, extra_bases=()):
    """Returns True only if everything passes. `insecure_local` exists for the automated tests (127.0.0.1 only)."""
    results = []

    def check(ok, msg):
        results.append(ok)
        say(("PASS  " if ok else "FAIL  ") + msg)
        return ok

    u = urlparse(base)
    local = u.hostname in ("127.0.0.1", "localhost")
    if u.scheme != "https" and not (insecure_local and local and u.scheme == "http"):
        check(False, f"{base} is not an https address (publishing must be HTTPS)")
        return False
    if local and not insecure_local:
        check(False, "localhost is not a real destination")
        return False
    if not base.endswith("/"):
        base += "/"
    try:
        status, ctype, n, _, body = fetch(base)
    except Exception as e:  # certificate errors, DNS, timeouts, 404 ...
        check(False, f"cannot open {base}: {e}")
        return False
    page = body.decode("utf-8", "replace")
    check(status == 200 and "text/html" in ctype.lower(), f"page opens (HTTP {status}, {ctype.split(';')[0]}, {n} bytes)")
    lp = Links()
    lp.feed(page)
    seen, downloads = set(), {}
    for raw in lp.urls:
        if raw.startswith(("#", "mailto:")):
            continue
        full = urljoin(base, raw)
        pu = urlparse(full)
        if pu.scheme != "https" and not (insecure_local and pu.hostname in ("127.0.0.1", "localhost")):
            check(False, f"link is not https: {raw}")
            continue
        if full in seen:
            continue
        seen.add(full)
        ours = full.startswith(base) or any(full.startswith(b) for b in extra_bases)
        if pu.hostname != u.hostname and not ours:
            # third-party links (Microsoft, winfsp.dev ...) are not ours to check, only that they are https
            continue
        try:
            if "/downloads/" in full or full.endswith(".tar.gz") or re.search(r"/(PriyaKey-[^/]+\.(zip|exe|apk)|SHA256SUMS\.txt)$", pu.path):
                dest = tempfile.NamedTemporaryFile(delete=False)
                dest.close()
                st, _, size, sha, _ = fetch(full, to_file=dest.name)
                downloads[os.path.basename(pu.path)] = (sha, size, dest.name)
                check(st == 200, f"downloaded {os.path.basename(pu.path)} ({size / 1048576:.1f} MB)")
            else:
                st, _, size, _, _ = fetch(full)
                check(st == 200, f"link resolves: {raw}")
        except Exception as e:
            check(False, f"link failed: {raw}: {e}")
    try:
        sums_name = "SHA256SUMS.txt"
        sums = {}
        if sums_name in downloads:
            with open(downloads[sums_name][2]) as fh:
                for line in fh:
                    p = line.split()
                    if len(p) == 2:
                        sums[p[1]] = p[0].lower()
        check(bool(sums), "SHA256SUMS.txt is published and readable")
        wanted = [n for n in downloads if re.match(r"PriyaKey-(Windows-Complete-|Setup-|[\d.\-rc]+\.apk)", n)]
        check(len(wanted) >= 3, f"the three intended downloads are linked ({', '.join(sorted(wanted))})")
        for name in wanted:
            sha = downloads[name][0]
            check(sums.get(name) == sha, f"{name}: matches SHA256SUMS.txt")
            check(sha in page, f"{name}: matches the fingerprint printed on the page")
        zips = [n for n in downloads if n.endswith(".zip")]
        for zn in zips:
            try:
                with zipfile.ZipFile(downloads[zn][2]) as z:
                    names = z.namelist()
                    check(z.testzip() is None, f"{zn}: archive is intact")
                    exe = [x for x in names if x.endswith(".exe") and "/redist/" not in x]
                    wv = [x for x in names if x.endswith("MicrosoftEdgeWebView2RuntimeInstallerX64.exe")]
                    wf = [x for x in names if x.endswith("redist/winfsp.msi")]
                    check(len(exe) == 1 and len(wv) == 1 and len(wf) == 1, f"{zn}: contains the installer and its redist folder (WebView2, WinFsp)")
                    if exe:
                        ei = hashlib.sha256(z.read(exe[0])).hexdigest()
                        inst = [n for n in downloads if n.startswith("PriyaKey-Setup-")]
                        check(bool(inst) and downloads[inst[0]][0] == ei, f"{zn}: inner installer is identical to the published installer")
                    for x in wv + wf:
                        check(hashlib.sha256(z.read(x)).hexdigest() in page, f"{zn}: {os.path.basename(x)} matches the fingerprint on the page")
            except (zipfile.BadZipFile, zlib.error, OSError, ValueError, EOFError, NotImplementedError) as e:
                check(False, f"{zn}: archive cannot be read ({e})")
        check("pending" in page.lower() or "release candidate" in page.lower(), "page keeps its release-candidate label")
    finally:
        for _, _, f in downloads.values():
            try:
                os.unlink(f)
            except OSError:
                pass
    return all(results)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("url")
    ap.add_argument("--downloads-base", action="append", default=[], help="address (ending in /) where the downloads are hosted, if not on the page's own site")
    a = ap.parse_args(argv)
    ok = verify(a.url, extra_bases=a.downloads_base)
    print("RESULT: " + ("ALL CHECKS PASSED" if ok else "FAILED - do not print the QR card"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
