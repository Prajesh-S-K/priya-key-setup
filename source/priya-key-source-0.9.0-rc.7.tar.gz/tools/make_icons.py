#!/usr/bin/env python3
"""Generates the Priya Key icon set from one drawing (stdlib only): PNGs, ICO, raw RGBA for the tray, a Windows .res
resource (icon group) that rust-lld links into the exe, and Android vector drawables."""
import os, struct, zlib, math

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CY, MG, BG1, BG2 = (45, 226, 230), (255, 79, 163), (7, 17, 30), (14, 34, 56)


def shade(u, v):
    """colour (r,g,b,a 0..1) at unit square position, or None outside the rounded square"""
    r = 0.22
    dx = max(abs(u - .5) - (.5 - r), 0); dy = max(abs(v - .5) - (.5 - r), 0)
    if math.hypot(dx, dy) > r:
        return (0, 0, 0, 0)
    t = v
    col = [BG1[i] + (BG2[i] - BG1[i]) * t for i in range(3)]
    # key: ring, shaft, teeth
    cx, cy = .5, .31
    d = math.hypot(u - cx, v - cy)
    key = (.075 <= d <= .17) or (abs(u - .5) <= .04 and .45 <= v <= .80) or (.54 <= u <= .66 and .60 <= v <= .66) or (.54 <= u <= .63 and .70 <= v <= .76)
    if d <= .035:
        return (*[c / 255 for c in MG], 1)
    if key:
        return (*[c / 255 for c in CY], 1)
    # thin magenta frame accent
    if abs(math.hypot(dx, dy) - (r - .03)) < .008 and (u < .5) == (v < .5):
        return (*[c / 255 for c in MG], .8)
    return (*[c / 255 for c in col], 1)


def render(n, ss=3):
    px = bytearray()
    for y in range(n):
        for x in range(n):
            a = [0, 0, 0, 0]
            for sy in range(ss):
                for sx in range(ss):
                    c = shade((x + (sx + .5) / ss) / n, (y + (sy + .5) / ss) / n)
                    al = c[3]
                    a[0] += c[0] * al; a[1] += c[1] * al; a[2] += c[2] * al; a[3] += al
            k = ss * ss
            al = a[3] / k
            if al > 0:
                px += bytes([round(a[0] / a[3] * 255), round(a[1] / a[3] * 255), round(a[2] / a[3] * 255), round(al * 255)])
            else:
                px += b"\0\0\0\0"
    return bytes(px)


def png(n, rgba):
    raw = b"".join(b"\0" + rgba[y * n * 4:(y + 1) * n * 4] for y in range(n))
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", n, n, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")


def ico(entries):
    out = struct.pack("<HHH", 0, 1, len(entries))
    off = 6 + 16 * len(entries)
    data = b""
    for n, p in entries:
        out += struct.pack("<BBBBHHII", n % 256, n % 256, 0, 0, 1, 32, len(p), off + len(data))
        data += p
    return out + data


def res_entry(rtype, rid, payload):
    def ident(v): return struct.pack("<HH", 0xFFFF, v)
    hdr_tail = struct.pack("<IHHII", 0, 0x1030, 0x409, 0, 0)  # DataVersion, flags (MOVEABLE|PURE|DISCARDABLE), lang, version, characteristics
    head = ident(rtype) + ident(rid) + hdr_tail
    hsize = 8 + len(head)
    e = struct.pack("<II", len(payload), hsize) + head + payload
    return e + b"\0" * (-len(e) % 4)


def main():
    sizes = [16, 32, 48, 64, 256]
    pngs = {}
    for n in sizes:
        pngs[n] = png(n, render(n, 3 if n > 64 else 4))
    os.makedirs(f"{ROOT}/brand", exist_ok=True)
    for n in (256, 64):
        open(f"{ROOT}/brand/icon-{n}.png", "wb").write(pngs[n])
    open(f"{ROOT}/brand/icon.ico", "wb").write(ico([(n, pngs[n]) for n in sizes]))
    A = f"{ROOT}/host/windows-app/assets"
    os.makedirs(A, exist_ok=True)
    open(f"{A}/icon64.rgba", "wb").write(render(64, 4))
    open(f"{A}/icon.ico", "wb").write(open(f"{ROOT}/brand/icon.ico", "rb").read())
    # Windows resource: RT_ICON (3) entries 1..n + RT_GROUP_ICON (14) id 1
    res = struct.pack("<IIHHHHIHHII", 0, 32, 0xFFFF, 0, 0xFFFF, 0, 0, 0, 0, 0, 0)  # empty header entry required first
    grp = struct.pack("<HHH", 0, 1, len(sizes))
    for i, n in enumerate(sizes, 1):
        res += res_entry(3, i, pngs[n])
        grp += struct.pack("<BBBBHHIH", n % 256, n % 256, 0, 0, 1, 32, len(pngs[n]), i)
    res += res_entry(14, 1, grp)
    open(f"{A}/app.res", "wb").write(res)
    # Android: adaptive icon pieces (vector) - same drawing in a 108dp viewport
    d = f"{ROOT}/android/app/src/main/res"
    os.makedirs(f"{d}/drawable", exist_ok=True); os.makedirs(f"{d}/mipmap-anydpi-v26", exist_ok=True); os.makedirs(f"{d}/values", exist_ok=True)
    open(f"{d}/drawable/ic_launcher_foreground.xml", "w").write("""<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
    <group android:scaleX="0.62" android:scaleY="0.62" android:pivotX="54" android:pivotY="54">
        <path android:fillColor="#2DE2E6" android:fillType="evenOdd" android:pathData="M54,17 a20,20 0 1,0 0.01,0 z M54,33 a8,8 0 1,1 -0.01,0 z"/>
        <path android:fillColor="#2DE2E6" android:pathData="M49,52 h10 v36 h-10 z M59,67 h14 v7 h-14 z M59,78 h10 v7 h-10 z"/>
        <path android:fillColor="#FF4FA3" android:pathData="M54,36.5 a3.5,3.5 0 1,0 0.01,0 z"/>
    </group>
</vector>
""")
    open(f"{d}/drawable/ic_notify.xml", "w").write("""<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">
    <path android:fillColor="#FFFFFF" android:fillType="evenOdd" android:pathData="M12,2 a5,5 0 1,0 0.01,0 z M12,6 a1.6,1.6 0 1,1 -0.01,0 z"/>
    <path android:fillColor="#FFFFFF" android:pathData="M11,10 h2 v11 h-2 z M13,15 h4 v2 h-4 z M13,18 h3 v2 h-3 z"/>
</vector>
""")
    open(f"{d}/values/ic_launcher_background.xml", "w").write('<?xml version="1.0" encoding="utf-8"?>\n<resources><color name="ic_launcher_background">#0B1D30</color></resources>\n')
    open(f"{d}/mipmap-anydpi-v26/ic_launcher.xml", "w").write('<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android"><background android:drawable="@color/ic_launcher_background"/><foreground android:drawable="@drawable/ic_launcher_foreground"/></adaptive-icon>\n')
    print("icons written")


main()
