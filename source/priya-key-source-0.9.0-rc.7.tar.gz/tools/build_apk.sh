#!/bin/sh
# Builds the Rust core for Android, then the release APK, signed with the project's private release key.
# The key (android/release.jks, android/keystore.properties) is created once, is git-ignored and must be kept: an APK
# signed with a different key cannot update an installed one.
set -eu
P="$(cd "$(dirname "$0")/.." && pwd)"
export JAVA_HOME="$P/.toolchains/jdk-17/Contents/Home" ANDROID_HOME="$P/.toolchains/android-sdk"
"$P/tools/build_android_core.sh" >/dev/null
cd "$P/android"
if [ ! -f keystore.properties ]; then
  umask 077
  PW=$(head -c 24 /dev/urandom | base64 | tr -d '/+=' | head -c 24)
  "$JAVA_HOME/bin/keytool" -genkeypair -keystore release.jks -alias giftkey -keyalg RSA -keysize 3072 -validity 12000 \
    -storepass "$PW" -keypass "$PW" -dname "CN=Priya Key, O=Personal, C=US" >/dev/null 2>&1
  printf 'storeFile=release.jks\nstorePassword=%s\nkeyAlias=giftkey\nkeyPassword=%s\n' "$PW" "$PW" > keystore.properties
  chmod 600 keystore.properties release.jks
fi
./gradlew --no-daemon -q assembleRelease
mkdir -p "$P/dist/android"
VER="$(cat "$P/VERSION")"
cp app/build/outputs/apk/release/app-release.apk "$P/dist/android/PriyaKey-$VER.apk"
"$ANDROID_HOME/build-tools/36.0.0/apksigner" verify --print-certs "$P/dist/android/PriyaKey-$VER.apk" | head -3
shasum -a 256 "$P/dist/android/PriyaKey-$VER.apk"
