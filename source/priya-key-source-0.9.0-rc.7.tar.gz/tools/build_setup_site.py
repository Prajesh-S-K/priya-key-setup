#!/usr/bin/env python3
"""Builds the static first-use setup site: setup-site/dist/{index.html, priya-key-icon.png, downloads/*}.
The page uses only relative links, so it works at whatever address it is published to. Nothing is uploaded by this tool."""
import argparse
import hashlib
import os
import re
import shutil
import subprocess
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def human(n):
    return f"{n / 1048576:.1f} MB" if n >= 1048576 else f"{n / 1024:.0f} KB"


def cert_sha(apk, apksigner):
    out = subprocess.run([apksigner, "verify", "--print-certs", apk], capture_output=True, text=True)
    if out.returncode != 0:
        raise SystemExit(f"apksigner could not verify {apk}: {out.stderr.strip()}")
    m = re.search(r"certificate SHA-256 digest: ([0-9a-f]{64})", out.stdout)
    if not m:
        raise SystemExit("no signing certificate fingerprint found")
    return m.group(1)


ZIP_README = """Priya Key {version} - complete Windows package (release candidate)

1. EXTRACT ALL FILES FIRST (right-click the ZIP > Extract All...). Do not run the setup from inside the ZIP preview.
2. Open PriyaKey-Setup-{version}.exe from the extracted folder and approve the administrator prompt.
   Keep the 'redist' folder next to the setup file: it holds WinFsp and the offline Microsoft WebView2 runtime installer,
   which the setup uses if the PC does not already have them. No other download is needed.
3. Plug the key in only AFTER the app is installed. Windows supplies the key's USB serial driver itself (it may use
   Windows Update the first time); that driver is not in this package.
The installer is not commercially signed. SmartScreen may show 'Windows protected your PC': choose More info > Run anyway only
if the SHA-256 of this ZIP matches the setup page. Windows 11 SMART APP CONTROL, if switched on, can block it with no
override at all: use a PC where it is off (or switch it off knowingly; it usually cannot be re-enabled without resetting Windows).
"""


def make_zip(path, version, win, redist):
    """Deterministic ZIP (fixed timestamps and order): <root>/setup.exe, <root>/redist/*, <root>/README.txt."""
    root = f"PriyaKey-Windows-{version}"
    items = [(f"{root}/{os.path.basename(win)}", win), (f"{root}/redist/winfsp.msi", os.path.join(redist, "winfsp.msi")),
             (f"{root}/redist/MicrosoftEdgeWebView2RuntimeInstallerX64.exe", os.path.join(redist, "webview2.exe"))]
    for _, f in items:
        if not os.path.isfile(f):
            raise SystemExit(f"missing redistributable: {f}")
    with zipfile.ZipFile(path, "w") as z:
        def add(name, data, comp):
            zi = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            zi.compress_type = comp
            zi.external_attr = 0o644 << 16
            z.writestr(zi, data)
        add(f"{root}/README.txt", ZIP_README.format(version=version).replace("\n", "\r\n"), zipfile.ZIP_DEFLATED)
        for name, f in items:
            with open(f, "rb") as fh:
                add(name, fh.read(), zipfile.ZIP_STORED if f.endswith(".exe") or f.endswith(".msi") else zipfile.ZIP_DEFLATED)


def build(version, win, apk, out, apksigner, redist, template=None, icon=None, downloads_base="", release=None):
    template = template or os.path.join(ROOT, "setup-site", "index.template.html")
    icon = icon or os.path.join(ROOT, "brand", "icon-64.png")
    for f in (win, apk, template, icon):
        if not os.path.isfile(f):
            raise SystemExit(f"missing input: {f}")
    dl = os.path.join(out, "downloads")
    shutil.rmtree(out, ignore_errors=True)
    os.makedirs(dl)
    shutil.copy(win, dl)
    shutil.copy(apk, dl)
    zname = f"PriyaKey-Windows-Complete-{version}.zip"
    zpath = os.path.join(dl, zname)
    make_zip(zpath, version, win, redist)
    shutil.copy(icon, os.path.join(out, "priya-key-icon.png"))
    # licences and the GPL source archive travel with the page (small files; always relative to the page)
    if release:
        for src, dst in ((os.path.join(release, "COPYING-GPL-3.0.txt"), "notices/COPYING-GPL-3.0.txt"), (os.path.join(release, "LICENSE.txt"), "notices/LICENSE.txt"),
                         (os.path.join(release, "THIRD_PARTY_NOTICES.txt"), "notices/THIRD_PARTY_NOTICES.txt"),
                         (os.path.join(release, "source", f"priya-key-source-{version}.tar.gz"), f"source/priya-key-source-{version}.tar.gz")):
            if not os.path.isfile(src):
                raise SystemExit(f"missing notice/source file: {src}")
            os.makedirs(os.path.dirname(os.path.join(out, dst)), exist_ok=True)
            shutil.copy(src, os.path.join(out, dst))
    wn, an = os.path.basename(win), os.path.basename(apk)
    vals = {"VERSION": version, "WIN_FILE": wn, "WIN_SHA": sha256(win), "WIN_SIZE": human(os.path.getsize(win)),
            "APK_FILE": an, "APK_SHA": sha256(apk), "APK_SIZE": human(os.path.getsize(apk)), "APK_CERT": cert_sha(apk, apksigner),
            "ZIP_FILE": zname, "ZIP_SHA": sha256(zpath), "ZIP_SIZE": human(os.path.getsize(zpath)),
            "WV_SHA": sha256(os.path.join(redist, "webview2.exe")), "WF_SHA": sha256(os.path.join(redist, "winfsp.msi")),
            "DL": downloads_base or "downloads/"}
    with open(template, encoding="utf-8") as fh:
        html = fh.read()
    for k, v in vals.items():
        html = html.replace("{{" + k + "}}", v)
    if "{{" in html:
        raise SystemExit("unreplaced placeholder in the page")
    with open(os.path.join(out, "index.html"), "w", encoding="utf-8") as fh:
        fh.write(html)
    with open(os.path.join(dl, "SHA256SUMS.txt"), "w") as fh:
        fh.write(f"{vals['ZIP_SHA']}  {zname}\n{vals['WIN_SHA']}  {wn}\n{vals['APK_SHA']}  {an}\n")
    return vals


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    v = open(os.path.join(ROOT, "VERSION")).read().strip()
    ap.add_argument("--version", default=v)
    ap.add_argument("--win", default=os.path.join(ROOT, "dist", "windows", f"PriyaKey-Setup-{v}.exe"))
    ap.add_argument("--apk", default=os.path.join(ROOT, "dist", "android", f"PriyaKey-{v}.apk"))
    ap.add_argument("--redist", default=os.path.join(ROOT, ".toolchains", "dl", "redist"), help="folder with winfsp.msi and webview2.exe")
    ap.add_argument("--downloads-base", default="", help="absolute https base (ending in /) if the big files are hosted elsewhere; default: relative downloads/")
    ap.add_argument("--release", help="release folder holding the notices and the source archive (required for a publishable page)")
    ap.add_argument("--out", default=os.path.join(ROOT, "setup-site", "dist"))
    ap.add_argument("--apksigner", default=os.path.join(ROOT, ".toolchains", "android-sdk", "build-tools", "36.0.0", "apksigner"))
    a = ap.parse_args(argv)
    vals = build(a.version, a.win, a.apk, a.out, a.apksigner, a.redist, downloads_base=a.downloads_base, release=a.release)
    print(f"setup page built in {a.out} (version {vals['VERSION']})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
