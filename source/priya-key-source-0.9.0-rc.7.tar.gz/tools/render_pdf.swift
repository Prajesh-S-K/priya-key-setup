// QA helper (macOS): renders page N (1-based, default 1) of a PDF to a PNG at 300 dpi so printed output can be decoded.
import AppKit
import PDFKit
let a = CommandLine.arguments
guard a.count >= 3, let doc = PDFDocument(url: URL(fileURLWithPath: a[1])) else { exit(2) }
let n = a.count > 3 ? Int(a[3]) ?? 1 : 1
guard let page = doc.page(at: n - 1) else { exit(3) }
let box = page.bounds(for: .mediaBox)
let s: CGFloat = 300.0 / 72.0
let w = Int(box.width * s), h = Int(box.height * s)
let rep = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: w, pixelsHigh: h, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!
let ctx = NSGraphicsContext(bitmapImageRep: rep)!
NSGraphicsContext.saveGraphicsState()
NSGraphicsContext.current = ctx
NSColor.white.set(); NSRect(x: 0, y: 0, width: w, height: h).fill()
ctx.cgContext.scaleBy(x: s, y: s)
page.draw(with: .mediaBox, to: ctx.cgContext)
NSGraphicsContext.restoreGraphicsState()
try! rep.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: a[2]))
