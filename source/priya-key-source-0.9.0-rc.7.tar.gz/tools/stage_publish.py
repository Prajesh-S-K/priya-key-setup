#!/usr/bin/env python3
"""Stages EXACTLY what may be published (an allowlist) and refuses anything else.
Published: index.html, icon, downloads (complete Windows ZIP, installer, APK, SHA256SUMS.txt), notices (licences) and the GPL
source archive. NOT published: the project directory, signing keys/keystore, board backups, host state, toolchains.
usage: stage_publish.py --src <setup-site folder> [--out publish-staging] [--split]
--split: the page links its downloads at another address (for example GitHub Releases). Two folders are staged: <out>/site (page, icon,
licences, source) and <out>/release-assets (the three downloads and SHA256SUMS.txt)."""
import argparse
import os
import re
import shutil
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ALLOWED = [r"^index\.html$", r"^priya-key-icon\.png$", r"^downloads/PriyaKey-Windows-Complete-[\w.\-]+\.zip$", r"^downloads/PriyaKey-Setup-[\w.\-]+\.exe$",
           r"^downloads/PriyaKey-[\w.\-]+\.apk$", r"^downloads/SHA256SUMS\.txt$", r"^notices/(COPYING-GPL-3\.0|LICENSE|THIRD_PARTY_NOTICES)\.txt$",
           r"^source/priya-key-source-[\w.\-]+\.tar\.gz$"]
FORBIDDEN = re.compile(r"(\.jks$|keystore|signing|\.key$|\.pem$|backup|hardware|host-state|identification|trusted_board|test_pin|\.toolchains|\.git|\.env|__pycache__|\.DS_Store)", re.I)


ALLOW_INSECURE_LOCAL = False   # tests only: lets a split page point at 127.0.0.1


class Refused(Exception):
    pass


def collect(src):
    files = []
    for d, _, names in os.walk(src):
        for n in names:
            rel = os.path.relpath(os.path.join(d, n), src).replace(os.sep, "/")
            files.append(rel)
    return sorted(files)


def check(src):
    files = collect(src)
    for rel in files:
        if FORBIDDEN.search(rel):
            raise Refused(f"forbidden file in the publish set: {rel}")
        if not any(re.match(p, rel) for p in ALLOWED):
            raise Refused(f"file is not on the publish allowlist: {rel}")
        if os.path.islink(os.path.join(src, rel)):
            raise Refused(f"symbolic link in the publish set: {rel}")
    need = ["index.html", "priya-key-icon.png", "downloads/SHA256SUMS.txt"]
    for n in need:
        if n not in files:
            raise Refused(f"required file missing: {n}")
    for pat in (r"^downloads/PriyaKey-Windows-Complete-.*\.zip$", r"^downloads/PriyaKey-Setup-.*\.exe$", r"^downloads/PriyaKey-[\d.\-rc]+\.apk$", r"^source/.*\.tar\.gz$", r"^notices/COPYING-GPL-3\.0\.txt$"):
        if not any(re.match(pat, f) for f in files):
            raise Refused(f"required file missing: {pat}")
    return files


def split_sets(files):
    site = [f for f in files if not f.startswith("downloads/")]
    assets = [f for f in files if f.startswith("downloads/")]
    return site, assets


def check_split(src):
    files = check(src)
    html = open(os.path.join(src, "index.html"), encoding="utf-8").read()
    if re.search(r'(?:href|src)="downloads/', html):
        raise Refused("the page still links its downloads relatively; build it with --downloads-base for a split publication")
    scheme = r"https?://127\.0\.0\.1" if ALLOW_INSECURE_LOCAL else "https://"
    if not re.search(r'href="' + scheme + r'[^"]*/PriyaKey-Windows-Complete-[^"]+\.zip"', html):
        raise Refused("the page does not link the complete Windows ZIP at an absolute https address")
    return files


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--src", required=True)
    ap.add_argument("--out", default=os.path.join(ROOT, "publish-staging"))
    ap.add_argument("--split", action="store_true")
    a = ap.parse_args(argv)
    try:
        files = check_split(a.src) if a.split else check(a.src)
    except Refused as e:
        print(f"REFUSED: {e}", file=sys.stderr)
        return 1
    shutil.rmtree(a.out, ignore_errors=True)
    if a.split:
        site, assets = split_sets(files)
        for rel in site:
            dst = os.path.join(a.out, "site", rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(os.path.join(a.src, rel), dst)
        for rel in assets:
            dst = os.path.join(a.out, "release-assets", os.path.basename(rel))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(os.path.join(a.src, rel), dst)
        print(f"staged split: site={len(site)} files, release-assets={len(assets)} files in {a.out}")
        return 0
    for rel in files:
        dst = os.path.join(a.out, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(os.path.join(a.src, rel), dst)
    total = sum(os.path.getsize(os.path.join(a.out, f)) for f in files)
    big = max(files, key=lambda f: os.path.getsize(os.path.join(a.out, f)))
    print(f"staged {len(files)} files, {total / 1048576:.1f} MB in {a.out}; largest: {big} ({os.path.getsize(os.path.join(a.out, big)) / 1048576:.1f} MB)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
