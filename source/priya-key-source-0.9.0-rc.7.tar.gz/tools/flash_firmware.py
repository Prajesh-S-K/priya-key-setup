#!/usr/bin/env python3
"""Flash the Priya Key board firmware package, behind the project's established board gates.

Default run is SAFE: it validates the package offline, identifies the connected board, checks security state, takes (or
verifies) a full-flash backup against the board, and then STOPS. Writing needs the extra argument
`--confirm-write <MAC>` that equals the identified board's MAC, so the owner authorizes the write for that exact board.

Gates (any failure is a STOP; there is no override):
  1. package   every file's SHA-256 matches SHA256SUMS.txt; flasher_args.json and the partition table agree; write regions
               are derived from the validated metadata, stay inside the flash and never touch NVS (0x9000-0xEFFF).
  2. identify  esptool chip-id / flash-id / read-mac and a read-only espefuse summary, evaluated by check_identification
               (classic ESP32, flash size known, no secure boot, no flash encryption, no restricted download mode, ...).
  3. capacity  the detected flash holds every write region.
  4. backup    a full-flash backup the size of the flash, not blank, owner-only, and `verify-flash` proves it equals the
               connected board; same-board MAC checks before and again immediately before writing.
  5. write     only the validated regions, no erase, then verify-flash of exactly what was written.
Exit status: 0 written and verified, 1 STOP, 3 gates passed but writing was not authorized.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import io
import json
import os
import shlex
import shutil
import struct
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import backup_manifest as BM  # noqa: E402
import check_identification as CI  # noqa: E402
import plan_flash as PF  # noqa: E402

NVS_START, NVS_END = 0x9000, 0x10000          # nvs + phy_init: the pairing record lives here, never written
BOOTLOADER_OFF, TABLE_OFF = 0x1000, 0x8000    # fixed by the ESP32 ROM
ASSET_SUBTYPE = 0x40
FILES = ("bootloader.bin", "partition-table.bin", "gpkey.bin", "assets.bin", "flasher_args.json")


class Stop(Exception):
    pass


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_table(blob):
    """Partition table (ESP32): 32-byte entries, MD5 entry 0xEBEB at the end. Returns {name: (type, subtype, offset, size)}."""
    if len(blob) < 64 or len(blob) > 0x1000:
        raise Stop("partition table has an unexpected size")
    parts, i = {}, 0
    while i + 32 <= len(blob):
        ent = blob[i:i + 32]
        if ent[:2] == b"\xeb\xeb":
            if hashlib.md5(blob[:i]).digest() != ent[16:32]:
                raise Stop("partition table MD5 does not match its entries")
            return parts
        if ent[:2] != b"\xaa\x50":
            raise Stop("partition table ends without its MD5 entry")
        _, typ, sub, off, size, name, _flags = struct.unpack("<HBBLL16sL", ent)
        name = name.split(b"\0")[0].decode("ascii", "replace")
        if name in parts:
            raise Stop(f"duplicate partition '{name}'")
        parts[name] = (typ, sub, off, size)
        i += 32
    raise Stop("partition table has no MD5 entry")


def validate_package(fw_dir, sums_path):
    """Offline checks. Returns the plan: list of (offset, path) writes, flash settings, end address."""
    if not os.path.isfile(sums_path):
        raise Stop(f"checksum list not found: {sums_path} (the package cannot be verified)")
    listed = {}
    with open(sums_path) as fh:
        for line in fh:
            parts = line.strip().split(None, 1)
            if len(parts) == 2:
                listed[os.path.basename(parts[1].lstrip("*").strip())] = (parts[0].lower(), parts[1].strip())
    for name in FILES:
        path = os.path.join(fw_dir, name)
        if not os.path.isfile(path):
            raise Stop(f"missing package file {name}")
        if name not in listed:
            raise Stop(f"{name} is not listed in the checksum file")
        if sha256_file(path) != listed[name][0]:
            raise Stop(f"{name} does not match its SHA-256 in the checksum file: the package is damaged or altered")

    with open(os.path.join(fw_dir, "flasher_args.json")) as fh:
        meta = json.load(fh)
    ff = meta.get("flash_files", {})
    want = {"0x1000": "bootloader/bootloader.bin", "0x8000": "partition_table/partition-table.bin", "0x10000": "gpkey.bin"}
    if ff != want:
        raise Stop(f"flasher_args.json flash_files {ff} differ from the expected layout {want}")
    if meta.get("extra_esptool_args", {}).get("chip") != "esp32":
        raise Stop("flasher_args.json is not for the classic ESP32")
    fs = meta.get("flash_settings", {})
    if fs.get("flash_mode") not in ("dio", "qio", "dout") or not str(fs.get("flash_freq", "")).endswith("m"):
        raise Stop("flasher_args.json has unusable flash settings")

    sizes = {n: os.path.getsize(os.path.join(fw_dir, n)) for n in FILES}
    with open(os.path.join(fw_dir, "partition-table.bin"), "rb") as fh:
        table = parse_table(fh.read())
    fac = table.get("factory"); assets = table.get("assets"); nvs = table.get("nvs")
    if not fac or fac[0] != 0 or fac[1] != 0:
        raise Stop("partition table has no factory app partition")
    if not assets or assets[0] != 1 or assets[1] != ASSET_SUBTYPE:
        raise Stop("partition table has no 'assets' data partition")
    if not nvs or nvs[2] != NVS_START:
        raise Stop("partition table moves the NVS partition: the pairing record would be lost")
    if fac[2] != 0x10000:
        raise Stop("app partition is not at 0x10000 as flasher_args.json says")
    app_off, assets_off = fac[2], assets[2]
    if sizes["gpkey.bin"] > fac[3]:
        raise Stop("application does not fit its partition")
    if sizes["assets.bin"] > assets[3]:
        raise Stop("dashboard image does not fit its partition")
    if sizes["bootloader.bin"] > TABLE_OFF - BOOTLOADER_OFF or sizes["partition-table.bin"] > 0x1000:
        raise Stop("bootloader or partition table too large for its region")
    for name in ("bootloader.bin", "gpkey.bin"):          # ESP image magic and classic-ESP32 chip id
        with open(os.path.join(fw_dir, name), "rb") as fh:
            h = fh.read(24)
        if len(h) < 24 or h[0] != 0xE9 or struct.unpack("<H", h[12:14])[0] != 0:
            raise Stop(f"{name} is not an ESP32 image")
    with open(os.path.join(fw_dir, "assets.bin"), "rb") as fh:
        ah = fh.read(12)
    if ah[:4] != b"GKAS" or struct.unpack("<I", ah[8:12])[0] != sizes["assets.bin"]:
        raise Stop("assets.bin is not a well-formed dashboard image")

    writes = [(BOOTLOADER_OFF, os.path.join(fw_dir, "bootloader.bin")), (TABLE_OFF, os.path.join(fw_dir, "partition-table.bin")),
              (app_off, os.path.join(fw_dir, "gpkey.bin")), (assets_off, os.path.join(fw_dir, "assets.bin"))]
    spans = sorted((off, off + os.path.getsize(p), p) for off, p in writes)
    for a, b in zip(spans, spans[1:]):
        if a[1] > b[0]:
            raise Stop("write regions overlap")
    for off, end, p in spans:
        if off < NVS_END and end > NVS_START:
            raise Stop(f"{os.path.basename(p)} would overwrite the NVS/phy region (0x9000-0xFFFF)")
    return {"writes": writes, "settings": fs, "end": max(e for _, e, _ in spans)}


class Runner:
    def __init__(self, esptool, espefuse, port, work):
        self.esptool, self.espefuse, self.port, self.work = esptool, espefuse, port, work

    def step(self, name, cmd):
        rc = 0
        with open(os.path.join(self.work, f"step-{name}.txt"), "w") as out:
            try:
                rc = subprocess.run(cmd, stdout=out, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL).returncode
            except OSError as e:
                out.write(f"cannot run {cmd[0]}: {e}\n")
                rc = 127
        with open(os.path.join(self.work, f"step-{name}.rc"), "w") as fh:
            fh.write(str(rc))
        if rc != 0:
            raise Stop(f"step '{name}' failed with exit code {rc} (see {self.work}/step-{name}.txt)")

    def base(self):
        return ["--port", self.port, "--baud", str(PF.BACKUP_BAUD), "--before", "default-reset", "--after", "hard-reset"]

    def es(self, name, *args, no_stub=False):
        self.step(name, self.esptool + self.base() + (["--no-stub"] if no_stub else []) + list(args))


def run(argv, say=print):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--port")
    ap.add_argument("--package", default=HERE, help="folder with the firmware files (default: this folder)")
    ap.add_argument("--sums", help="SHA256SUMS.txt (default: ../SHA256SUMS.txt, then ./SHA256SUMS.txt)")
    ap.add_argument("--workdir", default="priya-key-flash-work", help="private folder for step outputs and the backup (created mode 700)")
    ap.add_argument("--backup", help="an existing full-flash backup to verify against the board instead of reading a new one")
    ap.add_argument("--confirm-write", metavar="MAC", help="authorize writing to the board with this MAC (from the identification step)")
    ap.add_argument("--esptool", default=f"{shlex.quote(sys.executable)} -m esptool")
    ap.add_argument("--espefuse", default=f"{shlex.quote(sys.executable)} -m espefuse")
    ap.add_argument("--dry-run", action="store_true", help="validate the package offline and stop (no serial port needed)")
    a = ap.parse_args(argv)
    try:
        sums = a.sums or next((p for p in (os.path.join(a.package, "..", "SHA256SUMS.txt"), os.path.join(a.package, "SHA256SUMS.txt")) if os.path.isfile(p)), "")
        plan = validate_package(a.package, sums)
        say("package: checksums, layout, partition table and write regions validated")
        for off, p in plan["writes"]:
            say(f"  0x{off:06x}  {os.path.basename(p)}  ({os.path.getsize(p)} bytes)")
        if a.dry_run:
            return 0
        if not a.port:
            raise Stop("--port is required")
        work = os.path.abspath(a.workdir)
        os.makedirs(work, mode=0o700, exist_ok=True)
        os.chmod(work, 0o700)
        for stale in os.listdir(work):                                     # old evidence must never satisfy a new run
            if stale.startswith("step-") or stale in ("identification.json", PF.MANIFEST_NAME):
                os.remove(os.path.join(work, stale))
        r = Runner(shlex.split(a.esptool), shlex.split(a.espefuse), a.port, work)

        # 2. identification (read-only; each esptool command resets the board into its bootloader)
        r.es("chip_id", "chip-id", no_stub=True)
        r.es("flash_id", "flash-id", no_stub=True)
        r.es("read_mac", "read-mac", no_stub=True)
        r.step("efuse_summary", r.espefuse + ["--chip", "esp32"] + r.base() + ["summary", "--format", "json", "--file", os.path.join(work, "step-efuse_summary.json")])
        res = CI.evaluate(work)
        CI.write_evidence(work, res)
        if not res.passed:
            raise Stop("identification: " + "; ".join(f"[{c}] {m}" for c, m in res.stops))
        ident = res.data
        say(f"identified: {ident['chip']}, flash {ident['flash_label']}, MAC {ident['mac']}")
        # 3. capacity
        if ident["flash_bytes"] < plan["end"]:
            raise Stop(f"flash is {ident['flash_bytes']} bytes but the package needs {plan['end']}")

        # 4. backup, verified against the connected board
        r.es("backup_mac", "read-mac", no_stub=True)
        ok, why = CI.same_board(work, os.path.join(work, "step-backup_mac.txt"))
        if not ok:
            raise Stop(why)
        bk = os.path.join(work, PF.BACKUP_NAME)
        if a.backup:
            if not os.path.isfile(a.backup):
                raise Stop("the supplied backup file does not exist")
            if os.path.getsize(a.backup) != ident["flash_bytes"]:
                raise Stop(f"the supplied backup is {os.path.getsize(a.backup)} bytes, the board's flash is {ident['flash_bytes']}")
            if os.path.exists(bk):
                raise Stop("a backup already exists in the work folder; use a new --workdir (refusing to overwrite it)")
            fd = os.open(bk, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "wb") as dst, open(a.backup, "rb") as src:
                shutil.copyfileobj(src, dst)
            with open(os.path.join(work, "step-backup_read.txt"), "w") as fh:
                fh.write("existing backup supplied; its contents are compared with the board in step backup_verify\n")
            with open(os.path.join(work, "step-backup_read.rc"), "w") as fh:
                fh.write("0")
        else:
            if os.path.exists(bk):
                raise Stop("a backup already exists in the work folder; refusing to overwrite it")
            old = os.umask(0o077)
            try:
                r.es("backup_read", "read-flash", "0x0", f"0x{ident['flash_bytes']:X}", bk)
            finally:
                os.umask(old)
        os.chmod(bk, 0o600)
        with contextlib.redirect_stdout(io.StringIO()):
            mrc = BM.main(["--file", bk, "--expected-bytes", hex(ident["flash_bytes"]), "--mac", ident["mac"].replace(":", ""), "--out", os.path.join(work, PF.MANIFEST_NAME)])
        if mrc != 0:
            raise Stop("backup file checks failed (size, blank read or permissions)")
        r.es("backup_verify", "verify-flash", "0x0", bk)          # byte-for-byte comparison with the connected board
        problems = PF.backup_evidence(work, PF.load_json(os.path.join(work, "identification.json")))
        if problems:
            raise Stop("backup evidence incomplete: " + "; ".join(problems))
        say(f"backup verified against the board: {bk}  (keep it private and offline)")

        # 5. owner authorization, same-board check, write, verify
        if not a.confirm_write:
            say(f"All gates passed. NOTHING was written. To write, rerun with:  --confirm-write {ident['mac']}")
            return 3
        if a.confirm_write.strip().lower() != ident["mac"]:
            raise Stop(f"--confirm-write {a.confirm_write} is not the identified board's MAC {ident['mac']}")
        r.es("preflash_mac", "read-mac", no_stub=True)
        ok, why = CI.same_board(work, os.path.join(work, "step-preflash_mac.txt"))
        if not ok:
            raise Stop(why)
        fs = plan["settings"]
        pairs = [x for off, p in plan["writes"] for x in (f"0x{off:x}", p)]
        flags = ["--flash-mode", fs["flash_mode"], "--flash-freq", fs["flash_freq"], "--flash-size", "detect"]
        r.step("flash_write", r.esptool + ["--chip", "esp32"] + r.base() + ["write-flash"] + flags + pairs)
        r.step("flash_verify", r.esptool + ["--chip", "esp32"] + r.base() + ["verify-flash"] + flags + pairs)
        say("written and verified. Unplug and replug the board.")
        return 0
    except Stop as e:
        say(f"STOP: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(run(sys.argv[1:]))
