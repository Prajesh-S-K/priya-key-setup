#!/usr/bin/env python3
"""Print (never run) the gated board sequence, one stage at a time.

  --stage identify   identification only (default). Chip, flash size, MAC and read-only security inspection.
  --stage backup     full-flash backup + comparison with the board. Printed only if identification PASSED.
  --stage flash      the final flash action. Printed only if identification PASSED, a full-size backup exists and
                     verifies, the manifest is clean, the same board is still connected, and the backup was compared
                     with the board. Otherwise the stage is WITHHELD and nothing is printed that could flash.

Flash addresses and files come from firmware/m1-echo/build/flasher_args.json. Backup size comes from the saved
flash-id output via identification.json. This tool imports no serial library and executes nothing.
Exit status: 0 printed, 3 withheld.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.path.join(ROOT, "firmware", "m1-echo", "build")
BACKUP_BAUD = 115200
BACKUP_NAME = "flash-backup-full.bin"
MANIFEST_NAME = "flash-backup-full.manifest.json"

PREAMBLE = r'''# Proposed sequence. NOTHING HERE HAS BEEN RUN. Run from the project root. Review before executing.
# Every command that opens $PORT toggles DTR/RTS and resets the board into the ROM bootloader.
set -euo pipefail
export PORT={port}
export ESPTOOL="$HOME/.espressif/tools/python/v6.1/venv/bin/esptool"
export ESPEFUSE="$HOME/.espressif/tools/python/v6.1/venv/bin/espefuse"
export BK=hardware/backup            # mode 700, git-ignored, never shared
umask 077                            # files created below are owner-only
test -d "$BK" || {{ echo "STOP: $BK missing"; exit 1; }}

# run_step NAME COMMAND...  Runs one command WITHOUT a pipe, so the exit status is the command's own. Saves its output
# and exit code under $BK, prints the output, and stops the whole sequence on any failure. No retries, no overrides.
run_step() {{
  local name="$1"; shift
  local rc=0
  echo "== $name"
  "$@" >"$BK/step-$name.txt" 2>&1 || rc=$?
  echo "$rc" >"$BK/step-$name.rc"
  cat "$BK/step-$name.txt"
  if [ "$rc" -ne 0 ]; then
    echo "STOP: step '$name' failed with exit code $rc. Nothing further runs." >&2
    exit "$rc"
  fi
}}
'''


def load_json(path):
    try:
        with open(path) as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_rc(path):
    try:
        with open(path) as fh:
            return int(fh.read().strip())
    except (OSError, ValueError):
        return None


def identification(bk):
    ev = load_json(os.path.join(bk, "identification.json"))
    if not ev or ev.get("verdict") != "PASS":
        return None, ["identification has not passed (identification.json missing or verdict is not PASS)"]
    return ev, []


def backup_evidence(bk, ident):
    """Reasons the final flash action must be withheld. Empty list = evidence is complete."""
    why = []
    man = load_json(os.path.join(bk, MANIFEST_NAME))
    path = os.path.join(bk, BACKUP_NAME)
    if not os.path.exists(path):
        why.append(f"backup file {BACKUP_NAME} does not exist")
    if man is None:
        why.append(f"{MANIFEST_NAME} is missing or unreadable")
    if os.path.exists(path) and man is not None:
        size = os.path.getsize(path)
        if size != ident["flash_bytes"]:
            why.append(f"backup is {size} bytes, flash is {ident['flash_bytes']} bytes (not a full-size backup)")
        if man.get("bytes") != size or man.get("problems"):
            why.append(f"manifest reports problems or a different size: {man.get('problems')}")
        elif sha256_of(path) != man.get("sha256"):
            why.append("backup SHA-256 differs from the manifest (file changed after verification)")
    for step, label in (("backup_read", "backup read"), ("backup_verify", "comparison of the backup with the board")):
        rc = read_rc(os.path.join(bk, f"step-{step}.rc"))
        if rc != 0:
            why.append(f"{label} did not succeed (exit code record: {rc})")
    return why


def stage_identify(a):
    print(PREAMBLE.format(port=a.port))
    print("# ---- IDENTIFICATION ONLY (reads; resets the board; no flash or eFuse writes). Stops on the first failure.")
    base = "--port $PORT --baud 115200 --before default-reset --after hard-reset"
    print(f'run_step chip_id   "$ESPTOOL" {base} --no-stub chip-id')
    print(f'run_step flash_id  "$ESPTOOL" {base} --no-stub flash-id')
    print(f'run_step read_mac  "$ESPTOOL" {base} --no-stub read-mac')
    print("# Read-only security inspection. Only the 'summary' subcommand of espefuse is used; no burn, protect or")
    print("# --do-not-confirm option appears anywhere in this sequence. (esptool's get-security-info is not used:")
    print("# its source says the classic ESP32 does not support it.)")
    print(f'run_step efuse_summary "$ESPEFUSE" --chip esp32 {base} summary --format json --file "$BK/step-efuse_summary.json"')
    print()
    print("# Decide. Exit status 1 = STOP. There is no override. The next stages are not printed unless this passes.")
    print('python3 tools/check_identification.py --dir "$BK"')
    print('echo "Identification PASSED. Nothing else has run. Request the backup stage with:"')
    print('echo "  python3 tools/plan_flash.py --stage backup"')
    print()
    print("# STOP conditions evaluated by check_identification.py (any one ends the sequence):")
    print("#   a step exits non-zero, its output is empty, or it contains a fatal/traceback/connection error")
    print("#   the chip is not a classic ESP32, or the chip reports Secure Download Mode")
    print("#   flash size is not reported or is outside 1-16 MB")
    print("#   secure boot enabled (ABS_DONE_0 / ABS_DONE_1)")
    print("#   flash encryption enabled, or FLASH_CRYPT_CNT non-zero")
    print("#   restricted download mode (UART_DOWNLOAD_DIS, DISABLE_DL_ENCRYPT/DECRYPT/CACHE)")
    print("#   JTAG already permanently disabled, or read-protected eFuse blocks (RD_DIS non-zero)")
    print("#   any required eFuse missing, unreadable or unparseable (= unknown security status)")
    print("#   the MAC from read-mac differs from the eFuse MAC (board changed mid-sequence)")
    return 0


def withheld(why):
    print("STAGE WITHHELD. Nothing is printed that could write the board.")
    for w in why:
        print(f"  - {w}")
    return 3


def stage_backup(a):
    ident, why = identification(a.dir)
    if why:
        return withheld(why)
    nbytes, label = ident["flash_bytes"], ident["flash_label"]
    print(PREAMBLE.format(port=a.port))
    print(f"# ---- BACKUP of the identified board: MAC {ident['mac']}, flash {label} = {nbytes} bytes = 0x{nbytes:X}"
          " (from step-flash_id.txt)")
    print("# Never overwrite an existing backup.")
    print(f'test ! -e "$BK/{BACKUP_NAME}" || {{ echo "STOP: backup already exists"; exit 1; }}')
    base = "--port $PORT --baud 115200 --before default-reset --after hard-reset"
    print("# Same-board check: the connected board must be the one that was identified.")
    print(f'run_step backup_mac "$ESPTOOL" {base} --no-stub read-mac')
    print('python3 tools/check_identification.py --dir "$BK" --same-board "$BK/step-backup_mac.txt"')
    mins = round(nbytes * 10 / BACKUP_BAUD / 60, 1)
    print(f"# Full-flash read at {BACKUP_BAUD} baud (about {mins} minutes of line time). 460800 was tried on this board and failed with serial noise (CH340), so 115200 is used. The flasher stub is loaded into RAM only.")
    print(f'run_step backup_read "$ESPTOOL" --port $PORT --baud {BACKUP_BAUD} --before default-reset --after hard-reset '
          f'read-flash 0x0 0x{nbytes:X} "$BK/{BACKUP_NAME}"')
    print(f'chmod 600 "$BK/{BACKUP_NAME}"')
    print("# Local checks: exact size, not blank, SHA-256, owner-only permissions. Exit 1 = STOP.")
    print(f'python3 tools/backup_manifest.py --file "$BK/{BACKUP_NAME}" --expected-bytes 0x{nbytes:X} '
          f'--mac {ident["mac"].replace(":", "")} --out "$BK/{MANIFEST_NAME}"')
    print("# Compare the backup with the board (a mismatch is a non-zero exit and stops the sequence).")
    print(f'run_step backup_verify "$ESPTOOL" --port $PORT --baud {BACKUP_BAUD} --before default-reset --after hard-reset '
          f'verify-flash 0x0 "$BK/{BACKUP_NAME}"')
    print('echo "Backup verified against the board. Nothing has been written. Request the flash stage with:"')
    print('echo "  python3 tools/plan_flash.py --stage flash"')
    print("# Keep the backup offline. It may contain secrets from the board's previous firmware. Never commit or share it.")
    return 0


def stage_flash(a):
    ident, why = identification(a.dir)
    if not why:
        why = backup_evidence(a.dir, ident)
    if why:
        return withheld(why)
    meta = load_json(os.path.join(a.build_dir, "flasher_args.json"))
    if meta is None:
        return withheld(["firmware/m1-echo/build/flasher_args.json is missing: build the firmware first"])
    files, st, extra = meta["flash_files"], meta["flash_settings"], meta["extra_esptool_args"]
    rel = os.path.relpath(a.build_dir, ROOT)
    pairs = " ".join(f"{addr} {rel}/{f}" for addr, f in files.items())
    flags = f"--flash-mode {st['flash_mode']} --flash-freq {st['flash_freq']} --flash-size detect"
    print(PREAMBLE.format(port=a.port))
    print(f"# ---- FLASH. Identified board MAC {ident['mac']}; full backup of {ident['flash_bytes']} bytes verified against it.")
    print("# WRITES flash: bootloader, partition table, application. Destroys the existing ones. Needs its own approval.")
    for addr, f in files.items():
        print(f"#   {addr:8s} {f}")
    print('python3 tools/plan_flash.py --stage flash >/dev/null || { echo "STOP: evidence no longer complete"; exit 3; }')
    base = "--port $PORT --baud 115200 --before default-reset --after hard-reset"
    print("# Same-board check immediately before writing.")
    print(f'run_step preflash_mac "$ESPTOOL" {base} --no-stub read-mac')
    print('python3 tools/check_identification.py --dir "$BK" --same-board "$BK/step-preflash_mac.txt"')
    print(f'run_step flash_write "$ESPTOOL" --chip {extra["chip"]} {base} write-flash {flags} {pairs}')
    print(f'run_step flash_verify "$ESPTOOL" --chip {extra["chip"]} {base} verify-flash {flags} {pairs}')
    print("# No --erase-all. No eFuse, secure-boot or flash-encryption change.")
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--stage", choices=["identify", "backup", "flash"], default="identify")
    ap.add_argument("--dir", default=os.path.join(ROOT, "hardware", "backup"))
    ap.add_argument("--port", default="/dev/cu.usbserial-10")
    ap.add_argument("--build-dir", default=BUILD)
    a = ap.parse_args()
    return {"identify": stage_identify, "backup": stage_backup, "flash": stage_flash}[a.stage](a)


if __name__ == "__main__":
    sys.exit(main())
