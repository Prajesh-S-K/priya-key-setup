package com.giftkey.app

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

private fun sha(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }
private fun data(n: Int, seed: Int = 1) = ByteArray(n) { ((it * 31 + seed) and 0xff).toByte() }

/** In-memory vault. Failure switches simulate the defects found in review. */
class FakeVault(val files: MutableMap<String, ByteArray> = HashMap(), val dirs: MutableSet<String> = mutableSetOf("")) : VaultFiles {
    var eofAt: Long = -1            // read returns 0 at/after this offset (premature EOF)
    var failList: String? = null    // list(dir) returns null for this dir
    var sizeLies = false            // size(h) reports a different size
    var extraNames: List<VEntry> = emptyList()
    private val handles = HashMap<Long, String>()
    private val writing = HashMap<Long, ByteArrayOutputStream>()
    private var next = 1L
    override fun list(dir: String): List<VEntry>? {
        if (dir == failList) return null
        val out = ArrayList<VEntry>()
        for (d in dirs) if (d.isNotEmpty() && d.substringBeforeLast('/', "") == dir) out.add(VEntry(d.substringAfterLast('/'), true, 0))
        for ((p, v) in files) if (p.substringBeforeLast('/', "") == dir) out.add(VEntry(p.substringAfterLast('/'), false, v.size.toLong()))
        if (dir == "") out.addAll(extraNames)
        return out
    }
    override fun open(path: String, flags: Int): Long { val h = next++; handles[h] = path; if (flags and 1 != 0) writing[h] = ByteArrayOutputStream(); return h }
    override fun read(h: Long, off: Long, buf: ByteArray, len: Int): Int {
        val d = files[handles[h]] ?: return -2
        if (eofAt in 0..off) return 0
        val n = minOf(len.toLong(), d.size - off).toInt().coerceAtLeast(0)
        val lim = if (eofAt >= 0) minOf(n.toLong(), eofAt - off).toInt().coerceAtLeast(0) else n
        System.arraycopy(d, off.toInt(), buf, 0, lim)
        return lim
    }
    override fun write(h: Long, off: Long, buf: ByteArray, len: Int): Int { writing[h]!!.write(buf, 0, len); return len }
    override fun flush(h: Long): Long { writing[h]?.let { files[handles[h]!!] = it.toByteArray() }; return 0 }
    override fun close(h: Long): Long { handles.remove(h); writing.remove(h); return 0 }
    override fun size(h: Long): Long = (files[handles[h]]?.size ?: 0).toLong() + if (sizeLies) 1 else 0
    override fun mkdir(path: String): Long { dirs.add(path); return 0 }
    override fun verify(path: String, size: Long, sha256: String): Long = if (files[path]?.let { it.size.toLong() == size && sha(it) == sha256 } == true) 1 else 0
}

/** Folder tree whose contents come from maps. `declared` overrides the size a provider reports for a document. */
class MemSource(val dirs: Map<String, List<DocEntry>?>, val blobs: Map<String, ByteArray>, val short: Set<String> = emptySet()) : SourceTree {
    override val rootId = "root"
    override fun list(dirId: String) = dirs[dirId]
    override fun open(id: String): InputStream? = blobs[id]?.let { ByteArrayInputStream(if (id in short) it.copyOf(it.size / 2) else it) }
}

class MemSink(val corrupt: Boolean = false, val truncate: Boolean = false, val rename: Boolean = false) : SinkTree {
    override val rootId = "root"
    val tree = HashMap<String, ByteArray>()
    val created = ArrayList<String>()
    private val names = HashMap<String, String>()
    override fun mkdir(parentId: String, name: String): String? { created.add("$parentId/$name"); return "$parentId/$name" }
    override fun create(parentId: String, name: String): String? { if (rename) return null; val id = "$parentId/$name"; created.add(id); tree[id] = ByteArray(0); return id }
    override fun openOut(id: String): OutputStream = object : ByteArrayOutputStream() {
        override fun close() { super.close(); var b = toByteArray(); if (truncate) b = b.copyOf(b.size - 1); if (corrupt && b.isNotEmpty()) b[0] = (b[0] + 1).toByte(); tree[id] = b }
    }
    override fun openIn(id: String): InputStream? = tree[id]?.let { ByteArrayInputStream(it) }
}

private fun e(id: String, name: String, size: Long, dir: Boolean = false) = DocEntry(id, name, dir, size)

class EnginesTest {
    @get:Rule val tmp = TemporaryFolder()

    // ---------------------------------------------------------------- restore (review item 1)
    private fun vaultWith(vararg f: Pair<String, ByteArray>) = FakeVault(f.toMap().toMutableMap())

    @Test fun restoreHappyPathVerifiesAndMarksTrueOnce() {
        val v = vaultWith("a.bin" to data(200_000), "d/b.txt" to data(10)).also { it.dirs.add("d") }
        val marks = ArrayList<Boolean>(); val sink = MemSink()
        val r = RestoreEngine(v, { marks.add(it) }, chunk = 4096).run(sink)
        assertTrue(r.errors.toString(), r.verified)
        assertEquals(listOf(true), marks)
        assertArrayEquals(data(200_000), sink.tree["root/a.bin"])
        assertArrayEquals(data(10), sink.tree["root/d/b.txt"])
    }

    @Test fun prematureEofIsAnErrorAndNeverMarkedRestored() {
        val v = vaultWith("big.bin" to data(100_000)); v.eofAt = 50_000
        val marks = ArrayList<Boolean>(); val sink = MemSink()
        val r = RestoreEngine(v, { marks.add(it) }, chunk = 4096).run(sink)
        assertFalse(r.verified)
        assertTrue(r.errors.joinToString(), r.errors.any { "premature end" in it })
        assertEquals(listOf(false), marks)
        assertTrue("incomplete file must not be reported as a restored file", r.files.isEmpty())
    }

    @Test fun shortDestinationWriteIsDetected() {
        val v = vaultWith("a.bin" to data(5000)); val marks = ArrayList<Boolean>()
        val r = RestoreEngine(v, { marks.add(it) }).run(MemSink(truncate = true))
        assertFalse(r.verified); assertEquals(listOf(false), marks)
    }

    @Test fun corruptedDestinationIsDetected() {
        val v = vaultWith("a.bin" to data(5000)); val marks = ArrayList<Boolean>()
        val r = RestoreEngine(v, { marks.add(it) }).run(MemSink(corrupt = true))
        assertFalse(r.verified); assertEquals(listOf(false), marks)
    }

    @Test fun failedDirectoryListingIsNotAnEmptyFolder() {
        val v = vaultWith("d/x" to data(3), "top" to data(3)); v.dirs.add("d"); v.failList = "d"
        val marks = ArrayList<Boolean>()
        val r = RestoreEngine(v, { marks.add(it) }).run(MemSink())
        assertFalse(r.verified); assertEquals(listOf(false), marks)
        assertTrue(r.errors.any { "cannot list" in it })
    }

    @Test fun failedTopLevelListingIsAnError() {
        val v = vaultWith("a" to data(1)); v.failList = ""
        val marks = ArrayList<Boolean>()
        assertFalse(RestoreEngine(v, { marks.add(it) }).run(MemSink()).verified); assertEquals(listOf(false), marks)
    }

    @Test fun vaultFileChangingDuringCopyIsDetected() {
        val v = vaultWith("a.bin" to data(5000)); v.sizeLies = true
        val marks = ArrayList<Boolean>()
        assertFalse(RestoreEngine(v, { marks.add(it) }).run(MemSink()).verified); assertEquals(listOf(false), marks)
    }

    @Test fun providerRenamingToAvoidAConflictIsAnError() {
        val v = vaultWith("a.bin" to data(10)); val marks = ArrayList<Boolean>()
        val r = RestoreEngine(v, { marks.add(it) }).run(MemSink(rename = true))
        assertFalse(r.verified); assertEquals(listOf(false), marks)
    }

    @Test fun restoreRefusesHostileVaultNamesAndCreatesNothingForThem() {
        val v = vaultWith("ok.txt" to data(4)); v.extraNames = listOf(VEntry("../evil", false, 3), VEntry("a/b", false, 3), VEntry("..", true, 0))
        val marks = ArrayList<Boolean>(); val sink = MemSink()
        val r = RestoreEngine(v, { marks.add(it) }).run(sink)
        assertFalse(r.verified); assertEquals(listOf(false), marks)
        assertEquals(listOf("root/ok.txt"), sink.created)
        assertEquals(3, r.errors.count { "refused" in it })
    }

    // ---------------------------------------------------------------- import (names + exact reads)
    private fun src(vararg children: DocEntry, blobs: Map<String, ByteArray>, extra: Map<String, List<DocEntry>?> = emptyMap(), short: Set<String> = emptySet()) =
        MemSource(mapOf("root" to children.toList()) + extra, blobs, short)

    @Test fun importHappyPath() {
        val v = FakeVault()
        val s = src(e("f1", "a.txt", 5), e("d1", "sub", 0, true), blobs = mapOf("f1" to data(5), "f2" to data(70_000)), extra = mapOf("d1" to listOf(e("f2", "b.bin", 70_000))))
        val r = ImportEngine(v, chunk = 1000).run(s)
        assertTrue(r.errors.toString(), r.verified)
        assertArrayEquals(data(70_000), v.files["sub/b.bin"])
    }

    @Test fun importRefusesHostileSourceNamesAndNeverVerifies() {
        for (bad in listOf("../x", "a/b", "..", ".", "", "/abs", "C:\\x", "x\\y", "nul\u0000x")) {
            val v = FakeVault()
            val s = src(e("f1", bad, 3), blobs = mapOf("f1" to data(3)))
            val r = ImportEngine(v).run(s)
            assertFalse("'$bad' must not verify", r.verified)
            assertTrue("'$bad' must be refused", r.errors.any { "refused" in it })
            assertTrue("'$bad' must not reach the vault", v.files.isEmpty())
        }
    }

    @Test fun importDetectsIncompleteReadAndDuplicatesAndListingFailure() {
        val v1 = FakeVault()
        assertFalse(ImportEngine(v1).run(src(e("f1", "a", 10), blobs = mapOf("f1" to data(10)), short = setOf("f1"))).verified)
        val v2 = FakeVault()
        val dup = ImportEngine(v2).run(src(e("f1", "a", 3), e("f2", "a", 3), blobs = mapOf("f1" to data(3), "f2" to data(3, 2))))
        assertFalse(dup.verified); assertTrue(dup.errors.any { "duplicate" in it })
        val v3 = FakeVault()
        val r3 = ImportEngine(v3).run(src(e("d1", "sub", 0, true), blobs = emptyMap(), extra = mapOf("d1" to null)))
        assertFalse(r3.verified); assertTrue(r3.errors.any { "cannot list" in it })
        assertFalse(ImportEngine(FakeVault()).run(MemSource(mapOf("root" to null), emptyMap())).verified)
    }

    // ---------------------------------------------------------------- encrypted-folder import (review item 2)
    private fun vaultTree(vararg names: String, size: Int = 50): MemSource {
        val list = names.mapIndexed { i, n -> e("id$i", n, size.toLong()) }
        return MemSource(mapOf("root" to list), names.indices.associate { "id$it" to data(size, it) })
    }

    @Test fun encryptedCopyHappyPath() {
        val dest = File(tmp.root, "staging/x.gpv")
        assertNull(EncryptedCopy.run(vaultTree("vault.hdr.A", "vault.hdr.B", "journal-000000.log", "data-000000.seg"), dest, 16).also { /* error text */ })
        assertEquals(setOf("vault.hdr.A", "vault.hdr.B", "journal-000000.log", "data-000000.seg"), dest.list()!!.toSet())
        assertArrayEquals(data(50, 2), File(dest, "journal-000000.log").readBytes())
    }

    @Test fun hostileNamesCreateOrChangeNothingOutsideStaging() {
        for (bad in listOf("../evil", "..", ".", "a/b", "/etc/passwd", "C:\\win", "x\\y", "", "vault.hdr.A/../../evil", "..\\..\\evil")) {
            val sandbox = tmp.newFolder()
            val sentinel = File(sandbox, "outside.txt").also { it.writeText("keep") }
            val victim = File(sandbox, "evil").also { it.writeText("original") }
            val before = sandbox.list()!!.toSet()
            val stagingParent = File(sandbox, "vaults").also { it.mkdirs() }
            val dest = File(stagingParent, "x.gpv")
            val r = EncryptedCopy.run(vaultTree("vault.hdr.A", bad), dest, 16)
            assertNotNull("'$bad' must be refused", r)
            assertFalse("staging must not exist after a refusal: '$bad'", dest.exists())
            assertEquals("'$bad' changed the sandbox", before + "vaults", sandbox.list()!!.toSet() + if ("vaults" in before) emptySet() else emptySet())
            assertEquals("keep", sentinel.readText()); assertEquals("original", victim.readText())
            assertTrue(stagingParent.list()!!.isEmpty())
        }
    }

    @Test fun encryptedCopyRejectsDuplicatesFoldersUnexpectedEntriesAndBadListings() {
        val d = File(tmp.root, "s1/x.gpv")
        assertNotNull(EncryptedCopy.run(vaultTree("vault.hdr.A", "vault.hdr.A"), d)); assertFalse(d.exists())
        val withDir = MemSource(mapOf("root" to listOf(e("a", "vault.hdr.A", 5), e("b", "sub", 0, true))), mapOf("a" to data(5)))
        assertNotNull(EncryptedCopy.run(withDir, File(tmp.root, "s2/x.gpv")))
        assertNotNull(EncryptedCopy.run(vaultTree("vault.hdr.A", "notes.txt"), File(tmp.root, "s3/x.gpv")))
        assertNotNull(EncryptedCopy.run(vaultTree("journal-000000.log"), File(tmp.root, "s4/x.gpv")))     // no header: not a vault
        assertNotNull(EncryptedCopy.run(MemSource(mapOf("root" to null), emptyMap()), File(tmp.root, "s5/x.gpv")))
        assertNotNull(EncryptedCopy.run(MemSource(mapOf("root" to emptyList()), emptyMap()), File(tmp.root, "s6/x.gpv")))
        for (n in 2..6) assertFalse(File(tmp.root, "s$n/x.gpv").exists())
    }

    @Test fun incompleteEncryptedCopyIsRemoved() {
        val src = MemSource(mapOf("root" to listOf(e("a", "vault.hdr.A", 100))), mapOf("a" to data(100)), short = setOf("a"))
        val dest = File(tmp.root, "s7/x.gpv")
        assertNotNull(EncryptedCopy.run(src, dest)); assertFalse(dest.exists())
    }

    @Test fun existingDestinationIsNeverOverwritten() {
        val dest = tmp.newFolder("exists.gpv"); File(dest, "keep").writeText("x")
        assertNotNull(EncryptedCopy.run(vaultTree("vault.hdr.A"), dest))
        assertEquals("x", File(dest, "keep").readText())
    }

    @Test fun containmentRejectsSymlinkEscapes() {
        val base = tmp.newFolder("base"); val outside = tmp.newFolder("outside")
        java.nio.file.Files.createSymbolicLink(File(base, "link").toPath(), outside.toPath())
        try { Names.contained(base, listOf("link", "f")); fail("escape not detected") } catch (_: IllegalArgumentException) {}
        assertEquals(File(base, "ok"), Names.contained(base, listOf("ok")))
        for (bad in listOf("..", "a/b", "")) try { Names.contained(base, listOf(bad)); fail(bad) } catch (_: IllegalArgumentException) {}
    }
}
