package com.giftkey.app

import com.hoho.android.usbserial.driver.UsbSerialPort

/** Byte pipe handed to the Rust core. `read` returns an empty array when nothing arrived and null once the port is gone. */
class UsbIo(private val port: UsbSerialPort) {
    @Volatile var closed = false
        private set

    fun write(bytes: ByteArray): Boolean {
        if (closed) return false
        return try { port.write(bytes, 2000); true } catch (e: Exception) { closed = true; false }
    }

    fun read(timeoutMs: Int): ByteArray? {
        if (closed) return null
        return try {
            val buf = ByteArray(512)
            val n = port.read(buf, timeoutMs)
            if (n <= 0) ByteArray(0) else buf.copyOf(n)
        } catch (e: Exception) { closed = true; null }
    }

    fun close() {
        closed = true
        try { port.close() } catch (_: Exception) {}
    }
}
