package com.giftkey.app

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber

/** Finds the board (CH340, 1A86:7523), asks for USB permission, opens the serial port and hands it to the core. */
object UsbController {
    private const val ACTION_PERMISSION = "com.giftkey.app.USB_PERMISSION"
    private const val VID = 0x1A86
    private const val PID = 0x7523

    @Volatile private var io: UsbIo? = null
    @Volatile var lastError: String? = null
        private set
    private var registered = false

    fun isConnected(): Boolean = io?.closed == false

    private fun manager(ctx: Context) = ctx.getSystemService(Context.USB_SERVICE) as UsbManager

    fun findDevice(ctx: Context): UsbDevice? = manager(ctx).deviceList.values.firstOrNull { it.vendorId == VID && it.productId == PID }

    /** Called from the activity on attach or start. Opens the port when permission exists, otherwise asks for it. */
    fun connect(ctx: Context, onChange: () -> Unit = {}) {
        val app = ctx.applicationContext
        if (isConnected()) return
        val dev = findDevice(app) ?: run { lastError = null; return }
        val um = manager(app)
        if (!um.hasPermission(dev)) {
            register(app, onChange)
            val pi = PendingIntent.getBroadcast(app, 0, Intent(ACTION_PERMISSION).setPackage(app.packageName), PendingIntent.FLAG_MUTABLE)
            um.requestPermission(dev, pi)
            return
        }
        open(app, dev)
        onChange()
    }

    private fun register(app: Context, onChange: () -> Unit) {
        if (registered) return
        registered = true
        val rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (i.action == ACTION_PERMISSION && i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                    findDevice(c)?.let { open(c, it) }
                    onChange()
                } else if (i.action == ACTION_PERMISSION) {
                    lastError = "USB permission was declined"
                    onChange()
                }
            }
        }
        val f = IntentFilter(ACTION_PERMISSION)
        app.registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED)
    }

    private fun open(app: Context, dev: UsbDevice) {
        try {
            val driver = UsbSerialProber.getDefaultProber().probeDevice(dev) ?: throw IllegalStateException("not a supported serial chip")
            val conn = manager(app).openDevice(dev) ?: throw IllegalStateException("could not open the USB device")
            val port: UsbSerialPort = driver.ports[0]
            port.open(conn)
            port.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            // Leave the auto-reset lines released so opening the port does not reset the board.
            try { port.dtr = false; port.rts = false } catch (_: Exception) {}
            val u = UsbIo(port)
            io = u
            Native.attach(u)
            lastError = null
        } catch (e: Exception) {
            lastError = "Could not open the board: ${e.message}"
        }
    }

    fun disconnect() {
        io?.close()
        io = null
        Native.detach()
    }

    /** True when the port died underneath us (cable pulled before the detach broadcast). */
    fun reapIfDead(): Boolean {
        val u = io ?: return false
        if (u.closed) { disconnect(); return true }
        return false
    }
}
