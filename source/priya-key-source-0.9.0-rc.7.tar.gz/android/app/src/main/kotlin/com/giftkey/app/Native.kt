package com.giftkey.app

/** JNI surface of the Rust core (host/android-core). Negative return values are error codes (see core.rs `code`). */
object Native {
    init { System.loadLibrary("gpandroid") }

    const val OPEN_WRITE = 1
    const val OPEN_CREATE = 2
    const val OPEN_TRUNCATE = 4
    const val OPEN_CREATE_NEW = 8

    @JvmStatic external fun init(home: String): Boolean
    @JvmStatic external fun attach(io: Any): Boolean
    @JvmStatic external fun detach()
    @JvmStatic external fun request(json: String): String
    @JvmStatic external fun tick()
    @JvmStatic external fun unlocked(): String
    @JvmStatic external fun isDiscreet(): Boolean
    @JvmStatic external fun dashboard(bundled: String): String
    @JvmStatic external fun vOpen(id: String, path: String, flags: Int): Long
    @JvmStatic external fun vRead(id: String, h: Long, off: Long, buf: ByteArray, len: Int): Int
    @JvmStatic external fun vWrite(id: String, h: Long, off: Long, buf: ByteArray, len: Int): Int
    @JvmStatic external fun vSize(id: String, h: Long): Long
    @JvmStatic external fun vSetLen(id: String, h: Long, len: Long): Long
    @JvmStatic external fun vFlush(id: String, h: Long): Long
    @JvmStatic external fun vClose(id: String, h: Long): Long
    @JvmStatic external fun vMkdir(id: String, path: String): Long
    @JvmStatic external fun vDelete(id: String, path: String): Long
    @JvmStatic external fun vRename(id: String, from: String, to: String): Long
    @JvmStatic external fun vStat(id: String, path: String): String
    @JvmStatic external fun vList(id: String, dir: String): String
    @JvmStatic external fun vVerify(id: String, path: String, size: Long, sha256: String): Long
}
