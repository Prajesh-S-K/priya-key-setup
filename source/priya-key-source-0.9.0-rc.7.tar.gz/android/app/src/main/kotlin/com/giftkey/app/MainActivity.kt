package com.giftkey.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CompletableFuture
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var transfer: Transfer
    private val pool = Executors.newCachedThreadPool()
    private var folderResult: CompletableFuture<String?>? = null
    // Discreet mode: the service tells the activity to go away when the key is unplugged (everything is already locked).
    private val concealReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: android.content.Context, i: Intent) { finishAndRemoveTask() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Native.init(GiftDocumentsProvider.coreHome(this))
        transfer = Transfer(this)
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        web = WebView(this)
        web.settings.apply {
            javaScriptEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_NO_CACHE
        }
        web.addJavascriptInterface(Bridge(), "GiftNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest) = true // no navigation
        }
        web.webChromeClient = WebChromeClient()
        setContentView(web)
        val bundled = assets.open("index.html").bufferedReader().use { it.readText() }
        val page = Native.dashboard(bundled)   // verified cached board image if present, otherwise the bundled page
        web.loadDataWithBaseURL("https://appassets.invalid/", page.replaceFirst("<head>", "<head><script>$BRIDGE_JS</script>"), "text/html", "utf-8", null)
        registerConcealReceiver()
        handleUsb(intent)
    }

    private fun registerConcealReceiver() {
        registerReceiver(concealReceiver, android.content.IntentFilter(KeyService.ACTION_CONCEAL), android.content.Context.RECEIVER_NOT_EXPORTED)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleUsb(intent)
    }

    override fun onResume() {
        super.onResume()
        handleUsb(null)
    }

    private fun handleUsb(i: Intent?) {
        if (i == null || i.action == UsbManager.ACTION_USB_DEVICE_ATTACHED || UsbController.findDevice(this) != null) {
            UsbController.connect(this) { if (UsbController.isConnected()) KeyService.start(this) }
            if (UsbController.isConnected()) KeyService.start(this)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_TREE) {
            val u: Uri? = if (resultCode == RESULT_OK) data?.data else null
            folderResult?.complete(u?.toString())
        }
    }

    private fun pickTree(): String? {
        val f = CompletableFuture<String?>()
        folderResult = f
        runOnUiThread {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION), REQ_TREE)
        }
        return f.get()
    }

    private fun ask(build: (CompletableFuture<String?>) -> Unit): String? {
        val f = CompletableFuture<String?>()
        runOnUiThread { build(f) }
        return f.get()
    }

    private fun native(name: String, body: String): String {
        val a = JSONObject(body.ifEmpty { "{}" })
        val title = a.optString("title")
        return when (name) {
            "pick_folder" -> when {
                // The encrypted copy always lives in the app's private storage on Android.
                title.startsWith("Where to keep") -> JSONObject.quote(GiftDocumentsProvider.vaultsDir(this))
                else -> pickTree()?.let { JSONObject.quote(it) } ?: "null"
            }
            "confirm" -> {
                val r = ask { f ->
                    AlertDialog.Builder(this).setTitle(title).setMessage(a.optString("text"))
                        .setPositiveButton(a.optString("ok", "OK")) { _, _ -> f.complete("true") }
                        .setNegativeButton("Cancel") { _, _ -> f.complete("false") }
                        .setOnCancelListener { f.complete("false") }.show()
                }
                r ?: "false"
            }
            "prompt" -> {
                val r = ask { f ->
                    val e = EditText(this).apply { setText(a.optString("value")) }
                    AlertDialog.Builder(this).setTitle(title).setView(e)
                        .setPositiveButton("OK") { _, _ -> f.complete(e.text.toString()) }
                        .setNegativeButton("Cancel") { _, _ -> f.complete(null) }
                        .setOnCancelListener { f.complete(null) }.show()
                }
                if (r == null) "null" else JSONObject.quote(r)
            }
            "capabilities" -> """{"platform":"android","backup":true,"open_path":true,"battery":true,"discreet":true}"""
            "setup_status" -> setupStatus()
            "setup_action" -> { setupAction(a.optString("action")); "null" }
            "open_battery_settings" -> { setupAction("battery"); "null" }
            "open_path" -> {
                // Open the system file picker at the unlocked folders (they appear as roots there).
                runOnUiThread { try { startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")) } catch (_: Exception) {} }
                "null"
            }
            else -> "null"
        }
    }

    private fun setupStatus(): String {
        val arr = org.json.JSONArray()
        fun item(id: String, label: String, ok: Boolean, detail: String, action: String? = null, actionLabel: String? = null) {
            arr.put(JSONObject().put("id", id).put("label", label).put("ok", ok).put("detail", detail).also { if (action != null) it.put("action", action).put("action_label", actionLabel) })
        }
        val host = packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)
        item("host", "This phone supports USB devices", host, if (host) "USB host mode is available." else "Android does not report USB host support, so the key cannot be used with this phone.")
        val dev = UsbController.findDevice(this)
        item("board", "Key plugged in", dev != null, if (dev != null) "The key was found." else "Plug the key in with a USB cable or adapter that carries data (some cables only charge).")
        val um = getSystemService(android.content.Context.USB_SERVICE) as UsbManager
        item("usb", "Permission to use the key", dev != null && um.hasPermission(dev), if (dev == null) "Plug the key in first." else "Android asks once per connection; choose Allow.", "usb", "Ask now")
        val notif = android.os.Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        item("notif", "Notification while the key is connected", notif, "Android requires a visible notice while the key stays connected. It also has a Lock all button.", "notifications", "Allow")
        val pm = getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
        item("battery", "Unrestricted background use", pm.isIgnoringBatteryOptimizations(packageName), "Recommended: otherwise some phones stop the connection when the screen is off, which locks your folders.", "battery", "Open")
        return arr.toString()
    }

    private fun setupAction(a: String) {
        runOnUiThread {
            when (a) {
                "usb" -> UsbController.connect(this) { if (UsbController.isConnected()) KeyService.start(this) }
                "notifications" -> requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                "battery" -> try {
                    startActivity(Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                } catch (_: Exception) {
                    try { startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) {}
                }
            }
        }
    }

    /** API requests, with the operations that need Android's content URIs handled here. */
    private fun api(body: String): String {
        val r = try { JSONObject(body) } catch (_: Exception) { return Native.request(body) }
        return when (r.optString("cmd")) {
            "add_folder" -> {
                val src = r.optString("source", "")
                if (src.startsWith("content://")) transfer.importTree(Uri.parse(src), r.optString("name"), r.optBoolean("hidden"))
                else Native.request(r.put("parent", GiftDocumentsProvider.vaultsDir(this)).toString())
            }
            "restore" -> {
                val d = r.optString("dest", "")
                if (d.startsWith("content://")) transfer.restoreTree(r.getString("id"), Uri.parse(d)) else Native.request(body)
            }
            "delete_originals" -> transfer.deleteOriginals(r.getString("id"))
            "export_vault" -> transfer.exportBackup(r.getString("id"), Uri.parse(r.getString("dest")))
            "restore_backup" -> transfer.restoreOrRecover(Uri.parse(r.getString("src")), "link_vault", null)
            "recover_vault" -> {
                val d = r.optString("dir", "")
                if (d.startsWith("content://")) transfer.restoreOrRecover(Uri.parse(d), "recover_vault", r.optString("code")) else Native.request(body)
            }
            "unlock", "lock", "lock_all" -> Native.request(body).also { GiftDocumentsProvider.notifyRoots(this) }
            else -> Native.request(body)
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun ask(id: Int, kind: String, name: String, body: String) {
            pool.execute {
                val out = try {
                    if (kind == "native") native(name, body) else api(body)
                } catch (e: Throwable) {
                    if (kind == "native") "null" else JSONObject().put("ok", false).put("error", e.message ?: "error").toString()
                }
                runOnUiThread { web.evaluateJavascript("window.__gpResolve($id,${JSONObject.quote(out)})", null) }
            }
        }
    }

    override fun onDestroy() {
        // Leaving the app does not lock: the foreground service keeps the session so other apps can keep saving.
        try { unregisterReceiver(concealReceiver) } catch (_: Exception) {}
        pool.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val REQ_TREE = 7
        private const val BRIDGE_JS = """(function(){let n=0;const w=new Map();
const ask=(k,nm,b)=>new Promise(r=>{const id=++n;w.set(id,r);GiftNative.ask(id,k,nm,b)});
window.__gpBridge=(j)=>ask('api','',j);
window.__gpNative=(nm,j)=>ask('native',nm,j).then(t=>JSON.parse(t));
window.__gpResolve=(id,t)=>{const r=w.get(id);w.delete(id);if(r)r(t)};})();"""
    }
}
