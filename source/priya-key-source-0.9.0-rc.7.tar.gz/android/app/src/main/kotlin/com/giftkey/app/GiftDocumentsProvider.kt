package com.giftkey.app

import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.CancellationSignal
import android.os.Handler
import android.os.HandlerThread
import android.os.ParcelFileDescriptor
import android.os.ProxyFileDescriptorCallback
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import android.provider.DocumentsContract.Root
import android.provider.DocumentsProvider
import android.system.ErrnoException
import android.system.OsConstants
import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import java.io.FileNotFoundException

/**
 * Shows each UNLOCKED protected folder as a root in the system file picker, so other apps can open and save files in it.
 * Content is decrypted on demand by the Rust core; nothing is written to disk in the clear. Locking removes the roots and
 * makes every open file descriptor fail with EIO.
 */
class GiftDocumentsProvider : DocumentsProvider() {
    private val thread = HandlerThread("gk-fd").also { it.start() }
    private val handler by lazy { Handler(thread.looper) }

    override fun onCreate(): Boolean {
        Native.init(coreHome(context!!))
        return true
    }

    private fun split(docId: String): Pair<String, String> {
        val i = docId.indexOf(':')
        if (i < 0) throw FileNotFoundException(docId)
        return docId.substring(0, i) to docId.substring(i + 1)
    }

    private fun docId(id: String, path: String) = "$id:$path"

    private fun unlockedRoots(): JSONArray = JSONArray(Native.unlocked())

    override fun queryRoots(projection: Array<out String>?): Cursor {
        val c = MatrixCursor(projection ?: ROOT_COLUMNS)
        val arr = unlockedRoots()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            c.newRow().apply {
                add(Root.COLUMN_ROOT_ID, o.getString("id"))
                add(Root.COLUMN_DOCUMENT_ID, docId(o.getString("id"), ""))
                add(Root.COLUMN_TITLE, o.getString("name"))
                add(Root.COLUMN_SUMMARY, "Unlocked")
                add(Root.COLUMN_FLAGS, Root.FLAG_SUPPORTS_CREATE or Root.FLAG_LOCAL_ONLY)
                add(Root.COLUMN_ICON, R.drawable.ic_notify)
            }
        }
        return c
    }

    private fun mimeOf(name: String, dir: Boolean): String {
        if (dir) return Document.MIME_TYPE_DIR
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun addRow(c: MatrixCursor, id: String, path: String, name: String, dir: Boolean, size: Long, mtime: Long) {
        var flags = Document.FLAG_SUPPORTS_DELETE or Document.FLAG_SUPPORTS_RENAME
        flags = if (dir) flags or Document.FLAG_DIR_SUPPORTS_CREATE else flags or Document.FLAG_SUPPORTS_WRITE
        c.newRow().apply {
            add(Document.COLUMN_DOCUMENT_ID, docId(id, path))
            add(Document.COLUMN_DISPLAY_NAME, name)
            add(Document.COLUMN_MIME_TYPE, mimeOf(name, dir))
            add(Document.COLUMN_SIZE, if (dir) null else size)
            add(Document.COLUMN_LAST_MODIFIED, mtime * 1000)
            add(Document.COLUMN_FLAGS, flags)
        }
    }

    private fun rootName(id: String): String {
        val arr = unlockedRoots()
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).getString("id") == id) return arr.getJSONObject(i).getString("name")
        throw FileNotFoundException("locked")
    }

    override fun queryDocument(documentId: String, projection: Array<out String>?): Cursor {
        val (id, path) = split(documentId)
        val c = MatrixCursor(projection ?: DOC_COLUMNS)
        if (path.isEmpty()) {
            addRow(c, id, "", rootName(id), true, 0, 0)
            return c
        }
        val st = JSONObject(Native.vStat(id, path))
        if (st.has("err")) throw FileNotFoundException(documentId)
        addRow(c, id, path, st.getString("name"), st.getBoolean("dir"), st.getLong("size"), st.getLong("mtime"))
        return c
    }

    override fun queryChildDocuments(parentDocumentId: String, projection: Array<out String>?, sortOrder: String?): Cursor {
        val (id, dir) = split(parentDocumentId)
        val c = MatrixCursor(projection ?: DOC_COLUMNS)
        val txt = Native.vList(id, dir)
        if (txt.startsWith("{")) throw FileNotFoundException("locked")
        val arr = JSONArray(txt)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val name = o.getString("name")
            if (name == ".gp" && dir.isEmpty()) continue // internal metadata
            addRow(c, id, if (dir.isEmpty()) name else "$dir/$name", name, o.getBoolean("dir"), o.getLong("size"), o.getLong("mtime"))
        }
        return c
    }

    override fun isChildDocument(parentDocumentId: String, documentId: String): Boolean {
        val (pi, pp) = split(parentDocumentId)
        val (ci, cp) = split(documentId)
        return pi == ci && (pp.isEmpty() || cp == pp || cp.startsWith("$pp/"))
    }

    private class Fd(val id: String, val h: Long) : ProxyFileDescriptorCallback() {
        private fun fail(): Nothing = throw ErrnoException("giftkey", OsConstants.EIO)
        override fun onGetSize(): Long { val n = Native.vSize(id, h); if (n < 0) fail(); return n }
        override fun onRead(offset: Long, size: Int, data: ByteArray): Int {
            val n = Native.vRead(id, h, offset, data, minOf(size, data.size)); if (n < 0) fail(); return n
        }
        override fun onWrite(offset: Long, size: Int, data: ByteArray): Int {
            val n = Native.vWrite(id, h, offset, data, minOf(size, data.size)); if (n < 0) fail(); return n
        }
        override fun onFsync() { if (Native.vFlush(id, h) < 0) fail() }
        override fun onRelease() { Native.vClose(id, h) }
    }

    override fun openDocument(documentId: String, mode: String, signal: CancellationSignal?): ParcelFileDescriptor {
        val (id, path) = split(documentId)
        val write = mode.contains('w') || mode.contains('a')
        var flags = if (write) Native.OPEN_WRITE else 0
        if (mode.contains('t')) flags = flags or Native.OPEN_TRUNCATE
        val h = Native.vOpen(id, path, flags)
        if (h < 0) throw FileNotFoundException("cannot open ($h)")
        val sm = context!!.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        return sm.openProxyFileDescriptor(ParcelFileDescriptor.parseMode(mode), Fd(id, h), handler)
    }

    override fun createDocument(parentDocumentId: String, mimeType: String, displayName: String): String {
        val (id, dir) = split(parentDocumentId)
        val name = displayName.replace('/', '_')
        val path = if (dir.isEmpty()) name else "$dir/$name"
        val r = if (mimeType == Document.MIME_TYPE_DIR) {
            Native.vMkdir(id, path)
        } else {
            val h = Native.vOpen(id, path, Native.OPEN_WRITE or Native.OPEN_CREATE_NEW)
            if (h >= 0) { Native.vFlush(id, h); Native.vClose(id, h); 0 } else h
        }
        if (r < 0) throw FileNotFoundException("cannot create ($r)")
        notifyChildren(parentDocumentId)
        return docId(id, path)
    }

    override fun deleteDocument(documentId: String) {
        val (id, path) = split(documentId)
        if (path.isEmpty() || Native.vDelete(id, path) < 0) throw FileNotFoundException("cannot delete")
        notifyChildren(docId(id, path.substringBeforeLast('/', "")))
    }

    override fun renameDocument(documentId: String, displayName: String): String {
        val (id, path) = split(documentId)
        val parent = path.substringBeforeLast('/', "")
        val name = displayName.replace('/', '_')
        val to = if (parent.isEmpty()) name else "$parent/$name"
        if (path.isEmpty() || Native.vRename(id, path, to) < 0) throw FileNotFoundException("cannot rename")
        notifyChildren(docId(id, parent))
        return docId(id, to)
    }

    private fun notifyChildren(parentDocId: String) {
        context?.contentResolver?.notifyChange(DocumentsContract.buildChildDocumentsUri(AUTHORITY, parentDocId), null)
    }

    companion object {
        const val AUTHORITY = "com.giftkey.app.documents"
        private val ROOT_COLUMNS = arrayOf(Root.COLUMN_ROOT_ID, Root.COLUMN_DOCUMENT_ID, Root.COLUMN_TITLE, Root.COLUMN_SUMMARY, Root.COLUMN_FLAGS, Root.COLUMN_ICON)
        private val DOC_COLUMNS = arrayOf(Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE, Document.COLUMN_SIZE, Document.COLUMN_LAST_MODIFIED, Document.COLUMN_FLAGS)

        fun coreHome(ctx: Context): String = ctx.filesDir.resolve("gk").also { it.mkdirs() }.path
        fun vaultsDir(ctx: Context): String = ctx.filesDir.resolve("vaults").also { it.mkdirs() }.path

        fun notifyRoots(ctx: Context) {
            val uri: Uri = DocumentsContract.buildRootsUri(AUTHORITY)
            ctx.contentResolver.notifyChange(uri, null)
        }
    }
}
