package com.giftkey.app

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

/**
 * Android glue for import, restore and backup through content URIs. The decisions (name validation, exact byte counts,
 * verification, containment) live in Engines.kt and are unit-tested; this file only adapts Android APIs to those interfaces.
 */
class Transfer(private val ctx: Context) {
    private val cr: ContentResolver = ctx.contentResolver

    private class Pending(val tree: Uri, val recs: List<Rec>, val verified: Boolean)
    private val pending = HashMap<String, Pending>()

    // ------------------------------------------------------------------ adapters
    private inner class AndroidSource(val tree: Uri) : SourceTree {
        override val rootId: String = DocumentsContract.getTreeDocumentId(tree)
        override fun list(dirId: String): List<DocEntry>? = try {
            val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, dirId)
            val c = cr.query(uri, arrayOf(Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE, Document.COLUMN_SIZE), null, null, null)
            if (c == null) null else c.use {
                val out = ArrayList<DocEntry>()
                while (it.moveToNext()) out.add(DocEntry(it.getString(0), it.getString(1) ?: "", it.getString(2) == Document.MIME_TYPE_DIR, if (it.isNull(3)) -1 else it.getLong(3)))
                out
            }
        } catch (_: Exception) { null }
        override fun open(id: String): InputStream? = try { cr.openInputStream(DocumentsContract.buildDocumentUriUsingTree(tree, id)) } catch (_: Exception) { null }
    }

    private inner class AndroidSink(val tree: Uri) : SinkTree {
        override val rootId: String = DocumentsContract.getTreeDocumentId(tree)
        private fun uri(id: String) = DocumentsContract.buildDocumentUriUsingTree(tree, id)
        private fun make(parentId: String, mime: String, name: String): String? = try {
            val u = DocumentsContract.createDocument(cr, uri(parentId), mime, name)
            if (u == null) null
            else if (displayName(u) != name) { try { DocumentsContract.deleteDocument(cr, u) } catch (_: Exception) {}; null }   // provider renamed it to avoid a clash
            else DocumentsContract.getDocumentId(u)
        } catch (_: Exception) { null }
        override fun mkdir(parentId: String, name: String) = make(parentId, Document.MIME_TYPE_DIR, name)
        override fun create(parentId: String, name: String) = make(parentId, "application/octet-stream", name)
        override fun openOut(id: String): OutputStream? = try { cr.openOutputStream(uri(id), "wt") } catch (_: Exception) { null }
        override fun openIn(id: String): InputStream? = try { cr.openInputStream(uri(id)) } catch (_: Exception) { null }
    }

    private class NativeVault(val id: String) : VaultFiles {
        override fun list(dir: String): List<VEntry>? {
            val t = Native.vList(id, dir)
            if (t.startsWith("{")) return null
            return try {
                val a = JSONArray(t)
                (0 until a.length()).map { val o = a.getJSONObject(it); VEntry(o.getString("name"), o.getBoolean("dir"), o.getLong("size")) }
            } catch (_: Exception) { null }
        }
        override fun open(path: String, flags: Int) = Native.vOpen(id, path, flags)
        override fun read(h: Long, off: Long, buf: ByteArray, len: Int) = Native.vRead(id, h, off, buf, len)
        override fun write(h: Long, off: Long, buf: ByteArray, len: Int) = Native.vWrite(id, h, off, buf, len)
        override fun flush(h: Long) = Native.vFlush(id, h)
        override fun close(h: Long) = Native.vClose(id, h)
        override fun size(h: Long) = Native.vSize(id, h)
        override fun mkdir(path: String) = Native.vMkdir(id, path)
        override fun verify(path: String, size: Long, sha256: String) = Native.vVerify(id, path, size, sha256)
    }

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun fail(msg: String) = JSONObject().put("ok", false).put("error", msg).toString()
    private fun displayName(doc: Uri): String? =
        try { cr.query(doc, arrayOf(Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null } } catch (_: Exception) { null }

    private fun report(r: Report): JSONObject = JSONObject().apply {
        put("files", JSONArray(r.files.map { JSONObject().put("path", it.path).put("size", it.size).put("sha256", it.sha) }))
        put("bytes", r.bytes)
        put("errors", JSONArray(r.errors))
        put("skipped", JSONArray(r.skipped))
        put("verified", r.verified)
    }

    // ------------------------------------------------------------------ plain folder -> vault
    fun importTree(tree: Uri, name: String, hidden: Boolean): String {
        val add = JSONObject(Native.request(JSONObject().put("cmd", "add_folder").put("source", JSONObject.NULL).put("parent", GiftDocumentsProvider.vaultsDir(ctx)).put("name", name).put("hidden", hidden).toString()))
        if (!add.optBoolean("ok")) return add.toString()
        val id = add.getJSONObject("data").getString("id")
        val un = JSONObject(Native.request(JSONObject().put("cmd", "unlock").put("id", id).toString()))
        if (!un.optBoolean("ok")) return un.toString()
        val rep = try { ImportEngine(NativeVault(id)).run(AndroidSource(tree)) } catch (e: Exception) { Report().also { it.errors.add("import: ${e.message}") } }
        pending[id] = Pending(tree, rep.files.toList(), rep.verified)
        Native.request(JSONObject().put("cmd", "lock").put("id", id).toString())
        return JSONObject().put("ok", true).put("data", JSONObject().put("id", id).put("import", report(rep))).toString()
    }

    /** Deletes only originals whose bytes still match the hash recorded at import. Ordinary delete, not secure erasure. */
    fun deleteOriginals(id: String): String {
        val p = pending[id] ?: return fail("no verified import to clean up")
        if (!p.verified) return fail("the import was not verified: originals are kept")
        var deleted = 0
        val kept = JSONArray()
        for (r in p.recs) {
            val doc = DocumentsContract.buildDocumentUriUsingTree(p.tree, r.docId)
            val same = try { sha(cr.openInputStream(doc)) == r.sha } catch (_: Exception) { false }
            if (same && try { DocumentsContract.deleteDocument(cr, doc) } catch (_: Exception) { false }) deleted++ else kept.put(r.path)
        }
        pending.remove(id)
        return JSONObject().put("ok", true).put("data", JSONObject().put("deleted", deleted).put("kept", kept)
            .put("note", "Ordinary delete; this is not secure erasure on SSD or flash storage.")).toString()
    }

    private fun sha(ins: InputStream?): String {
        val md = MessageDigest.getInstance("SHA-256")
        (ins ?: throw IllegalStateException("cannot read")).use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) { val n = s.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        return hex(md.digest())
    }

    // ------------------------------------------------------------------ vault -> plain folder
    fun restoreTree(id: String, tree: Uri): String {
        val un = JSONObject(Native.request(JSONObject().put("cmd", "unlock").put("id", id).toString()))
        if (!un.optBoolean("ok")) return un.toString()
        val mark = { v: Boolean -> Native.request(JSONObject().put("cmd", "mark_restored").put("id", id).put("verified", v).toString()); Unit }
        val rep = RestoreEngine(NativeVault(id), mark).run(AndroidSink(tree))
        Native.request(JSONObject().put("cmd", "lock").put("id", id).toString())
        return JSONObject().put("ok", true).put("data", report(rep)).toString()
    }

    // ------------------------------------------------------------------ backups of the ENCRYPTED folder (ciphertext only)
    private fun cardDir(id: String): File? {
        val cards = JSONObject(Native.request("""{"cmd":"status"}""")).optJSONObject("data")?.optJSONArray("cards") ?: return null
        for (i in 0 until cards.length()) if (cards.getJSONObject(i).getString("id") == id) return File(cards.getJSONObject(i).getString("dir"))
        return null
    }

    /** Verified copy of the encrypted folder into the picked tree. The folder must be locked. */
    fun exportBackup(id: String, tree: Uri): String {
        if (Native.unlocked().contains(id)) return fail("lock the folder first, then make the backup")
        val src = cardDir(id) ?: return fail("unknown folder")
        val files = src.listFiles() ?: return fail("cannot read the encrypted folder")
        if (files.isEmpty() || files.any { it.isDirectory || !Names.VAULT_FILE.matches(it.name) }) return fail("the encrypted folder has unexpected content; no backup was made")
        val sink = AndroidSink(tree)
        val existing = AndroidSource(tree).list(sink.rootId) ?: return fail("cannot read the destination folder")
        if (existing.any { it.name == src.name }) return fail("the destination already contains ${src.name}")
        val root = sink.mkdir(sink.rootId, src.name) ?: return fail("cannot create the backup folder")
        val errors = ArrayList<String>()
        var bytes = 0L
        var count = 0
        for (f in files) {
            try {
                val doc = sink.create(root, f.name) ?: throw IllegalStateException("cannot create the file")
                val md = MessageDigest.getInstance("SHA-256")
                var n = 0L
                f.inputStream().use { ins -> (sink.openOut(doc) ?: throw IllegalStateException("cannot write")).use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) { val k = ins.read(buf); if (k < 0) break; md.update(buf, 0, k); out.write(buf, 0, k); n += k }
                    out.flush()
                } }
                if (n != f.length()) throw IllegalStateException("copied $n of ${f.length()} bytes")
                val back = sink.openIn(doc) ?: throw IllegalStateException("cannot re-read")
                var m = 0L
                val md2 = MessageDigest.getInstance("SHA-256")
                back.use { s -> val buf = ByteArray(64 * 1024); while (true) { val k = s.read(buf); if (k < 0) break; md2.update(buf, 0, k); m += k } }
                if (m != n || hex(md2.digest()) != hex(md.digest())) throw IllegalStateException("differs after copying")
                bytes += n; count++
            } catch (e: Exception) { errors.add("${f.name}: ${e.message}") }
        }
        val rep = JSONObject().put("dest", src.name).put("files", count).put("bytes", bytes).put("verified", errors.isEmpty() && count == files.size).put("errors", JSONArray(errors))
        return JSONObject().put("ok", true).put("data", JSONObject().put("report", rep)
            .put("note", "This is a copy of the ENCRYPTED folder. Keep it somewhere safe; the recovery code cannot recreate a folder file that was deleted.")).toString()
    }

    /** Restore a backup (or recover with a code) from a picked .gpv tree; the local copy is removed again if it is refused. */
    fun restoreOrRecover(tree: Uri, cmd: String, code: String?): String {
        val src = AndroidSource(tree)
        val name = displayName(DocumentsContract.buildDocumentUriUsingTree(tree, src.rootId)) ?: return fail("cannot read the folder name")
        if (!name.endsWith(".gpv")) return fail("pick the encrypted folder itself (its name ends in .gpv)")
        val vaults = File(GiftDocumentsProvider.vaultsDir(ctx))
        val dest = try { Names.contained(vaults, listOf(name)) } catch (e: Exception) { return fail(e.message ?: "bad folder name") }
        EncryptedCopy.run(src, dest)?.let { return fail(it) }
        val req = JSONObject().put("cmd", cmd).put("dir", dest.path)
        if (cmd == "recover_vault") req.put("code", code ?: "")
        val r = Native.request(req.toString())
        if (!JSONObject(r).optBoolean("ok")) dest.deleteRecursively()
        return r
    }
}
