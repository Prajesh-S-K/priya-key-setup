package com.giftkey.app

import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

/*
 * Transfer logic with NO Android dependencies, so it runs under plain JUnit with in-memory fakes (see EnginesTest).
 * Rules enforced here: every name from a folder provider is validated before use; reads must reach exactly the expected
 * size (a short or empty read is an error, never "the end"); the destination is re-read and compared in size and hash;
 * a failed directory listing is an error, never an empty folder; nothing is reported verified after any error.
 */

data class DocEntry(val id: String, val name: String, val isDir: Boolean, val size: Long /* -1 = unknown */)

interface SourceTree {
    val rootId: String
    /** null = the listing failed (null cursor, exception, permission); NEVER an empty list for a failure. */
    fun list(dirId: String): List<DocEntry>?
    fun open(id: String): InputStream?
}

interface SinkTree {
    val rootId: String
    fun mkdir(parentId: String, name: String): String?
    /** Must return null (and leave nothing behind) if the provider would rename the file to avoid a conflict. */
    fun create(parentId: String, name: String): String?
    fun openOut(id: String): OutputStream?
    fun openIn(id: String): InputStream?
}

data class VEntry(val name: String, val isDir: Boolean, val size: Long)

interface VaultFiles {
    /** null = failed (locked, error). */
    fun list(dir: String): List<VEntry>?
    fun open(path: String, flags: Int): Long
    fun read(h: Long, off: Long, buf: ByteArray, len: Int): Int
    fun write(h: Long, off: Long, buf: ByteArray, len: Int): Int
    fun flush(h: Long): Long
    fun close(h: Long): Long
    fun size(h: Long): Long
    fun mkdir(path: String): Long
    fun verify(path: String, size: Long, sha256: String): Long
}

data class Rec(val path: String, val docId: String, val size: Long, val sha: String)

class Report {
    val files = ArrayList<Rec>()
    val errors = ArrayList<String>()
    val skipped = ArrayList<String>()
    var verified = false
    val bytes get() = files.sumOf { it.size }
}

object Names {
    const val MAX_BYTES = 255
    const val MAX_DEPTH = 64
    const val MAX_ENTRIES = 200_000

    /** null = acceptable single path component; otherwise the reason it is refused. */
    fun problem(name: String): String? {
        if (name.isEmpty()) return "empty name"
        if (name == "." || name == "..") return "relative name"
        if (name.any { it == '/' || it == '\\' }) return "path separator in name"
        if (name.any { it.code < 0x20 || it.code == 0x7f }) return "control character in name"
        if (name.toByteArray(Charsets.UTF_8).size > MAX_BYTES) return "name too long"
        if (name.length >= 2 && name[1] == ':' && name[0].isLetter()) return "drive-letter name"
        return null
    }

    /** `base/comp` after validating each component, and proves the canonical result stays inside `base`. */
    fun contained(base: File, comps: List<String>): File {
        for (c in comps) problem(c)?.let { throw IllegalArgumentException("$it: '$c'") }
        var f = base
        for (c in comps) f = File(f, c)
        val root = base.canonicalFile.path + File.separator
        require(f.canonicalFile.path.startsWith(root)) { "path escapes the destination" }
        return f
    }

    val VAULT_FILE = Regex("^(vault\\.hdr\\.[AB]|journal-\\d{6}\\.log|data-\\d{6}\\.seg)$")
}

private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

/** Reads exactly to end of stream, hashing; returns (bytes, sha) and feeds each block to `sink`. */
private fun pump(ins: InputStream, chunk: Int, sink: (ByteArray, Int) -> Unit): Pair<Long, String> {
    val md = MessageDigest.getInstance("SHA-256")
    val buf = ByteArray(chunk)
    var total = 0L
    while (true) {
        val n = ins.read(buf)
        if (n < 0) break
        if (n == 0) continue
        md.update(buf, 0, n)
        sink(buf, n)
        total += n
    }
    return total to hex(md.digest())
}

private fun hashStream(ins: InputStream?, chunk: Int): Pair<Long, String>? =
    if (ins == null) null else try { ins.use { pump(it, chunk) { _, _ -> } } } catch (e: Exception) { null }

/** Source folder -> vault. */
class ImportEngine(private val vault: VaultFiles, private val chunk: Int = 64 * 1024) {
    private var entries = 0

    fun run(src: SourceTree): Report {
        val rep = Report()
        walk(src, src.rootId, "", 0, rep)
        rep.verified = rep.errors.isEmpty() && rep.files.all { vault.verify(it.path, it.size, it.sha) == 1L }
        return rep
    }

    private fun walk(src: SourceTree, dirId: String, rel: String, depth: Int, rep: Report) {
        if (depth > Names.MAX_DEPTH) { rep.errors.add("$rel: folders nested too deeply"); return }
        val list = src.list(dirId)
        if (list == null) { rep.errors.add("${rel.ifEmpty { "(top)" }}: cannot list the folder"); return }
        val seen = HashSet<String>()
        for (ch in list) {
            if (++entries > Names.MAX_ENTRIES) { rep.errors.add("too many entries"); return }
            val path = if (rel.isEmpty()) ch.name else "$rel/${ch.name}"
            val bad = Names.problem(ch.name)
            if (bad != null) { rep.errors.add("$path: refused ($bad)"); continue }
            if (!seen.add(ch.name)) { rep.errors.add("$path: duplicate name in the same folder"); continue }
            if (rel.isEmpty() && ch.name == ".gp") { rep.skipped.add(path); continue }
            if (ch.isDir) {
                if (vault.mkdir(path) < 0) rep.errors.add("$path: cannot create folder") else walk(src, ch.id, path, depth + 1, rep)
            } else try { rep.files.add(copyIn(src, path, ch)) } catch (e: Exception) { rep.errors.add("$path: ${e.message}") }
        }
    }

    private fun copyIn(src: SourceTree, path: String, ch: DocEntry): Rec {
        val h = vault.open(path, 1 or 8)   // write | create-new (same values as Native.OPEN_*)
        if (h < 0) throw IllegalStateException("cannot create ($h)")
        var off = 0L
        val (count, sha) = try {
            val ins = src.open(ch.id) ?: throw IllegalStateException("cannot read the original")
            val r = ins.use { s ->
                pump(s, chunk) { b, n ->
                    val w = vault.write(h, off, b, n)
                    if (w != n) throw IllegalStateException("write failed ($w)")
                    off += n
                }
            }
            if (ch.size >= 0 && r.first != ch.size) throw IllegalStateException("read ${r.first} of ${ch.size} bytes (incomplete)")
            if (vault.flush(h) < 0) throw IllegalStateException("save failed")
            if (vault.size(h) != r.first) throw IllegalStateException("stored size differs")
            r
        } finally {
            vault.close(h)
        }
        return Rec(path, ch.id, count, sha)
    }
}

/** Vault -> plain folder. Calls `markRestored` exactly once, with true only when EVERYTHING verified. */
class RestoreEngine(private val vault: VaultFiles, private val markRestored: (Boolean) -> Unit, private val chunk: Int = 64 * 1024) {
    private var entries = 0

    fun run(sink: SinkTree): Report {
        val rep = Report()
        try { walk(sink, "", sink.rootId, 0, rep) } catch (e: Exception) { rep.errors.add("restore: ${e.message}") }
        rep.verified = rep.errors.isEmpty() && rep.files.all { r -> verifyDest(sink, r) }
        markRestored(rep.verified)
        return rep
    }

    private fun verifyDest(sink: SinkTree, r: Rec): Boolean {
        val got = hashStream(sink.openIn(r.docId), chunk) ?: return false
        return got.first == r.size && got.second == r.sha && vault.verify(r.path, r.size, r.sha) == 1L
    }

    private fun walk(sink: SinkTree, dir: String, parentId: String, depth: Int, rep: Report) {
        if (depth > Names.MAX_DEPTH) { rep.errors.add("$dir: folders nested too deeply"); return }
        val list = vault.list(dir)
        if (list == null) { rep.errors.add("${dir.ifEmpty { "(top)" }}: cannot list the encrypted folder"); return }
        val seen = HashSet<String>()
        for (e in list) {
            if (++entries > Names.MAX_ENTRIES) { rep.errors.add("too many entries"); return }
            val path = if (dir.isEmpty()) e.name else "$dir/${e.name}"
            if (dir.isEmpty() && e.name == ".gp") continue
            val bad = Names.problem(e.name)
            if (bad != null) { rep.errors.add("$path: refused ($bad)"); continue }
            if (!seen.add(e.name)) { rep.errors.add("$path: duplicate name"); continue }
            if (e.isDir) {
                val id = sink.mkdir(parentId, e.name)
                if (id == null) rep.errors.add("$path: cannot create folder") else walk(sink, path, id, depth + 1, rep)
            } else try { rep.files.add(copyOut(sink, path, e, parentId)) } catch (x: Exception) { rep.errors.add("$path: ${x.message}") }
        }
    }

    private fun copyOut(sink: SinkTree, path: String, e: VEntry, parentId: String): Rec {
        val size = e.size
        val h = vault.open(path, 0)
        if (h < 0) throw IllegalStateException("cannot open ($h)")
        try {
            val doc = sink.create(parentId, e.name) ?: throw IllegalStateException("cannot create the file")
            val md = MessageDigest.getInstance("SHA-256")
            val out = sink.openOut(doc) ?: throw IllegalStateException("cannot write")
            val buf = ByteArray(chunk)
            var off = 0L
            out.use { o ->
                while (off < size) {
                    val want = minOf(buf.size.toLong(), size - off).toInt()
                    val n = vault.read(h, off, buf, want)
                    if (n < 0) throw IllegalStateException("read failed ($n)")
                    if (n == 0) throw IllegalStateException("premature end of file at $off of $size bytes")
                    md.update(buf, 0, n)
                    o.write(buf, 0, n)
                    off += n
                }
                o.flush()
            }
            if (off != size) throw IllegalStateException("copied $off of $size bytes")
            if (vault.size(h) != size) throw IllegalStateException("file changed while copying")
            return Rec(path, doc, size, hex(md.digest()))
        } finally {
            vault.close(h)
        }
    }
}

/** A picked encrypted folder (.gpv) -> a fresh staging directory, with whole-tree validation before anything is created. */
object EncryptedCopy {
    fun run(src: SourceTree, dest: File, chunk: Int = 64 * 1024): String? {
        // phase 1: enumerate and validate everything; nothing is created yet
        val list = src.list(src.rootId) ?: return "cannot read the folder"
        if (list.isEmpty()) return "the folder is empty"
        if (list.size > 64) return "too many entries for an encrypted folder"
        val seen = HashSet<String>()
        for (e in list) {
            Names.problem(e.name)?.let { return "refused '${e.name}': $it" }
            if (e.isDir) return "unexpected sub-folder '${e.name}'"
            if (!Names.VAULT_FILE.matches(e.name)) return "unexpected entry '${e.name}'"
            if (!seen.add(e.name)) return "duplicate entry '${e.name}'"
        }
        if (!seen.contains("vault.hdr.A") && !seen.contains("vault.hdr.B")) return "this is not an encrypted Priya Key folder"
        if (dest.exists()) return "a folder with this name already exists"
        val targets = try { list.associateWith { Names.contained(dest, listOf(it.name)) } } catch (e: Exception) { return e.message }
        // phase 2: copy and verify
        try {
            if (!dest.mkdirs()) return "cannot create the staging folder"
            for ((e, f) in targets) {
                val ins = src.open(e.id) ?: throw IllegalStateException("cannot read ${e.name}")
                val (n, sha) = java.io.FileOutputStream(f).use { o ->
                    ins.use { s -> pump(s, chunk) { b, k -> o.write(b, 0, k) } }.also { o.flush(); o.fd.sync() }
                }
                if (e.size >= 0 && n != e.size) throw IllegalStateException("${e.name}: read $n of ${e.size} bytes (incomplete)")
                val back = hashStream(f.inputStream(), chunk)
                if (back == null || back.first != n || back.second != sha) throw IllegalStateException("${e.name} differs after copying")
            }
            return null
        } catch (e: Exception) {
            dest.deleteRecursively()   // only the staging directory this call created
            return e.message ?: "copy failed"
        }
    }
}
