package com.giftkey.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder

/**
 * Foreground service (type connectedDevice) that keeps the board session alive while a folder is unlocked: heartbeats
 * every 500 ms via the core, USB loss handling, and roots-changed notifications for the file picker.
 */
class KeyService : Service() {
    @Volatile private var running = false
    private var last = ""
    private var hadBoard = false

    /** The key is gone (detach broadcast or dead port): lock happens in the core; here the UI side is cleaned up. */
    private fun keyLost() {
        UsbController.disconnect()
        GiftDocumentsProvider.notifyRoots(applicationContext)   // provider roots disappear with the lock
        if (Native.isDiscreet()) {
            // Discreet mode (explicit setting): close the dashboard so nothing stays on screen or in recents.
            sendBroadcast(Intent(ACTION_CONCEAL).setPackage(packageName))
        }
    }

    private val detachReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { if (i.action == android.hardware.usb.UsbManager.ACTION_USB_DEVICE_DETACHED) keyLost() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_LOCK) {
            Native.request("""{"cmd":"lock_all"}""")
            GiftDocumentsProvider.notifyRoots(applicationContext)
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("key", "Board connection", NotificationManager.IMPORTANCE_LOW))
        val open = android.app.PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), android.app.PendingIntent.FLAG_IMMUTABLE)
        val lock = android.app.PendingIntent.getService(this, 1, Intent(this, KeyService::class.java).setAction(ACTION_LOCK), android.app.PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "key")
            .setContentTitle("Priya Key")
            .setContentText("Key connected. Folders lock when it is unplugged.")
            .setSmallIcon(R.drawable.ic_notify)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Lock all", lock).build())
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        running = true
        registerReceiver(detachReceiver, android.content.IntentFilter(android.hardware.usb.UsbManager.ACTION_USB_DEVICE_DETACHED), Context.RECEIVER_EXPORTED)
        Thread {
            while (running) {
                try {
                    Native.tick()
                    val present = UsbController.isConnected() && UsbController.findDevice(applicationContext) != null
                    if (hadBoard && !present) keyLost()      // covers a missed broadcast and a port that died under us
                    hadBoard = present
                    UsbController.reapIfDead()
                    val now = Native.unlocked()
                    if (now != last) {
                        last = now
                        GiftDocumentsProvider.notifyRoots(applicationContext)
                    }
                    if (!UsbController.isConnected() && now == "[]") {
                        // board gone and everything locked: nothing left to keep alive
                        running = false
                    }
                } catch (_: Throwable) {}
                try { Thread.sleep(500) } catch (_: InterruptedException) {}
            }
            try { unregisterReceiver(detachReceiver) } catch (_: Exception) {}
            stopForeground(STOP_FOREGROUND_REMOVE)   // nothing connection-related keeps running while the key is away
            stopSelf()
        }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    companion object {
        const val ACTION_LOCK = "com.giftkey.app.LOCK"
        const val ACTION_CONCEAL = "com.giftkey.app.CONCEAL"
        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, KeyService::class.java))
        }
    }
}
