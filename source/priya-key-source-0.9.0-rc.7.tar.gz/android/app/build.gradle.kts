import java.util.Properties

val versionText = rootProject.file("../VERSION").readText().trim()   // e.g. 0.9.0-rc.1
val vm = Regex("""(\d+)\.(\d+)\.(\d+)(?:-rc\.(\d+))?""").matchEntire(versionText) ?: error("bad VERSION: $versionText")
val vcode = vm.groupValues[1].toInt() * 1_000_000 + vm.groupValues[2].toInt() * 10_000 + vm.groupValues[3].toInt() * 100 + (vm.groupValues[4].ifEmpty { "99" }).toInt()

plugins { id("com.android.application") }

val ksProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "com.giftkey.app"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.giftkey.app"
        minSdk = 30            // Android 11 baseline
        targetSdk = 36
        versionCode = vcode
        versionName = versionText
    }
    signingConfigs {
        if (ksProps.isNotEmpty()) create("release") {
            storeFile = rootProject.file(ksProps.getProperty("storeFile"))
            storePassword = ksProps.getProperty("storePassword")
            keyAlias = ksProps.getProperty("keyAlias")
            keyPassword = ksProps.getProperty("keyPassword")
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            if (ksProps.isNotEmpty()) signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging { jniLibs { useLegacyPackaging = false } }
}

dependencies {
    implementation("com.github.mik3y:usb-serial-for-android:3.9.0")
    testImplementation("junit:junit:4.13.2")
}

// The dashboard is the same single page the Windows app embeds.
val copyDashboard by tasks.registering(Copy::class) {
    from(rootProject.file("../dashboard/index.html"))
    into(layout.projectDirectory.dir("src/main/assets"))
}
tasks.named("preBuild") { dependsOn(copyDashboard) }
