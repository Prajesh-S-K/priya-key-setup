# gifts-priya — ESP32 Hardware Key for Encrypted Folders

A personal gift project: a basic 30-pin ESP32 dev board, connected by USB cable, acts as the physical key that unlocks encrypted folders on a Windows 11 PC or an Android 11+ phone. Files stay on the host. The host encrypts and decrypts; file contents never pass through the ESP32.

## Current status

**Phase 01 — architecture and feasibility, documentation only. Revision 4 (2026-10-19).**
Nothing is implemented. No firmware has been written, built, or flashed. No code has been run on Windows, on an Android phone, or on the ESP32. No real folders have been touched. The on-disk vault format is **not frozen**; it is frozen only after crash-recovery review (milestone M4g). M0 is partial: the USB bridge enumerated (VID:PID 1A86:7523, CH340 family, variant unconfirmed; read-only, port not opened). Module variant, flash size and chip revision are unknown. Windows 11 is the primary target, Windows 10 a target pending verification, Android 11+ the baseline. No Windows machine or Android phone is confirmed, and no compatibility is claimed. Two review items remain open: interrupted pairing confirmation and checkpoint/garbage-collection safety. Read the labels:

| Label | Meaning |
|---|---|
| **DOC-VERIFIED** | Stated by an official document or primary source that was read during this phase (link given). |
| **PROPOSED** | Our design decision or estimate. Not tested. |
| **DOC-NOT-YET-VERIFIED** | Depends on a document, spec, license text or API page we have not read. Reading it resolves the item. |
| **RUNTIME-TEST** | Can be settled only by running something: the board, Windows, a phone, an editor, a library build. |

## Documents

| File | Content |
|---|---|
| [docs/requirements.md](docs/requirements.md) | Our requirements as a checklist, kept separate from suggestions found in reference material, plus limitations and acceptance criteria |
| [docs/architecture.md](docs/architecture.md) | Trust boundaries, authentication, key lifecycle, recovery, storage format, save and lock semantics, dashboard delivery, per-component stack |
| [docs/hardware-checklist.md](docs/hardware-checklist.md) | What we must learn about the board and the phone, and how to learn it safely |
| [docs/milestones.md](docs/milestones.md) | Risk-first staged plan with concrete pass/fail tests |
| [reports/m1-preparation.md](reports/m1-preparation.md) | M1 preparation: protocol, firmware build record, tests, proposed board sequence (nothing run on the board) |
| [reports/pre-m1-readiness.md](reports/pre-m1-readiness.md) | Pre-M1 readiness: primary-source findings, toolchain inventory and plan, M1 build/test sequence, proposed identification and flashing commands (none executed) |
| [reports/m0-hardware-identification.md](reports/m0-hardware-identification.md) | M0 observations (partial) |
| [reports/phase-01-feasibility.md](reports/phase-01-feasibility.md) | Findings with evidence, unresolved questions, review checklist |

## Product summary

1. Plug in the ESP32, open the companion dashboard (auto-launch is best-effort and OS-restricted).
2. Skippable futuristic HUD startup animation, then a four-digit PIN screen.
3. After authentication: cards for protected folders (Locked, Locked · Hidden, Unlocked, Saving).
4. Add, encrypt, lock, unlock, change visibility, and permanently remove encryption. Change PIN. Set up a separate offline recovery secret.
5. Browse and preview inside the dashboard. External apps may edit and save while a session is unlocked.
6. BOOT button is a privacy button (first press locks and stops service, second press restores service and requires the PIN again). Unplugging also locks.

## Hard constraints that shape the design

- Classic ESP32 board, no ESP32-S3 and no extra hardware without discussion.
- No Wi-Fi or internet service needed. The USB data cable is the authentication link.
- Hiding is presentation, not security.
- No secure-erase claims on flash. No continuous hardware enforcement claimed against a compromised host.
- No eFuse burning, no permanent debug disable, no irreversible security setting during development.

## Next step

Wait for the architecture review. No milestone is started until then.

## Build and status (2026-10-19)

| Part | Status |
|---|---|
| ESP32 firmware (PIN, delays, pairing, privacy button, key release) | RUNTIME-TEST passed on the board (M2) |
| Vault format, journal, recovery, import/restore verification | Tested on the Mac, including fault sweeps |
| Windows app (WinFsp drive + WebView2 dashboard) and installer | Built on the Mac; **acceptance tests pending** (no Windows PC yet) |
| Android app (USB, DocumentsProvider, dashboard) and signed APK | Built on the Mac; **acceptance tests pending** (no phone yet) |
| Board-stored dashboard assets | Not implemented; the dashboard is bundled in both apps (needs a firmware change and your approval to flash) |

Build: `tools/build_installer.sh` (dist/windows/GiftKey-Setup.exe), `tools/build_apk.sh` (dist/android/GiftKey.apk). Details and limitations: [reports/m3-m4-result.md](reports/m3-m4-result.md). Licence: GPL-3.0-or-later ([LICENSE](LICENSE)).
