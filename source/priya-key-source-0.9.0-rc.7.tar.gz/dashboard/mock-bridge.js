// Development-only bridge: simulates the native host so the dashboard can be viewed in a normal browser.
(function(){
  let st={paired:true,authenticated:false,device:'Locked',recovery:true,cards:[{id:'a1',name:'Taxes 2025',hidden:false,state:'Locked',dir:'C:/Users/priya/3f9a21c4.gpv'},{id:'b2',name:'Family photos',hidden:true,state:'Locked · Hidden',dir:'D:/Backup/9b02ee17.gpv'},{id:'c3',name:'Passport scans',hidden:false,state:'Locked',dir:'E:/Docs/55aa01d9.gpv'},{id:'d4',name:'Love letters',hidden:true,state:'Locked · Hidden',dir:'C:/Users/priya/Desktop/0c7d4b3a.gpv'}],hidden_count:2};
  const files={'':[{name:'docs',dir:true,size:0},{name:'readme.txt',dir:false,size:1600},{name:'pic.png',dir:false,size:70}],docs:[{name:'notes.md',dir:false,size:19}]};
  const png='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==';
  let wrong=0;
  const P=new URLSearchParams(location.search).get('p')||'windows';
  window.__gpNative=async(n,a)=>{const x=JSON.parse(a);
    if(n==='capabilities')return P==='android'?{platform:'android',backup:true,open_path:true,battery:true}:P==='none'?null:{platform:'windows',backup:true,open_path:true,autostart:true};
    if(n==='setup_status'&&P==='android')return [{id:'usb',label:'USB access for the key',ok:true,detail:'Granted'},{id:'notif',label:'Notifications',ok:false,detail:'Needed to show that the key is connected.',action:'notifications',action_label:'Allow'},{id:'bat',label:'Unrestricted background use',ok:false,detail:'Recommended so Android does not stop the connection.',action:'battery',action_label:'Open settings'}];
    if(n==='autostart_get')return false;if(n==='autostart_set')return true;if(n==='pick_folder')return 'C:/Users/priya/Documents/Example';if(n==='confirm')return true;if(n==='prompt')return 'Renamed';return null};
  window.__gpBridge=async(s)=>{const r=JSON.parse(s),o=d=>JSON.stringify({ok:true,data:d});
    switch(r.cmd){
      case 'status':{const vis=st.cards.filter(c=>st.authenticated);return o({device:st.authenticated?'Active':'Locked',paired:st.paired,authenticated:st.authenticated,recovery:st.recovery,cards:st.authenticated?st.cards:[]})}
      case 'events':return o({events:[]});
      case 'auth':if(r.pin==='1234'){st.authenticated=true;return o({result:'ok'})}wrong++;return o({result:'wrong_pin',delay_ms:wrong>3?5000:0});
      case 'lock_all':st.authenticated=false;return o({});
      case 'unlock':st.cards.find(c=>c.id===r.id).state='Unlocked';return o({});
      case 'lock':{const c=st.cards.find(c=>c.id===r.id);c.state=c.hidden?'Locked · Hidden':'Locked';return o({})}
      case 'set_hidden':{const c=st.cards.find(c=>c.id===r.id);c.hidden=r.hidden;c.state=c.state==='Unlocked'?'Unlocked':(r.hidden?'Locked · Hidden':'Locked');return o({})}
      case 'browse':return o({entries:files[r.path]||[]});
      case 'preview':return r.path.endsWith('png')?o({kind:'image',mime:'image/png',size:70,base64:png}):o({kind:'text',mime:'text/plain',size:19,text:'# disposable\nhello from the vault\n'});
      case 'add_folder':return o({id:'n'+Date.now(),import:{files:[{path:'a',size:1,sha256:''}],bytes:1234,errors:[],skipped:[],verified:true}});
      case 'setup_recovery':case 'rotate_recovery':return o({code:'7K2M-9QXA-D4TR-1VHB-N6WE-PZ03-8YCG-F5JS-KT2D-WA71-9MXH-4EQ6-B'});
      case 'export_vault':return o({report:{dest:'x',files:5,bytes:4096,verified:true,errors:[]},note:'This is a copy of the ENCRYPTED folder.'});
      case 'restore_backup':return o({id:'z9'});
      default:return o({});
    }};
})();
