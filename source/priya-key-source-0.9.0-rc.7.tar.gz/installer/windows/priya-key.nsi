; Priya Key Windows installer (NSIS). Built on macOS by tools/build_installer.sh with /DVERSION=... /DOUT=...
; Release candidate: not yet run on Windows.
Unicode true
!ifndef VERSION
  !define VERSION "0.0.0"
!endif
!ifndef NUMVER
  !define NUMVER "0.0.0.0"
!endif
!define APP "Priya Key"
!define EXE "priya-key.exe"
!define REGUN "Software\Microsoft\Windows\CurrentVersion\Uninstall\PriyaKey"
Name "${APP} ${VERSION}"
OutFile "${OUT}"
InstallDir "$PROGRAMFILES64\PriyaKey"
InstallDirRegKey HKLM "Software\PriyaKey" "InstallDir"
RequestExecutionLevel admin
SetCompressor /SOLID lzma
Icon "..\..\brand\icon.ico"
UninstallIcon "..\..\brand\icon.ico"
VIProductVersion "${NUMVER}"
VIAddVersionKey "ProductName" "${APP}"
VIAddVersionKey "FileDescription" "${APP} installer (release candidate)"
VIAddVersionKey "FileVersion" "${VERSION}"
VIAddVersionKey "LegalCopyright" "GPL-3.0-or-later"

!include "MUI2.nsh"
!include "LogicLib.nsh"
!define MUI_ICON "..\..\brand\icon.ico"
!define MUI_UNICON "..\..\brand\icon.ico"
!insertmacro MUI_PAGE_LICENSE "..\..\LICENSE"
!insertmacro MUI_PAGE_COMPONENTS
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

Section "Priya Key (required)" SecMain
  SectionIn RO
  ; Upgrade: close a running copy first (this locks every folder and removes its drives).
  nsExec::Exec 'taskkill /IM ${EXE} /F'
  Sleep 800
  SetOutPath "$INSTDIR"
  File "/oname=${EXE}" "..\..\dist\windows\${EXE}"
  File "..\..\LICENSE"
  File "/oname=priya-key.ico" "..\..\brand\icon.ico"
  File "..\..\VERSION"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  WriteRegStr HKLM "Software\PriyaKey" "InstallDir" "$INSTDIR"
  CreateDirectory "$SMPROGRAMS\${APP}"
  CreateShortcut "$SMPROGRAMS\${APP}\${APP}.lnk" "$INSTDIR\${EXE}" "" "$INSTDIR\priya-key.ico"
  WriteRegStr HKLM "${REGUN}" "DisplayName" "${APP}"
  WriteRegStr HKLM "${REGUN}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKLM "${REGUN}" "DisplayIcon" "$INSTDIR\priya-key.ico"
  WriteRegStr HKLM "${REGUN}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegStr HKLM "${REGUN}" "Publisher" "Personal project"
  WriteRegDWORD HKLM "${REGUN}" "NoModify" 1

  ; --- WinFsp (drive support). Installed from the bundled MSI when it is not already present.
  SetRegView 64
  ReadRegStr $0 HKLM "SOFTWARE\WinFsp" "InstallDir"
  ${If} $0 == ""
    SetRegView 32
    ReadRegStr $0 HKLM "SOFTWARE\WinFsp" "InstallDir"
  ${EndIf}
  SetRegView 64
  ${If} $0 == ""
    SetOutPath "$PLUGINSDIR"
    File "/oname=winfsp.msi" "..\..\dist\windows\redist\winfsp.msi"
    ExecWait 'msiexec /i "$PLUGINSDIR\winfsp.msi" /qb /norestart' $1
    ${If} $1 != 0
    ${AndIf} $1 != 3010
      MessageBox MB_ICONEXCLAMATION "WinFsp could not be installed (code $1). Priya Key needs it to show unlocked folders as a drive. Install it from https://winfsp.dev and start Priya Key again."
    ${EndIf}
  ${EndIf}

  ; --- WebView2 runtime (the dashboard window). Present on Windows 11 and updated Windows 10.
  ReadRegStr $2 HKLM "SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" "pv"
  ${If} $2 == ""
    ReadRegStr $2 HKCU "Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" "pv"
  ${EndIf}
  ${If} $2 == ""
    ${If} ${FileExists} "$EXEDIR\redist\MicrosoftEdgeWebView2RuntimeInstallerX64.exe"
      ExecWait '"$EXEDIR\redist\MicrosoftEdgeWebView2RuntimeInstallerX64.exe" /silent /install' $3
    ${Else}
      MessageBox MB_ICONEXCLAMATION "The Microsoft WebView2 runtime is not installed and its installer was not found next to this setup file (folder 'redist'). Install it from https://developer.microsoft.com/microsoft-edge/webview2/ and start Priya Key again."
    ${EndIf}
  ${EndIf}
SectionEnd

Section /o "Start Priya Key with Windows (in the tray)" SecAuto
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "PriyaKey" '"$INSTDIR\${EXE}" --tray'
SectionEnd

Section /o "Desktop shortcut (optional)" SecDesk
  CreateShortcut "$DESKTOP\${APP}.lnk" "$INSTDIR\${EXE}" "" "$INSTDIR\priya-key.ico"
SectionEnd

Section "Uninstall"
  nsExec::Exec 'taskkill /IM ${EXE} /F'
  Sleep 500
  Delete "$INSTDIR\${EXE}"
  Delete "$INSTDIR\LICENSE"
  Delete "$INSTDIR\VERSION"
  Delete "$INSTDIR\priya-key.ico"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR"
  Delete "$DESKTOP\${APP}.lnk"
  Delete "$SMPROGRAMS\${APP}\${APP}.lnk"
  RMDir "$SMPROGRAMS\${APP}"
  DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "PriyaKey"
  DeleteRegKey HKLM "${REGUN}"
  DeleteRegKey HKLM "Software\PriyaKey"
  ; NOT removed: %APPDATA%\PriyaKey (pairing record, folder list) and every encrypted folder you created. WinFsp stays installed.
  MessageBox MB_ICONINFORMATION "Priya Key was removed. Your encrypted folders and the settings in %APPDATA%\PriyaKey were NOT deleted. Delete the encrypted folders yourself only if you are sure you will never need them."
SectionEnd
